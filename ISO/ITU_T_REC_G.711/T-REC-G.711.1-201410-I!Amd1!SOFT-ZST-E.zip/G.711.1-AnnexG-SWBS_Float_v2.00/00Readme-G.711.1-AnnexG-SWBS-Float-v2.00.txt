===============================================================================
   ITU-T G.711.1 Annex G (ex G.711.1-SWBS-Float) Source Code
   (C) 2014 France Telecom, Huawei Technologies
 
   Software Release 2.00 (2012-09) (version renumbered from 1.01 for 
   consistency with G.711.1 2nd edition).

   NB - The version numbers inside the .c and .h files have NOT been changed!

===============================================================================


These files represent the ITU-T G.711.1-SWBS Coder Floating-Point C simulation.
All code is written in ANSI-C.  The coder is implemented as two separate programs:

        encoder -stereo -c [coreflag] [-options] <infile> <codefile> [rate]
        decoder -stereo -c [coreflag] [-options] <codefile> <outfile> [rate] 
	

                            FILE FORMATS:
                            =============

The file format of the supplied binary data is 16-bit binary data which is
read and written in 16 bit little-endian words.
The data is therefore platform DEPENDENT.

The bitstream follows the ITU-T G.192 format. For every 5-ms input speech frame,
the bitstream contains the following data:

	Word16 SyncWord
	Word16 DataLen
	Word16 1st Databit
	Word16 2nd DataBit
	.
	.
	.
	Word16 Nth DataBit

with N = DataLen
Each bit is presented as follows: Bit 0 = 0x007f, Bit 1 = 0x0081.

The SyncWord from the encoder is always 0x6b21. The SyncWord 0x6b20, on decoder side, 
indicates that the current frame was received in error (frame erasure).

The DataLen parameter gives the number of speech data bits in the frame. 


			INSTALLING THE SOFTWARE
			=======================

Installing the software on the PC:

The package includes a Visual C++ 2008 solution. 

This code has been successfully compiled and run on the following
platforms:
 
Platform                   Operating System      Compiler
-----------------------------------------------------------------------------
PC                         Windows 7             Visual C++ 2008 Express Edition


                       RUNNING THE SOFTWARE
                       ====================
The command line for the WB stereo encoder is as follows:

encoder -stereo -wb -c [coreflag] [-options] <infile> <codefile> [rate]

where
        rate            is the desired encoding bitrate in kbit/s: either  96 or 128 (96 for R3ws or 128 for R5*ws)
        infile          is the name of the input file to be encoded
        codefile        is the name of the output bitstream file
        -c [coreflag]   coreflag is the core indicator: 1a, 1u, 1as and 1us for 80 kbit/s a law core, 80 kbit/s u law core, 96 kbit/s a law core and 96 kbit/s u law core respectively
Options:
        -quiet          quiet processing


The command line for the SWB stereo encoder is as follows:

encoder -stereo -c [coreflag] [-options] <infile> <codefile> [rate]

where
        rate            is the desired encoding bitrate in kbit/s: (112 for R4ss, 128 for R5ss,144 for R6ss or R6*ss, 160 for R7*ss )
        infile          is the name of the input file to be encoded
        codefile        is the name of the output bitstream file
        -c [coreflag]   coreflag is the core indicator: 1a, 1u, 1as and 1us for 80 kbit/s a law core, 80 kbit/s u law core, 96 kbit/s a law core and 96 kbit/s u law core respectively
Options:
        -quiet          quiet processing


The command line for the WB and SWB stereo decoder are the same, as follows:

decoder -stereo -c [coreflag] [-options]  <codefile> <outfile> [rate] -

where
        rate            is the desired decoding bitrate in kbit/s: 96 for R3ws,112 for R4ss,128 for R5*ws or R5ss, 144 for R6ss or R6*ss,160 for R7*ss 
        codefile        is the name of the input bitstream file
        outfile         is the name of the decoded output file
        -c [coreflag]   coreflag is the core indicator: 1a, 1u, 1as and 1us for 80 kbit/s a law core, 80 kbit/s u law core, 96 kbit/s a law core and 96 kbit/s u law core respectively
Options:	
        -quiet          quiet processing
        -bitrateswitch [bsflag]        bsflag is 1 for G.711.1 core at 80kbit/s and 0 for G.711.1 core at 96 kbit/s

The encoder input and the decoder output files are sampled data files containing 
16-bit PCM signals. The encoder output and decoder input files follow the ITU-T 
G.192 bitstream format.

