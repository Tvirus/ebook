/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: lowband.h
 *  Function: Header of lower-band encoder and decoder
 *------------------------------------------------------------------------
 */

#ifndef LOWBAND_H
#define LOWBAND_H


#define  ALAW_DEADZONE   11  /* Quantizer dead zone around zero (to minimize crackling) */
#define  MULAW_DEADZONE  7   /* Quantizer dead zone around zero (to minimize crackling) */
#define  ALAW_OFFSET     8   /* A-law offset to enable a zero output (0 = disable) */

#define  G711ULAW        1
#define  G711ALAW        2

/* Noise shaping parameters */

#define L_WINDOW         80     /* length of the LP analysis */
#define ORD_M            4      /* LP order (and # of "lags" in autocorr.c)  */

#define ORD_MP1          5      /* LP order + 1  */

#define GAMMA1           30147  /* 0.92f in Q15 */
#define GAMMA1f          0.92f  /* 0.92f in Q15 */
#define MAX_NORM         16     /* when to begin noise shaping deactivation  */
                                /* use MAX_NORM = 32 to disable this feature */


void    *lowband_encode_const (Short);
void    lowband_encode_dest (void*);
void    lowband_encode_reset (void*);
void    lowband_encode (const Float*, unsigned char*, unsigned char*, void*);
void    lbe_bitalloc( Short* expi, Short* bit_alloc );


void    *lowband_decode_const (int);
void    lowband_decode_dest (void*);
void    lowband_decode_reset (void*);
void    lowband_decode( const unsigned char*, const unsigned char*, 
                        int, Float*, Float*, void*, Float* );


Short   AutocorrNS( Float x[], Float r[] );


/* Tables used in AutocorrNS() */
extern const Float NS_windowf[L_WINDOW];
extern const Float NS_lag_f[ORD_M];

#endif
