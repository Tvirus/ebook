/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: g711.h
 *  Function: Header of embedded lower-band PCM coders
 *------------------------------------------------------------------------
 */

#ifndef G711_H
#define G711_H

Short convertLin_ALaw(Short x, Short *ind2, Short *xq, Short* expo);
Short convertLin_MuLaw(Short x, Short *ind2, Short *xq, Short* expo);

Short convertALaw_Lin(Short ind, Short *expo, Short* signo);
Short convertALaw_Lin_enh(Short code2, Short exp, Short sign, Short numbits);
Short convertMuLaw_Lin(Short ind, Short *expo, Short* signo);
Short convertMuLaw_Lin_enh(Short code2, Short exp, Short sign, Short numbits);

#endif
