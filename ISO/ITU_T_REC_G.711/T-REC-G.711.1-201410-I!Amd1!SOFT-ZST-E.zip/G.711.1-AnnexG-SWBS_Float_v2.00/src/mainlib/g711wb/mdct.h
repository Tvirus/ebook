/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: MDCT headers
 *------------------------------------------------------------------------
 */

#ifndef MDCT_H
#define MDCT_H

#include <stdio.h>
#include "fec_highband.h"
#ifdef LAYER_STEREO
#include "defines_mdct.h"
#endif

/* Functions : */
void f_mdct_point80(
  Float * f_mem,        /* (i): old input samples    */
  Float * f_input,      /* (i): input samples        */
  Float * f_ykr         /* (o): MDCT coefficients    */
);


void f_inv_mdct_point80(
  Float * xr,         /* (o):   output samples                     */
  Float * ykq,        /* (i):   MDCT coefficients                  */
  Float * ycim1,      /* (i):   previous MDCT memory               */
  Short   loss_flag,  /* (i):   packet-loss flag                   */
  Float * cur_save,   /* (i/o): signal saving buffer               */
  HBFEC_State * st    /* (i/o): work space for HB FERC             */ 	
);

void f_mdct ( Float *mem, Float *input, Float *ykr );
void f_inv_mdct ( Float  *xr, Float  *ykq, Float  *ycim1, Short  loss_flag, Float  *cur_save, HBFEC_State  *st );


/* Tables : */
extern const Float MDCT_hf[MDCT_L_WIN];
extern const Float MDCT_wcosf[MDCT_L_WIN4];
extern const Float MDCT_wsinf[MDCT_L_WIN4];
extern const Float MDCT_wetrf[MDCT_L_WIN4];
extern const Float MDCT_wetif[MDCT_L_WIN4];
extern const Float MDCT_wetrm1f[MDCT_L_WIN4];
extern const Float MDCT_wetim1f[MDCT_L_WIN4];

extern const Float MDCT_h_swbf[MDCT2_L_WIN2];
extern const Float MDCT_wsin_swbf[MDCT2_L_WIN4+1];
extern const Float MDCT_wetr_swbf[MDCT2_L_WIN4];
extern const Float MDCT_weti_swbf[MDCT2_L_WIN4];
extern const Float MDCT_rw1_tbl_swbf[MDCT2_SBARYSZ];  
extern const Float MDCT_rw2_tbl_swbf[MDCT2_SBARYSZ];  
extern const Float MDCT_wetrm1_swbf[MDCT2_L_WIN4];
extern const Float MDCT_wetim1_swbf[MDCT2_L_WIN4];

extern const Short MDCT_tab_rev_ipp_swbs[MDCT2_EXP_NB_REV];
extern const Short MDCT_tab_rev_i_swbs[MDCT2_EXP_NB_REV];
extern const Short MDCT_tab_map_swbs[MDCT2_NP*MDCT2_NPP];
extern const Short MDCT_tab_map2_swbs[MDCT2_NP*MDCT2_NPP];
 


#endif /* MDCT_H */
