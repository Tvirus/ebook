/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: lpctool.h
 *  Function: Header of linear prediction tools
 *------------------------------------------------------------------------
 */

#ifndef LPCTOOL_H
#define LPCTOOL_H


void Levinson( Float R[], Float rc[], Short *stable, Short ord, Float *a );
void Weight_a( Float a[], Float ap[], Float gamma, Short m );
void f_Lag_window( Float *R, const Float *W, Short ord );
void  Autocorr(Float x_f[], const Float win[], Float Rf[], Short ord, Short len);


#endif
