/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: highband.h
 *  Function: Higher-band VQ constants
 *------------------------------------------------------------------------
 */

#ifndef HIGHBAND_H
#define HIGHBAND_H

#include "fec_highband.h"

#define N_FR_FREQ      36          /* Number of quantized coefficients */
#define MAXBIT_SHAPE   5           /* Number of bits allocated for shape */
#define CB_SIZE        32          /* Shape codebook size */
#define BITMASK_SHAPE  0x1F        /* Bit mask for shape index */
#define N_DIV          6           /* Number of subvectors */
#define VECLEN         6           /* Subvector length */
#define N_CAN          8           /* Number of preselected candidates */
#define GSCALE_FACT    25905       /* Gain scaling factor, 4*sqrt(10) in Q11 */
#define DE_SCALE_FACT  20724       /* Gain de-scaling factor 1/(4*sqrt(10)), Q18 */

typedef struct {
  Short s_wvq[N_DIV*2];	
  Short s_pow;
} INDEX;

typedef struct {    /* used in encoder only */
	Float in[L_FRAME_NB];
} VQE_State;

typedef struct {    /* used in decoder only */
  Float f_prev[L_FRAME_NB];
  Float f_curSave[L_FRAME_NB];
  Short s_SpectrumQ_pre;
  int   i_reset;
  HBFEC_State hbfec_st;
} VQD_State;

/* Global tables */
extern const Float gfCodebook_0ch[CB_SIZE][VECLEN];
extern const Float gfCodebook_1ch[CB_SIZE][VECLEN];
extern const Float gfCodebook_0ch_pow[CB_SIZE];
extern const Float gfCodebook_1ch_pow[CB_SIZE];
extern const Float gfCodebook_cross[CB_SIZE][CB_SIZE];

/* Function prototypes */
void*  highband_encode_const(void);
void   highband_encode_dest(void *work);
int    highband_encode_reset(void *work);
int    highband_encode(
  const Float  fBufin[],        /* (i): Input higher-band signal */
  unsigned char *bitstream,     /* (o): Output bitstream         */
  void          *work,          /* (i/o): Pointer to work space  */
  Float         *mdct_in,
  Float         *mdct_localdec,
  Float         *mdct_err       /* (o): MDCT coefficients error  */
);

void*  highband_decode_const(void);
void   highband_decode_dest(void *work);
int    highband_decode_reset(void *work);
int    highband_decode(
  const unsigned char *bitstream,  /* (i): Input bitstream                */
  Short               erasure,     /* (i): FER flag, 0:No FER/1:FER       */
  Float               fBufout[],   /* (o): Output higher-band signal */
  void                *work,       /* (i/o): Pointer to work space        */
  int                 cod_Mode,    /* (i): Mode information obtained in BWE */
  Float               *snb_mdct,   /* (o) */
  Float               *smdct_err,  /* (i): MDCT coefficetnts errors quantized in SHB layer */
  const Short         *pBit_g,     /* (i): Input bitstream for correction factors */
  int                 bitratemode, /* (i): Bitrate mode  */
  int                 bit_switch_flag,
  const Float         sattenu      /* (i) */
);

int   VQencode_spectrum( Float[], Short[], Float, Short* );
int   norm_spectrum ( Float[], Short, Float[], Float* );
void  vq_preselect ( Float[], const Float(*pCodebook)[VECLEN], const Float*, Float[N_CAN], Float[N_CAN], Short[N_CAN] );
void  vq_mainselect ( Short[], Short[], Short[], Float[N_CAN], Float[N_CAN], Float[N_CAN], Float[N_CAN], Float[] );
int   VQdecode_spectrum ( Short[], Short , Float[] );

Short mulaw( Short );
int   mux_bitstream( INDEX*, unsigned char* );
Short mulawinv( Short index );
int   demux_bitstream (INDEX * index,unsigned char *bitstream);

#endif  /* HIGHBAND_H */
