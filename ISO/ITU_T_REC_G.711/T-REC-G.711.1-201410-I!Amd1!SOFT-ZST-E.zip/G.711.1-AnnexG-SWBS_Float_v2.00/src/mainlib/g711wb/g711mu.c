/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: g711mu.c
 *  Function: Core encoding/decoding and 
 *            lower-band enhancement layer decoding (mu-law)
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"


/*
 * Conversion of a linear sample to an enhanced Mu law coded sample
 *
 * G.711 quantizer encodes the input sample with 8 bits, and
 * the lower-band enhancement layer quantizes the refinement signal
 * with the number of bits which is allocated dynamically, based on
 * the exponent values of core layer signals.
 */


/* Core layer encoding */
Short    convertLin_MuLaw(  /* Returns core layer code */
  Short x,        /* (i): Input sample                                   */
  Short *ind2,    /* (o): Refinement signal which has a 3-bit resolution */
  Short *xq,      /* (o): Locally decoded core layer sample              */
  Short *expo     /* (o): Exponent value of core layer sample            */
)
{
  Short sign, exp, mant, ind_tmp, ind, val;

  sign = 0x80;

  if( x >= -32635)
      x = x;
  else
      x = -32635;
  if( x <= 32635)
      x = x;
  else
      x = 32635;

  if(x < 0)
  {
    x = (x == (Short)0x8000) ? (Short)0x7fff : -x;                  /* 2's complement is used. */
 /* x = s_xor(x, (Short)0xFFFF); */ /* abs(x) - 1 */
    sign = 0;
  }
  x += 132;
  exp = 7 - Fnorme16(x);          /* 7 >= pos >= 1 */
  x = x >> exp;
  *ind2 = x & 0x7;            /* save 3 LSB */

  x = x >> 3;
  mant = x - 16;                /* remove leading 1 */
  ind_tmp = sign + ((exp<<4) + mant);
  ind = ind_tmp ^ 0x007F;     /* toogle all bits except sign*/

  *expo = exp;

  /* decode g711 for noise shaping */

  val = mant << 3;               /* get mantissa to right position */
  val = val + 128 + 4;            /* leading 1 & rounding */

  val = (val<<exp) - 132;    /* suppress encoder offset */

  if(sign == 0)                    /* sign bit ==0 ' negative value */
  {
	val = (val == (Short)0x8000) ? (Short)0x7fff : -val;
  }
  *xq = val;

  return ind;
}



/* Core layer decoding */
Short    convertMuLaw_Lin(  /* Returns core layer signal */
  Short ind,     /* (i): Input Layer 0 (core layer, G.711) code */
  Short *expo,   /* (o): Exponent value of core layer sample    */
  Short* signo   /* (o): Sign of core layer sample              */
)
{
  Short y, val;
  Short sign;

  sign = ind & 0x80;
  *signo = sign;          /* *signo is an array variable. */

  y = (ind^0x007F) & 0x7F;  /* without sign */
  *expo = y >> 4;

  val = (y & 0xF) << 3;      /* get mantissa to right position */
  val = val + 128 + 4;            /* leading 1 & rounding */	

  val = (val<<*expo) - 132;  /* suppress encoder offset */

  if(sign == 0)  /* sign bit ==0 ' negative value */
  {
    val = (val == (Short)0x8000) ? (Short)0x7fff : -val;
  }

  return val;
}



/* Layer 1 (Lower-band enhancement - LBE) decoding */
Short convertMuLaw_Lin_enh(  /* Returns LBE layer signal */
  Short code2,   /* (i): Layer 1 (Lower-band enhancement) code */
  Short exp,     /* (i): Exponent value of core layer sample   */
  Short sign,    /* (i): Sign of core layer sample             */
  Short numbits  /* (i): Number of bits allocated for LBE code */
)
{
  Short ext;

  ext = code2 << (4-numbits);  /* for rounding operation in case that numbits = 3 */
  ext = ext - ( 8 - (0x8>>numbits));
  ext = ext << (exp-1);

  if(sign == 0)
  {
	ext = (ext == (Short)0x8000) ? (Short)0x7fff : -ext;
  }

  return ext;
}

