/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: fec_highband.h
 *  Function: Header of high-band frame erasure concealment (FERC)
 *------------------------------------------------------------------------
 */

#ifndef FEC_HIGHBAND_H
#define FEC_HIGHBAND_H

#include "pcmswb_common.h"

/* Constants for higher-band FERC */

#define MAXPIT                144 /* maximal pitch lag (20ms @8kHz) => 50 Hz */
#define HB_PITCH_SEARCH_RANGE 3
#define ATT_WEIGHT_STEP       164
#define HB_FEC_BUF_LEN        (L_FRAME_NB*3 + 144)	

#define F_ATT_WEIGHT_STEP     0.005f

typedef struct {
  Float f_hb_buf[HB_FEC_BUF_LEN]; /* HB signal buffer for FERC */
  Short s_lb_t0;                  /* pitch delay of lowerband  */
  Short s_first_loss_frame;
  Short s_hb_t0;                  /* pitch delay of higherband */
  Float f_att_weight;
  Short s_high_cor;
  Short s_pre_bfi;
} HBFEC_State;

/* Function prototypes */
void  update_hb_buf(Float *hb_buf, Float *output_hi);
void   copy_lb_pitch(void * SubDecoderL, void * SubDecoderH);

Float f_cor_hb_fec(Float * hb_buf, Short *hb_pitch_best);

#endif
