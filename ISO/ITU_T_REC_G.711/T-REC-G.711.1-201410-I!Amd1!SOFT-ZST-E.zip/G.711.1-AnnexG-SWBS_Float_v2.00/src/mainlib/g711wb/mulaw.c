/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"


/*----------------------------------------------------------------
  Function:
    Mu-law compression of gain, 8bit, u=255
  Return value
    Quantized value in log scale
  ----------------------------------------------------------------*/
Short mulaw(Short linbuf)
{
  Short  absno;
  Short  exponent;
  Short  mantissa;
  Short  logbuf;

  if( linbuf < 4 )
  {
    logbuf = linbuf & 0x3;
  }
  else
  {
    absno = linbuf + 130;

    exponent = 7 - Fnorme16(absno);

    mantissa = ((absno >> exponent) - 128) >> 2;
    logbuf = (exponent << 5) + mantissa;

    logbuf += 3 ;
	
	if( 255 <= logbuf)
		logbuf = 255;
	else
		logbuf = logbuf;
  }

  return logbuf;
}
