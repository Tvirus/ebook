/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: highband_dec.h
 *  Function: Layer 2 (Higher-band) decoder
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "G711WB_highband.h"
#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"
#include "fec_highband.h"
#include "bwe.h"
#include "g711enh.h"



#define DECODER_OK  2
#define DECODER_NG  3



/*----------------------------------------------------------------
  Function:
    Higher-band decoder constructor
  Return value
    Pointer to work space
  ----------------------------------------------------------------*/
void* highband_decode_const(void)
{
  VQD_State  *dec_st=NULL;

  dec_st = (VQD_State *)malloc( sizeof(VQD_State) );
  if (dec_st == NULL) return NULL;

  highband_decode_reset( (void *)dec_st );

  return (void *)dec_st;
}



/*----------------------------------------------------------------
  Function:
    Higher-band decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void  highband_decode_dest(
  void *work        /* (i): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;

  if (dec_st != NULL)  free( dec_st );
}



/*----------------------------------------------------------------
  Function:
    Higher-band decoder reset
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int   highband_decode_reset(
  void *work        /* (i/o): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;

  if (dec_st != NULL) {
    zeroF(L_FRAME_NB, dec_st->f_prev);
    zeroF(L_FRAME_NB, dec_st->f_curSave);
    dec_st->s_SpectrumQ_pre = 0;
    dec_st->i_reset = 1;
    zeroF(HB_FEC_BUF_LEN, dec_st->hbfec_st.f_hb_buf);
    dec_st->hbfec_st.s_lb_t0 = 0;
    dec_st->hbfec_st.s_first_loss_frame = 1;
    dec_st->hbfec_st.s_hb_t0 = 0;
    dec_st->hbfec_st.f_att_weight = 1.0f;
    dec_st->hbfec_st.s_high_cor = 0;
    dec_st->hbfec_st.s_pre_bfi = 0;
  }
  return DECODER_OK;
}



/*----------------------------------------------------------------
  Function:
    Higher-band decoder
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int   highband_decode(
  const unsigned char *bitstream,  /* (i): Input bitstream                */
  Short               erasure,     /* (i): FER flag, 0:No FER/1:FER       */
  Float               fBufout[],   /* (o): Output higher-band signal      */
  void                *work,       /* (i/o): Pointer to work space        */
  int                 cod_Mode,    /* (i): Mode information obtained in BWE */
  Float               *nb_mdct,   /* (o) */
  Float               *mdct_err,  /* (i): MDCT coefficetnts errors quantized in SHB layer  */
  const Short         *pBit_g,     /* (i): Input bitstream for correction factors */
  int                 bitratemode, /* (i): Bitrate mode  */
  int                 bit_switch_flag,
  const Float         sattenu      /* (i) */
) {

  Float f_sb_err[12];
  Float f_mdct_corr[L_FRAME_NB];
  Float fOut[L_FRAME_NB];
  Float fSpectrum[L_FRAME_NB];  /* MDCT coefficients, floating      */
  VQD_State *dec_st=(VQD_State *)work;
  int   i;
  INDEX index;                            /* Gain and VQ indices              */

  Short s_idx, e_idx;

  zeroF( L_FRAME_NB, fSpectrum);
  zeroF( L_FRAME_NB, fOut);
  zeroF( L_FRAME_NB, f_mdct_corr);
  zeroF( 12, f_sb_err);

  if (erasure == 0) {  /* No FER */
		/* deMUX of indices */
		demux_bitstream(&index, (unsigned char *)bitstream);

		/* De-quantize MDCT coefficients */
		VQdecode_spectrum(index.s_wvq,     /* (i) */
                        index.s_pow,     /* (i) */
                        &fSpectrum[4]  /* (o) */
		);
		
		/* Windowing */
		fSpectrum[0] = 0.0f;
		fSpectrum[1] = 0.0f;
		fSpectrum[2] = 0.0f;
		fSpectrum[3] = 0.0f;
		fSpectrum[4] *= (Float) 0.130526192220052e+00;  /* *= sin(   PI/24) */
		fSpectrum[5] *= (Float) 0.382683432365090e+00;  /* *= sin( 3*PI/24) */
		fSpectrum[6] *= (Float) 0.608761429008721e+00;  /* *= sin( 5*PI/24) */
		fSpectrum[7] *= (Float) 0.793353340291235e+00;  /* *= sin( 7*PI/24) */
		fSpectrum[8] *= (Float) 0.923879532511287e+00;  /* *= sin( 9*PI/24) */
		fSpectrum[9] *= (Float) 0.991444861373810e+00;  /* *= sin(11*PI/24) */
	
		
		if( bit_switch_flag == 1 )
		{
			for( i=6; i<16; i++ )
			{
				mdct_err[i] = fSpectrum[26-i] / 2;
			} 
		}
		else if( bit_switch_flag == 2 )
		{
			for( i=6 ; i<16 ; i++ ){
				mdct_err[i] = mdct_err[i] * sattenu;
			}
		}
		
		if( cod_Mode == TRANSIENT )
		{
			for(i=0; i<10; i++)
			{
				Float f_tmp = (mdct_err[i] + fSpectrum[20-i]) / 2;
				fSpectrum[10-i] = fSpectrum[10-i] + f_tmp;	
			}
		}
		else
		{
			for(i=0; i<16; i++)
			{
				fSpectrum[15-i] = fSpectrum[15-i] + mdct_err[i];	
			}
		}
		
		if( bitratemode == MODE_R4sm || bitratemode == MODE_R5ssm )
		{
			g711el1_decode (pBit_g, (const Float*) fSpectrum, f_mdct_corr, f_sb_err, &s_idx, &e_idx);
		
			for(i=0; i<L_FRAME_NB; i++)
			{
				fSpectrum[i] = fSpectrum[i] * f_mdct_corr[i];
			}
			for(i = s_idx; i < e_idx; i++)
			{
				fSpectrum[i] += f_sb_err[i-s_idx];
			}
		}
		movF( L_FRAME_NB , fSpectrum , nb_mdct );
  }

  /* iMDCT */
  f_inv_mdct(fOut, fSpectrum, dec_st->f_prev, (Short)erasure, dec_st->f_curSave, &dec_st->hbfec_st);

   /* Mute at first frame after reset */
  if (dec_st->i_reset != 0) {
	  zeroF(L_FRAME_NB, fOut);
	  dec_st->i_reset = 0;
  }

  /* Update higher-band FERC buffer */
  if (erasure == 0) {
	  update_hb_buf(dec_st->hbfec_st.f_hb_buf, fOut);
  }

  /* Copy decoded signal to output buffer */
  movF(L_FRAME_NB, fOut, fBufout);
  
  return 0;
}
