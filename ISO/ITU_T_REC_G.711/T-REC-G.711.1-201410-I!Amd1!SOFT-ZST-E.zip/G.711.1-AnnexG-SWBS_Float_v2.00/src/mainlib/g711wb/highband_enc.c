/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: highband_enc.c
 *  Function: Layer 2 (Higher-band) encoder
 *------------------------------------------------------------------------
 */

#include <math.h>
#include "pcmswb_common.h"
#include "G711WB_highband.h"

#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"

#define ENCODER_OK  0
#define ENCODER_NG  1

/*----------------------------------------------------------------
  Function:
    Higher-band encoder constructor
  Return value:
    Pointer to work space
  ----------------------------------------------------------------*/
void* highband_encode_const(void)
{
  VQE_State  *enc_st=NULL;

  enc_st = (VQE_State *)malloc( sizeof(VQE_State) );
  if (enc_st == NULL)
    return NULL;

  highband_encode_reset( (void *)enc_st );

  return (void *)enc_st;
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void  highband_encode_dest(
  void *work        /* (i): Pointer to work space  */
) {
  VQE_State  *enc_st=(VQE_State *)work;

  if (enc_st != NULL)
    free( enc_st );
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder reset
  Return value:
    ENCODER_OK
  ----------------------------------------------------------------*/
int   highband_encode_reset(
  void *work        /* (i/o): Pointer to work space  */
) {
  VQE_State  *enc_st=(VQE_State *)work;

  if (enc_st != NULL) {
	zeroF(L_FRAME_NB, enc_st->in);
  }
  return ENCODER_OK;
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder
  Return value:
    ENCODER_OK
  ----------------------------------------------------------------*/
int highband_encode(
  const Float   fBufIn[],        /* (i): Input higher-band signal */
  unsigned char *bitstream,      /* (o): Output bitstream         */
  void          *work,           /* (i/o): Pointer to work space  */
  Float         *mdct_in,        /* (o) */
  Float         *mdct_localdec,  /* (o) */
  Float         *mdct_err        /* (o): MDCT coefficients error  */
) {
  VQE_State *enc_st=(VQE_State *)work;
  Short  i;
  INDEX  index;                 /* Gain and VQ indices             */
  Short  expSpect;              /* Q of sSpectrum[]                */
  Float  gain;                  /* Normalizing RMS, Float          */
  Float  spectrum[L_FRAME_NB];  /* MDCT coefficients, Float        */
  Float  normSpec[N_FR_FREQ];   /* Normalized coefficients, Float  */
  Float  Qspectrum[L_FRAME_NB];/* local-decoded MDCT coefficients */
  Float  spectmp[L_FRAME_NB];
  Short  exptmp;

  /* MDCT */
  /* Short -> Float (to be removed in float-only software) */
  f_mdct(enc_st->in, (Float *) fBufIn, spectrum);

  movF( L_FRAME_NB , spectrum, spectmp);

    /* Frequency weighting */
  expSpect = ExpFto16Array(L_FRAME_NB, spectrum);
  exptmp = expSpect;
  if (expSpect == ExpFto16Array(18, &spectrum[10])) {
	  expSpect--;
  }

  /* Frequency weighting */
  for (i = 27; i >= 22; i--) {
	spectrum[i] *= 1.33331298828125f;//-------->This code used multiplier of Fix code.
  }
  for (i = 21; i >= 16; i--) {
	spectrum[i] *= 1.66668701171875f;//-------->This code used multiplier of Fix code.
  }
  for (i = 15; i >= 10; i--) {
    spectrum[i] *= 2.0f;
  }

  spectrum[9] *= (Float) 0.991444861373810e+00;  /* *= sin(11*PI/24) */
  spectrum[8] *= (Float) 0.923879532511287e+00;  /* *= sin( 9*PI/24) */
  spectrum[7] *= (Float) 0.793353340291235e+00;  /* *= sin( 7*PI/24) */
  spectrum[6] *= (Float) 0.608761429008721e+00;  /* *= sin( 5*PI/24) */
  spectrum[5] *= (Float) 0.382683432365090e+00;  /* *= sin( 3*PI/24) */
  spectrum[4] *= (Float) 0.130526192220052e+00;  /* *= sin(   PI/24) */

  /* Normalize MDCT coefficients with RMS */
  norm_spectrum(&spectrum[4],  /* (i) */
                expSpect,      /* (i) */
                normSpec,      /* (o) */
                &gain          /* (o) */
    );

  /* Quantize normalized MDCT coefficients */
  VQencode_spectrum(normSpec,    /* (i) */
                    index.s_wvq, /* (o) */
                    gain,        /* (i) */
                    &index.s_pow /* (o) */
    );

  /* MUX of indices */
  mux_bitstream(&index, bitstream);

  /* Save current input signal */
  movF(L_FRAME_NB, (Float *) fBufIn, enc_st->in);

  /* Local decoding */
  zeroF( L_FRAME_NB , Qspectrum );

  VQdecode_spectrum(
    index.s_wvq,       /* (i) */
    index.s_pow,       /* (i) */
    &Qspectrum[4]    /* (o) */
  );

  zeroF(4, Qspectrum);

  Qspectrum[4] *= (Float) 0.130526192220052e+00;  /* *= sin(   PI/24) */
  Qspectrum[5] *= (Float) 0.382683432365090e+00;  /* *= sin( 3*PI/24) */
  Qspectrum[6] *= (Float) 0.608761429008721e+00;  /* *= sin( 5*PI/24) */
  Qspectrum[7] *= (Float) 0.793353340291235e+00;  /* *= sin( 7*PI/24) */
  Qspectrum[8] *= (Float) 0.923879532511287e+00;  /* *= sin( 9*PI/24) */
  Qspectrum[9] *= (Float) 0.991444861373810e+00;  /* *= sin(11*PI/24) */

  for( i=0 ; i<L_FRAME_NB ; i++ ){
	  mdct_in[i] = spectmp[i];
	  mdct_localdec[i] = Qspectrum[i];
  }

  for( i=0 ; i<16 ; i++ )
  {
    mdct_err[i] = mdct_in[15-i] - mdct_localdec[15-i];
  }

  return ENCODER_OK;
}
