/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: lowband_dec.c
 *  Function: Lower-band decoder
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "g711.h"
#include "fec_lowband.h"
#include "G711WB_lowband.h"
#include "lpctool.h"



typedef struct {
  Short   s_law;                   /* G.711 law */
  Float   f_sigdec_past[L_WINDOW]; /* buffer for past G.711 decoded signal */
  Float   f_mem_A[ORD_M + 1];      /* A(z) of previous frame */
  Float   f_mem_rc[ORD_M];         /* Reflection coefficients of previous frame */
  Float   f_mem_wfilter[ORD_M];    /* buffer for the weighting filter */
  Short   s_loss_cnt;              /* indicator of past lost frames (up to 2) */
  Float   f_energy;                /* Signal energy of previous frame */
 void*  pFECWork;               /* Lower band FEC work area */
} lowband_decode_work;



static void lowband_lbe_demux(const unsigned char *code1, Short * expi, Short * excode, Short * bit_alloc);



/* -------------------------------------------------------------------
  Function:
    Lower-band decoder constructor
  Return value:
    Pointer of work space
   -------------------------------------------------------------------*/
void    *lowband_decode_const(
  int    law                /* (i): G.711 decoding law [G711ALAW/G711ULAW] */
) {
  lowband_decode_work *work=NULL;

  if ( law == G711ULAW || law == G711ALAW ) {
    work = (lowband_decode_work *)malloc( sizeof(lowband_decode_work) );
    if ( work != NULL )
    {
	  work->s_law = law;

      /* FEC routines for 5ms frame */
      work->pFECWork = FEC_lowerband_const();
      if ( work->pFECWork == NULL ) {
        lowband_decode_dest((void *)work);
        return NULL;
      }

      lowband_decode_reset( (void *)work );
    }
  }
  return (void *)work;
}



/* -------------------------------------------------------------------
  Function:
    Lower-band decoder destructor
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_decode_dest(
  void *ptr   /* (i): Pointer to work space */
) {
  lowband_decode_work *work = (lowband_decode_work *)ptr;

	
  if (work != NULL)
  {
    FEC_lowerband_dest(work->pFECWork);
    free( work );
  }
}



/* -------------------------------------------------------------------
  Function:
    Lower-band decoder reset
  Return value:
    None
   -------------------------------------------------------------------*/
void
lowband_decode_reset(
  void *ptr                     /* (i/o): Pointer to work space */
  )
{
  lowband_decode_work *work = (lowband_decode_work *) ptr;

  if (work != NULL) {
    work->f_mem_A[0] = 1.0f;
    zeroF(ORD_M, &work->f_mem_A[1]);
    zeroF(ORD_M, work->f_mem_rc);
    zeroF(ORD_M, work->f_mem_wfilter);
    zeroF(L_WINDOW, work->f_sigdec_past);
    work->s_loss_cnt = 0;
    work->f_energy = 0;           /* could be set to some high value */
    FEC_lowerband_reset(work->pFECWork);
  }
}



/* -------------------------------------------------------------------
  Function:
    Lower band decoder
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_decode(
  const unsigned char code0[],   /* (i): Layer 0 bitstream (multiplexed)    */
  const unsigned char code1[],   /* (i): Layer 1 bitstream (multiplexed)    */
  int                 loss_flag, /* (i): Frame erasure status flag          */
  Float               sigout[],  /* (o): Output 5-ms signal                 */
  Float               *gain,     /* (o): Target gain for noise gate         */
  void                *ptr,      /* (i/o): Pointer to work space            */
  Float               *nb_sig
) {

  Float   r[ORD_M + 1];
  Short   i, j, norm, offset, stable, stmp, sigtmp;
  Short   sigdec[L_FRAME_NB], exp[L_FRAME_NB], sign[L_FRAME_NB],
          bit_alloc[L_FRAME_NB], excode_buf[ORD_M + L_FRAME_NB], *excode;
  Float   tmp, alpha;
  Float   ftmp, fener;

  lowband_decode_work *work = (lowband_decode_work *)ptr;

  Float  *f_rc = work->f_mem_rc;   /* Reflection coefficients              */
  Float  *f_A = work->f_mem_A;     /* A0(z) with spectral expansion        */

  /* G.711 decoding function */
  Short   (*convertLog_Lin)(Short, Short*, Short*);
  Short   (*convertLog_Lin_enh)(Short, Short, Short, Short);


  if (work->s_loss_cnt == 0) {
    /* LP analysis and filter weighting */
    norm = AutocorrNS(work->f_sigdec_past, r);
    Levinson(r, f_rc, &stable, ORD_M, f_A);

    if (norm >= MAX_NORM) {
      for (i = 1; i <= ORD_M; ++i)
        f_A[i] /= Pow(2.0f, (Float) (i + norm - MAX_NORM));
    }
    else {
      if (f_rc[0] > 0.9844f) {    /* -rc[0] == r[1]/r[0] < -0.984375 */
        alpha = 0.92f * 16.0f * (1.047f - f_rc[0]);
        Weight_a(f_A, f_A, alpha, ORD_M);
      }
      else {
        Weight_a(f_A, f_A, GAMMA1f, ORD_M);
      }
    }
  }


	if (loss_flag == 0) {
		excode = excode_buf + ORD_M;
		
		if (work->s_law == G711ALAW) {
			convertLog_Lin = convertALaw_Lin;
			convertLog_Lin_enh = convertALaw_Lin_enh;
			offset = ALAW_OFFSET;
		}
		else {                      /* work->law == G711ULAW */
			convertLog_Lin = convertMuLaw_Lin;
			convertLog_Lin_enh = convertMuLaw_Lin_enh;
			offset = 0;
		}
		/* Zero code detection */
		if (code1 != NULL) {        /* Layer 1 exists */
			stmp = 0;
			for (i = 0; i < L_FRAME_NB / 4; i++) {
				stmp += (Short) code1[i];
			}
			if (stmp == 0) {
				code1 = NULL;
			}
		}
		for (i = 0; i < L_FRAME_NB; i++) {
			/* Decoding of the shaped sample */
			sigtmp = (*convertLog_Lin) (code0[i], &exp[i], &sign[i]);
			sigdec[i] = sigtmp - offset;
		}
		
		/* Updating of the past synthesized buffer */
		movF(L_FRAME_NB, work->f_sigdec_past + L_FRAME_NB, work->f_sigdec_past);
		movSF(L_FRAME_NB, sigdec, work->f_sigdec_past + L_FRAME_NB);

	  if (code1 != NULL) {        /* Layer 1 exists */
        lowband_lbe_demux(code1, exp, excode, bit_alloc);

      for (i = 0; i < L_FRAME_NB; i++) {
        excode[i] =
          (*convertLog_Lin_enh) (excode[i], exp[i], sign[i], bit_alloc[i]);
      }
      if (work->s_loss_cnt == 0) {
        movFS(ORD_M, work->f_mem_wfilter, excode_buf);

        for (i = 0; i < L_FRAME_NB; i++) {
          /* Noise shaping of the enhancement layer signal */
          tmp = f_A[0] * excode[i];
          for (j = 1; j <= ORD_M; j++)
            tmp -= f_A[j] * excode[i - j];
          excode[i] = (Short) Floor(tmp + 0.5f);

          /* Add the enhancement layer signal */
          tmp = (Float) sigdec[i] + excode[i];
          sigdec[i] = roundFto16(tmp);
        }
      }

      /* Update the shaping filter memory */
      movSF(ORD_M, excode_buf + L_FRAME_NB, work->f_mem_wfilter);
    }
  }


  /* ---------------------------------------------------------- */
  /* Lower-band frame-erasure concealment (FERC)                */
  /* Sigout is 5-ms delayed from sigtmp.                        */
  /* ---------------------------------------------------------- */
  FEC_lowerband(loss_flag, sigdec, sigout, work->pFECWork, nb_sig);

  /* Updating of the lost frames counter */

  loss_flag = ((Short) loss_flag < 1) ? (Short) loss_flag : 1;  /* 1 or zero */
  stmp = work->s_loss_cnt + (Short) loss_flag;    /* Add 1 if Loss */
  stmp = (stmp < 2) ? stmp : 2; /* Do not Count above 2 */
  stmp = stmp - 1;              /* Decrement if no Loss */
  stmp = stmp + (Short) loss_flag;      /* But Re-Increment Since there is Loss */
  work->s_loss_cnt = (stmp > 0) ? stmp : 0;       /* Do not Decrement below 0 */



  /* ----------------------------- */
  /* Calculate Gain for Noise Gate */
  /* ----------------------------- */
  fener = 150.0f;               /* offset energy measure */
  for (i = L_WINDOW / 2; i < L_WINDOW; ++i) {
    ftmp = work->f_sigdec_past[i] - 0.75f * work->f_sigdec_past[i - 1];
    fener += ftmp * ftmp;
  }
  ftmp = fener;
  fener += work->f_energy;
  work->f_energy = ftmp;

  fener = Sqrt(fener);
  *gain = fener / 64.0f;

  if (*gain > 1.0f)
    *gain = 1.0f;
  if (*gain < 0.25f)
    *gain = 0.25f;

  return;
}



Short get_lb_pitch(void *lb_dec)
{
  lowband_decode_work *lb_dec_pt = (lowband_decode_work *) lb_dec;

  return get_lb_pit(lb_dec_pt->pFECWork);
}



/* Bitstream demultiplexing for Layer 1 */
static void
lowband_lbe_demux(
  const unsigned char *code1,   /* (i): Layer 1 bitstream    */
  Short * expi,                 /* (o): exponent signal      */
  Short * excode,               /* (o): enhancement signal   */
  Short * bit_alloc             /* (o): bit allocation table */
  )
{
  unsigned char *pcode1 = (unsigned char *)code1;
  Short   bit_pos;
  Short   i;
  Short   tmp1;

  /* Bit allocation */
  lbe_bitalloc(expi, bit_alloc);

  /* Retrieve excode */
  bit_pos = 8;
  tmp1 = (Short) (*pcode1);
  for (i = 0; i < L_FRAME_NB; i++) {
    if (bit_pos < bit_alloc[i]) {
      pcode1++;
      tmp1 <<= 8;
      tmp1 |= (Short) (*pcode1);
      bit_pos += 8;
    }

    bit_pos -= bit_alloc[i];
    excode[i] = tmp1 >> bit_pos;
    tmp1 -= (excode[i] << bit_pos);
  }

  return;
}
