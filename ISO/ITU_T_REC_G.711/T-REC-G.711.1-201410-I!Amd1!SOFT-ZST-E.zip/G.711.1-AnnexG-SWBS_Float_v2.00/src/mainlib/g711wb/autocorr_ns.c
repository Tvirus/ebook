/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: autocorr_ns.c
 *  Function: Compute autocorrelations of signal for noise shaping
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "G711WB_lowband.h"
#include "lpctool.h"


Short
AutocorrNS( /*  Return: R0 Normalization shift       */
  Float x[],                    /* (i)    : Input signal (80 samples)    */
  Float r[]                     /* (o) DPF: Autocorrelations (low)       */
  )
{
  Short   i, j, norm;
  Float   fmult;

  Float   alpha, sum, zcr;
  Float   y[L_WINDOW];

  /* Approximate R(1)/R(0) (tilt or harmonicity) with a zero-crossing measure */
  Short   zcross = L_WINDOW - 1;
  Short   x_s[L_WINDOW];

  movFS(L_WINDOW, x, x_s);
  for (i = 1; i < L_WINDOW; ++i) {
    if ((x_s[i - 1] ^ x_s[i]) < 0) {
      zcross--;
    }
  }
  zcross = 12543 + zcross * (Short) (1 << 8);   /* set the factor between .38 and 1.0 */
  zcr = (Float) zcross / 32768.0f;

  /* Pre-emphesis and windowing */
  for (i = 1; i < L_WINDOW; i++) {
    /* Emphasize harmonic signals more than noise-like signals */
    y[i] = NS_windowf[i] * (x[i] - zcr * x[i - 1]);
  }

  /* Low level fixed noise shaping (when rms <= 100) */
  alpha = 100.0f;
  sum = alpha * 100.0f;

  for (i = 1; i < L_WINDOW; i++) {
    sum += y[i] * y[i];
  }
  fmult = 1.0f;

  if (sum > 0.5f * 2147483647.0f) {
    fmult = 0.25f;
    alpha *= fmult;
    sum = alpha * 25.0f;
    for (i = 1; i < L_WINDOW; i++) {
      y[i] *= fmult;
      sum += y[i] * y[i];
    }
  }

  alpha *= 0.95f;

  norm = Fnorme32(sum);
  r[0] = sum;

  /* Compute r[1] to r[m] */
  for (i = 1; i <= ORD_M; i++) {
    /* low level fix noise shaping */
    sum = alpha * 100.0f * fmult;
    alpha *= 0.95f;

    for (j = 1; j < L_WINDOW - i; j++) {
      sum += y[j] * y[j + i];
    }

    r[i] = sum;
  }

  /* Lag windowing */
  f_Lag_window(r, NS_lag_f, ORD_M);

  return norm - 1;
}

