/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: cfft.c
 *  Function: 20-point complex FFT
 *------------------------------------------------------------------------
 */
 
#include "pcmswb_common.h"
#include "defines_mdct.h"
#include "cfft.h"


/*--------------------------------------------------------------------------*
 *  Function  cfft()                                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Complex Good-Thomas fast Fourier transform                              *
 *--------------------------------------------------------------------------*/

void f_cfft (
  Float * x1,  /* (i/o) pointer on the real part of data       */
  Float * x2,  /* (i/o) pointer on the imaginary part of data  */
  Short sign   /* (i) flag to select FFT (1) or IFFT (-1)      */
) {                               
  Float        tab_x1[MDCT_NP * MDCT_NPP];
  Float        tab_x2[MDCT_NP * MDCT_NPP];
  Float        rx1[MDCT_NP];
  Float        rx2[MDCT_NP];
  Float        *ptr_x1;   /* Pointer on tab_x1 */
  Float        *ptr_x2;   /* Pointer on tab_x2 */
  Float        *ptr0_x1;  /* Pointer on tab_x1 for DFT step */
  Float        *ptr0_x2;  /* Pointer on tab_x2 for DFT step */
  const Float  *ptr_cos;  /* Pointer on cos table */
  const Float  *ptr_sin;  /* Pointer on sin table */
  const Short  *ptr_map;  /* Pointer on mapping indice (input and output) */

  Short        ip, ipp, i, j;
  Float        x1_tmp;
  Float        x2_tmp;
  Short        exp_n2;
  Short        n1;
  Short        n2;        /* size of sub array */
  Short        n3;
  Short        p;         /* size of the butterfly */
  Short        inkw;
  Float        rix;
  Float        cix;
  Float        rjx;
  Float        cjx;

  /********************************************************************************
   * Mapping for the input indices (Good Thomas FTT)                              *
   ********************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_maps;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (ipp = 0; ipp < MDCT_NPP; ipp++) {
      i = (Short) * ptr_map++;
      *ptr_x1++ = x1[i];
      *ptr_x2++ = x2[i];
    }
  }

  /***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (j = 0; j < MDCT_NB_REV; j++) {
      i = MDCT_tab_rev_is[j];
      ipp = MDCT_tab_rev_ipps[j];
      x1_tmp = ptr_x1[ipp];     /* swap value ptr_x1[i] and ptr_x1[ipp] */
      x2_tmp = ptr_x2[ipp];     /* swap value ptr_x2[i] and ptr_x2[ipp] */
      ptr_x1[ipp] = ptr_x1[i];
      ptr_x2[ipp] = ptr_x2[i];
      ptr_x1[i] = x1_tmp;
      ptr_x2[i] = x2_tmp;
    }
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }

  /*******************************************************************************
   * n1 size of butterfly                                                        *
   *******************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (exp_n2 = 0; exp_n2 <= MDCT_EXP_NPP; exp_n2++) {
      /*  n2 : size of sub arrays */
      n2 = 1 << exp_n2;
      n1 = n2 >> 1;
      n3 = MDCT_EXP_NPP - exp_n2;

      /* p equal the size of the butterfly */
      for (p = 0; p < n1; p++) {
        /*  get twiddle factor in arrays rw1 and rw2 */
        inkw = (p * MDCT_NP) << n3;
        x1_tmp = MDCT_rw1f[inkw];
        x2_tmp = -(Float) sign *MDCT_rw2f[inkw];

        for (i = p; i < MDCT_NPP; i += n2) {
          /*  selecet item p in array p */
          j = i + n1;

          /*   butterfly on x[i] and x[j] */
          rix = ptr_x1[i];
          cix = ptr_x2[i];

          /*  twiddle factor */
          rjx = (x1_tmp * ptr_x1[j]) - (x2_tmp * ptr_x2[j]);
          cjx = (x2_tmp * ptr_x1[j]) + (x1_tmp * ptr_x2[j]);
          ptr_x1[i] = rix + rjx;
          ptr_x2[i] = cix + cjx;
          ptr_x1[j] = rix - rjx;
          ptr_x2[j] = cix - cjx;
        }
      }
    }                           /* end while */
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }                             /* end for ip */

  /**************************************************************************/

  ptr0_x1 = tab_x1;
  ptr0_x2 = tab_x2;
  for (ipp = 0; ipp < MDCT_NPP; ipp++) {
    ptr_x1 = ptr0_x1;
    ptr_x2 = ptr0_x2;
    for (ip = 0; ip < MDCT_NP; ip++) {
      rx1[ip] = *ptr_x1;
      rx2[ip] = *ptr_x2;
      ptr_x1 += MDCT_NPP;
      ptr_x2 += MDCT_NPP;
    }

    ptr_x1 = ptr0_x1++;
    ptr_x2 = ptr0_x2++;
    ptr_cos = MDCT_xcosf;
    ptr_sin = MDCT_xsinf;

    if (sign > 0) {             /* FFT */
      for (ip = 0; ip < MDCT_NP; ip++) {
        x1_tmp = (Float) 0.0;
        x2_tmp = (Float) 0.0;
        for (i = 0; i < MDCT_NP; i++) {
          x1_tmp += rx1[i] * (*ptr_cos) - rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) + rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }                         /*end for ip */
    }
    else {                      /* IFFT */
      for (ip = 0; ip < MDCT_NP; ip++) {
        x1_tmp = (Float) 0.0;
        x2_tmp = (Float) 0.0;
        for (i = 0; i < MDCT_NP; i++) {
          x1_tmp += rx1[i] * (*ptr_cos) + rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) - rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }                         /*end for ip */
    }
  }                             /*end for ipp */

  /***************************************************************************
  * mapping for the output indices                                          *
  ***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_map2s;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (ipp = 0; ipp < MDCT_NPP; ipp++) {
      i = (Short) * ptr_map++;
      x1[i] = *ptr_x1++;
      x2[i] = *ptr_x2++;
    }
  }

  return;
}




void f_cfft_point80(
  Float * fx1,   /* (i/o) real part of data                 */
  Float * fx2,   /* (i/o) imaginary part of data            */
  Short   sign   /* (i) flag to select FFT (1) or IFFT (-1) */
)
{	
  Float    fACC0;                 /* first ACC */
  Float    fACC1;                 /* second ACC */

  Float *ftab_x1, *ftab_x2, *frx1, *frx2;

  Short mdct_np, mdct_npp, mdct_exp_npp, mdct_nb_rev;
  const Float *fmdct_rw1, *fmdct_rw2;
  const Short *mdct_tab_rev_i, *mdct_tab_rev_ipp;
  const Float *fmdct_xcos, *fmdct_xsin;

  Float *fptr_x1;               /* Pointer on tab_x1 */
  Float *fptr_x2;               /* Pointer on tab_x2 */
  Float *fptr0_x1;              /* Pointer on tab_x1 for DFT step */
  Float *fptr0_x2;              /* Pointer on tab_x2 for DFT step */
  const Float *fptr_cos;          /* Pointer on cos table */
  const Float *fptr_sin;          /* Pointer on sin table */
  const Short *ptr_map;          /* Pointer on mapping indice (input and output) */
  const Short *mdct_tab_map2;

  Short    ip, ipp, i, j;
  Float    fx1_tmp;
  Float    fx2_tmp;
  Short    exp_n2;
  Short    n1;
  Short    n2;                 /* size of sub array */
  Short    n3;
  Short    p;
  Short    inkw;
  Float    fw1;
  Float    fw2;
  Float    frix;
  Float    fcix;
  Float    frjx;
  Float    fcjx;
  Short    q;

    /* 80 points MDCT */
	mdct_np = MDCT2_NP;
	mdct_npp = MDCT2_NPP;
	mdct_exp_npp = MDCT2_EXP_NPP;
	mdct_nb_rev = MDCT2_EXP_NB_REV;

	ptr_map = MDCT_tab_map_swbs;

	fmdct_rw1 = MDCT_rw1_tbl_swbf;
	fmdct_rw2 = MDCT_rw2_tbl_swbf;

	mdct_tab_rev_i = MDCT_tab_rev_i_swbs;
	mdct_tab_rev_ipp = MDCT_tab_rev_ipp_swbs;

	fmdct_xcos = MDCT_xcos_swbf;
	fmdct_xsin = MDCT_xsin_swbf;
	mdct_tab_map2 = MDCT_tab_map2_swbs;

  ftab_x1 = (Float *) calloc ( (mdct_np * mdct_npp), sizeof(Float) );
  ftab_x2 = (Float *) calloc ( (mdct_np * mdct_npp), sizeof(Float) );
  frx1 = (Float *) calloc ( mdct_np, sizeof(Float) );
  frx2 = (Float *) calloc ( mdct_np, sizeof(Float) );


  /********************************************************************************
   * Re-indexing (mapping of input indices)                                       *
   ********************************************************************************/

  fptr_x1 = ftab_x1;
  fptr_x2 = ftab_x2;
  for (ip = 0; ip < mdct_np; ip++) {
    for (ipp = 0; ipp < mdct_npp; ipp++) {
      i = (Short) * ptr_map++;
      *fptr_x1++ = fx1[i];
      *fptr_x2++ = fx2[i];
    }
  }


  /*******************************************************************************/

  fptr_x1 = ftab_x1;
  fptr_x2 = ftab_x2;

  for (ip = 0; ip < mdct_np; ip++) {
    for (j = 0; j < mdct_nb_rev; j++) {
      i = mdct_tab_rev_i[j];
      ipp = mdct_tab_rev_ipp[j];
      fx1_tmp = fptr_x1[ipp];     /* swap value ptr_x1[i] and ptr_x1[ipp] */
      fx2_tmp = fptr_x2[ipp];     /* swap value ptr_x2[i] and ptr_x2[ipp] */
      fptr_x1[ipp] = fptr_x1[i];
      fptr_x2[ipp] = fptr_x2[i];
      fptr_x1[i] = fx1_tmp;
      fptr_x2[i] = fx2_tmp;
    }
    fptr_x1 += mdct_npp;
    fptr_x2 += mdct_npp;
  }

  /*******************************************************************************
   * n1 size of butterfly                                                        *
   *******************************************************************************/

  fptr_x1 = ftab_x1;
  fptr_x2 = ftab_x2;

      /* 80 points MDCT */
	  for (ip = 0; ip < mdct_np; ip++)
	  {
		  for (exp_n2 = 0; exp_n2 <= mdct_exp_npp; exp_n2++)
		  {
			  n2 = 1 << exp_n2;
			  n1 = n2 >> 1;
			  n3 = mdct_exp_npp - exp_n2;
			  inkw = 0;
			  q = 1 << n3;

			  for (p = 0; p < n1; p++)
			  {
				  /* get twiddle factor in arrays rw1 and rw2 */
				  fw1 = fmdct_rw1[inkw];
				  fw2 = fmdct_rw2[inkw];
				  inkw += q; /* q is constant inside the loop */

				  if (sign > 0)
				  {
					  fw2 = -fw2;
				  }

				  if (sign > 0)            /* FFT */
				  {
					  for (i = p; i < mdct_npp; i += n2)
					  {
						  /* select item p in array p */
						  j = i + n1;

						  /* butterfly on x[i] and x[j] */
						  frix = fptr_x1[i];
						  fcix = fptr_x2[i];

						  /* twiddle factor */
                          fACC0 = (fw1 * fptr_x1[j]) - (fw2 * fptr_x2[j]);
                          fACC1 = (fw2 * fptr_x1[j]) + (fw1 * fptr_x2[j]);

						  frjx = fACC0;
						  fcjx = fACC1;

                          fptr_x1[i] = frix + frjx;
                          fptr_x2[i] = fcix + fcjx;
                          fptr_x1[j] = frix - frjx;
                          fptr_x2[j] = fcix - fcjx;
					  }
				  }
				  else                    /* IFFT */
				  {
					  for (i = p; i < mdct_npp; i += n2)
					  {
						  /* select item p in array p */
						  j = i + n1;

						  /* butterfly on x[i] and x[j] */
						  frix = fptr_x1[i]/* / 2.0f*/;
						  fcix = fptr_x2[i]/* / 2.0f*/;

						  /* twiddle factor */
				          fACC0 = (fw1 * fptr_x1[j]) - (fw2 * fptr_x2[j]);
						  frjx = fACC0/* / 2.0f*/;
						  fACC0 = (fw2 * fptr_x1[j]) + (fw1 * fptr_x2[j]);
						  fcjx = fACC0/* / 2.0f*/;

						  fptr_x1[i] = frix + frjx;
						  fptr_x2[i] = fcix + fcjx;
						  fptr_x1[j] = frix - frjx;
						  fptr_x2[j] = fcix - fcjx;
					  }
				  }
			  }
		  }                           /* end while */
		  fptr_x1 += mdct_npp;
		  fptr_x2 += mdct_npp;
	  }                             /* end for ip */

  /**************************************************************************/

  fptr0_x1 = ftab_x1;
  fptr0_x2 = ftab_x2;

  for (ipp = 0; ipp < mdct_npp; ipp++)
  {
    fptr_x1 = fptr0_x1;
    fptr_x2 = fptr0_x2;
    for (ip = 0; ip < mdct_np; ip++)
    {
      frx1[ip] = *fptr_x1;
      frx2[ip] = *fptr_x2;

      fptr_x1 += mdct_npp;
      fptr_x2 += mdct_npp;
    }
    fptr_x1 = fptr0_x1++;
    fptr_x2 = fptr0_x2++;

    fptr_cos = fmdct_xcos;
    fptr_sin = fmdct_xsin;
    if (sign > 0)                /* FFT */
    {
      for (ip = 0; ip < mdct_np; ip++)
      {
        /* Set Overflow to 0 to test it after radix 5 with Q15 sin & cos coef */
        /* keep pointer's position on cos & sin tables */

        fACC0 = 0.0f;
        fACC1 = 0.0f;

        for (i = 0; i < mdct_np; i++)
        {
          fACC0 += ((frx1[i] * (*fptr_cos)) -  (frx2[i] * (*fptr_sin)));
          fACC1 += ((frx2[i] * (*fptr_cos++)) + (frx1[i] * (*fptr_sin++)));
        }
        *fptr_x1 = fACC0 * 2.0f;
        *fptr_x2 = fACC1 * 2.0f;

        fptr_x1 += mdct_npp;
        fptr_x2 += mdct_npp;
      }
    }

	else                        /* IFFT */
    {
      for (ip = 0; ip < mdct_np; ip++)
      {

        /* Set Overflow to 0 to test it after radix 5 with Q15 sin & cos coef */
        /* keep pointer's position on cos & sin tables */

        fACC0 = 0.0f;
        fACC1 = 0.0f;

        for (i = 0; i < mdct_np; i++)
        {
          fACC0 += ((frx1[i] * (*fptr_cos)) + (frx2[i] * (*fptr_sin)));
		  fACC1 += ((frx2[i] * (*fptr_cos++)) - (frx1[i] * (*fptr_sin++)));
        }
        *fptr_x1 = fACC0 / 2.0f;
        *fptr_x2 = fACC1 / 2.0f;

        fptr_x1 += mdct_npp;
        fptr_x2 += mdct_npp;
      }                         /* end for ip */
    }
  }                             /* end for ipp */


  /***************************************************************************
   * mapping for the output indices                                          *
   ***************************************************************************/
  fptr_x1 = ftab_x1;
  fptr_x2 = ftab_x2;
  ptr_map = mdct_tab_map2;

  for (ip = 0; ip < mdct_np; ip++)
  {
    for (ipp = 0; ipp < mdct_npp; ipp++)
    {
      i = (Short) * ptr_map++;
      fx1[i] = *fptr_x1++;
      fx2[i] = *fptr_x2++;
    }
  }
  free(ftab_x1);
  free(ftab_x2);
  free(frx1);
  free(frx2);

  return;
}


