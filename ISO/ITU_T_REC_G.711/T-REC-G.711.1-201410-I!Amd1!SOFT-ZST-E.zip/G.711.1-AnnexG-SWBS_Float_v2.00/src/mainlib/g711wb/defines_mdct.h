/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: defines_mdct.h
 *  Function: MDCT constants
 *------------------------------------------------------------------------
 */

#ifndef DEFINES_MDCT_H
#define DEFINES_MDCT_H

/* constants for MDCT and inverse MDCT */
#define MDCT_L_WIN          80
#define MDCT_L_WIN2         40
#define MDCT_L_WIN4         20
#define MDCT_NP              5
#define MDCT_EXP_NPP         2
#define MDCT_NB_REV          1
#define MDCT_NPP            (1<<MDCT_EXP_NPP)

#define MDCT2_L_WIN        160
#define MDCT2_L_WIN2        80
#define MDCT2_L_WIN4        40

/* constants for MDCT and inverse MDCT in PCMSWB coder */
#define MDCT2_NP             5
#define MDCT2_EXP_NPP        3
#define MDCT2_EXP_NB_REV     2
#define MDCT2_NPP           (1<<MDCT2_EXP_NPP)	
#define MDCT2_SBARYSZ (1 << (MDCT2_EXP_NPP-1))	

#endif /* DEFINES_MDCT_H */
