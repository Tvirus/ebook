/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"


/*----------------------------------------------------------------
  Function:
    Mu-law expansion of gain, 8bit, u=255
  Return value
    Reconstructed value in linear scale
  ----------------------------------------------------------------*/
Short mulawinv (
  Short  index
) {
  Short  mantissa;
  Short  exponent;
  Short  logbuf;
  Short  linbuf;

  logbuf = index & 0x00ff;

  if (logbuf < 4) {
    linbuf = logbuf & 0x0003;
  }
  else {
    logbuf -= 3;
    exponent = (logbuf >> 5) & 0x0007;
    mantissa = logbuf & 0x001f;
    linbuf = (((mantissa << 2) + 130) << exponent) - 130;
  }

  return linbuf;
}
