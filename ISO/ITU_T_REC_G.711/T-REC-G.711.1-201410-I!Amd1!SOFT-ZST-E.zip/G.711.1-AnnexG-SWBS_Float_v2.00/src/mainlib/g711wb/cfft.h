/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: cfft.h
 *  Function: complex FFT headers
 *------------------------------------------------------------------------
 */

#ifndef CFFT_H
#define CFFT_H

#include <stdio.h>

/* Functions : */

void f_cfft ( Float * x1, Float * x2, Short sign );

void f_cfft_point80(
  Float * x1,   /* (i/o) real part of data                 */
  Float * x2,   /* (i/o) imaginary part of data            */
  Short   sign  /* (i) flag to select FFT (1) or IFFT (-1) */
);

/* Tables : */

extern const Short MDCT_tab_maps[MDCT_NP*MDCT_NPP];
extern const Short MDCT_tab_map2s[MDCT_NP*MDCT_NPP];
extern const Short MDCT_tab_rev_is[MDCT_NB_REV];
extern const Short MDCT_tab_rev_ipps[MDCT_NB_REV];
extern const Float MDCT_rw1f[MDCT_L_WIN4];
extern const Float MDCT_rw2f[MDCT_L_WIN4];
extern const Float MDCT_xcosf[25];
extern const Float MDCT_xsinf[25];
extern const Float MDCT_wcosf[MDCT_L_WIN4];

extern const Float MDCT_xcos_swbf[25];
extern const Float MDCT_xsin_swbf[25];
extern const Float MDCT_rw1_tbl_swbf[MDCT2_SBARYSZ];  
extern const Float MDCT_rw2_tbl_swbf[MDCT2_SBARYSZ];  

extern const Short MDCT_tab_map_swbs[MDCT2_NP*MDCT2_NPP];
extern const Short MDCT_tab_map2_swbs[MDCT2_NP*MDCT2_NPP];
extern const Short MDCT_tab_rev_ipp_swbs[MDCT2_EXP_NB_REV];
extern const Short MDCT_tab_rev_i_swbs[MDCT2_EXP_NB_REV];


#endif /* CFFT_H */
