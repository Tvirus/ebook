/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies
---------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "dsputil.h"

#include <math.h>

/*----------------------------------------------------------------
Function:
Finds number of shifts to normalize a 16-bit array variable.
Return value
Number of shifts
----------------------------------------------------------------*/
Short    ExpSArray(
                     Short     n,     /* (i): Array size   */
                     Short  *sx    /* (i): Data array   */
                     )
{
  Short     k;
  Short     exp;
  Short  sMax;
  Short  sAbs;

  sMax = (Short)fabs( sx[0] ); 

  for ( k = 1; k < n; k++ )
  {
    sAbs = (Short)fabs( sx[k] );
    sMax = (Short)max( sMax, sAbs );
  }

  exp = norm_s( sMax );
  return exp;
}

void movS_ext(
               Short  n,     /* I : */
               Short  *sx,   /* I : */
               Short  m,     /* I : */
               Short  *sy,   /* O : */
               Short  l      /* I : */
               )
{
  Short k;

  for ( k = 0; k < n; k++ )
  {
    *sy = *sx; 
    sx += m;
    sy += l;
  }
}

Short norm_s (Short var1)
{
    Short var_out;

    if (var1 == 0)
    {
        var_out = 0;
    }
    else
    {
        if (var1 == (Short) 0xffff)
        {
            var_out = 15;
        }
        else
        {
            if (var1 < 0)
            {
                var1 = ~var1;
            }
            for (var_out = 0; var1 < 0x4000; var_out++)
            {
                var1 <<= 1;
            }
        }
    }
    return (var_out);
}

Short norm_l (Word32 L_var1)
{
    Short var_out;

    if (L_var1 == 0)
    {
        var_out = 0;
    }
    else
    {
        if (L_var1 == (Word32) 0xffffffffL)
        {
            var_out = 31;
        }
        else
        {
            if (L_var1 < 0)
            {
                L_var1 = ~L_var1;
            }
            for (var_out = 0; L_var1 < (Word32) 0x40000000L; var_out++)
            {
                L_var1 <<= 1;
            }
        }
    }
    return (var_out);
}
