/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#ifndef _BIT_OP_H_
#define _BIT_OP_H_

#ifndef _STDLIB_H_
#include <stdlib.h>
#endif

#include "floatutil.h"


Short GetBit( unsigned short **pBit, Short nbits );  /*defined at the end of this file */

long s_GetBitLong(
                  unsigned short **pBit,/* i/o: pointer on address of next bit */
                  Short nbits           /* i:   number of bits of code         */
                  );

void s_PushBit(Short code,Short **pBit,Short nbits);

void s_PushBitLong(
                 long code,       /* i:   codeword                       */
                 Short **pBit,    /* i/o: pointer on address of next bit */
                 Short nbits       /* i:   number of bits of code         */
                 );

#endif
