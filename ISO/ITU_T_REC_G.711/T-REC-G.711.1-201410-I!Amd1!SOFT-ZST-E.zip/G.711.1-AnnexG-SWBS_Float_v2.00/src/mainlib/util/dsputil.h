/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies
---------------------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#ifndef DSPUTIL_H
#define DSPUTIL_H

#ifndef _STDLIB_H_
#include <stdlib.h>
#endif

#include "floatutil.h"

Short ExpSArray(Short n, Short  *sx);

void   movS_ext(Short n, Short *sx, Short m, Short *sy, Short l);

Short norm_s (Short var1);

Short norm_l (Word32 L_var1);
#endif
