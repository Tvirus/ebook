/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include <math.h>
#include "bit_op.h"
#include "g711enh.h"
#include "softbit.h"
#include "bwe.h"

#include "g711enh_table.h"



#define ENCODER_OK  0
#define ENCODER_NG  1

#define INV_N_FR_FREQ    26214
#define INV_N_FR_FREQ_F  0.0125


static void search_pulses(Float* spec, Short* pos, Short* sign, Float* mag_vec, Short rms_index);
static Short pmag_vq(Float* vec);



void hbe_bitalloc( Short* expi, Short* bit_alloc )
{
  Short  i, tmp;
  Short  bit_reservoir, acc_cnt_bit, thresh_expi, alloc_bit_tmp;
  Short  cnt_exp[MAX_HB_EXP_POS], *p_cnt_exp = cnt_exp + MAX_HB_ENH_BITS, *p_tmp;	
  Short  cnt_bit[MAX_HB_EXP_POS], *p_cnt_bit = cnt_bit + MAX_HB_ENH_BITS;	
  Short  exp_tab_pos[L_FRAME_NB], exp_sort[L_FRAME_NB];
  Short  offset[MAX_HB_EXP];

  zeroS( L_FRAME_NB, exp_tab_pos);
  zeroS( L_FRAME_NB, exp_sort);
  zeroS( MAX_HB_EXP, offset);


  /* initialization */
  bit_reservoir = 21;
  zeroS (L_FRAME_NB, bit_alloc);
  zeroS (MAX_HB_EXP_POS, cnt_exp);
  zeroS (MAX_HB_EXP_POS, cnt_bit);

  /* Bucket sort */ 
  /* count number of each expi */
  for(i=0; i<L_FRAME_NB; i++)
  {
    p_cnt_exp[expi[i]] += 1;
  }

  /* calculate offset */
  offset[MAX_HB_EXP_1] = 0;
  p_tmp = &p_cnt_exp[MAX_HB_EXP_1];
  for(i=MAX_HB_EXP_2; i>=0; i--)
  {
    offset[i] = offset[i+1] + *(p_tmp--);	
  }

  /* sorting */
  for(i=0; i<L_FRAME_NB; i++)
  {
    exp_sort[offset[expi[i]]] = expi[i];
    exp_tab_pos[offset[expi[i]]] = i;
    offset[expi[i]] += 1;
  }

  /* Bit allocation */
  /* count the total amount of bits for each expi */
  for(i=0; i<L_FRAME_NB; i++)
  {
    p_cnt_bit[exp_sort[i]] += 1;
    tmp = exp_sort[i] - 1;
    p_cnt_bit[tmp] += 1;
    tmp = exp_sort[i] - 2;
	p_cnt_bit[tmp] += 1;
  }

  /* extract threshold of expi */
  acc_cnt_bit = p_cnt_bit[MAX_HB_EXP_1];
  thresh_expi = MAX_HB_EXP;
  for(i=MAX_HB_EXP_2; i>MINUS_MAX_HB_ENH_BITS; i--)
  {
    if( acc_cnt_bit > bit_reservoir )
    {
      acc_cnt_bit -= p_cnt_bit[i+1];
      thresh_expi = i + 1;
      break;
    }
    acc_cnt_bit += p_cnt_bit[i];
  }

  /* compute bit allocation */
  for(i=0; i<L_FRAME_NB; i++)
  {
    if( exp_sort[i] <= thresh_expi){break;}

	if( (Short)MAX_HB_ENH_BITS <= (exp_sort[i] - thresh_expi))
      alloc_bit_tmp = (Short)MAX_HB_ENH_BITS;
	else
      alloc_bit_tmp = (exp_sort[i] - thresh_expi);
    bit_alloc[exp_tab_pos[i]] = alloc_bit_tmp;
    bit_reservoir = bit_reservoir - alloc_bit_tmp;

    if( alloc_bit_tmp != MAX_HB_ENH_BITS )
    {
      expi[exp_tab_pos[i]] = thresh_expi;
    }
  }

  for(i=0; bit_reservoir>0; i++)
  {
    if( expi[i] == thresh_expi && bit_alloc[i] < MAX_HB_ENH_BITS ) 
    {
      bit_alloc[i] += 1;
      bit_reservoir -= 1;
    }
  }
  return;
}




void g711el1_encode (
                     const Float*  ffSpectrum,		/* (i): Input MDCT coefficient in mid-band          */
                     const Float*  ffQspectrum,		/* (i): Local decoded MDCT coefficient in mid-band  */
                     unsigned short* bstr_buff		/* (o): Output bitstream in soft bit format        */
                     )
{
	Short i, j;
	Float fEspectrum[L_FRAME_NB];
	Float *p_ftmp;
	Float fmax_d,fe_err,fdtmp;
	Float flog_rms;
	Float fmag_vec[3];
	Float fe_qx[L_FRAME_NB], fp_x_qx[L_FRAME_NB];
	Short max_i = 0;
    Short rms_index;
	Short pos[3], sign[3];
	Short pmag_idx;
	Short idx_g;
	Short max_exp;
	Short exp[L_FRAME_NB], bitalloc[L_FRAME_NB];
	Short e_idx, s_idx;
	
	unsigned short *pBit_g;

	zeroS( L_FRAME_NB, exp);
	zeroS( L_FRAME_NB, bitalloc);
	zeroF( L_FRAME_NB, fe_qx);
	zeroF( L_FRAME_NB, fp_x_qx);
	zeroF( L_FRAME_NB, fEspectrum);
	zeroF( 3 , fmag_vec );
	zeroS( 3 , pos );
	zeroS( 3 , sign );

	/* initialization */
	pBit_g = bstr_buff;

	for(i = 0; i < L_FRAME_NB; i++)
	{
		fEspectrum[i] = ffSpectrum[i] - ffQspectrum[i];
	}
	
	p_ftmp = fEspectrum;
	fmax_d = 1.175494351e-38f;

	for(i = 0; i < 4; i++)
	{
		fe_err = p_ftmp[0] * p_ftmp[0];
		for(j = 1; j < 10; j++)
		{
			fe_err += (p_ftmp[j] * p_ftmp[j]);
		}
		p_ftmp += 10;	
		if( fmax_d < fe_err )
		{
			fmax_d = fe_err;
			max_i = i;
		}
	}
	
	s_PushBit (max_i, (unsigned short **)(&pBit_g), 2);        /* store subband index */

	/* set subband boundaries */
	s_idx = sb_bound[max_i][0];
	e_idx = sb_bound[max_i][1];

	/* log_rms = (1/2)log2(max_d/10) */
	if(fmax_d == 0.0f)
	{
		rms_index = -8;
	}
	else
	{
		flog_rms = (1.0f/2.0f)*f_Log2(fmax_d/10.0f);
		rms_index = roundFto16( flog_rms );
		if( rms_index < -8 )
		{
			rms_index = -8;
		}
		else if( rms_index > 7 )
		{
			rms_index = 7;
		}
	}
	s_PushBit ((rms_index+8), (unsigned short **)(&pBit_g), 4);  /* store rms index */

	p_ftmp = fEspectrum + s_idx;
	search_pulses(p_ftmp, pos, sign, fmag_vec, rms_index);

	/* store positions, signs and magnitudes */
	for(i = 0; i < 3; i++)
	{
		s_PushBit(pos[i], (unsigned short **)(&pBit_g), 2);
		s_PushBit(sign[i], (unsigned short **)(&pBit_g), 1);
	}
	pmag_idx = pmag_vq(fmag_vec);
	s_PushBit(pmag_idx, (unsigned short **)(&pBit_g), 4);

	for(i=0; i<L_FRAME_NB; i++)
	{
		fe_qx[i]   = ffQspectrum[i] * ffQspectrum[i];
		fp_x_qx[i] = ffSpectrum[i] * ffQspectrum[i];
	}

	/* Bit allocation */
	max_exp = MAX_HB_EXP;
	for(i=0; i<L_FRAME_NB; i++)
	{
		exp[i] = max_exp - Fnorme16(ffQspectrum[i]);
		if( exp[i] >= MAX_HB_EXP ){
			exp[i] = MAX_HB_EXP - 1;
		}
		if( ffQspectrum[i] == 0.0f || exp[i] < 0 )
		{
			exp[i] = 0;
		}
	}

	/* force exp[k] to zero */
	for(i=0; i<3; i++)
	{
		j = (s_idx+i) + (pos[i]*3);
		exp[j] = 0;
	}

	hbe_bitalloc (exp, bitalloc);

	for(i=0; i<L_FRAME_NB; i++)
	{
		if(bitalloc[i] != 0)
		{
			/* for addressing */
			fmax_d = (f_sg2[bitalloc[i]][0] * fp_x_qx[i]) - (f_sge[bitalloc[i]][0] * fe_qx[i]);
			idx_g = 0;

			/* for addressing */
			for(j=1; j<ncb_alloc[bitalloc[i]]; j++)
			{
				fdtmp = (f_sg2[bitalloc[i]][j] * fp_x_qx[i]) - (f_sge[bitalloc[i]][j] * fe_qx[i]);
				if( fdtmp > fmax_d )
				{
					fmax_d = fdtmp;
					idx_g = j;
				}
			}
			s_PushBit (idx_g, (unsigned short **)(&pBit_g), bitalloc[i]);
		}
	}
} 


static void search_pulses(Float* spec,
                          Short* pos,
                          Short* sign,
                          Float* mag_vec,
                          Short rms_index)
{
  Float *ptr0, *ptr1;
  Float magi;
  Short  posi;
  Float inv_rms_q;
  Float tmp;

  Short i, j;

  inv_rms_q = (Float)(1 << (7-rms_index)) / 128.0f;
  /* search max and its position in each track */
  ptr0 = spec;
  for(i = 0; i < 3; i++)
  {
    ptr1 = ptr0++;
    posi = 0;
    magi = abs_f(*ptr1);
    ptr1 += 3;
    for(j = 1; j < 4; j++)
    {
      tmp = abs_f(*ptr1);
      if( magi < tmp ){
        posi = j;
      }
      magi = f_max(magi, tmp);
      ptr1 += 3;
    }
    /* mag_vec[i] = log10(pmag[0] * inv_rms_q) */
    if(magi != 0)
    {
		mag_vec[i] = (Float)log10(magi * inv_rms_q);
    }
    pos[i] = posi;
    j = i + ((posi << 1) + posi);
    sign[i] = 1;
    if(spec[j] < 0) 
    {
      sign[i] = (Short)0;
    }
  }
  return;
}



static Short pmag_vq(Float* vec)
{
	Float dist;
    Float tmp;
    Float min_dist = 3.402823466e+38f;
	Short min_idx = 0;
	Short i, j;
	Float *pcbk = (Float *)f_pmag_cbk;

  for(i = 0; i < 16; i++)
  {
    dist = 0.0f;

    for(j = 0; j < 3; j++)
    {
      tmp = vec[j] - pcbk[j];
      dist += (tmp * tmp);
    }

    if( dist < min_dist )
    {
      min_dist = dist;
      min_idx = i;
    }

    pcbk += 3;
  }
  return min_idx;
}
