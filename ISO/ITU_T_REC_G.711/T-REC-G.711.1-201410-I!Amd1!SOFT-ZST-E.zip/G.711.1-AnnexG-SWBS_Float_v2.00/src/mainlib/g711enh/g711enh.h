/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#ifndef __G711ENH_H__
#define __G711ENH_H__

/*------------------------------------------------------------------------*
* Defines
*------------------------------------------------------------------------*/
#define MAX_HB_EXP      32
#define MAX_HB_ENH_BITS 3
#define MAX_HB_EXP_POS  (MAX_HB_EXP+MAX_HB_ENH_BITS)	
#define MAX_NCB_GAIN    (1<<MAX_HB_ENH_BITS)	

#define MAX_HB_EXP_1      31
#define MAX_HB_EXP_2      30
#define MINUS_MAX_HB_ENH_BITS  -3

/*------------------------------------------------------------------------*
* Prototypes
*------------------------------------------------------------------------*/
void g711el1_encode (
                     const Float*  ffSpectrum,  /* (i): Input MDCT coefficient in mid-band          */
                     const Float*  ffQspectrum, /* (i): Local decoded MDCT coefficient in mid-band  */
                     unsigned short* bstr_buff  /* (o): Output bitstream in soft bit format         */
                     );

void g711el1_decode (
                     const Short* bstr_buff,  /* (i): Input bitstream in soft bit format     */
                     const Float* fQspectrum, /* (i): Input MSCT coefficients of mid-band    */
                     Float*       fmdct_corr, /* (o): Correction factors of MDCT coefficient */
                     Float*       fsb_err,    /* (o) */
                     Short*       s_idx,
                     Short*       e_idx
                     );

void hbe_bitalloc ( Short*, Short* );

#endif  /* __G711ENH_H__ */
