/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#ifndef __G711ENH_TABLE_H__
#define __G711ENH_TABLE_H__


extern const Float f_pmag_cbk[];
extern Float f_sg2[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];
extern Float f_sge[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];
extern Float f_sgain[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];

extern Short sb_bound[4][2];
extern Short ncb_alloc[MAX_HB_ENH_BITS+1];

#endif	/* __G711ENH_TABLE_H__ */
