/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "g711enh.h"
#include "softbit.h"
#include "bwe.h"
#include "g711enh_table.h"


#define DECODER_OK  2
#define DECODER_NG  3

extern const Float f_pmag_cbk[3*16];


void g711el1_decode (
                     const Short* bstr_buff,  /* (i): Input bitstream in soft bit format     */
                     const Float* fQspectrum, /* (i): Input MSCT coefficients of mid-band    */
                     Float*       fmdct_corr, /* (o): Correction factors of MDCT coefficient */
                     Float*       fsb_err,    /* (o) */
                     Short*       s_idx,
                     Short*       e_idx
                     )
{
	Float f_rms_q;
	Short i;
	unsigned short *pBit_g;
	Short rms_index;
	Short pos[3], sign[3];
	Short exp[L_FRAME_NB], bitalloc[L_FRAME_NB];
	Short pos_idx;
	Short pmag_idx;
	Short idx_g, max_exp;
	Short max_i;
	Float *f_pcbk;

	zeroS( L_FRAME_NB, exp);
	zeroS( L_FRAME_NB, bitalloc);

	/* initialization */
	pBit_g = (unsigned short *) bstr_buff;

	/* selected subband decoding */
	max_i = GetBit ((unsigned short **)(&pBit_g), 2);
	*s_idx = sb_bound[max_i][0];		
	*e_idx = sb_bound[max_i][1];

	/* rms decoding */
	rms_index = GetBit((unsigned short **)(&pBit_g), 4);
	
	f_rms_q = 0.00390625f * Pow( 2.0f , (Float)rms_index);

	for(i = 0; i < 3; i++)
	{
		pos[i] = GetBit((unsigned short **)(&pBit_g), 2);
		sign[i] = GetBit((unsigned short **)(&pBit_g), 1);
		if (sign[i] == 0) {
			sign[i] = (Short)-1;	
		}
	}
	pmag_idx = GetBit((unsigned short **)(&pBit_g), 4) * 3;
	f_pcbk = (Float*)(f_pmag_cbk + pmag_idx);

	for(i = 0; i < 3; i++)
	{
		pos_idx = (pos[i]*3) + i;    /* pos[i] = 3 * pos[i] + i */
		fsb_err[pos_idx] = Pow(10.0f , *f_pcbk) * f_rms_q * (Float)sign[i];
		pos[i] = *s_idx + pos_idx;
		f_pcbk++;
	}
 
	/* Bit allocation */
	max_exp = MAX_HB_EXP;
	for(i=0; i<L_FRAME_NB; i++)
	{
		exp[i] = max_exp - Fnorme16(fQspectrum[i]);
		if( exp[i] >= MAX_HB_EXP ){
			exp[i] = MAX_HB_EXP - 1;
		}
		if (fQspectrum[i] == 0.0f || exp[i] < 0)
		{
			exp[i] = 0;
		}
	}
	
	for(i = 0; i < 3; i++)
	{
		pos_idx = pos[i];
		exp[pos_idx] = 0;
	}

	hbe_bitalloc(exp, bitalloc);

	for(i=0; i<L_FRAME_NB; i++)
	{
		fmdct_corr[i] = 1.0f;

		if(bitalloc[i] != 0)
		{
			idx_g = GetBit ((unsigned short **)(&pBit_g), bitalloc[i]);
			fmdct_corr[i] = f_sgain[bitalloc[i]][idx_g];
		}
	}
	
	for(i = 0; i < 3; i++)
	{
		pos_idx = pos[i];
		fmdct_corr[pos_idx] = 1.0f;		/* (to be converted) the Q-facor of mdct_corr[] is not available */
	}
}

