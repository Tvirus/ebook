/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#ifndef PCMSWB_H
#define PCMSWB_H

/*------------------------------------------------------------------------*
* Defines
*------------------------------------------------------------------------*/
#define MODE_R1nm    2 /* G.711        ,  NB,  64k (=R1) */
#define MODE_R2nm    5 /* G.711.1      ,  NB,  80k (=R2a) */
#define MODE_R2wm    6 /* G.711.1      ,  WB,  80k (=R2b) */
#define MODE_R3wm    8 /* G.711.1      ,  WB,  96k (=R3) */
#define MODE_R3sm    9 /* G.711.1      , SWB,  96k [R2wm+16k] */
#define MODE_R4sm   10 /* G.711.1      , SWB, 112k [R2wm+16k*2] */
#define MODE_R4ssm  11 /* G.711.1      , SWB, 112k [R3wm+16k] */
#define MODE_R5ssm  12 /* G.711.1      , SWB, 128k [R3wm+16k*2] */
#ifdef LAYER_STEREO
#define MODE_R4ss   13 /* G.711.1      , SWB stereo, 112k [R3sm + 16 kbit/s stereo layer] */
#define MODE_R5ss   14 /* G.711.1      , SWB stereo, 128k [R4sm + 16 kbit/s stereo layer] */
#define MODE_R6ss   15 /* G.711.1      , SWB stereo, 144k [R4sm + 2x16 kbit/s stereo layer] */
#define MODE_R6sss  16 /* G.711.1      , SWB stereo, 144k [R4*sm + 2x16 kbit/s stereo layer] */
#define MODE_R7sss  17 /* G.711.1      , SWB stereo, 160k [R5*sm + 2x16 kbit/s stereo layer] */
#define MODE_R3ws   18 /* G.711.1      ,  WB stereo,  96k [R2wm + 16 kbit/s stereo layer] */
#define MODE_R5sws  19 /* G.711.1      ,  WB stereo, 128k [R3wm + 2x16 kbit/s stereo layer] */
#endif
/* G.711.1 aliases */
#define MODE_R1      2 /* G.711        ,  NB,  64k */
#define MODE_R2a     5 /* G.711.1      ,  NB,  80k */
#define MODE_R2b     6 /* G.711.1      ,  WB,  80k */
#define MODE_R3      8 /* G.711.1      ,  WB,  96k */

#define  MODE_ULAW           1
#define  MODE_ALAW           2

#define  G711ULAW_CORE       100
#define  G711ALAW_CORE       200

#define  G711ULAW_CORE_80    400
#define  G711ALAW_CORE_80    500
#define  G711ULAW_CORE_96    600
#define  G711ALAW_CORE_96    700

#define NBITS_MODE_R1nm  320 /* G.711      , NB, 64k (=R1) */
#define NBITS_MODE_R2nm  400 /* G.711.1    , NB, 80k (=R2a) */
#define NBITS_MODE_R2wm  400 /* G.711.1    , WB, 80k (=R2b) */
#define NBITS_MODE_R3wm  480 /* G.711.1    , WB, 96k (=R3) */
#define NBITS_MODE_R3sm  480 /* G.711.1    ,SWB, 96k [R2wm+16k] */
#define NBITS_MODE_R4sm  560 /* G.711.1    ,SWB,112k [R2wm+16k*2] */
#define NBITS_MODE_R4ssm 560 /* G.711.1    ,SWB,112k [R3wm+16k] */
#define NBITS_MODE_R5ssm 640 /* G.711.1    ,SWB,128k [R3wm+16k*2] */
#ifdef LAYER_STEREO
#define NBITS_MODE_R3ws  480 /* G.711.1  ,  WB stereo,  96k [R2wm + 16 kbit/s stereo layer] */
#define NBITS_MODE_R5sws 640 /* G.711.1  ,  WB stereo, 128k [R3wm + 2x16 kbit/s stereo layer] */
#define NBITS_MODE_R4ss  560 /* G.711.1  , SWB stereo, 112k [R3sm + 16 kbit/s stereo layer] */
#define NBITS_MODE_R5ss  640 /* G.711.1  , SWB stereo, 128k [R4sm + 16 kbit/s stereo layer] */
#define NBITS_MODE_R6ss  720 /* G.711.1  , SWB stereo, 144k [R4sm + 2x16 kbit/s stereo layer] */
#define NBITS_MODE_R6sss 720 /* G.711.1  , SWB stereo, 144k [R4*sm + 2x16 kbit/s stereo layer] */
#define NBITS_MODE_R7sss 800 /* G.711.1  , SWB stereo, 160k [R5*sm + 2x16 kbit/s stereo layer] */
#endif
/* G.711.1 aliases */
#define NBITS_MODE_R1    320 /* G.711      , NB, 64k */
#define NBITS_MODE_R2a   400 /* G.711.1    , NB, 80k */
#define NBITS_MODE_R2b   400 /* G.711.1    , WB, 80k */
#define NBITS_MODE_R3    480 /* G.711.1    , WB, 96k */

#define  NSamplesPerFrame08k  40   /* Number of samples a frame in 8kHz  */
#define  NSamplesPerFrame16k  80   /* Number of samples a frame in 16kHz */
#define  NSamplesPerFrame32k 160   /* Number of samples a frame in 32kHz */

#define  NBytesPerFrame_G711WB_0     40   /* G.711.1 Subcodec 0 */
#define  NBytesPerFrame_G711WB_1     10   /* G.711.1 Subcodec 1 */
#define  NBytesPerFrame_G711WB_2     10   /* G.711.1 Subcodec 2 */
#define  NBytesPerFrame_SWB_0         5   /* SWB Subcodec 0 */
#define  NBytesPerFrame_SWB_1        10   /* SWB Subcodec 1 */
#define  NBytesPerFrame_SWB_2        10   /* SWB Subcodec 2 */

#define  NBitsPerFrame_G711WB_0      (NBytesPerFrame_G711WB_0*8)	
#define  NBitsPerFrame_G711WB_1      (NBytesPerFrame_G711WB_1*8)	
#define  NBitsPerFrame_G711WB_2      (NBytesPerFrame_G711WB_2*8)	
#define  NBitsPerFrame_SWB_0         (NBytesPerFrame_SWB_0*8)	
#define  NBitsPerFrame_SWB_1         (NBytesPerFrame_SWB_1*8)	
#define  NBitsPerFrame_SWB_2         (NBytesPerFrame_SWB_2*8)	

#define  NBYTEPERFRAME_MAX   NBytesPerFrame0 /* Max value of NBytesPerFrameX */
#ifdef LAYER_STEREO
#define  MaxBytesPerFrame  (NBytesPerFrame_G711WB_0+NBytesPerFrame_G711WB_1+NBytesPerFrame_G711WB_2+NBytesPerFrame_SWB_1+NBytesPerFrame_SWB_2 + 20)
#else
#define  MaxBytesPerFrame  (NBytesPerFrame_G711WB_0+NBytesPerFrame_G711WB_1+NBytesPerFrame_G711WB_2+NBytesPerFrame_SWB_1+NBytesPerFrame_SWB_2)
#endif
#define  MaxBitsPerFrame   (MaxBytesPerFrame*8)	

#define  L_DELAY_COMP_MAX  250 /* need to be considered */

#define NBitsPerFrame_EL1 40
#define NBitsPerFrame_SWBL2   40

#define NTAP_QMF_WB   32
#define QMF_DELAY_WB  (NTAP_QMF_WB-2)

#define NTAP_QMF_SWB  (NTAP_QMF_WB)
#define QMF_DELAY_SWB (QMF_DELAY_WB)

/*------------------------------------------------------------------------*
* Prototypes
*------------------------------------------------------------------------*/
void* pcmswbEncode_const(unsigned short sampf, int core, int mode
#ifdef LAYER_STEREO
                        ,short channel
#endif
	);
void  pcmswbEncode_dest(void* p_work);
int   pcmswbEncode_reset(void* p_work);
int   pcmswbEncode( const short* inwave, unsigned char* bitstream, void* p_work );

void* pcmswbDecode_const(int core, int mode);
void  pcmswbDecode_dest(void* p_work);
int   pcmswbDecode_reset(void* p_work);
int   pcmswbDecode(
#ifdef LAYER_STEREO
                      unsigned char*  bitstream,   /* (i):   Input bitstream  */
#else
	                  const unsigned char* bitstream, 
#endif
					  short* outwave, void* p_work, int ploss_status
#ifdef LAYER_STEREO
                     ,short *highest_mode
#endif       
					  );
int   pcmswbDecode_set(int mode, void*  p_work);

#endif  /* PCMSWB_H */
