/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "errexit.h"
#include "pcmswb_common.h"
#include "softbit.h"
#include "qmfilt.h"
#include "G711WB_lowband.h"
#include "G711WB_highband.h"
#include "bwe.h"
#include "avq.h"
#ifdef LAYER_STEREO
#include "stereo_tools.h"
#include "g711_stereo.h"
#include "floatutil.h"
#include "dsputil.h"
#endif

#define OK  0
#define NG  1

typedef struct {
  Short Mode;                   /* Decoding mode */
  Short OpFs;                   /* Sampling frequency */
  Float f_gain_ns;              /* Noise shaping gain */
  void* G711WB_SubDecoderL;     /* Work space for G.711.1 lower-band */
  void* G711WB_SubDecoderH;     /* Work space for G.711.1 higher-band */
  void* SubDecoderSH;           /* Work space for super-higher-band sub-decoder */
  void* SubDecoderBWE;          /* Work space for 8kbps swb extension */
  void* pQMFBuf_SWB;            /* QMF filter buffer for SWB */
  void* pQMFBuf_WB;             /* QMF filter buffer for WB */
  Float f_DiffMDCTCoefHigh[16]; /* Differential MDCT coefficients in G.711.1 higher-band */
  Short prev_Mode;
  Short prev2_Mode;
  Short prev_ploss_status;
  Float f_sattenu;
  Float f_sattenu1;
  Float f_sattenu3;
  Float f_prev_fenv[8];
  Short prev_bit_switch_flag, bit_switch_count;
  Short bit_switch_status;
#ifdef LAYER_STEREO
    void*  G711_stereo_SubDecoder; /* Work space for G.711.1 stereo decoder */
    void*  pQMFBuf_left_SWB;        /* QMF filter buffer for SWB */
    void*  pQMFBuf_right_SWB;        /* QMF filter buffer for SWB */
    Short frame_idx;
    Short BW_flag;
    Short channel;
    Short rs_stereo_mono_counter;
    Short stereo_fec_counter;
#endif
} pcmswbDecoder_WORK;

/*----------------------------------------------------------------
Function:
PCM SWB decoder constructor
Return value:
Pointer to work space
----------------------------------------------------------------*/
void *pcmswbDecode_const(
  int core,  /* (i): Core mode (G711ALAW_CORE/G711ULAW_CORE) */
  int mode   /* (i): Decoding mode                             */
)
{
  pcmswbDecoder_WORK *w=NULL;
  Short law;

  /* Static memory allocation */
  w = (void *)malloc( sizeof(pcmswbDecoder_WORK) );
  if ( w == NULL )  return NULL;

  w->Mode = (Short) mode;
  w->prev_Mode = -1;
  w->prev2_Mode = -1;
#ifdef LAYER_STEREO
    w->channel = 1; 
    w->rs_stereo_mono_counter = 0; 
    w->stereo_fec_counter = 0; 
#endif
  if( core != G711ULAW_CORE && core != G711ALAW_CORE ){
    error_exit("Core specification error.");
  }

  switch(w->Mode) {
  case MODE_R1nm  : w->OpFs =  8000; break;
  case MODE_R2nm  : w->OpFs =  8000; break;
  case MODE_R2wm  : w->OpFs = 16000; break;
  case MODE_R3wm  : w->OpFs = 16000; break;
  case MODE_R3sm  : w->OpFs = 32000; break;
  case MODE_R4sm  : w->OpFs = 32000; break;
  case MODE_R4ssm : w->OpFs = 32000; break;
  case MODE_R5ssm : w->OpFs = 32000; break;
#ifdef LAYER_STEREO
  case MODE_R3ws  : w->OpFs = 16000;w->channel = 2; break;
  case MODE_R5sws : w->OpFs = 16000;w->channel = 2; break;
  case MODE_R4ss  : w->OpFs = 32000;w->channel = 2; break;
  case MODE_R5ss  : w->OpFs = 32000;w->channel = 2; break;
  case MODE_R6ss  : w->OpFs = 32000;w->channel = 2; break;
  case MODE_R6sss : w->OpFs = 32000;w->channel = 2; break;
  case MODE_R7sss : w->OpFs = 32000;w->channel = 2; break;
#endif
  default : error_exit("Decoding mode error.");
  }

  law = MODE_ULAW;
  if( core == G711ALAW_CORE )
  {
    law = MODE_ALAW;
  }

  w->G711WB_SubDecoderL = lowband_decode_const(law);
  if (w->G711WB_SubDecoderL == NULL)  error_exit( "G.711.1 lower band decoder init error." );

  w->G711WB_SubDecoderH = highband_decode_const();
  if (w->G711WB_SubDecoderH == NULL)  error_exit( "G.711.1 higher band decoder init error." );

  w->pQMFBuf_WB = QMFilt_const(NTAP_QMF_WB, fSWBQmf0, fSWBQmf1);
  if (w->pQMFBuf_WB == NULL)  error_exit( "G.711.1 QMF init error." );

  w->pQMFBuf_SWB = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
  if (w->pQMFBuf_SWB == NULL)  error_exit( "SWB QMF init error." );

  w->SubDecoderBWE = bwe_decode_const();
  if (w->SubDecoderBWE == NULL)  error_exit( "BWE decoder init error." );

  if (w->Mode >= MODE_R3sm)
  {
    w->SubDecoderSH = avq_decode_const();
    if (w->SubDecoderSH == NULL) error_exit( "AVQ decoder init error." );
  }
#ifdef LAYER_STEREO
    w->G711_stereo_SubDecoder = g711_stereo_decode_const();
    w->frame_idx = 0;
    w->pQMFBuf_left_SWB  = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
    w->pQMFBuf_right_SWB = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
    if ( w->pQMFBuf_left_SWB == NULL || w->pQMFBuf_right_SWB == NULL)  error_exit( "QMF init error." );
#endif
  pcmswbDecode_reset( (void *)w );

  return (void *)w;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder set mode and output SF in bitrateswitch mode
Return value:
Pointer to work space
----------------------------------------------------------------*/
int pcmswbDecode_set(
  int mode,    /* (i): Decoding mode */
  void* p_work /* (i/o): Work space  */
)
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

  w->Mode = mode;
#ifndef LAYER_STEREO
  w->OpFs = 32000;
#endif
  return OK;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder destructor
Return value:
None
----------------------------------------------------------------*/
void pcmswbDecode_dest(
  void* p_work  /* (i): Work space */
)
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

  if( w != NULL ) {
    lowband_decode_dest( w->G711WB_SubDecoderL );  /* LB for WB   */
    highband_decode_dest( w->G711WB_SubDecoderH ); /* HB for WB   */
    QMFilt_dest( w->pQMFBuf_WB );                  /* QMF for WB  */
    QMFilt_dest( w->pQMFBuf_SWB );                 /* QMF for SWB */
    bwe_decode_dest( w->SubDecoderBWE );           /* BWE for SWB */
    if( w->Mode >= MODE_R3sm )
    {
      avq_decode_dest (w->SubDecoderSH);           /* AVQ for SWB */
    }
#ifdef LAYER_STEREO
    g711_stereo_decode_dest( w->G711_stereo_SubDecoder);
    QMFilt_dest( w->pQMFBuf_left_SWB );               /* QMF for SWB */
    QMFilt_dest( w->pQMFBuf_right_SWB );              /* QMF for SWB */    
#endif
    free( w );
  }
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder reset
Return value:
OK
----------------------------------------------------------------*/
int pcmswbDecode_reset(
  void* p_work  /* (i/o): Work space */
)
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

  if (w != NULL) {
    lowband_decode_reset( w->G711WB_SubDecoderL );  /* LB for WB   */
    highband_decode_reset( w->G711WB_SubDecoderH ); /* HB for WB   */
    QMFilt_reset( w->pQMFBuf_WB );                  /* QMF for WB  */
    QMFilt_reset( w->pQMFBuf_SWB );                 /* QMF for SWB */
    bwe_decode_reset( w->SubDecoderBWE );           /* BWE for SWB */
    if( w->Mode >= MODE_R3sm )
    {
      avq_decode_reset (w->SubDecoderSH);           /* AVQ for SWB */
    }

    w->f_gain_ns = 1.0f;
    w->f_sattenu = 0.1f;
    w->f_sattenu1 = 0.1f;
    w->f_sattenu3 = 1.0f;
    w->prev_ploss_status = 0;
    w->prev_bit_switch_flag = 0;
    w->bit_switch_count = 0;
    w->bit_switch_status = 0;
    zeroF(16, w->f_DiffMDCTCoefHigh);
    zeroF(8, w->f_prev_fenv);
#ifdef LAYER_STEREO
    g711_stereo_decode_reset( w->G711_stereo_SubDecoder );
    QMFilt_reset( w->pQMFBuf_left_SWB );            /* QMF for SWB */
    QMFilt_reset( w->pQMFBuf_right_SWB );           /* QMF for SWB */
    w->BW_flag = 0;
#endif
  }

  return OK;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder
Return value:
OK/NG
----------------------------------------------------------------*/
int pcmswbDecode(
#ifdef LAYER_STEREO
  unsigned char*  bitstream,   /* (i):   Input bitstream  */
#else
  const unsigned char* bitstream,   /* (i):   Input bitstream  */
#endif
  Short*               outwave,     /* (o):   Output signal    */
  void*                p_work,      /* (i/o): Work space       */
  int                  ploss_status /* (i):   Packet-loss flag */
#ifdef LAYER_STEREO
 ,short*                highest_mode
#endif
) 
{
  unsigned char  *bpt = (unsigned char  *)bitstream, *bptmp;
  Short i, n;
  Float f_SubSigSuperWideLowQMF[L_FRAME_WB];  /*  0- 8 kHz signal (80 points) */

  Float f_SubSigSuperWideHighQMF[L_FRAME_WB]; /*  8-14 kHz signal (80 points) */
  Float f_SubSigLow[L_FRAME_NB];              /*  0- 4 kHz signal (40 points) */
  Float f_SubSigHigh[L_FRAME_NB];             /*  4- 8 kHz signal (40 points) */
  Float f_nb_sig[L_FRAME_NB];
  Float f_outwave[L_FRAME_SWB];

  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

  unsigned short bst_buff[NBitsPerFrame_SWB_1];
  unsigned short bst_buff2[NBitsPerFrame_SWB_2];
  unsigned short *pBit_BWE, *pBit_SVQ, *pBit_SVQ2;
  unsigned short *pBit_MB, *pBit_MB2;
  Short index_g, cod_Mode, T_modify_flag;
  Short bit_switch_flag;
  Short ploss_status_buff;
  Short layers_SWB;
  Float f_nb_mdct[L_FRAME_NB];
  Float f_Tenv_SWB[SWB_TENV];

  Float f_coef_SWB[SWB_F_WIDTH];

  Float f_Fenv_SVQ[SWB_NORMAL_FENV];
  Float f_gain;
  Float f_powerL, f_powerH;
#ifdef LAYER_STEREO
  Float f_mono_dec[80];

  Short syn_left_wb_s[L_FRAME_WB],syn_right_wb_s[L_FRAME_WB],syn_left[L_FRAME_SWB],syn_right[L_FRAME_SWB];

  Float f_syn_left_swb_s[L_FRAME_WB],f_syn_right_swb_s[L_FRAME_WB],f_syn_left_wb_s[L_FRAME_WB],f_syn_right_wb_s[L_FRAME_WB],f_syn_left[L_FRAME_SWB],f_syn_right[L_FRAME_SWB];

  Short bpt_stereo_swb[160]; 
  Short SWB_WB_flag;
  Float temp_mem_left[G711_WB_DMX_DELAY],temp_mem_right[G711_WB_DMX_DELAY];
  Short st_swb2wb;
  Short stereo_mono_flag;
  st_swb2wb = 0;
  stereo_mono_flag = 0;
#endif
  /* initialize */
  f_gain = 1.0f;
  layers_SWB = 0;
  bit_switch_flag = 0;
  ploss_status_buff = 0;
  zeroS(NBitsPerFrame_SWB_1, (Short*)bst_buff);
  zeroS(NBitsPerFrame_SWB_2, (Short*)bst_buff2);
  zeroF(L_FRAME_NB, f_nb_mdct);
  zeroF(SWB_TENV, f_Tenv_SWB);
  zeroF(SWB_F_WIDTH, f_coef_SWB);
  zeroF(SWB_NORMAL_FENV, f_Fenv_SVQ);

  if (p_work == NULL)
  {
      return NG;
  }

  zeroF(L_FRAME_NB, f_SubSigHigh); 
  zeroF(L_FRAME_WB, f_SubSigSuperWideHighQMF);
  zeroF(L_FRAME_SWB, f_outwave);

#ifdef LAYER_STEREO
    if(w->channel == 2)
    {
        w->stereo_fec_counter++;
        if(ploss_status == 0)
        {
            w->stereo_fec_counter = 0; 
        }
        if(w->stereo_fec_counter >= INIT_STEREO_MONO_FEC)
        {
            zeroS(20,((g711_stereo_decode_WORK *)(w->G711_stereo_SubDecoder))->pre_ild_q);
        }
        stereo_mono_flag = 1; 

        switch (*highest_mode)
        {
        case MODE_R3ws:
            if(w->Mode <= MODE_R2wm) /* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    w->Mode = MODE_R3ws; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        case MODE_R4ss:
            if(w->Mode <= MODE_R3sm)/* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    if(w->Mode <= MODE_R2wm)
                    {
                        st_swb2wb = 1; 
                    }
                    w->Mode = MODE_R4ss; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        case MODE_R5sws:
            if(w->Mode <= MODE_R3wm)/* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    w->Mode = MODE_R5sws; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        case MODE_R6sss:
            if(w->Mode <= MODE_R4ssm)/* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    if(w->Mode <= MODE_R3wm)
                    {
                        st_swb2wb = 1; 
                    }
                    w->Mode = MODE_R6sss; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        case MODE_R7sss:
            if(w->Mode <= MODE_R5ssm)/* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    if(w->Mode <= MODE_R3wm)
                    {
                        st_swb2wb = 1; 
                    }
                    w->Mode = MODE_R7sss; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        default:
            if(w->Mode <= MODE_R4sm)/* mono */
            {
                w->rs_stereo_mono_counter++;
                stereo_mono_flag = 0; 
                if(w->prev_Mode >= 0) /* not first frame */
                {
                    if(w->Mode <= MODE_R2wm)
                    {
                        st_swb2wb = 1; 
                    }
                    w->Mode = MODE_R5ss; 
                }
            }
            else
            {
                w->rs_stereo_mono_counter = 0; 
            }
            break;
        }

        if (w->Mode == MODE_R3ws)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2;
            hardbit2softbit(10, bptmp, bpt_stereo_swb );
        }
        if (w->Mode == MODE_R4ss)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1;
            hardbit2softbit(10, bptmp, bpt_stereo_swb );
        }
        if (w->Mode == MODE_R5ss)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2;
            hardbit2softbit(10, bptmp, bpt_stereo_swb );
        }
        if (w->Mode == MODE_R6ss)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2;
            hardbit2softbit(20, bptmp, bpt_stereo_swb );
        }
        if(w->Mode == MODE_R5sws)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2;
            hardbit2softbit(20, bptmp, bpt_stereo_swb );
        }
        if(w->Mode == MODE_R6sss)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1;
            hardbit2softbit( 20, bptmp, bpt_stereo_swb );
        }
        if(w->Mode == MODE_R7sss)
        {
            bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2;
            hardbit2softbit( 20, bptmp, bpt_stereo_swb );
        }

        switch (*highest_mode)
        {
        case MODE_R3ws:
            if(stereo_mono_flag == 0)
            {
                if((w->prev_Mode < 0) || (w->rs_stereo_mono_counter >= INIT_STEREO_MONO)) /* first frame or after 100 frames switched from stereo to mono */
                {
                    w->Mode = MODE_R3ws; 
                    movSS(5, (Short *)initial_switch3, (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2));
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2;
                    hardbit2softbit( 10, bptmp, bpt_stereo_swb );
                }
            }
            break;
        case MODE_R4ss:
            if(stereo_mono_flag == 0)
            {
                if(w->prev_Mode < 0) /* first frame */
                {
                    w->Mode = MODE_R4ss; 
                    movSS(5, (Short *)initial_switch, (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2));
                    movSS(5, (Short *)(initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2), 
                        (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1)); 
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1;
                    hardbit2softbit( 10, bptmp, bpt_stereo_swb );
                }
                else if(w->rs_stereo_mono_counter >= INIT_STEREO_MONO)
                {
                    hardbit2softbit( 10, initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2, bpt_stereo_swb );
                }
            }
            break;
        case MODE_R5sws:
            if(stereo_mono_flag == 0)
            {
                if(w->prev_Mode < 0) /* first frame */
                {
                    w->Mode = MODE_R5sws; 
                    movSS(10, (Short *)(initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2), (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2));
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2;
                    hardbit2softbit( 20, bptmp, bpt_stereo_swb );
                }
                else if(w->rs_stereo_mono_counter >= INIT_STEREO_MONO)
                {
                    hardbit2softbit( 20, initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2, bpt_stereo_swb );
                }
            }
            break;
        case MODE_R6sss:
            if(stereo_mono_flag == 0)
            {
                if(w->prev_Mode < 0) /* first frame */
                {
                    w->Mode = MODE_R6sss; 
                    movSS(5, (Short *)(initial_switch), (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2));
                    movSS(10, (Short *)(initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2), (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1));
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1;
                    hardbit2softbit( 20, bptmp, bpt_stereo_swb );
                }
                else if(w->rs_stereo_mono_counter >= INIT_STEREO_MONO)
                {
                    hardbit2softbit( 20, initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2, bpt_stereo_swb );
                }
            }
            break;
        case MODE_R7sss:
            if(stereo_mono_flag == 0)
            {
                if(w->prev_Mode < 0) /* first frame */
                {
                    w->Mode = MODE_R7sss; 
                    movSS(20, (Short *)(initial_switch), (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2));
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2;
                    hardbit2softbit( 20, bptmp, bpt_stereo_swb );
                }
                else if(w->rs_stereo_mono_counter >= INIT_STEREO_MONO)
                {
                    hardbit2softbit( 20, initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2, bpt_stereo_swb );
                }
            }
            break;
        default:
            if(stereo_mono_flag == 0)
            {
                if(w->prev_Mode < 0) /* first frame */
                {
                    w->Mode = MODE_R5ss; 
                    movSS(20, (Short *)initial_switch, (Short *)(bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2));
                    bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2 + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2;
                    hardbit2softbit( 20, bptmp, bpt_stereo_swb );
                }
                else if(w->rs_stereo_mono_counter >= INIT_STEREO_MONO)
                {
                    hardbit2softbit( 20, initial_switch + NBytesPerFrame_SWB_1 + NBytesPerFrame_SWB_2, bpt_stereo_swb );
                }
            }
            break;
        }

        if(ploss_status == 0)
        {
            read_index1( bpt_stereo_swb, &SWB_WB_flag);

            if((w->Mode == MODE_R6ss || w->Mode == MODE_R5ss || w->Mode == MODE_R4ss || w->Mode == MODE_R6sss
                || w->Mode == MODE_R7sss) && (*highest_mode > 0))/* swb */
            {
                SWB_WB_flag = 1; 
            }
            else if(w->Mode == MODE_R5sws && (*highest_mode > 0)) /* wb */
            {
                SWB_WB_flag = 0; 
            }
            w->BW_flag = SWB_WB_flag; 
            if(SWB_WB_flag == 0)
            {
                w->OpFs = 16000; 
            }
        }
        else
        {
            SWB_WB_flag = w->BW_flag;
        }
    }
#endif

  /* ------------------------------------------- */
  /* Super higher-band enhancement layer decoder */
  /* ------------------------------------------- */
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R3sm  ||  /* G.711.1 */
        w->Mode == MODE_R4sm  ||  /* G.711.1 */
        w->Mode == MODE_R4ssm ||  /* G.711.1 */
        w->Mode == MODE_R5ssm || /* G.711.1 */
        w->Mode == MODE_R4ss  ||  /* G.711.1 */
        w->Mode == MODE_R5ss  ||  /* G.711.1 */
        w->Mode == MODE_R6ss  || /* G.711.1 */      
        w->Mode == MODE_R6sss ||  /* G.711.1 */
        w->Mode == MODE_R7sss)   
#else
  if (w->Mode == MODE_R3sm || w->Mode == MODE_R4sm || w->Mode == MODE_R4ssm || w->Mode == MODE_R5ssm)
#endif
  {
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R3sm || w->Mode == MODE_R4sm || w->Mode == MODE_R4ss || w->Mode == MODE_R5ss || w->Mode == MODE_R6ss) { /* G.711.1 CORE (R2b) */
#else
    if (w->Mode == MODE_R3sm || w->Mode == MODE_R4sm){
#endif
      bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2;
    }
    else{ /* w->Mode == MODE_R4ssm || w->Mode == MODE_R5ssm */ /* G.711.1 CORE (R3) */
      bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2; 
    }
    hardbit2softbit(NBytesPerFrame_SWB_1, bptmp, bst_buff);

    pBit_BWE = bst_buff;
    pBit_MB = bst_buff + NBITS_MODE_R1SM_BWE;

    /* extract mode information */
    cod_Mode = 0;
    if (bst_buff[0] == G192_BITONE)
    {
      cod_Mode = 2;
    }
    if (bst_buff[1] == G192_BITONE)
    {
      cod_Mode += 1;
    }

    /* decode 6.4-8kHz subband for mid-band */
    if (cod_Mode != TRANSIENT)
    {
        g711el0_decode_AVQ_flt (pBit_MB , w->f_DiffMDCTCoefHigh , pBit_BWE);
    }
#ifdef LAYER_STEREO
        if (w->Mode == MODE_R4sm  ||
            w->Mode == MODE_R5ssm ||
            w->Mode == MODE_R5ss  ||
            w->Mode == MODE_R6ss  ||
            w->Mode == MODE_R7sss)
#else
    if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm)
#endif
    {
        bptmp += NBytesPerFrame_SWB_1;
        hardbit2softbit (NBytesPerFrame_SWB_2, bptmp, bst_buff2);
    }
    pBit_MB2 = bst_buff2;
  }

  /* --------------------------------------------------------------------- */
  /* G.711.1 lower-band decoder including both core and enhancement layers */
  /* Frame erasure concealment is integrated in the decoder.               */
  /* --------------------------------------------------------------------- */
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R2a   ||
        w->Mode == MODE_R3    ||
        w->Mode == MODE_R4ssm ||
        w->Mode == MODE_R5ssm ||
        w->Mode == MODE_R5sws ||
        w->Mode == MODE_R6sss ||
        w->Mode == MODE_R7sss) {
#else
  if (w->Mode == MODE_R2a || w->Mode == MODE_R3 || w->Mode == MODE_R4ssm || w->Mode == MODE_R5ssm) {
#endif
    lowband_decode(bpt, bpt+NBytesPerFrame_G711WB_0, ploss_status, f_SubSigLow, &f_gain, w->G711WB_SubDecoderL, f_nb_sig);
    bpt += (NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1);
  }
  else { /* w->Mode == MODE_R1 || w->Mode == MODE_R2b || w->Mode == MODE_R3sm || w->Mode == MODE_R4sm */
    /* Core layer only */
    /* When the second parameter is NULL, this decoder works as G.711 decoder. */
    lowband_decode( bpt, NULL, ploss_status, f_SubSigLow, &f_gain, w->G711WB_SubDecoderL, f_nb_sig );
    bpt += NBytesPerFrame_G711WB_0;
  }

  /* --------------------------------------------- */
  /* G.711.1 higher-band enhancement layer decoder */
  /* --------------------------------------------- */
#ifdef LAYER_STEREO
    if (w->Mode >= MODE_R2b) {
#else
  if (w->Mode == MODE_R2b || w->Mode == MODE_R3 || w->Mode == MODE_R3sm ||
      w->Mode == MODE_R4sm || w->Mode == MODE_R4ssm || w->Mode == MODE_R5ssm) {
#endif
		if (ploss_status != 0)
		{
		  /* Get the LB pitch for HB FERC */
		  copy_lb_pitch(w->G711WB_SubDecoderL, w->G711WB_SubDecoderH);
		}
#ifdef LAYER_STEREO
        if (w->Mode == MODE_R2b || w->Mode == MODE_R3 || w->Mode == MODE_R3ws || w->Mode == MODE_R5sws)
#else
        if (w->Mode == MODE_R2b || w->Mode == MODE_R3)
#endif
		{
		  zeroF( 16 , w->f_DiffMDCTCoefHigh );
		  cod_Mode = -1;
		}
		bit_switch_flag = 0;

        if (w->prev_Mode >= 0)
        {
#ifdef LAYER_STEREO
          if((w->Mode < MODE_R3sm && w->prev_Mode >= MODE_R3sm && (w->prev_Mode - MODE_R3sm) <= 3) || st_swb2wb)
#else
          if (w->Mode < MODE_R3sm && w->prev_Mode >= MODE_R3sm)
#endif
		  {
			bit_switch_flag = 1;
		  }
#ifdef LAYER_STEREO
          if(w->Mode >= MODE_R3sm && (w->Mode - MODE_R3sm) <= 3 && w->prev2_Mode < MODE_R3sm)
#else
          if (w->Mode >= MODE_R3sm && w->prev2_Mode < MODE_R3sm)
#endif
		  {
			bit_switch_flag = 2;
		  }
        }

    highband_decode( bpt, ploss_status, f_SubSigHigh, w->G711WB_SubDecoderH,
      cod_Mode, f_nb_mdct , w->f_DiffMDCTCoefHigh, (const Short*)pBit_MB2, w->Mode,
      bit_switch_flag, w->f_sattenu);
    bpt += NBytesPerFrame_G711WB_2;
  }

  /* --------------------- */
  /* Band reconstructing   */
  /* --------------------- */
  if (w->OpFs == 8000) {
    movF(L_FRAME_NB, f_SubSigLow, f_outwave);
  }
  else if (w->OpFs == 16000) {
#ifdef LAYER_STEREO
        if(w->channel == 1)
        {
#endif
			/* Band reconstructing with QMF */
			QMFilt_syn(L_FRAME_NB, f_SubSigLow, f_SubSigHigh, f_outwave, w->pQMFBuf_WB);
#ifdef LAYER_STEREO
        }
        else
        {
            QMFilt_syn(L_FRAME_NB, f_SubSigLow, f_SubSigHigh, f_mono_dec, w->pQMFBuf_WB );

            /*Apply Noise Gate to decoded mono*/
            f_powerL = 0;
            f_powerH = 0;
            for ( i = 0; i < L_FRAME_NB; i++ )
            {
                Float tmp;
                tmp = (Float)roundFto16(f_SubSigLow[i]);
				f_powerL += abs_f(tmp);
				tmp = (Float)roundFto16(f_SubSigHigh[i]);
				f_powerH += abs_f(tmp);
			}
			if ((f_gain < 1.0f) && (f_powerH > 800) && (0.0625f * f_powerH > f_powerL))
			{
			    f_gain = 1.0f;
			}
  
            for (i = 0; i < L_FRAME_WB; ++i) {
                w->f_gain_ns = 0.989319f * w->f_gain_ns + 0.010681f * (f_gain + 1.52587890625e-05f);
      
                if (w->f_gain_ns < 1.0f)
                {
                    f_mono_dec[i] = f_mono_dec[i] * w->f_gain_ns;
			    }
			}

            g711_stereo_decode(&bpt_stereo_swb[1], f_mono_dec, syn_left_wb_s,syn_right_wb_s, w->G711_stereo_SubDecoder, 
                               w->Mode,SWB_WB_flag ,ploss_status,0, stereo_mono_flag);
            interleave( syn_left_wb_s, syn_right_wb_s, outwave, L_FRAME_WB );
        }
#endif
  }
  else { /* w->OpFs == 32000 */
    /* Band reconstructing with QMF */
    QMFilt_syn(L_FRAME_NB, f_SubSigLow, f_SubSigHigh, f_SubSigSuperWideLowQMF, w->pQMFBuf_WB);
#ifdef LAYER_STEREO
    if ((w->Mode >= MODE_R3sm && w->Mode <= (MODE_R3sm + 8)) || (w->prev_Mode >= MODE_R3sm && w->prev_Mode <= (MODE_R3sm + 8)))
#else
    if (w->Mode >= MODE_R3sm || w->prev_Mode >= MODE_R3sm)
#endif
    {
      if (w->prev_Mode < 0)
      {
        w->prev2_Mode = w->Mode;
        w->bit_switch_count = 0;
      }
#ifdef LAYER_STEREO
      else if((w->Mode < MODE_R3sm && w->prev_Mode >= MODE_R3sm && (w->prev_Mode - MODE_R3sm) <= 3) || st_swb2wb)
#else
      else if (w->Mode < MODE_R3sm && w->prev_Mode >= MODE_R3sm)
#endif
      {
        w->prev2_Mode = w->Mode;
        bit_switch_flag = 1;
        w->bit_switch_count++;
      }
#ifdef LAYER_STEREO
      else if(w->Mode >= MODE_R3sm && (w->Mode - MODE_R3sm) <= 3 && w->prev2_Mode < MODE_R3sm)
#else
      else if (w->Mode >= MODE_R3sm && w->prev2_Mode < MODE_R3sm)
#endif
      {
        bit_switch_flag = 2;
        w->bit_switch_count = 0;
      }
      else
      {
        w->bit_switch_count = 0;
      }

      /* BWE decoding from SWBL0 */
      pBit_BWE = bst_buff;
      cod_Mode = NORMAL;
#ifdef LAYER_STEREO
      if(w->Mode >= MODE_R3sm && (w->Mode - MODE_R3sm) <= 8)
#else
      if (w->Mode >= MODE_R3sm)
#endif
      {
        unsigned short *pBit = pBit_BWE;
        cod_Mode = GetBit(&pBit, 2);
      }
      ploss_status_buff = ploss_status;
      if (w->prev_ploss_status == 1 && cod_Mode <= 1)
      {
        ploss_status = 1;
      }

      T_modify_flag = bwe_dec_freqcoef(&pBit_BWE, f_nb_sig, w->SubDecoderBWE,
        &cod_Mode, f_Tenv_SWB, f_coef_SWB, &index_g, f_Fenv_SVQ, f_nb_mdct,
        ploss_status, bit_switch_flag, w->prev_bit_switch_flag);

      /* AVQ decoding from SWBL1&2 */
#ifdef LAYER_STEREO
      if (w->Mode >= MODE_R3sm && (w->Mode - MODE_R3sm) <= 8)
#else
      if (w->Mode >= MODE_R3sm)
#endif
      {
        if (ploss_status == 0 && w->bit_switch_status == 0)
        {    
          layers_SWB = 1;
#ifdef LAYER_STEREO
          if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm || w->Mode == MODE_R5ss || w->Mode == MODE_R6ss || w->Mode == MODE_R7sss)
#else
          if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm)
#endif
          {
            layers_SWB = 2;
          }
          pBit_SVQ = bst_buff + NBITS_MODE_R1SM_TOTLE;    
          pBit_SVQ2 = bst_buff2 + NBitsPerFrame_EL1;

          swbl1_decode_AVQ((void*)w->SubDecoderSH, pBit_SVQ, pBit_SVQ2, (const Float*)f_Fenv_SVQ,
            f_coef_SWB, index_g, cod_Mode, layers_SWB);
          w->prev_ploss_status = 0;
        }
        else
        {
          bwe_avq_buf_reset(w->SubDecoderSH);
          w->prev_ploss_status = 1;
          if (ploss_status_buff == 0)
          {
            AVQ_state_dec *wtmp = w->SubDecoderSH;
            w->prev_ploss_status = 0;
            wtmp->pre_cod_Mode = cod_Mode;
          }
        }
      }

      if (bit_switch_flag == 1)
      {
        for (i=0 ; i<60 ; i++)
        {
          f_coef_SWB[i] = f_coef_SWB[i] * w->f_sattenu3;
        }
        if (w->bit_switch_count > 200)
        {
          w->f_sattenu3 -= 0.02f;
        }
        w->f_sattenu3 = f_max(w->f_sattenu3, 0.5f);
      }
      else
      {
        w->f_sattenu3 = 1.0f;
      }

      if (bit_switch_flag == 2)
      {
        for (i=0 ; i<60 ; i++)
        {
          f_coef_SWB[i] = f_coef_SWB[i] * w->f_sattenu;
        }
        w->f_sattenu += 0.02f;
        w->prev2_Mode = MODE_R2wm;
        if (w->f_sattenu > 1.0f)
        {
          w->f_sattenu = 0.1f;
          bit_switch_flag = 0;
          w->prev2_Mode = w->Mode;
        }
      }

      if (bit_switch_flag == 0)
      {
        if (w->prev_bit_switch_flag == 1)
        {
          w->f_sattenu1 = 0.1f;
        }
      }
      else
      {
        if (w->f_sattenu1 < 1.0f)
        {
          for (i=0 ; i<60 ; i++)
          {
            f_coef_SWB[i] = f_coef_SWB[i] * w->f_sattenu1;
          }
          w->f_sattenu1 += 0.02f;
        }
      }

      /* BWE-based post-processing */
#ifdef LAYER_STEREO
      if (w->channel == 1)
#endif
      bwe_dec_timepos(cod_Mode, f_Tenv_SWB, f_coef_SWB, f_SubSigSuperWideHighQMF,
        w->SubDecoderBWE, ploss_status, T_modify_flag);
    }
#ifdef LAYER_STEREO
        if (w->channel == 2)
        {
            g711_stereo_decode_WORK *ptr = (g711_stereo_decode_WORK *)w->G711_stereo_SubDecoder;
            BWE_state_dec *dec_st = (BWE_state_dec *)w->SubDecoderBWE;
            Short flag = 0;

            /*Apply Noise Gate to decoded mono*/
			f_powerL = 0;
			f_powerH = 0;
			for ( i = 0; i < L_FRAME_NB; i++ )
			{
				Float tmp;
				tmp = (Float)roundFto16(f_SubSigLow[i]);
				f_powerL += abs_f(tmp);
				tmp = (Float)roundFto16(f_SubSigHigh[i]);
				f_powerH += abs_f(tmp);
			}
			if ((f_gain < 1.0f) && (f_powerH > 800) && (0.0625f * f_powerH > f_powerL))
			{
				f_gain = 1.0f;
			}

			n = (w->OpFs == 8000) ? L_FRAME_NB : L_FRAME_WB;
			for (i = 0; i < n; ++i) {
			  w->f_gain_ns = 0.989319f * w->f_gain_ns + 0.010681f * (f_gain + 1.52587890625e-05f);
      
			  if (w->f_gain_ns < 1.0f)
			  {
				  f_SubSigSuperWideLowQMF[i] = f_SubSigSuperWideLowQMF[i] * w->f_gain_ns;
			  }
			}

            g711_stereo_decode(&bpt_stereo_swb[1], f_SubSigSuperWideLowQMF, syn_left_wb_s,syn_right_wb_s, 
                               w->G711_stereo_SubDecoder,w->Mode, SWB_WB_flag, ploss_status, cod_Mode, 
                               stereo_mono_flag);

            g711_stereo_decoder_shb(&bpt_stereo_swb[75], f_coef_SWB, f_syn_left_swb_s, f_syn_right_swb_s,
                                    w->G711_stereo_SubDecoder, ploss_status, w->Mode);
            /*post process for stereo*/
            if((dec_st->pre_mode == TRANSIENT && ptr->pre_swb_ILD_mode == 1)|| ptr->swb_ILD_mode == 1)
            {
                flag = 1;
            }

            if(cod_Mode == TRANSIENT)
            {
                if(flag == 0)
                {
                    if (ptr->delay < 0)
                    {
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_left_swb_s,  w->SubDecoderBWE, T_modify_flag, 1, 0, ptr->c1_swb[0]);
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_right_swb_s, w->SubDecoderBWE, T_modify_flag, 0, -ptr->delay,ptr->c2_swb[0]);
                    }
                    else
                    {
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_left_swb_s,  w->SubDecoderBWE, T_modify_flag, 1, ptr->delay,ptr->c1_swb[0]);
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_right_swb_s, w->SubDecoderBWE, T_modify_flag, 0, 0,ptr->c2_swb[0]);  
                    }
                }
                else/*ild transient*/
                {
                    if (ptr->c1_swb[0] > ptr->c2_swb[0])
                    {
                        /*post process for only left channel*/
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_left_swb_s, w->SubDecoderBWE, T_modify_flag, 1, 0,ptr->c1_swb[0]);
                        /*update the memory for right channel*/
                        T_Env_Postprocess(f_syn_right_swb_s, dec_st->right_tPre_s); 
                        for(i=0; i<SWB_T_WIDTH; i+=2)
                        {
                            f_syn_right_swb_s[i] = -f_syn_right_swb_s[i];
                        }
                        /* copy decoded sound data to output buffer */
                        movF( HALF_SUB_SWB_T_WIDTH, &f_syn_right_swb_s[SWB_T_WIDTH-HALF_SUB_SWB_T_WIDTH], dec_st->right_tPre_s );
                    }
                    else
                    {
                        /*update the memory for left channel*/
                        T_Env_Postprocess(f_syn_left_swb_s, dec_st->left_tPre_s); 
                        for(i=0; i<SWB_T_WIDTH; i+=2)
                        {
                            f_syn_left_swb_s[i] = -f_syn_left_swb_s[i];
                        }
                        /* copy decoded sound data to output buffer */
                        movF( HALF_SUB_SWB_T_WIDTH, &f_syn_left_swb_s[SWB_T_WIDTH-HALF_SUB_SWB_T_WIDTH], dec_st->left_tPre_s );
                        /*post process for only right channel*/
                        stereo_dec_timepos(cod_Mode,f_Tenv_SWB, f_syn_right_swb_s, w->SubDecoderBWE, T_modify_flag, 0, 0,ptr->c2_swb[0]);
                    }
                }
            }
            else
            {
                /*only update the memory for both channels*/
                T_Env_Postprocess(f_syn_left_swb_s, dec_st->left_tPre_s); 
                for(i=0; i<SWB_T_WIDTH; i+=2)
                {
                    f_syn_left_swb_s[i] = -f_syn_left_swb_s[i];
                }
                movF( HALF_SUB_SWB_T_WIDTH, &f_syn_left_swb_s[SWB_T_WIDTH-HALF_SUB_SWB_T_WIDTH], dec_st->left_tPre_s );

                T_Env_Postprocess(f_syn_right_swb_s, dec_st->right_tPre_s); 
                for(i=0; i<SWB_T_WIDTH; i+=2)
                {
                    f_syn_right_swb_s[i] = -f_syn_right_swb_s[i];
                }
                /* copy decoded sound data to output buffer */
                movF( HALF_SUB_SWB_T_WIDTH, &f_syn_right_swb_s[SWB_T_WIDTH-HALF_SUB_SWB_T_WIDTH], dec_st->right_tPre_s );

                dec_st->pre_mode = cod_Mode;
            }
            ptr->pre_swb_ILD_mode = ptr->swb_ILD_mode; 

            for (i = 0; i< G711_WB_DMX_DELAY; i++)
            {
                temp_mem_left[i]  = f_syn_left_swb_s[L_FRAME_WB - G711_WB_DMX_DELAY + i]; 
                temp_mem_right[i] = f_syn_right_swb_s[L_FRAME_WB - G711_WB_DMX_DELAY + i];
            }

            for (i = (L_FRAME_WB-1); i >= G711_WB_DMX_DELAY; i--)
            {
                f_syn_left_swb_s[i]  = f_syn_left_swb_s[i-G711_WB_DMX_DELAY]; 
                f_syn_right_swb_s[i] = f_syn_right_swb_s[i-G711_WB_DMX_DELAY];
            }

            for (i = 0; i < G711_WB_DMX_DELAY; i++)
            {
                f_syn_left_swb_s[i]  = ptr->mem_left[i]; 
                f_syn_right_swb_s[i] = ptr->mem_right[i];
                ptr->mem_left[i]   = temp_mem_left[i]; 
                ptr->mem_right[i]  = temp_mem_right[i];
            }

			movSF(80, syn_left_wb_s, f_syn_left_wb_s);
			movSF(80, syn_right_wb_s, f_syn_right_wb_s);

            QMFilt_syn(L_FRAME_WB, f_syn_left_wb_s,  f_syn_left_swb_s,  f_syn_left,  w->pQMFBuf_left_SWB ); 
            QMFilt_syn(L_FRAME_WB, f_syn_right_wb_s, f_syn_right_swb_s, f_syn_right, w->pQMFBuf_right_SWB );

			movFS(160, f_syn_left, syn_left);
			movFS(160, f_syn_right, syn_right);

            interleave(syn_left, syn_right, outwave, L_FRAME_SWB );
        }
    else
    {
#endif 
    QMFilt_syn(L_FRAME_WB, f_SubSigSuperWideLowQMF, f_SubSigSuperWideHighQMF, f_outwave, w->pQMFBuf_SWB);

    movFS(L_FRAME_SWB, f_outwave, outwave);
#ifdef LAYER_STEREO
    } 
#else
    w->bit_switch_status = 0;
    if (w->Mode < MODE_R3sm)
    {
      w->bit_switch_status = 1;
    }
  
    if (bit_switch_flag == 1)
    {
      w->Mode = MODE_R3sm;
    }

    w->prev_Mode = w->Mode;
    w->prev_bit_switch_flag = bit_switch_flag;

    movF(8 , f_Fenv_SVQ, w->f_prev_fenv);
#endif
  }

#ifdef LAYER_STEREO
    w->bit_switch_status = 0;
    if (w->Mode < MODE_R3sm)
    {
      w->bit_switch_status = 1;
    }
  
    if (bit_switch_flag == 1)
    {
      w->Mode = MODE_R3sm;
    }

    w->prev_Mode = w->Mode;
    w->prev_bit_switch_flag = bit_switch_flag;

    movF(8 , f_Fenv_SVQ, w->f_prev_fenv);
  /* ---------------- */
  /* Apply Noise Gate */
  /* ---------------- */
    if(w->channel == 1)
    {
#endif
  if (w->OpFs == 8000 || w->OpFs == 16000) { /* Not operating in 32-kHz mode */
    if (w->OpFs == 16000)
    {
      f_powerL = 0;
      f_powerH = 0;
      for ( i = 0; i < L_FRAME_NB; i++ )
      {
        Float tmp;
        tmp = (Float)roundFto16(f_SubSigLow[i]);
        f_powerL += abs_f(tmp);
        tmp = (Float)roundFto16(f_SubSigHigh[i]);
        f_powerH += abs_f(tmp);
      }
      if ((f_gain < 1.0f) && (f_powerH > 800) && (0.0625f * f_powerH > f_powerL))
      {
        f_gain = 1.0f;
      }
    }
  
    n = (w->OpFs == 8000) ? L_FRAME_NB : L_FRAME_WB;
    for (i = 0; i < n; ++i) {
      w->f_gain_ns = 0.989319f * w->f_gain_ns + 0.010681f * (f_gain + 1.52587890625e-05f);
      
      if (w->f_gain_ns < 1.0f)
      {
          outwave[i] = roundFto16(f_outwave[i] * w->f_gain_ns);
      }
      else
      {
          outwave[i] = roundFto16(f_outwave[i]);
      }
    }
  }
#ifdef LAYER_STEREO
    }
#endif
  return OK;
}
