/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: prehpf.c
 *  Function: Pre-processing 1-tap high-pass filtering
 *            Cut-off (-3dB) frequency is approximately 50 Hz,
 *            if the recommended filt_no value is used.
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "prehpf.h"
#ifdef LAYER_STEREO
#include "dsputil.h"
#include "floatutil.h"
#include "stereo_tools.h"
#endif

#define Q_14  16384.0f

typedef struct {
  Float f_memx;
  Float f_memy;
} HPASSMEM;

/* Constructor */
void  *highpass_1tap_iir_const(void)  /* returns pointer to work space */
{
  HPASSMEM *hpmem;

  hpmem = (HPASSMEM *)malloc( sizeof(HPASSMEM) );

  if ( hpmem != NULL )
    highpass_1tap_iir_reset( (void *)hpmem );
  return (void *)hpmem;
}

/* Destructor */
void  highpass_1tap_iir_dest(void *ptr)
{
  HPASSMEM *hpmem = (HPASSMEM *)ptr;	
  if (hpmem != NULL )
  {
    free( hpmem );
  }
}

/* Reset */
void  highpass_1tap_iir_reset(void *ptr)
{
  HPASSMEM *hpmem = (HPASSMEM *)ptr;
  if (hpmem != NULL) {
    hpmem->f_memx = 0.0f;
    hpmem->f_memy = 0.0f;
  }
}

/* Filering */
void  highpass_1tap_iir(
  Short filt_no,  /* (i):   Filter cutoff specification. */
                  /*        Use 5 for 8-kHz input,       */
                  /*            6 for 16-kHz input,      */
                  /*            7 for 32-kHz input       */
  Short n,        /* (i):   Number of samples            */
  Short sigin[],  /* (i):   Input signal                 */
  Float sigout[], /* (o):   Output signal                */
  void  *ptr      /* (i/o): Work space                   */
) 
{
  Float   lAcc;
  int     k;
  Float   sigpre;
  Float   acc;
  HPASSMEM *hpmem = (HPASSMEM *) ptr;

  acc = hpmem->f_memy;
  sigpre = hpmem->f_memx;

  for (k = 0; k < n; k++) {
	/* y[k] = a * y[k-1] + x[k] - x[k-1] */
	lAcc = Floor( acc * Q_14 );
	lAcc = Floor( lAcc / Pow( 2.0f , (Float)filt_no )) / Q_14;
	acc = (Floor(acc * Q_14) - Floor(lAcc * Q_14)) / Q_14;
	acc = (Floor( acc * Q_14 ) + Floor( (Float)*sigin * Q_14 )) / Q_14;
	acc = (Floor( acc * Q_14 ) - Floor( sigpre * Q_14 )) / Q_14;
    sigpre = *sigin++;
	*sigout++ = (Float)roundFto16( acc );
  }
  hpmem->f_memx = sigpre;
  hpmem->f_memy = acc;
}
#ifdef LAYER_STEREO
void  highpass_1tap_iir_stereo(
                        Short  filt_no,  /* (i):   Filter cutoff specification. */
                        /*        Use 5 for 8-kHz input,       */
                        /*            6 for 16-kHz input,      */
                        /*            7 for 32-kHz input       */
                        Short  n,        /* (i):   Number of samples            */
                        Short  sigin[],  /* (i):   Input signal (Q0)            */
                        Float  sigout[], /* (o):   Output signal (Q0)           */
                        void    *ptr      /* (i/o): Work space                   */
                        ) 
{
  Short      k;

  Float lAcc; /* Q14 */

  HPASSMEM *hpmem = (HPASSMEM *)ptr;
  Short *ptr_sig,*ptr_sigpre;

  /* k = 0 */
  ptr_sig = sigin;

  lAcc = hpmem->f_memy * 0.9921875f + (*ptr_sig) - hpmem->f_memx;
    *sigout++ = roundFto16F(lAcc); 

  ptr_sigpre = ptr_sig++;
  for ( k = 1; k < n; k++ )
  {
    /* y[k] = a * y[k-1] + x[k] - x[k-1] */
    lAcc = lAcc * 0.9921875f + (*ptr_sig++ ) - (*ptr_sigpre++);
    *sigout++ = roundFto16F(lAcc);
  }

  hpmem->f_memx = *ptr_sigpre;
  hpmem->f_memy = lAcc;
}
#endif
