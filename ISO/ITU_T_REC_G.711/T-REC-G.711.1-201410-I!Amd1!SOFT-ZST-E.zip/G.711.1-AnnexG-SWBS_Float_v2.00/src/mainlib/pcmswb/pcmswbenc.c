/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "errexit.h"
#include "pcmswb_common.h"
#include "softbit.h"
#include "prehpf.h"
#include "qmfilt.h"
#include "G711WB_lowband.h"
#include "G711WB_highband.h"
#include "g711enh.h"
#include "bwe.h"
#include "avq.h"
#ifdef LAYER_STEREO
#include "g711_stereo.h"
#include "stereo_tools.h"
#include "stdio.h"
#endif

#define OK  0
#define NG  1

/* High-pass filter cutoff definition */
#define FILT_NO_8KHZ_INPUT   5
#define FILT_NO_16KHZ_INPUT  6
#define FILT_NO_32KHZ_INPUT  7

typedef struct {
  Short Mode;               /* Encoding mode */
  Short OpFs;               /* Sampling frequency */
  Float f_DCBuf[QMF_DELAY_WB];
  void* pHpassFiltBuf;      /* High-pass filter buffer */
  void* G711WB_SubEncoderL; /* Work space for G.711.1 lower-band */
  void* G711WB_SubEncoderH; /* Work space for G.711.1 higher-band */
  void* SubEncoderSH;       /* Work space for super-higher-band sub-encoder */
  void* SubEncoderBWE;      /* Work space for 8kbps swb extension */
  void* pQmfBuf_WB;         /* QMF buffer for G.711.1 */
  void* pQmfBuf_SWB;        /* QMF buffer for SWB input */
  Float f_DiffMDCTCoefHigh[16]; /* Differential MDCT coefficients in G.711.1 higher-band  */
  Float f_LocalDecDiffMDCTCoefHigh[16];
#ifdef LAYER_STEREO
  Short  frame_idx;
  Short  framelen;
  Short  channel;
  void*   G711_stereo_SubEncoder;    /* Work space for G.711.1 stereo encoder */
  void*   pQmfBuf_SWB_left;
  void*   pQmfBuf_SWB_right;
  void*   pHpassFiltBuf_L;      /* High-pass filter buffer for L channel */
  void*   pHpassFiltBuf_R;      /* High-pass filter buffer for R channel */
#endif
} pcmswbEncoder_WORK;

/*----------------------------------------------------------------
Function:
PCM SWB encoder constructor
Return value:
Pointer to work space
----------------------------------------------------------------*/
void *pcmswbEncode_const(
  unsigned short sampf, /* (i): Input sampling rate (Hz)                */
  int core,             /* (i): Core mode (G711ALAW_CORE/G711ULAW_CORE) */
  int mode              /* (i): Encoding mode                           */
#ifdef LAYER_STEREO
 ,Short channel
#endif
)
{
  pcmswbEncoder_WORK *w=NULL;
  Short law;

  /* Static memory allocation */
  w = (void *)malloc(sizeof(pcmswbEncoder_WORK));
  if (w == NULL)  return NULL;

  w->Mode = mode;
  w->OpFs = 32000; /* Input sampling rate is 32kHz in default */
  if (sampf == 8000)
  {
    w->OpFs = 8000; /* Input sampling rate is 8 kHz */
  }
  if (sampf == 16000)
  {
    w->OpFs = 16000; /* Input sampling rate is 16 kHz */
  }

  zeroF(QMF_DELAY_WB, w->f_DCBuf);
  if (core != G711ULAW_CORE && core != G711ALAW_CORE) {
    error_exit("Core specification error.");
  }
#ifdef LAYER_STEREO
  if ( w->Mode != MODE_R1nm  && w->Mode != MODE_R2nm  &&
       w->Mode != MODE_R2wm  && w->Mode != MODE_R3wm  &&
       w->Mode != MODE_R3sm  && w->Mode != MODE_R4sm  &&
       w->Mode != MODE_R4ssm && w->Mode != MODE_R5ssm && !((w->Mode - MODE_R5ssm) >= 1 && (w->Mode - MODE_R5ssm) <= 7)) {
#else
  if (w->Mode == MODE_R1nm && w->Mode == MODE_R2nm && w->Mode == MODE_R2wm && w->Mode == MODE_R3wm
      && w->Mode == MODE_R3sm && w->Mode == MODE_R4sm && w->Mode == MODE_R4ssm && w->Mode == MODE_R5ssm) {
#endif
    error_exit( "Encoding mode error." );
  }

  law = MODE_ULAW;
  if (core == G711ALAW_CORE)
  {
    law = MODE_ALAW;
  }

  w->pHpassFiltBuf = highpass_1tap_iir_const();
  if (w->pHpassFiltBuf == NULL)  error_exit( "HPF init error." );

  w->pQmfBuf_SWB = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
  if (w->pQmfBuf_SWB == NULL)  error_exit( "SWB QMF init error." );

  w->pQmfBuf_WB = QMFilt_const(NTAP_QMF_WB, fSWBQmf0, fSWBQmf1);
  if (w->pQmfBuf_WB == NULL)  error_exit( "G.711.1 QMF init error." );

  w->G711WB_SubEncoderL = lowband_encode_const(law);
  if (w->G711WB_SubEncoderL == NULL)  error_exit( "G.711.1 lower band encoder init error." );

  w->G711WB_SubEncoderH = highband_encode_const();
  if (w->G711WB_SubEncoderH == NULL)  error_exit( "G.711.1 higher band encoder init error." );

  w->SubEncoderBWE = bwe_encode_const();
  if (w->SubEncoderBWE == NULL)   error_exit( "BWE encoder init error." );
#ifdef LAYER_STEREO
  if ((w->Mode >= MODE_R3sm && (w->Mode - MODE_R3sm) <= 3) ||(w->Mode >= MODE_R4ss && (w->Mode - MODE_R4ss) <= 4))
#else
  if (w->Mode >= MODE_R3sm)
#endif
  {
    w->SubEncoderSH = avq_encode_const();
    if (w->SubEncoderSH == NULL) error_exit( "AVQ encoder init error." );
  }
#ifdef LAYER_STEREO
    w->frame_idx = 0;
    w->channel = channel;

    w->pHpassFiltBuf_L = highpass_1tap_iir_const();
    if ( w->pHpassFiltBuf_L == NULL )  error_exit( "HPF init error." );

    w->pHpassFiltBuf_R = highpass_1tap_iir_const();
    if ( w->pHpassFiltBuf_R == NULL )  error_exit( "HPF init error." );

    w->pQmfBuf_SWB_left  = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
    w->pQmfBuf_SWB_right = QMFilt_const(NTAP_QMF_SWB, fSWBQmf0, fSWBQmf1);
    if ( w->pQmfBuf_SWB_left == NULL || w->pQmfBuf_SWB_right == NULL )  error_exit( "STERO SWB QMF init error." );

    w->G711_stereo_SubEncoder = g711_stereo_encode_const();

    w->framelen = L_FRAME_SWB;

    if (sampf == 8000)
    {
      w->framelen = L_FRAME_NB; 
    }

    if (sampf == 16000)
    {
      w->framelen = L_FRAME_WB; 
    }
#endif
  pcmswbEncode_reset( (void *)w );

  return (void *)w;
}

/*----------------------------------------------------------------
Function:
PCM SWB encoder destructor
Return value:
None
----------------------------------------------------------------*/
void pcmswbEncode_dest(
  void* p_work   /* (i): Work space */
)
{
  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;

  if (w != NULL) {
    highpass_1tap_iir_dest( w->pHpassFiltBuf );    /* HPF         */
    QMFilt_dest( w->pQmfBuf_SWB );                 /* QMF for SWB */
    QMFilt_dest( w->pQmfBuf_WB );                  /* QMF for WB  */
    lowband_encode_dest( w->G711WB_SubEncoderL );  /* LB for WB   */
    highband_encode_dest( w->G711WB_SubEncoderH ); /* HB for WB   */
    bwe_encode_dest( w->SubEncoderBWE );           /* BWE for SWB */
#ifdef LAYER_STEREO
    if(w->OpFs == 32000)
#else
    if (w->Mode >= MODE_R3sm)
#endif
    {
      avq_encode_dest (w->SubEncoderSH);           /* AVQ for SWB */
    }
#ifdef LAYER_STEREO
      highpass_1tap_iir_dest( w->pHpassFiltBuf_L );
      highpass_1tap_iir_dest( w->pHpassFiltBuf_R );
      g711_stereo_encode_dest(w->G711_stereo_SubEncoder);
      QMFilt_dest( w->pQmfBuf_SWB_left );
      QMFilt_dest( w->pQmfBuf_SWB_right );
#endif
    free( w );
  }
}

/*----------------------------------------------------------------
Function:
PCM SWB encoder reset
Return value:
OK
----------------------------------------------------------------*/
int pcmswbEncode_reset(
  void* p_work   /* (i/o): Work space */
)
{
  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;

  if (w != NULL)
  {
    highpass_1tap_iir_reset(w->pHpassFiltBuf);      /* HPF         */
    QMFilt_reset( w->pQmfBuf_SWB );                 /* QMF for SWB */
    QMFilt_reset( w->pQmfBuf_WB );                  /* QMF for WB  */
    lowband_encode_reset( w->G711WB_SubEncoderL );  /* LB for WB   */
    highband_encode_reset( w->G711WB_SubEncoderH ); /* HB for WB   */
    bwe_encode_reset( w->SubEncoderBWE );           /* BWE for SWB */
#ifdef LAYER_STEREO
    /* reset for AVQ encoder */
    if (w->OpFs == 32000)
#else
    if( w->Mode >= MODE_R3sm )
#endif
    {
      avq_encode_reset (w->SubEncoderSH);            /* AVQ for SWB */
    }
    zeroF(16, w->f_DiffMDCTCoefHigh);
    zeroF(16, w->f_LocalDecDiffMDCTCoefHigh);
#ifdef LAYER_STEREO
    highpass_1tap_iir_reset(w->pHpassFiltBuf_L);
    highpass_1tap_iir_reset(w->pHpassFiltBuf_R);
    g711_stereo_encode_reset(w->G711_stereo_SubEncoder);
#endif
  }

  return OK;
}

/*----------------------------------------------------------------
Function:
PCM SWB encoder
Return value:
OK/NG
----------------------------------------------------------------*/
int pcmswbEncode(
  const Short*   inwave,
  unsigned char* bitstream,
  void*          p_work
)
{
  unsigned char *bpt = bitstream;
  Short i;
  Float f_SubSigSuperWideLow[L_FRAME_WB];  /*  0- 8 kHz signal (80 points) */
  Float f_SubSigSuperWideHigh[L_FRAME_WB]; /*  8-14 kHz signal (80 points) */

  Float f_SubSigLow[L_FRAME_NB];           /*  0- 4 kHz signal (40 points) */
  Float f_SubSigHigh[L_FRAME_NB];          /*  4- 8 kHz signal (40 points) */

  Float f_SubSigSuperWideHigh_temp[QMF_DELAY_WB];
  Float f_SigInQMF[L_FRAME_SWB];

  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;
  BWE_state_enc *enc_st = (BWE_state_enc *)w->SubEncoderBWE;

  unsigned short bst_buff[NBitsPerFrame_SWB_1];
  unsigned short bst_buff2[NBitsPerFrame_SWB_2];
  unsigned short *pBit_BWE, *pBit_SVQ, *pBit_SVQ2;
  unsigned short *pBit_MB, *pBit_MB2;
  Short transi;
  Short index_g, cod_Mode, T_modify_flag = 0;
  Short layers_SWB; 
  Float f_MDCTCoefHigh[L_FRAME_NB];
  Float f_MDCTCoefLocalDecHigh[L_FRAME_NB];
  Float f_Fenv_SWB_unq[SWB_NORMAL_FENV];
  Float f_tEnv[SWB_TENV];
  Float f_coef_SWB[SWB_F_WIDTH];
  Float f_Fenv_SWB[SWB_NORMAL_FENV];
#ifdef LAYER_STEREO
  Short input_left_s[L_FRAME_SWB];     
  Short input_right_s[L_FRAME_SWB];
  Short mono[L_FRAME_WB];

  Float f_mono[80];

  Float f_side_swb_s[L_FRAME_WB];

  Float gain[2];
  /* high pass filtering */
  Float f_input_left_hpf[L_FRAME_SWB];
  Float f_input_right_hpf[L_FRAME_SWB];

  /* QMF signals */
  Float f_input_left_qmf_wb_s[L_FRAME_WB];
  Float f_input_left_qmf_swb_s[L_FRAME_WB];
  Float f_input_right_qmf_wb_s[L_FRAME_WB];
  Float f_input_right_qmf_swb_s[L_FRAME_WB];

  Short bpt_stereo_swb[160]; 
#endif

  /* initialize */
  zeroS(NBitsPerFrame_SWB_1, (Short*)bst_buff);
  zeroS(NBitsPerFrame_SWB_2, (Short*)bst_buff2);
  zeroF(L_FRAME_NB, f_MDCTCoefHigh);
  zeroF(L_FRAME_NB, f_MDCTCoefLocalDecHigh);
  zeroF(SWB_NORMAL_FENV, f_Fenv_SWB_unq);
  zeroF(SWB_TENV, f_tEnv);
  zeroF(SWB_F_WIDTH, f_coef_SWB);
  zeroF(SWB_NORMAL_FENV, f_Fenv_SWB);
#ifdef LAYER_STEREO
  if(w->channel == 2)
  {
    /* Stereo channel split */
    deinterleave( inwave, input_left_s, input_right_s, w->framelen*2 );
    if(w->OpFs == 32000)
    {
      write_index1(bpt_stereo_swb, 1);
     
      /* high-pass filtering L and R channels before processing downmix */
      highpass_1tap_iir_stereo( FILT_NO_32KHZ_INPUT, L_FRAME_SWB, (Short *)input_left_s,  f_input_left_hpf,  w->pHpassFiltBuf_L );
      highpass_1tap_iir_stereo( FILT_NO_32KHZ_INPUT, L_FRAME_SWB, (Short *)input_right_s, f_input_right_hpf, w->pHpassFiltBuf_R );

      /* Band splitting with QMF (SWB) */
      QMFilt_ana(L_FRAME_SWB, f_input_left_hpf,  f_input_left_qmf_wb_s,  f_input_left_qmf_swb_s,  w->pQmfBuf_SWB_left );
      QMFilt_ana(L_FRAME_SWB, f_input_right_hpf, f_input_right_qmf_wb_s, f_input_right_qmf_swb_s, w->pQmfBuf_SWB_right );
          
      /*swb mono downmix and encoder*/
      downmix_swb(f_input_left_qmf_swb_s, f_input_right_qmf_swb_s, f_SubSigSuperWideHigh,f_side_swb_s,w->G711_stereo_SubEncoder);

      G711_stereo_encoder_shb(f_SubSigSuperWideHigh,f_side_swb_s,w->G711_stereo_SubEncoder,&bpt_stereo_swb[1], w->Mode, gain);      

      /*wb mono downmix and encoder*/
      downmix(f_input_left_qmf_wb_s, f_input_right_qmf_wb_s, mono, w->G711_stereo_SubEncoder,&bpt_stereo_swb[1],w->Mode,&w->frame_idx,w->OpFs);
    }
    else
    {
      write_index1(bpt_stereo_swb, 0);

      /* high-pass filtering L and R channels before processing downmix */
      highpass_1tap_iir_stereo(FILT_NO_16KHZ_INPUT, L_FRAME_WB, (Short *)input_left_s, f_input_left_hpf, w->pHpassFiltBuf_L );
      highpass_1tap_iir_stereo(FILT_NO_16KHZ_INPUT, L_FRAME_WB, (Short *)input_right_s, f_input_right_hpf, w->pHpassFiltBuf_R );

      /* mono downmix */
      downmix(f_input_left_hpf, f_input_right_hpf, mono, w->G711_stereo_SubEncoder,&bpt_stereo_swb[1],w->Mode,&w->frame_idx,w->OpFs);
    }
  }

  if(w->channel == 2)
  {
    /* Band splitting with QMF for WB */
	movSF(80, mono, f_mono);
    QMFilt_ana( L_FRAME_WB, f_mono, f_SubSigLow, f_SubSigHigh, w->pQmfBuf_WB );
  }
#endif

  if (p_work == NULL)
  {
    return NG;
  }

  /* ------------------------------- */
  /* Pre-processing & band splitting */
  /* ------------------------------- */
#ifdef LAYER_STEREO
  if(w->channel == 1)
  {
#endif
  if (w->OpFs == 8000) { /* Narrow band input */
    /* High-pass filtering */
    highpass_1tap_iir(FILT_NO_8KHZ_INPUT, L_FRAME_NB, (Short*)inwave, f_SubSigLow, w->pHpassFiltBuf);
  }
  else if (w->OpFs == 16000) { /* Wideband input */
    /* High-pass filtering */
    highpass_1tap_iir(FILT_NO_16KHZ_INPUT, L_FRAME_WB, (Short *)inwave, f_SigInQMF, w->pHpassFiltBuf);

    /* Band splitting with QMF for WB */
    QMFilt_ana(L_FRAME_WB, f_SigInQMF, f_SubSigLow, f_SubSigHigh, w->pQmfBuf_WB);
  }
  else { /* w->OpFs == 32000 */  /* Super wideband input */
    /* High-pass filtering */
    highpass_1tap_iir(FILT_NO_32KHZ_INPUT, L_FRAME_SWB, (Short *)inwave, f_SigInQMF, w->pHpassFiltBuf);

    /* Band splitting with QMF for SWB */
    QMFilt_ana(L_FRAME_SWB, f_SigInQMF, f_SubSigSuperWideLow, f_SubSigSuperWideHigh, w->pQmfBuf_SWB);
    QMFilt_ana(L_FRAME_WB, f_SubSigSuperWideLow, f_SubSigLow, f_SubSigHigh, w->pQmfBuf_WB);
  }
#ifdef LAYER_STEREO
  }

  if (w->channel == 1)
  {
#endif
  movF(QMF_DELAY_WB, &f_SubSigSuperWideHigh[L_FRAME_WB-QMF_DELAY_WB], f_SubSigSuperWideHigh_temp);
  movF_bwd(L_FRAME_WB-QMF_DELAY_WB, f_SubSigSuperWideHigh+L_FRAME_WB-1-QMF_DELAY_WB, f_SubSigSuperWideHigh+L_FRAME_WB-1);
  movF(QMF_DELAY_WB, w->f_DCBuf, f_SubSigSuperWideHigh);
  movF(QMF_DELAY_WB, f_SubSigSuperWideHigh_temp, w->f_DCBuf);
#ifdef LAYER_STEREO
  }
#endif
  /* --------------------------------------------------------------------- */
  /* G.711.1 lower-band encoder including both core and enhancement layers */
  /* --------------------------------------------------------------------- */
#ifdef LAYER_STEREO
  if ((w->Mode == MODE_R2a)   ||
      (w->Mode == MODE_R3)    ||
      (w->Mode == MODE_R4ssm) ||
      (w->Mode == MODE_R5ssm) ||
      (w->Mode == MODE_R5sws) ||
      (w->Mode == MODE_R6sss) ||
      (w->Mode == MODE_R7sss)) {
#else
  if ((w->Mode == MODE_R2a) || (w->Mode == MODE_R3) || (w->Mode == MODE_R4ssm) || (w->Mode == MODE_R5ssm)) {
#endif
    /* Core layer + Lower band enhancement layer */
    lowband_encode(f_SubSigLow, bpt, bpt+NBytesPerFrame_G711WB_0, w->G711WB_SubEncoderL);
    bpt += (NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1);
  }
  else { /* w->Mode == MODE_R1 || w->Mode == MODE_R2b || w->Mode == MODE_R3sm || w->Mode == MODE_R4sm */
    /* Core layer only */
    lowband_encode(f_SubSigLow, bpt, NULL, w->G711WB_SubEncoderL);
    bpt += NBytesPerFrame_G711WB_0;
  }

  /* --------------------------------------------- */
  /* G.711.1 higher-band enhancement layer encoder */
  /* --------------------------------------------- */
#ifdef LAYER_STEREO
  if (w->Mode >= MODE_R2b) {
#else
  if ((w->Mode == MODE_R2b) || (w->Mode == MODE_R3) || (w->Mode == MODE_R3sm) || 
      (w->Mode == MODE_R4sm) || (w->Mode == MODE_R4ssm) || (w->Mode == MODE_R5ssm)) {
#endif
    if (w->OpFs == 8000) {
      zeroF(NBytesPerFrame_G711WB_2/2, (Float *)bpt);
    }
    else {
      highband_encode(f_SubSigHigh, bpt, w->G711WB_SubEncoderH, f_MDCTCoefHigh, f_MDCTCoefLocalDecHigh, w->f_DiffMDCTCoefHigh);
    }
    bpt += NBytesPerFrame_G711WB_2;
  }

  /* ------------------------------------------- */
  /* Super-higher-band enhancement layer encoder */
  /* ------------------------------------------- */
#ifdef LAYER_STEREO
  if((w->Mode >= MODE_R3sm) && ((w->Mode - (MODE_R3sm + 8)) <= 0))
#else
  if ((w->Mode == MODE_R3sm) || (w->Mode == MODE_R4sm) || (w->Mode == MODE_R4ssm) || (w->Mode == MODE_R5ssm))
#endif
  {
    T_modify_flag = Icalc_tEnv(f_SubSigSuperWideHigh, f_tEnv, &transi, enc_st->preMode, (void*)enc_st);
  }
#ifdef LAYER_STEREO
  if((w->Mode >= MODE_R3sm)&& ((w->Mode - (MODE_R3sm + 8)) <= 0))
#else
  if ((w->Mode == MODE_R3sm) || (w->Mode == MODE_R4sm) || (w->Mode == MODE_R4ssm) || (w->Mode == MODE_R5ssm))
#endif
  {
    /* BWE encoding for SWBL0 */
    pBit_BWE = bst_buff;
    bwe_enc( f_SubSigSuperWideHigh, &pBit_BWE, w->SubEncoderBWE, f_tEnv, transi,
      &cod_Mode, f_Fenv_SWB, f_coef_SWB, &index_g, T_modify_flag, f_Fenv_SWB_unq
#ifdef LAYER_STEREO
     , gain, w->channel
#endif
	  );

    /* G.711.1 enhancement layer 0 encoding */
    if (cod_Mode != TRANSIENT)
    {
      pBit_MB = bst_buff + NBITS_MODE_R1SM_BWE;
      g711el0_encode_AVQ_flt((const Float *)w->f_DiffMDCTCoefHigh, pBit_MB, w->f_LocalDecDiffMDCTCoefHigh, f_Fenv_SWB[0]);
    }

    /* G.711.1 enhancement layer 1 encoding */
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R4sm  || 
        w->Mode == MODE_R5ssm ||
        w->Mode == MODE_R5ss  ||
        w->Mode == MODE_R6ss  ||
        w->Mode == MODE_R7sss)
#else
    if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm)
#endif
    {
      if (cod_Mode == TRANSIENT)
      {
        for (i=0; i<10; i++)
        {
          f_MDCTCoefLocalDecHigh[10-i] = f_MDCTCoefLocalDecHigh[10-i] + (w->f_LocalDecDiffMDCTCoefHigh[i] + f_MDCTCoefLocalDecHigh[20-i]);
        }
      }
      else
      {
        for (i=0; i<16; i++)
        {
          f_MDCTCoefLocalDecHigh[15-i] = f_MDCTCoefLocalDecHigh[15-i] + w->f_LocalDecDiffMDCTCoefHigh[i];
        }
      }
      pBit_MB2 = bst_buff2;
      g711el1_encode ((const Float *)f_MDCTCoefHigh, (const Float *)f_MDCTCoefLocalDecHigh, pBit_MB2);
    }

    /* AVQ encoding for SWBL1&2 */
    layers_SWB = 1;
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R4sm  || 
        w->Mode == MODE_R5ssm ||
        w->Mode == MODE_R5ss  ||
        w->Mode == MODE_R6ss  ||
        w->Mode == MODE_R7sss)
#else
    if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm)
#endif
    {
      layers_SWB = 2;
    }

    pBit_SVQ = bst_buff + NBITS_MODE_R1SM_TOTLE;
    pBit_SVQ2 = bst_buff2 + NBitsPerFrame_EL1;

    swbl1_encode_AVQ( (void*)w->SubEncoderSH, f_coef_SWB, f_Fenv_SWB, f_Fenv_SWB_unq,
      index_g, cod_Mode, pBit_SVQ, pBit_SVQ2, layers_SWB );
    softbit2hardbit (NBytesPerFrame_SWB_1, bst_buff, bpt);
    bpt += NBytesPerFrame_SWB_1;
  }
#ifdef LAYER_STEREO
    if (w->Mode == MODE_R4sm  || 
        w->Mode == MODE_R5ssm ||
        w->Mode == MODE_R5ss  ||
        w->Mode == MODE_R6ss  ||
        w->Mode == MODE_R7sss)
#else
  if (w->Mode == MODE_R4sm || w->Mode == MODE_R5ssm)
#endif
  {
    softbit2hardbit (NBytesPerFrame_SWB_2, bst_buff2, bpt);
    bpt += NBytesPerFrame_SWB_2;
  }
#ifdef LAYER_STEREO
  if(w->channel == 2)
  {
    if(w->Mode == MODE_R3ws || w->Mode == MODE_R4ss || w->Mode == MODE_R5ss)
    {
        softbit2hardbit(10, bpt_stereo_swb, bpt);
        bpt += 10;
    }
    else
    {
        softbit2hardbit(20, bpt_stereo_swb, bpt);
        bpt += 20;
    }
  }
#endif
  return OK;
}
