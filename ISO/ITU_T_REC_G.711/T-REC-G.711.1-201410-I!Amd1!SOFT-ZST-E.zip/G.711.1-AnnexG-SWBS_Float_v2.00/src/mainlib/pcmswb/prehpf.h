/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: prehpf.h
 *  Function: Header of pre-processing 1-tap high-pass filtering
 *------------------------------------------------------------------------
 */

#ifndef FPREHPF_H
#define FPREHPF_H

void  *highpass_1tap_iir_const (void);
void  highpass_1tap_iir_dest (void*);
void  highpass_1tap_iir_reset (void*);
void  highpass_1tap_iir (Short, Short, Short*, Float*, void*);
#ifdef LAYER_STEREO
void  highpass_1tap_iir_stereo(
                        Short  filt_no,  /* (i):   Filter cutoff specification. */
                        /*        Use 5 for 8-kHz input,       */
                        /*            6 for 16-kHz input,      */
                        /*            7 for 32-kHz input       */
                        Short  n,        /* (i):   Number of samples            */
                        Short  sigin[],  /* (i):   Input signal (Q0)            */
                        Float  sigout[], /* (o):   Output signal (Q0)           */
                        void    *ptr      /* (i/o): Work space                   */
                        );
#endif

#endif  /* FPREHPF_H */
