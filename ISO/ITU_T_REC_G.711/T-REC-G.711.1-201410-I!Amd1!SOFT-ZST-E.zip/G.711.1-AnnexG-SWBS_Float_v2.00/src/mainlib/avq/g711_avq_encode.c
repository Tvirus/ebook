/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "bwe.h"
#include "avq.h"
#include "rom.h"
#include "float.h" // for FLT_MIN



/*-----------------------------------------------------------------*
*   Funtion  gain_quant                                           *
*            ~~~~~~~~~~~~                                         *
*   Quantization of gains between the specified range             *
*   using the specified number of levels.                         *
*-----------------------------------------------------------------*/
static Short gain_quant(/* o:   quantization index            */
                         Float *gain
                         )
{
  Short idx;

  idx = 0;
  if (*gain != 0.0f)
  {
    idx = -1;
    do
    {
      idx = idx + 1;
    }
    while (*gain > Gain_In_flt[idx]);
    *gain = Gain_Out_flt[idx];
  }

  return idx;
}



/*-----------------------------------------------------------------*
*  Function  g711el0_encode_AVQ()		                              *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
*  Enhancement layer G711EL0 encoding                             *
*-----------------------------------------------------------------*/
void g711el0_encode_AVQ_flt(
                        const Float    *mdct_err,        /* i:   Input MDCT coefficient error in mid-band    */
                        unsigned short *bstr_buff,       /* o:   Output bitstream in soft bit format         */
                        Float          *mdct_err_loc,    /* o:   Output MDCT coefficietns for mid-band       */
                        const Float    fEnv_BWE0         /* i:   Frequency envelope for 1st SWB subband      */
                        )
{
  Short i, j;
  unsigned short *bstr_tmp;
  Short unbits;

  Short tmp16;
  Short Yb_norm[(8+1)*N_SV_MB];

  unsigned short *bptpt;
  Short index_fEnv_codebook, index_fEnv_codeword, ixg;
  Float FEnv0;
  Float *ptr0, *ptr1;
  Short sign16;
                  
  Short index_gain;
  Float Coef[2], Dist_min, Dist, *spt;
  Float Gain, Inv_Gain;
  Float ener;
  Float tmp0, tmp1;
    
  Float Yb[NB_COEF_711_EL0];   

  bstr_tmp = bstr_buff;

  ener = FLT_MIN;        
  for( i=0; i<NB_COEF_711_EL0; i++ )
  {
      Yb[i] = mdct_err[i];          
      ener += Yb[i] * Yb[i];
  }

  /* compute & quantize MB gain */
  Gain = (Float) Sqrt( ener/NB_COEF_711_EL0 );
  if (fEnv_BWE0 == 0.0f) Gain = 0.25f;
  else Gain /= fEnv_BWE0;

  /* Limit the Gain to 1.0 */
  if (Gain > 1.0f)
       Gain = 1.0f;
  index_gain = gain_quant( &Gain );

  if (fEnv_BWE0 == 0.0f) Gain = 1000.0f; else
  Gain *= fEnv_BWE0;

  Inv_Gain = INV_CNST_WEAK_FX_F / Gain;   
  for (i=0; i<NB_COEF_711_EL0; i++) 
  {
      Yb[i] = Yb[i] * Inv_Gain;
  }

  AVQ_cod( Yb, Yb_norm, N_BITS_AVQ_MB, N_SV_MB );

  /* write MB AVQ parameters to the bitstream */
  s_PushBit( index_gain, &bstr_tmp, N_BITS_G_MB );
  unbits = AVQ_encmux_bstr( Yb_norm, &bstr_tmp, N_BITS_AVQ_MB, N_SV_MB );

  bptpt = bstr_buff-NBITS_MODE_R1SM_BWE;
  tmp16 = GetBit( &bptpt, 8); 
  index_fEnv_codebook = tmp16 & 1;
  tmp16 = tmp16 >> 1;
  ixg = tmp16 & 0x1F;
  tmp16 = GetBit( &bptpt, 7); 
  index_fEnv_codeword = tmp16 & 0x3F;
  tmp16 = index_fEnv_codeword << 2;

  FEnv0 = codebookH[tmp16];

  if( index_fEnv_codebook==0 ) {
    FEnv0 = codebookL[tmp16];
  }

  Gain = Gain_Out_flt[index_gain] * FEnv0 * Pow(2.0f, (Float)ixg);

  for( i=0; i<NB_COEF_711_EL0; i++ )
  {
    mdct_err_loc[i] = Yb_norm[i] * Gain;
  }
  
  /* fill missing coefficients */
  if(unbits >= N_BITS_FILL_MB)
  {
    bstr_tmp -= unbits;

    ener = 0.0f;
    for (j=0; j<NB_COEF_711_EL0/2; j++)
    {
      ener += mdct_err_loc[j] * mdct_err_loc[j];
    }

    ptr0 = Yb + 6;
    ptr1 = mdct_err_loc + 6;
    if(ener != 0.0f) {
      ptr0 += 2;
      ptr1 += 2;
    }

    sign16 = 0;
    if(*ptr0 >= 0.0f) sign16 = 2;
    Coef[0] = Fabs(*ptr0) * CNST_WEAK_FX_F;
    ptr0++;
    if(*ptr0 >= 0.0f) sign16 = sign16 + 1;
    Coef[1] = Fabs(*ptr0) * CNST_WEAK_FX_F;

    /* quantize 2 coeficients */
    spt = (Float *) t_qua_MB_coef;
    index_gain = 0;
    Dist_min = FLT_MAX;

    for( i = 0; i<8; i++ )
    {
        Dist  = Fabs( Coef[0] - (*spt) );
        spt++;
        Dist += Fabs( Coef[1] - (*spt) );
        spt++;

        if( Dist < Dist_min )
        {
            Dist_min = Dist;
            index_gain = i;
        }
    }

    /* dequantize 2 coeficients */
    spt = (Float *) t_qua_MB_coef + (index_gain << 1);

    Coef[0] = *spt;
    Coef[1] = *(spt+1);

    tmp0 = Coef[0] * Gain;
    tmp1 = Coef[1] * Gain;

    if( (sign16 & 2) == 0 )
      tmp0 = -tmp0;
    if( (sign16 & 1) == 0 )
      tmp1 = -tmp1;
    *ptr1 = tmp0;
    *(ptr1+1) = tmp1;

    /* Write to the bitstream */
    /* sign[n] > 0 ==> '1' otherwise '0' */
    s_PushBit( sign16, &bstr_tmp, 2 );
    s_PushBit( index_gain, &bstr_tmp, N_BITS_FILL_MB-1 );
  }
  else
  {
    i = 0;
    if( Fabs(Yb[6]) > Fabs(Yb[7]) )
    {
        i = 1;
    }
    s_PushBit( i, &bstr_tmp, 1 );

    ener = 0.0f;
    for (j=0; j<NB_COEF_711_EL0/2; j++)
    {
      ener += mdct_err_loc[j] * mdct_err_loc[j];
    }
    if(ener == 0.0f)
    {
      tmp0 = 0.45f * mdct_err_loc[8];
      tmp1 = 0.35f * mdct_err_loc[8];

      if( i )
      {
        mdct_err_loc[6] = tmp0; 
        mdct_err_loc[7] = tmp1;
      }
      else
      {
        mdct_err_loc[6] = tmp1;
        mdct_err_loc[7] = tmp0; 
      }
    }
  }
  return;
}
