/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "bwe.h"
#include "avq.h"
#include "rom.h"


static void read_FEnv0_flt(
                unsigned short *bptpt,
                unsigned short *index_gain,
                Float  *FEnv0
                )
{
  Short index_fEnv_codebook, index_fEnv_codeword;
  Float *Pit_Fen;

  *index_gain = GetBit( &bptpt, 5);    /* read & decode global gain */
  index_fEnv_codebook = GetBit( &bptpt, 1);
  bptpt++;    /* skip 2nd index_fEnv_codebook reading */
  index_fEnv_codeword = GetBit( &bptpt, 6);

  Pit_Fen = codebookH;

  if( index_fEnv_codebook==0 )
  {
    Pit_Fen = codebookL;
  }

  *FEnv0 = Pit_Fen[index_fEnv_codeword << 2];

  return;
}


/*--------------------------------------------------------------------------*
*  Function  g711el0_decode_AVQ()		                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
*  Enhancement layer G711EL0 decoding, AVQ decoding of 6.4-8kHz band       *
*--------------------------------------------------------------------------*/
void g711el0_decode_AVQ_flt (
                         unsigned short       *bstr_EL0,  /* i:   Input bitstream for G711EL0 in soft bit format  */
                         Float         mdct_err[], /* o:   Output MDCT coefficients for mid-band           */
                         const unsigned short *bstr_BWE   /* i:   Input bitstream for SWBL0 in soft bit format    */
                         ) 
{
  Short i, mode;
  unsigned short *bptpt;
  Short index_gain;
  Short ixg;
  Short unbits, sign[2], index_coefs;
  Short Yfb[NB_COEF_711_EL0];
  Float FEnv0;
  Float Gain;
  Float ener;
  Float tmp, tmp2;

  ixg = 0;

  /* decode frequency envelope for 1st SWB subband */
  bptpt = (unsigned short*)bstr_BWE;

  mode = GetBit( &bptpt, 1);
  if( mode==NORMAL ) /* normal frame */
  {
    bptpt++;    /* skip noise_flag reading */
    read_FEnv0_flt( bptpt, &ixg, &FEnv0 );
  }
  else
  {
    mode = GetBit( &bptpt, 1 );
    if( mode==0 ) /* sharp frame */
    {
      read_FEnv0_flt( bptpt, &ixg, &FEnv0 );
    }
  }
  
  bptpt = (unsigned short *)bstr_EL0;

  /***** MB decoding *****/

  /* decode MB gain */
  index_gain = GetBit( &bptpt, N_BITS_G_MB );

  Gain = Gain_Out_flt[index_gain] * FEnv0 * Pow(2.0f, (Float)ixg);

  /* read and decode AVQ parameters from G711EL0 */
  unbits = AVQ_demuxdec_bstr( bptpt, Yfb, N_BITS_AVQ_MB, N_SV_MB );
  bptpt += N_BITS_AVQ_MB;

  /* reconstruct output MDCT MB coefficients */
  for( i=0; i<NB_COEF_711_EL0; i++ )
  {
    mdct_err[i] = Yfb[i] * Gain;
  }

  ener = sum_vect_E(mdct_err, NB_COEF_711_EL0/2);

  /* reconstruct missing coefficients */
  if( unbits >= N_BITS_FILL_MB)
  {
    bptpt -= unbits;

    /* read from the bitstream */
    sign[0] = GetBit( &bptpt, 1 );
    sign[1] = GetBit( &bptpt, 1 );
    index_coefs = GetBit( &bptpt, N_BITS_FILL_MB-1 );

    /* dequantize 2 coeficients */
    index_coefs = index_coefs << 1;
    tmp  = t_qua_MB_coef[index_coefs] * Gain;
    tmp2 = t_qua_MB_coef[index_coefs+1] * Gain;

    if( sign[0] == 0 )
      tmp  = -tmp;
    if( sign[1] == 0 )
      tmp2 = -tmp2;

    if( ener == 0.0f )
    {
      mdct_err[6] = tmp;
      mdct_err[7] = tmp2;
    }
    else
    {
      mdct_err[8] = tmp;
      mdct_err[9] = tmp2;
    }
  }
  else
  {
    i = GetBit( &bptpt, 1 );
    /* fill missing coefficients */
    if( ener == 0.0f )
    {
      if( i != 0)
      {
        tmp2 = 0.45f * mdct_err[8];
        tmp  = 0.35f * mdct_err[8];
      }
      else
      {
        tmp2 = 0.35f * mdct_err[8];
        tmp  = 0.45f * mdct_err[8];
      }
      mdct_err[6] = tmp2;
      mdct_err[7] = tmp;
    }
  }
}
