/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: stereo_tools.h
 *  Function: Header of basic stereo functions and stereo bitstream functions
 *------------------------------------------------------------------------
 */

#ifndef G711TOOLS_H
#define G711TOOLS_H

#ifdef LAYER_STEREO
#include "defines_mdct.h"
#include "floatutil.h"

/* interleaving and deinterleaving functions */
void interleave(        Short* left,   /* i: Left input channel */
                        Short* right,  /* i: Right input channel */
                        Short* output, /* o: Interleaved output signal */
                        Short  N);     /* Number of samples in input frames */

void deinterleave(const Short* input,  /* i: Interleaved input signal */
                        Short* left,   /* o: Left output channel */
                        Short* right,  /* o: Right output channel */
                        Short  N);     /* Number of samples in input frame */

void f_OLA(Float *cur_real, Float *mem_real, Short *cur_ola);

void windowStereoF(Float *input, Float *mem_input, Float *output);

/* bitstream writing */
void write_index1(Short* bpt_stereo, Short index);
void write_index2(Short* bpt_stereo, Short index);
void write_index3(Short* bpt_stereo, Short index);
void write_index4(Short* bpt_stereo, Short index);
void write_index5(Short* bpt_stereo, Short index);

/* bitstream reading */
void read_index1(Short* bpt_stereo, Short* index);
void read_index2(Short* bpt_stereo, Short* index);
void read_index3(Short* bpt_stereo, Short* index);
void read_index4(Short* bpt_stereo, Short* index);
void read_index5(Short* bpt_stereo, Short* index);

void zero32(Short  n, Word32* sx);

Word32    L_sum_mul_Array(
                       Short     n,      /* (i): Array size    */
                       Short  *sx,       /* (i): Data array 1  */
                       Short  *sy        /* (i): Data array 2  */
					   );

Short multSFtoS(Short s, Float f);

/* Max function for Short data */
Short maxS( Short var1, Short var2);

/* Min function for Short data */
Short minS(Short var1, Short var2);

/* Abs function for Short data */
Short absS(Short var1);

/* Max function for Long data */
Word32 maxL( Word32 var1, Word32 var2);

/* Abs function for Long data */
Word32 absL (Word32 var1);

Float roundFto16F(Float x);

Float roundFto32F(Float x);

void movFL(
             int     n,  /* I : */
             Float   *x, /* I : */
             Word32  *y  /* O : */
             );
#endif /* LAYER_STEREO */
#endif /* G711TOOLS_H */
