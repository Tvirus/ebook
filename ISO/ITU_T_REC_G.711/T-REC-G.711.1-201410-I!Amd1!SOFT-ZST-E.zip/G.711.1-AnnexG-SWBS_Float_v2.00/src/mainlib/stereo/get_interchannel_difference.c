/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
Version 1.0
Copyright (c) 2012,
Huawei Technologies, France Teleccom
---------------------------------------------------------------------------------------*/

#ifdef LAYER_STEREO

#include <math.h>
#include "g711_stereo.h"
#include "fft.h"
#include "qmfilt.h"
#include "stereo_tools.h"
#include "pcmswb_common.h"
#include "mdct.h"
#include "bwe.h"
#include "stdio.h"
#include "rom.h"

static void get_ic(Float Ipd, Short Itd, Short flagHighEner, 
                   Float phase_mean_std_sm_ct, Short *ic_idx, Short *ic_flag);

static void calcPhaseStd(Float *temp_phase_ipd, Float *phase_mean_buf1, 
                         Short *phase_num, Float *phase_mean_std_sm_ct, Short *pos1);

static Float calcPhaseMean(Short *phase_mean_buf, Float mean_ipd, 
                            Float *phase_mean_std_sm, Short *f_num, 
                            Float *ipd_mean_sm, Word32 ipd_reg_num_sm,
                            Float en_ratio_sm);

static void updateIpd(Word32 *mean_ipd, Short *pre_ipd_mean, Short *ipd_num, 
                      Short *ipd_reg_num, Short *ipd_reg_num_sm, Short *phase_mean_buf);

static Word32 excludeOutlier(Word32 mean_ipd, Float *temp_phase_ipd, Float pre_Ipd);
static Short getGlobalPhaseStd(Word32 mean_ipd, Float *temp_phase_ipd, Word32 *energy_bin_sm);
static Word32 getWeightedMeanGlobalPhase (Word32 *energy_bin_sm, Float *temp_phase_ipd);

static Short selectITDmain(Short nb_pos, Short nb_neg, Word32 std_itd_pos, Word32 std_itd_neg, 
                            Short mean_itd_pos, Short mean_itd_neg, Short pre_Itd);
static Short checkMeaningfulITD(Word32 std_itd_sm, Word32 nb_idx_sm, Short pre_Itd, Short flagITDstd);
static Short smoothMeanITD(Short mean_itd_pos, Short *pre_itd);
static void smoothITD(Short nb_inst, Short std_itd_inst,  Short *std_itd, 
                      Short flagHighEner,Short *nb, Short *mean_itd, Short mean_itd_inst, 
                      Word32 *Crxyt, Word32 *Crxyt2, Word32 *Cixyt, Word32 *Cixyt2,
                      Short *std_itd_sm, Short *nb_idx_sm);

static void calcStandITD(Float *temp_phase, Float *itd, 
                         Short nb_pos, Short mean_itd_pos, Short *std_itd_pos2, 
                         Short nb_neg, Short mean_itd_neg, Short *std_itd_neg2);
static Short getITDstd(Float std_itd, Short n, Short nb);

static Word32 updateMemEner(Word32 mem_energy,  Word32 energy);
static void udpdateEnerBin(Short f_num , Short n, Word32 *energy_bin, Word32 *energy_bin_sm);
static void udpdateEner_ratio_sm(Word32 en_l, Word32 en_r, Short *en_ratio_sm);
static void normalizeEnerBin(Short n, Word32 en_l, Word32 en_r, Word32 *energy_bin);

static void calcEnerITD(Short n, Word32 *energyL, Word32 *energyR, 
                        Word32 *energy_bin, Short q_left, Short q_right, 
                        Word32 *Crxyt, Word32 *Cixyt, Word32 *Crxyt2, Word32 *Cixyt2,
                        Float *temp_phase, Float *temp_phase_ipd, 
                        Float *L_real, Float *L_imag, Float *R_real, Float *R_imag);

static void calcMeanITD(Float *temp_phase, Float *itd, Short *mean_itd_pos, 
                        Short *mean_itd_neg, Short *nb_pos2, Short *nb_neg2);

static Short getMeanITD(Float sum_itd, Short nb);

/*************************************************************************
* get_interchannel_difference
*
* calculate whole wideband ITD IPD and IC
**************************************************************************/
void get_interchannel_difference(g711_stereo_encode_WORK *w,
                                 Float L_real[],
                                 Float L_imag[],
                                 Short q_left,
                                 Float R_real[],
                                 Float R_imag[],
                                 Short q_right,
                                 Short *ic_idx,
                                 Short *ic_flag
                                 )
{
    Short i;
    Short flagITDstd, flagHighEner;
    Short flagPos, flagNeg;
    Word32 *Crxyt, *Cixyt, *Crxyt2, *Cixyt2;

    Short nb_pos, nb_neg, nb_pos_inst, nb_neg_inst;

	Short Itd;
	Float Ipd;

    Short mean_itd_pos, mean_itd_neg, mean_itd_neg_inst, mean_itd_pos_inst;
    Short std_itd_pos_inst, std_itd_neg;
    Short std_itd_pos, std_itd_neg_inst;
    Word32 mean_ipd;
    Short std_ipd;

    /* input */
    Word32 energyL;
    Word32 energyR;

    Float temp_phase[13];
    Float temp_phase_inst[13];
    Float temp_phase_ipd[13];

    Float itd[13];
    Float itd_inst[13];

    Word32 phase_mean_std_mean,phase_mean_std_std;
    Word32 energy_bin[STARTBANDITD + BANDITD], en_l, en_r;

    phase_mean_std_mean = 0; 
    phase_mean_std_std = 0;  
    en_l = 0; 
    en_r = 0; 

    q_left -= 11;
    q_right -= 11;

    /* computation and (weak and strong) smoothing of cross spectrum */
    energyL = 0; 
    energyR = 0; 
    Crxyt  = w->Crxyt + STARTBANDPHA;
    Cixyt  = w->Cixyt + STARTBANDPHA;
    Crxyt2 = w->Crxyt2 + STARTBANDPHA;
    Cixyt2 = w->Cixyt2 + STARTBANDPHA;

    calcEnerITD(6, &energyL, &energyR, &energy_bin[1], 
                q_left, q_right, Crxyt, Cixyt, Crxyt2, Cixyt2, &temp_phase[1], 
                &temp_phase_ipd[1],&L_real[1], &L_imag[1], &R_real[1], &R_imag[1]);

    en_l = energyL; 
    en_r = energyR; 
    Crxyt  += BANDPHA;
    Cixyt  += BANDPHA;
    Crxyt2 += BANDPHA;
    Cixyt2 += BANDPHA;

    calcEnerITD(6, &energyL, &energyR, &energy_bin[7], 
                q_left, q_right, Crxyt, Cixyt, Crxyt2, Cixyt2, &temp_phase[7], 
                &temp_phase_ipd[7], &L_real[7], &L_imag[7],
                &R_real[7], &R_imag[7]);

    for(i=STARTBANDPHA; i<13; i++) 
    {
        temp_phase_inst[i] = -temp_phase_ipd[i]; 
    }

    /*get weighting factor for full band IPD estimation*/
    normalizeEnerBin(6, en_l, en_r, &energy_bin[1]);

    udpdateEner_ratio_sm(en_l, en_r, &w->en_ratio_sm); 

    udpdateEnerBin(w->f_num ,6, &energy_bin[1], &w->energy_bin_sm[1]);

    /* get positive and negative mean ITD with weak and strong smoothing */
    calcMeanITD(temp_phase, itd, &mean_itd_pos, &mean_itd_neg, &nb_pos, &nb_neg);
    calcMeanITD(temp_phase_inst, itd_inst, &mean_itd_pos_inst, &mean_itd_neg_inst, &nb_pos_inst, &nb_neg_inst);

    /* update channel energies */
    w->mem_energyL = updateMemEner(w->mem_energyL, energyL); 
    w->mem_energyR = updateMemEner(w->mem_energyR, energyR); 

    /* Non meaningfull ITD for low energy stereo signal /*/
    /* flagITDstd = 0 if no low energy channel; #0 otherwise */
    flagITDstd = 0; 

    if(w->mem_energyL < 35)
    {
        flagITDstd++;
    }
    if(w->mem_energyR < 35)
    {
        flagITDstd++;
    }

    /*compute if high energy >100 in both channels = 1;  otherwise = 0  */
    flagHighEner = 0; 
    if(w->mem_energyL > 354)
    {
        flagHighEner++;
    }
    if(w->mem_energyR > 354)
    {
        flagHighEner++;
    }
    flagHighEner = flagHighEner/2;

    /* ITD standard deviation for positive and negative mean ITD with weak and strong smoothing */
    if(flagITDstd == 0) 
    {
        calcStandITD(&temp_phase[STARTBANDITD], &itd[STARTBANDITD], nb_pos, mean_itd_pos, 
                     &std_itd_pos, nb_neg, mean_itd_neg, &std_itd_neg );
    }
    else
    {
        nb_pos = 0; 
        nb_neg = 0; 
        std_itd_pos = 1792; 
        std_itd_neg = 1792; 
    }
    calcStandITD(&temp_phase_inst[STARTBANDITD], &itd_inst[STARTBANDITD], 
                 nb_pos_inst, mean_itd_pos_inst, &std_itd_pos_inst, 
                 nb_neg_inst, mean_itd_neg_inst, &std_itd_neg_inst);

    /* If weak smoothing positive ITD is stronger than strong smoothing positive ITD */
    /* replace strong smoothing positive ITD by weak smoothing positive ITD */
    Crxyt  = w->Crxyt;
    Cixyt  = w->Cixyt;
    Crxyt2 = w->Crxyt2;
    Cixyt2 = w->Cixyt2;
    smoothITD(nb_pos_inst, std_itd_pos_inst,  &std_itd_pos, flagHighEner, 
              &nb_pos, &mean_itd_pos, mean_itd_pos_inst, Crxyt, Crxyt2, 
              Cixyt, Cixyt2, &w->std_itd_pos_sm, &w->nb_idx_pos_sm );

    /* If weak smoothing negative ITD is stronger than strong smoothing negative ITD */
    /* replace strong smoothing negative ITD by weak smoothing negative ITD */
    smoothITD(nb_neg_inst, std_itd_neg_inst, &std_itd_neg, flagHighEner,
              &nb_neg, &mean_itd_neg, mean_itd_neg_inst, Crxyt, Crxyt2, 
              Cixyt, Cixyt2, &w->std_itd_neg_sm,  &w->nb_idx_neg_sm );

    /* smoothing of positive and negative ITD */
    mean_itd_pos = smoothMeanITD(mean_itd_pos, &w->pre_itd_pos); 

    mean_itd_neg = smoothMeanITD(mean_itd_neg, &w->pre_itd_neg); 

    /* non meaningful ITD set to zero */
    flagPos = checkMeaningfulITD(w->std_itd_pos_sm, w->nb_idx_pos_sm, w->pre_Itd, flagITDstd);
    if(flagPos !=0)
    {
        mean_itd_pos = 0; 
    }
    flagNeg = checkMeaningfulITD(w->std_itd_neg_sm, w->nb_idx_neg_sm, w->pre_Itd, flagITDstd);
    if(flagNeg !=0 ) 
    {
        mean_itd_neg = 0; 
    }

    /* selection of main ITD among the positive and negative */
    Itd = selectITDmain(nb_pos, nb_neg, std_itd_pos, std_itd_neg, mean_itd_pos, mean_itd_neg, w->pre_Itd);

    /* get weighted mean whole wideband IPD */
    mean_ipd = getWeightedMeanGlobalPhase(w->energy_bin_sm, temp_phase_ipd); 

    /* get standard deviation of whole wideband IPD */
    std_ipd = getGlobalPhaseStd(mean_ipd, temp_phase_ipd, w->energy_bin_sm);

    /* exclude outliers from mean whole wideband IPD and standard deviation */
    if (std_ipd > PI_D8_4096)
    {
        mean_ipd = excludeOutlier(mean_ipd, temp_phase_ipd, w->pre_Ipd);
    }

    if (Itd != 0)
    {
        mean_ipd = 0; 
    }

    /* avoid instability of whole wideband IPD */
    updateIpd(&mean_ipd, &w->pre_ipd_mean, &w->ipd_num, &w->ipd_reg_num,
              &w->ipd_reg_num_sm, &w->phase_mean_buf[w->pos1]);

    /* get final whole wideband IPD */
    Ipd = calcPhaseMean(w->phase_mean_buf, (Short)(mean_ipd), &w->phase_mean_std_sm,
                        &w->f_num, &w->ipd_mean_sm, w->ipd_reg_num_sm, w->en_ratio_sm);
    w->pre_Itd = Itd; 
    w->pre_Ipd = Ipd; 

    /* compute non-weighted mean IPD and standard deviation for IC computation */
    calcPhaseStd(temp_phase_ipd, w->phase_mean_buf1, &w->phase_num, 
                 &w->phase_mean_std_sm_ct, &w->pos1);

    /* get whole wideband IC parameter */
    get_ic(Ipd, Itd, flagHighEner, w->phase_mean_std_sm_ct, ic_idx,ic_flag); 
    w->fb_ITD = Itd;

	w->fb_IPD = roundFto16(Ipd);

    return;
}

/*************************************************************************
* get_ic
*
* compute the IC parameter
**************************************************************************/
static void get_ic(Float Ipd, Short Itd, Short flagHighEner, 
                   Float phase_mean_std_sm_ct, Short *ic_idx, Short *ic_flag) 
{ 
    Short ic_flag2, ic_idx2; 
    Short i;  
    const Short *ptr; 
    Short flag; 

    ic_flag2 = 0;  
    if(flagHighEner !=0) 
    { 
		flag = roundFto16(abs_f(Ipd)) + absS(Itd);

        if(flag == 0) 
        { 
            if(phase_mean_std_sm_ct >= 819) /* 0.2 */ 
            { 
                ic_flag2 = 1;  
                ptr = threshPhaseMeanStdSMct; 
                ic_idx2 = 3;  
                for(i=0; i<3; i++) 
                { 
                    if(phase_mean_std_sm_ct >= *ptr++) 
                    { 
                        ic_idx2--; 
                    } 
                } 
                *ic_idx = ic_idx2;  
            } 
        } 
    } 
    *ic_flag = ic_flag2;  

    return; 
} 

/*************************************************************************
* calcPhaseStd
*
* Calculate the standard deviation of phase
**************************************************************************/
static void calcPhaseStd(Float *temp_phase_ipd, Float *phase_mean_buf1, Short *phase_num, 
                         Float *phase_mean_std_sm_ct, Short *pos1) 
{ 
    Float sum_ipd; 
	Float phase_mean_mean, phase_mean_std, mean_ipd; 

    Short i; 
    Float Acc; 

    sum_ipd = temp_phase_ipd[STARTBANDPHA]; 

    for(i = 2; i< 11; i++) 
    { 
        sum_ipd += temp_phase_ipd[i]; 
    } 

	mean_ipd = sum_ipd * 0.1f;

    phase_mean_buf1[*pos1] = mean_ipd;  
    *pos1 = (*pos1 + 1); 
    if(*pos1 >= IPD_FNUM)
    { 
        *pos1 = 0;  
    } 
    Acc = phase_mean_buf1[0]; 
    for(i = 1; i < IPD_FNUM; i ++) 
    { 
        Acc += phase_mean_buf1[i];
    } 

	phase_mean_mean = Acc * 0.1f;

    phase_mean_std = abs_f(mean_ipd - phase_mean_mean);

    i = *phase_num;  
    if(phase_mean_std <= 12) /* 0.003 Q12 */ 
    { 
        i++; 
    } 
    else 
    { 
        i=0;  
    } 
    if (i > 5)
    { 
        *phase_mean_std_sm_ct = phase_mean_std;  
        i = 5;  
    } 
    else 
    { 
		*phase_mean_std_sm_ct = 0.0078125f * phase_mean_std + 0.9921875f * *phase_mean_std_sm_ct;
    } 
    *phase_num = i;  

    return; 
} 

/*************************************************************************
* calcPhaseMean
*
* Calculate the mean of the phase
**************************************************************************/
static Float calcPhaseMean(Short *phase_mean_buf, Float mean_ipd, 
                            Float *phase_mean_std_sm, Short *f_num, 
                            Float *ipd_mean_sm, Word32 ipd_reg_num_sm, 
                            Float en_ratio_sm)
{ 
	Short i;
    Float Ipd, phase_mean_mean, phase_mean_std; 

	Float Acc;

    Short flag; 

    flag = 0;  
    if(ipd_reg_num_sm > 12800)
		flag++;/* 50 q8 */ 

    Acc = phase_mean_buf[0]; 
    for(i = 1; i < IPD_FNUM; i ++) 
    { 
        Acc += phase_mean_buf[i]; 
    } 

	phase_mean_mean = Acc * 0.1f;

    phase_mean_std = abs_f(phase_mean_mean - mean_ipd); 

    if(*f_num == 0) 
    { 
        *phase_mean_std_sm = phase_mean_std;  
        *f_num += 1;  
    } 
    else 
    { 
		*phase_mean_std_sm = 0.015625f * phase_mean_std + 0.984375f * (*phase_mean_std_sm);
    } 
    if(*phase_mean_std_sm < 328)
		flag++; /* 0.08 */ 

	mean_ipd = 0.015625f * mean_ipd + 0.984375f * (*ipd_mean_sm);

    Ipd = 0;

	if (abs_f(en_ratio_sm) <= 4864) /* 9.5 */ 
    { 
        if(flag !=0) 
			Ipd = mean_ipd; 
    } 

    *ipd_mean_sm = mean_ipd;  

    return (Ipd); 
}   

/*************************************************************************
* updateIpd
*
* Smooth IPD in order to avoid fast change from PI to -PI
**************************************************************************/
static void updateIpd(Word32 *mean_ipd, Short *pre_ipd_mean, Short *ipd_num, 
                      Short *ipd_reg_num, Short *ipd_reg_num_sm, 
                      Short *phase_mean_buf)
{
    Word32 tmp32;

    tmp32 = (*mean_ipd - *pre_ipd_mean);
    if(absL(tmp32) > PI_1D5_4096)
    {
        if(*ipd_num < 10)
        {
            *mean_ipd = *pre_ipd_mean;
            *ipd_num = (1 + *ipd_num);
        }
        else
        {
            *ipd_num = 0; 
            *pre_ipd_mean = (Short)(*mean_ipd); 
        }
    }
    else
    {
        *pre_ipd_mean = (Short)(*mean_ipd); 
        *ipd_num = 0; 
    }
    if(absL(*mean_ipd) > 10240)
    {
        *ipd_reg_num = (1 + *ipd_reg_num);
        *ipd_reg_num = minS(*ipd_reg_num, 70);
    }
    else
    {
        *ipd_reg_num = (*ipd_reg_num - 1);
        *ipd_reg_num = maxS(*ipd_reg_num, 0);
    }

	*ipd_reg_num_sm = roundFto16(0.984375f * (*ipd_reg_num_sm) + (*ipd_reg_num) * 4.0f);

    *phase_mean_buf = (Short)(*mean_ipd); 

    return;
}

/*************************************************************************
* excludeOutlier
*
* exclude the IPD outlier
**************************************************************************/
static Word32 excludeOutlier(Word32 mean_ipd, Float *temp_phase_ipd, Float pre_Ipd)
{
	Float tmp32;
	Float sum_ipd;

    Short i;

    if (mean_ipd > 0)
    {
        sum_ipd = 0; 
        for(i = STARTBANDPHA; i< 7; i++)
        {
			tmp32 = abs_f(mean_ipd - temp_phase_ipd[i]);

            if ((temp_phase_ipd[i] < 0) && (tmp32 > PI_4096_D_4))
            {
                temp_phase_ipd[i] = (temp_phase_ipd[i] + PI_2_4096); 
            }
			sum_ipd += temp_phase_ipd[i];
        }
		mean_ipd = roundFto32(sum_ipd * 0.16666667f);
    }
    else
    {
		tmp32 = abs_f(mean_ipd - temp_phase_ipd[STARTBANDPHA]);
  
        if ((temp_phase_ipd[STARTBANDPHA] > 0) && (tmp32 > PI_4096_D_4))
        {
            temp_phase_ipd[STARTBANDPHA] = temp_phase_ipd[STARTBANDPHA] - PI_2_4096; 
        }
        sum_ipd = temp_phase_ipd[STARTBANDPHA];
        for(i = STARTBANDPHA + 1; i< 7; i++)
        {
		    tmp32 = abs_f(mean_ipd - temp_phase_ipd[i]);

            if ((temp_phase_ipd[i] > 0) && (tmp32 > PI_4096_D_4))
            {
                temp_phase_ipd[i] = temp_phase_ipd[i] - PI_2_4096; 
            }
			sum_ipd += temp_phase_ipd[i];
        }
        mean_ipd = roundFto32(sum_ipd * 0.16666667f); /* 1/6 */
    }
    if ((pre_Ipd > PI_08_4096) && (mean_ipd < -PI_08_4096))
    {
        mean_ipd = (mean_ipd + PI_2_4096);
    }
    if ((pre_Ipd < -PI_08_4096) && (mean_ipd > PI_08_4096))
    {
        mean_ipd = (mean_ipd - PI_2_4096);
    }

    return(mean_ipd);
}

/*************************************************************************
* getGlobalPhaseStd
*
* compute the standard deviation of IPD over several subband
**************************************************************************/
static Short getGlobalPhaseStd(Word32 mean_ipd, Float *temp_phase_ipd, 
                                Word32 *energy_bin_sm)
{
    Short i, std_ipd;

	Float tmp32_2;
	Float tmp16, tmp16_2;

    tmp16_2 = (Float)mean_ipd;
    tmp16 = (temp_phase_ipd[STARTBANDPHA] - tmp16_2);

	tmp16 = energy_bin_sm[STARTBANDPHA] * tmp16;

	tmp32_2 = tmp16 * tmp16;

    for(i = 2; i< 7; i++)
    {
        tmp16 = (temp_phase_ipd[i] - tmp16_2);

	    tmp16 = energy_bin_sm[i] * tmp16;

		tmp32_2 += tmp16 * tmp16;
    }

	std_ipd = roundFto16(Sqrt(tmp32_2) / 2147483648.0f);

    return(std_ipd );
}

/*************************************************************************
* getWeightedMeanGlobalPhase
*
* compute the whole wideband IPD based on energy weighted subband IPD
**************************************************************************/
static Word32 getWeightedMeanGlobalPhase(Word32 *energy_bin_sm, Float *temp_phase_ipd)
{
    Short i;
    Word32 mean_ipd;
	Float f_mean_ipd;

	f_mean_ipd = energy_bin_sm[STARTBANDPHA] * temp_phase_ipd[STARTBANDPHA];

	for(i = 2; i< 7; i++)
	{
		f_mean_ipd += energy_bin_sm[i] * temp_phase_ipd[i];
	}

	mean_ipd = roundFto32(f_mean_ipd / 2147483648.0f);

    return(mean_ipd); 
}

/*************************************************************************
* selectITDmain
*
* select the final ITD based on positive and negative ITD
**************************************************************************/
static Short selectITDmain(Short nb_pos, Short nb_neg, Word32 std_itd_pos, 
                            Word32 std_itd_neg, Short mean_itd_pos, Short mean_itd_neg, 
                            Short pre_Itd)
{
	Short Itd;

    if (nb_pos > nb_neg)
    {
        if ((std_itd_pos < std_itd_neg) ||(nb_pos >= (nb_neg * 2)))
        {
			Itd = roundFto16(abs_f(mean_itd_pos * 0.00390625f));
        }
        else
        {
            if ((std_itd_neg * 2) < std_itd_pos)
            {
			    Itd = roundFto16(-abs_f(mean_itd_neg * 0.00390625f));
            }
            else
            {
                if (pre_Itd > 0)
                {
			        Itd = roundFto16(abs_f(mean_itd_pos * 0.00390625f));
                }
                else
                {
			        Itd = roundFto16(-abs_f(mean_itd_neg * 0.00390625f));
                }
            }
        }
    }
    else
    {
        
        if ((std_itd_neg < std_itd_pos) || (nb_neg >= (nb_pos * 2)))
        {
			Itd = roundFto16(-abs_f(mean_itd_neg * 0.00390625f));
        }
        else
        {
            if ((std_itd_pos * 2) < std_itd_neg)
            {
			    Itd = roundFto16(abs_f(mean_itd_pos * 0.00390625f));
            }
            else
            {
                if (pre_Itd > 0)
                {
			        Itd = roundFto16(abs_f(mean_itd_pos * 0.00390625f));
                }
                else
                {
			        Itd = roundFto16(-abs_f(mean_itd_neg * 0.00390625f));
                }
            }
        }
    }

    return(Itd);
}

/*************************************************************************
* checkMeaningfulITD
*
* Check if it is a meaningful ITD
**************************************************************************/
static Short checkMeaningfulITD(Word32 std_itd_sm, Word32 nb_idx_sm, 
                                 Short pre_Itd, Short flagITDstd)
{

    Short flag;
    Word32 Ltmp;

    flag = flagITDstd; 
    if(flagITDstd ==0) 
    {
        if(std_itd_sm >= 768)
			flag++;
        Ltmp = 2048;
        if(pre_Itd !=0)
			Ltmp= (Ltmp - 256);
        if(nb_idx_sm <= Ltmp)
			flag++;
    }

    return(flag);
}

/*************************************************************************
* smoothMeanITD
*
* smoothing of the whole wideband ITD value over time
**************************************************************************/
static Short smoothMeanITD(Short mean_itd, Short *pre_itd)
{
	*pre_itd = roundFto16(((*pre_itd) * 63.0f + mean_itd) * 0.015625f);

	return *pre_itd;
}

/*************************************************************************
* smoothITD
*
* selection between weak and strong smoothing based whole wideband ITD 
**************************************************************************/
static void smoothITD(Short nb_inst, Short std_itd_inst,  Short *std_itd, 
                      Short flagHighEner, Short *nb, Short *mean_itd, Short mean_itd_inst, 
                      Word32 *Crxyt, Word32 *Crxyt2, Word32 *Cixyt, Word32 *Cixyt2,
                      Short *std_itd_sm, Short *nb_idx_sm)
{
    Short tmp16;
    Short i;
    Short flag;

    flag = 0; 
    if(flagHighEner !=0) 
    {
        if(nb_inst == BANDITD)
			flag++;
        if (std_itd_inst < 512)
			flag++;
        flag = (flag >> 1);
        if (nb_inst == 0)
			flag++;
    }

    if(flag != 0) 
    {
        *std_itd_sm = std_itd_inst; 
        *std_itd    = std_itd_inst; 
        *nb         = nb_inst; 
        *nb_idx_sm  = (nb_inst << 8);
        *mean_itd   = mean_itd_inst;
        for(i=STARTBANDITD; i<13; i++)
        {
            Crxyt[i] = Crxyt2[i]; 
            Cixyt[i] = Cixyt2[i]; 
        }
    }
    else
    {
        tmp16 = ((*std_itd_sm - *std_itd) >> 6);
        *std_itd_sm = (*std_itd_sm - tmp16);

        tmp16 = ((*nb_idx_sm - (*nb << 8)) >> 6);
        *nb_idx_sm = (*nb_idx_sm - tmp16);
    }

    return;
}

/*************************************************************************
* calcStandITD
*
* compute standard deviation of positive and negative ITD
**************************************************************************/
static void calcStandITD(Float *temp_phase, Float *itd, 
                         Short nb_pos, Short mean_itd_pos, Short *std_itd_pos2, 
                         Short nb_neg, Short mean_itd_neg, Short *std_itd_neg2)
{
    Float std_itd_pos, std_itd_neg;
    Short i;
	Float *ptr1, tmp16;
	Float *ptr0;
    const Short *ptr_pos, *ptr_neg;

    ptr0 = temp_phase;
    ptr1 = itd;
    /* standard deviation for positive and negative mean ITD with low and high smoothing */
    std_itd_pos = 0; 
    std_itd_neg = 0; 
    ptr_pos = INV_nb_idx;
    ptr_neg = INV_nb_idx;

    for(i = 0; i< BANDITD; i++)
    {
        if (*ptr0 > 0)
        {
            tmp16 = (*ptr1 - mean_itd_pos);
            std_itd_pos += tmp16 * tmp16;
            ptr_pos++;
        }
        else
        {
            tmp16 = (*ptr1 - mean_itd_neg);
            std_itd_neg += tmp16 * tmp16;
            ptr_neg++;
        }
        ptr0++; ptr1++;
    }
	std_itd_pos *= 2;
	std_itd_neg *= 2;

    *std_itd_pos2 = getITDstd(std_itd_pos, (Short)*ptr_pos, nb_pos);
    *std_itd_neg2 = getITDstd(std_itd_neg, (Short)*ptr_neg, nb_neg);
     
    return;
}

/*************************************************************************
* getITDstd
*
* Compute of square root for standard deviation
**************************************************************************/
static Short getITDstd(Float std_itd, Short n, Short nb)
{
    Short tmp16;

    tmp16 = 1792; /* 7*256 */
    if (nb > 0)
    {
		tmp16 = roundFto16(Sqrt(std_itd * n * 0.0000152587890625f));
    }

    return (tmp16);
}

/*************************************************************************
* updateMemEner
*
* smoothing of energy
**************************************************************************/
static Word32 updateMemEner(Word32 mem_energy, Word32 energy)
{
	return roundFto16(0.75f * mem_energy + 0.70710678f * Sqrt((Float)energy));
}

/*************************************************************************
* udpdateEnerBin
*
* smooth the energy of each bin
**************************************************************************/
static void udpdateEnerBin(Short f_num, Short n, Word32 *energy_bin, 
                           Word32 *energy_bin_sm)
{
	Word32 *ptr0, *ptr1;

    Short i;

    ptr1 = energy_bin_sm;
    ptr0 = energy_bin;
    if( f_num == 0)
    {
        for(i = 0; i < n; i++)
        {
            *ptr1++ = *ptr0++; 
        }
    }
    else
    {
        for(i = 0; i < n; i++)
        {
			*ptr1 = (Word32)((*ptr1) * 0.984375f + (*ptr0) * 0.015625f);

            ptr1++; ptr0++;
        }
    }

    return;
}

/*************************************************************************
* udpdateEner_ratio_sm
*
* update the energy ratio between two channels
**************************************************************************/
static void udpdateEner_ratio_sm(Word32 en_l, Word32 en_r, Short *en_ratio_sm) 
{ 
    Float tmp32, tmp32_2; 
    Float tmp16; 
  
    tmp32 = (en_l + 1.0f); 
    tmp32_2 = (en_r + 1.0f);

	tmp16 = ild_calculation(tmp32,tmp32_2);

	*en_ratio_sm = roundFto16(0.984375f * (*en_ratio_sm) + tmp16 * 8.0f);

    return; 
} 

/*************************************************************************
* normalizeEnerBin
*
* Normalize the energy of each bin
**************************************************************************/
static void normalizeEnerBin(Short n, Word32 en_l, Word32 en_r, Word32 *energy_bin)
{
    Float tmp; 
	Word32 *ptrL;
    Short i; 

    tmp = 2147483647.0f / (en_l + en_r + 1.0f);

    ptrL = energy_bin;
    for(i = 0; i < n; i++)
    {
        *ptrL++ = (Word32)(*ptrL * tmp); /* Q31 */
    }

    return;
}

/*************************************************************************
* calcEnerITD
*
* compute weak and strong smoothing cross spectrum and subband energy
**************************************************************************/
Short Exp16Array_stereoF(Short n, Float *s_real, Float *s_imag)
{ 
    Float sMax, sAbs;
	Short k, exp; 

    sMax = f_max( abs_f( s_imag[0] ), abs_f( s_real[0] )); 
    for ( k = 1; k < n; k++ ) 
    { 
        sAbs = abs_f( s_real[k] ); 
        sMax = f_max( sMax, sAbs ); 
        sAbs = abs_f( s_imag[k] ); 
        sMax = f_max( sMax, sAbs ); 
    }
	k = roundFto16(sMax);
    exp = norm_s( k ); 
    if(k == 0)
    {
        exp = 15; 
    }

    return(exp);
}

static void calcEnerITD(Short n, Word32 *energyL, Word32 *energyR, 
                        Word32 *energy_bin, Short q_left, Short q_right, 
                        Word32 *Crxyt, Word32 *Cixyt, Word32 *Crxyt2, Word32 *Cixyt2,
                        Float *temp_phase, Float *temp_phase_ipd, 
                        Float *L_real, Float *L_imag, Float *R_real, Float *R_imag)
{ 
    Short i; 
    Float  tmpLr, tmpLi, tmpRr, tmpRi; 
    Float *ptrLr, *ptrLi, *ptrRr, *ptrRi; 
    Float *ptr_phase, *ptr_phase_ipd; 
    Word32 *ptr_enerBin, *ptr_Crxyt, *ptr_Cixyt, *ptr_Crxyt2, *ptr_Cixyt2; 
    Float tmp32, tmp32_2, temp, tempi; 
    Short normL, normR;
    Short normL2, normR2, normLR; 
    Float energyL_loc, energyR_loc; 
	Float tmp_pow1, tmp_pow2, tmp_pow3, tmp_pow4, tmp_pow5;

    normL = Exp16Array_stereoF(n, L_real, L_imag); 
    normR = Exp16Array_stereoF(n, R_real, R_imag); 

    normL--; 
    normR--; 
    energyL_loc = 0; 
    energyR_loc = 0; 

    normL2 = (q_left + normL) * 2; 
    normR2 = (q_right + normR) * 2; 
    normLR = ((normL + normR) +(q_right + q_left)); 

    ptrLr         = L_real; 
    ptrLi         = L_imag; 
    ptrRr         = R_real; 
    ptrRi         = R_imag; 
    ptr_Crxyt     = Crxyt; 
    ptr_Cixyt     = Cixyt; 
    ptr_Crxyt2    = Crxyt2; 
    ptr_Cixyt2    = Cixyt2; 
    ptr_enerBin   = energy_bin; 
    ptr_phase     = temp_phase; 
    ptr_phase_ipd = temp_phase_ipd; 

	tmp_pow1 = Pow(2.0f,(Float)normL);
	tmp_pow2 = Pow(2.0f,(Float)normR);
	tmp_pow3 = Pow(0.5f,(Float)normL2);
	tmp_pow4 = Pow(0.5f,(Float)normR2);
	tmp_pow5 = Pow(0.5f,(Float)normLR);
    for(i=0; i<n; i++)
    { 
        tmpLr       = ((*ptrLr++) * tmp_pow1); 
        tmpLi       = ((*ptrLi++) * tmp_pow1); 
        tmpRr       = ((*ptrRr++) * tmp_pow2); 
        tmpRi       = ((*ptrRi++) * tmp_pow2); 
        tmp32       = (tmpLr) * (tmpLr); 
        tmp32       = tmp32 + tmpLi * tmpLi; 
        energyL_loc = (energyL_loc + tmp32 * 0.5f); 
        tmp32_2     = tmpRr * tmpRr; 
        tmp32_2     = tmp32_2 + tmpRi * tmpRi; 
        energyR_loc = (energyR_loc + tmp32_2 * 0.5f); 
        tmp32       = (tmp32 * tmp_pow3); 
        tmp32_2     = (tmp32_2 * tmp_pow4); 
        *ptr_enerBin++ = (Word32)(tmp32 + tmp32_2);  
        temp        = (tmpLr * tmpRr); 
        temp        = (temp + tmpLi * tmpRi); 
        tempi       = (tmpLi * tmpRr); 
        tempi       = (tempi - tmpLr * tmpRi); 
        temp        = (temp * tmp_pow5); 
        tempi       = (tempi * tmp_pow5); 
        tmp32       = ((*ptr_Crxyt - temp) * 0.015625f); 
        *ptr_Crxyt  = (Word32)(*ptr_Crxyt - tmp32);  
        tmp32       = ((*ptr_Cixyt - tempi) * 0.015625f); 
        *ptr_Cixyt  = (Word32)(*ptr_Cixyt - tmp32);  
        tmp32       = ((*ptr_Crxyt2 - temp) * 0.25f); 
        *ptr_Crxyt2 = (Word32)(*ptr_Crxyt2 - tmp32);  
        tmp32       = ((*ptr_Cixyt2 - tempi) * 0.25f); 
        *ptr_Cixyt2 = (Word32)(*ptr_Cixyt2 - tmp32);  

		*ptr_phase++ = -(Float)atan2(*ptr_Cixyt, *ptr_Crxyt) * 4096.0f;

		*ptr_phase_ipd++ = (Float)atan2(*ptr_Cixyt2, *ptr_Crxyt2) * 4096.0f;

        ptr_Crxyt++; ptr_Cixyt++; ptr_Crxyt2++; ptr_Cixyt2++; 
    } 
    energyL_loc  = (energyL_loc * Pow(0.5f,normL2-1.0f)); 
    energyR_loc  = (energyR_loc * Pow(0.5f,normR2-1.0f)); 
    *energyL = (Word32)(energyL_loc + *energyL); 
    *energyR = (Word32)(energyR_loc + *energyR); 

    return; 
}

/*************************************************************************
* calcMeanITD
*
* Calculate the mean of the ITDs
**************************************************************************/
static void calcMeanITD(Float *temp_phase, Float *itd, 
                        Short *mean_itd_pos, Short *mean_itd_neg,
                        Short *nb_pos2, Short *nb_neg2)
{
    Short i, nb_pos, nb_neg;
    Float sum_itd_pos, sum_itd_neg;
    const Short *ptr1, *ptr2;

    ptr1 = NFFT_D_2_PI_I;
    ptr2 = MAX_PHASE_I;

    sum_itd_pos = 0; 
    sum_itd_neg = 0; 
    nb_pos = 0; 
    nb_neg = 0; 

    for(i = STARTBANDITD; i< 13; i++)
    {
		itd[i] = temp_phase[i] * (*ptr1++) * 0.000030517578125f;

        if(abs_f(temp_phase[i]) < *ptr2++)
        {
            if (temp_phase[i] > 0)
            {
                sum_itd_pos += itd[i];
                nb_pos++;
            }
            else
            {
                sum_itd_neg += itd[i];
                nb_neg++;
            }
        }
    }

    *mean_itd_neg = getMeanITD(sum_itd_neg, nb_neg); 
    *mean_itd_pos = getMeanITD(sum_itd_pos, nb_pos); 
    *nb_pos2 = nb_pos; 
    *nb_neg2 = nb_neg; 

    return;
}

/*************************************************************************
* getMeanITD
*
* compute the mean ITD from sum of subband ITD
**************************************************************************/
static Short getMeanITD(Float sum_itd, Short nb)
{
    Short mean;

    mean = 0; 
    if(nb > 0)
    {
		mean = roundFto16(sum_itd / nb);
    }

    return (mean);
}
#endif /*LAYER_STEREO*/
