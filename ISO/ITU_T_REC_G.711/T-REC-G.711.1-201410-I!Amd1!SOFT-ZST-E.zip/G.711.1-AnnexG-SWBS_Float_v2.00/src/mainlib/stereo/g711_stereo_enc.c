/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

#ifdef LAYER_STEREO

#include <math.h>
#include "g711_stereo.h"
#include "fft.h"
#include "qmfilt.h"
#include "stereo_tools.h"
#include "pcmswb_common.h"
#include "mdct.h"
#include "bwe.h"
#include "fec_highband.h"
#include "rom.h"

/*************************************************************************
* ild_calculation
*
* Calculate the wideband ILD
**************************************************************************/
Float ild_calculation(Float L_ener,Float R_ener)
{
	L_ener = f_max(L_ener, 0.0000000001f);
	R_ener = f_max(R_ener, 0.0000000001f);
	return 10.0f * Log10(L_ener/R_ener);
}

/*************************************************************************
* ild_attack_detect
*
* Wideband stereo transient detection
**************************************************************************/
int ild_attack_detect(			   
            float* L_ener, /* i: energy per sub-band of L channel */
			float* R_ener, /* i: energy per sub-band of R channel */
			void*   ptr
            )
{
	int b, i;
    float ILD_sum = 0, ILD_sumH = 0;
    float sum_mean = 0,sum_meanH = 0;
    float dev,devH;
	g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr; 
    short flag;

	for(b=0; b< 14; b++)
	{
		ILD_sum += Log10((L_ener[b]+(float)1e-10)/(R_ener[b] + (float)1e-10));
	}
	for(; b< 20; b++)
	{
        ILD_sumH += Log10((L_ener[b]+(float)1e-10)/(R_ener[b] + (float)1e-10));  
	}

	ILD_sum *= 10.0f;
	ILD_sumH *= 10.0f;

	for(i = 1; i < FNUM; i++)
    {
        sum_mean += w->pre_ild_sum[i-1];
        sum_meanH += w->pre_ild_sum_H[i-1];
        w->pre_ild_sum[i-1] = w->pre_ild_sum[i];
        w->pre_ild_sum_H[i-1] = w->pre_ild_sum_H[i];
        
    }
	sum_mean /= (Float)FNUM;
	sum_meanH /= (Float)FNUM;

    w->pre_ild_sum[i - 1] = ILD_sum;
    w->pre_ild_sum_H[i - 1] = ILD_sumH;
    sum_mean += ILD_sum / FNUM;
    sum_meanH += ILD_sumH / FNUM;

    dev = abs_f(ILD_sum - sum_mean);

    devH = abs_f(ILD_sumH - sum_meanH);

    flag = 0;

    if (dev > 210 || devH > 77)
    {
        flag = 1;
    }

     return(flag);
}

/*************************************************************************
* ild_attack_detect_shb
*
* Super higher band stereo transient detection
**************************************************************************/
Short ild_attack_detect_shb( Float* L_ener, /* i: energy per sub-band of L channel */
                             Float* R_ener, /* i: energy per sub-band of R channel */
                             Short q_left_en,
                             Short q_right_en,
                             void* ptr
                             )
{
    Short i;
    Float sum_mean;
    Float dev;

    Short flag;
    Float ILD;
    Float ILD_sum;
    Short tmp;
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr;

    flag = 0; 

    tmp     = (q_left_en - q_right_en);
		
	ILD_sum = ild_calculation(L_ener[0], R_ener[0] * powT[60 + tmp]);

	ILD = ild_calculation(L_ener[1], R_ener[1] * powT[60 + tmp]);

    ILD_sum = (ILD_sum + ILD);

    w->pre_ild_sum_swb[w->pos]   = ILD_sum;  

    sum_mean = (w->pre_ild_sum_swb[0] + w->pre_ild_sum_swb[1]);
    for(i = 2; i < FNUM; i++)
    {
        sum_mean = (sum_mean + w->pre_ild_sum_swb[i]);
    }
	sum_mean = sum_mean * 0.1428571429f; /* /7 */

	dev = abs_f(ILD_sum - sum_mean);

    if(dev > 34.25f)
    {
        flag = 1;
    }

    return(flag);
}

/*-----------------------------------------------------------------------*
*                                                                        *
*                   Quantization of stereo parameters                    *
*                                                                        *
*------------------------------------------------------------------------*/
static Short searchSegPWQU_5seg(Float val);
static void searchNeighborPWQU (Short *idxQ0, Float val, Short valQ,
                                Short halfStepQ, const Short *indPWQU);
static Short searchSegPWQU_3seg(Float val, const Short *threshPWQU);
static Short searchSegQ_2bits(Float val);

static Short quantUniform(Short param,
                     const Short *ptrParam, 
                     const Short *tabQ, 
                           Short *index);

static Short searchIdxPWQU_5seg_5bits(Float val);
static Short searchIdxPWQU_3seg_4bits(Float val);
static Short searchIdxPWQU_3seg_3bits(Float val);

static Short searchIdxQU(Short param, /* i: parameter value to quantize*/                
                    const Short *ptrParam, 
                    const Short *tabQ);
/*************************************************************************
* searchIdxQU: search the quantization index of uniform quantizer on 4 or 5 bits
* routine called by quantWholeWB_ITDorIPD to quantize whole wideband IPD on 4 bits (16 levels)
* quantizer in tab_phase_q4
* routine called by quantUniform to quantize individuals IPDs with 5 or 4 bits  
* parameters of uniform quantizer in ParamQuantPhase: 
* 1/stepQ, nbLevels/2-1, stepQ/2, 0, nbLevels-1
* uniform quantizer levels in tabQ (tab_phase_q5 or tab_phase_q4)
**************************************************************************/
static Short searchIdxQU(Short param, /* i: parameter value to quantize*/                
                    const Short *ptrParam, 
                    const Short *tabQ)
{
    Short idxQ0, valQ; 

    /* parameters of uniform phase quantizers */
	idxQ0 = roundFto16(param * (*ptrParam++) * 0.000030517578125f); /* param*invStepQ */

    idxQ0 = (idxQ0 + *ptrParam++);  /* param*invStepQ + nbQLev/2*/
    valQ  = tabQ[idxQ0];  

    searchNeighborPWQU(&idxQ0, param, valQ, *ptrParam, ptrParam+1);

    return(idxQ0);
}

/*************************************************************************
* searchSegPWQU_3seg
* routine called by searchIdxPWQU_3seg_3bits and searchIdxPWQU_3seg_4bits
* search the segment in a piece wise uniform quantizer with 3 segments
* segment thresholds in threshPWQU4 or threshPWQU3
**************************************************************************/
static Short searchSegPWQU_3seg(Float val, const Short *threshPWQU)
{
    Short iseg;
    const Short *ptrThreshPWQU;

    ptrThreshPWQU = threshPWQU;
    iseg = 0; 
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }

    return(iseg);
}

/*************************************************************************
* searchSegQ_2bits
* routine called by quantRefineILD
* search the segment in a scalar quantizer with 4 levels (2bits)
* quantizer thresholds in threshPWQU2
**************************************************************************/
static Short searchSegQ_2bits(Float val)
{
    Short iseg;
    const Short *ptrThreshPWQU;

    ptrThreshPWQU = threshPWQU2;
    iseg = 0; 
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }

    return(iseg);
}

/*************************************************************************
* searchSegPWQU_5seg
* routine called by searchIdxPWQU_5seg_5bits( ILDs quantization with 5 bits)  
* search the segment in a piece wise uniform quantizer with 5 segments
* segment thresholds in threshPWQU5 
**************************************************************************/
static Short searchSegPWQU_5seg (Float val)
{
    Short iseg;
    const Short *ptrThreshPWQU;

    ptrThreshPWQU = threshPWQU5;
    iseg = 0; 
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }
    if(val > *ptrThreshPWQU++) {
        iseg++;
    }

    return(iseg);
}

/*************************************************************************
* quantUniform
* routine called by quantIPD: uniform quantization of IPDs with 5 or 4 bits  
* parameters of uniform quantizer in ParamQuantPhase: 
* 1/stepQ, nbLevels/2-1, stepQ/2, nbLevels-1
* uniform quantizer levels in tabQ (tab_phase_q5 or tab_phase_q4)
**************************************************************************/
Short quantUniform(      Short param, 
                    const Short *ptrParam, 
                    const Short *tabQ, 
                          Short *index
                    )
{

    *index = searchIdxQU(param, ptrParam, tabQ); 

    return tabQ[*index];
}

/*************************************************************************
* searchIdxPWQU_3seg_4bits
* routine called by quantRefineILD, quantILD0, calc_quantILD_diff
* piece wise uniform quantization with 3 segments and 4 bits 
* quantizer: tab_ild_q4
**************************************************************************/
static Short searchIdxPWQU_3seg_4bits(Float val)
{
    Short iseg, idxQ, valQ; 
	Float val2;

    iseg = searchSegPWQU_3seg (val, threshPWQU4); 
    val2 = (val + bSeg4[iseg]); 

	idxQ = roundFto16(val2 * invStepQ4_QN15[iseg]);

    idxQ = (idxQ + ind0Seg4[iseg]);
    valQ = tab_ild_q4[idxQ];
    searchNeighborPWQU(&idxQ,val, valQ, halfStepQ4[iseg], &indPWQU4[iseg]); 

    return(idxQ);
}

/*************************************************************************
* searchIdxPWQU_3seg_3bits
* routine called by quantRefineILD and quantILD0
* piece wise uniform quantization with 3 segments on 3 bits
* quantizer: tab_ild_q3
**************************************************************************/
static Short searchIdxPWQU_3seg_3bits(Float val)
{
    Short idxQ, iseg;

    iseg = searchSegPWQU_3seg (val, threshPWQU3);
    idxQ = initIdxQ3[iseg]; 
    if(iseg == 1) {
		idxQ += roundFto16(val * 0.00048828125f);

        searchNeighborPWQU (&idxQ, val, tab_ild_q3[idxQ], HALFSTEPQ3, indPWQU3);
    }

    return(idxQ);
}

/*************************************************************************
* searchIdxPWQU_5seg_5bits
* routine called by g711_stereo_encoder_shb, quantILD0 and and calc_quantILD_abs
* piece wise uniform quantization of ILD with 5 bits
**************************************************************************/
static Short searchIdxPWQU_5seg_5bits(Float val)
{
    Short iseg, idxQ, valQ;
	Float val2;

    iseg = searchSegPWQU_5seg (val); 
    val2 = (val + bSeg5[iseg]);

	idxQ = roundFto16(val2 * invStepQ5_QN15[iseg]);

    idxQ = (idxQ + ind0Seg5[iseg]);
    valQ = tab_ild_q5[idxQ];
    searchNeighborPWQU(&idxQ, val, valQ, halfStepQ5[iseg], &indPWQU5[iseg]); 

    return (idxQ);
}

/*************************************************************************
* searchNeighborPWQU
* routine called by searchIdxPWQU_3seg_4bits,searchIdxPWQU_3seg_3bits, 
* and searchIdxPWQU_5seg_5bits
* select the nearest neighbour between two quantization levels 
**************************************************************************/
static void searchNeighborPWQU(Short *idxQ0, 
                               Float val, 
                               Short valQ,
                               Short halfStepQ, 
                               const Short *indPWQU
                               ) 
{
    Float errQL1, errQ2;
	Short idxQ;

    idxQ = *idxQ0; 
    errQL1 = val - valQ;

    if(errQL1 < 0) 
    {
        errQ2 = (errQL1 + halfStepQ);

        if(errQ2 <= 0) 
			idxQ--;
        idxQ = maxS(*indPWQU,idxQ);
    }
	else
    {
        indPWQU++;
        errQ2 = (errQL1 - halfStepQ);

        if(errQ2 >0) 
			idxQ++;
        idxQ = minS(*indPWQU,idxQ);
    }
    *idxQ0 = idxQ; 

    return;
}

/*************************************************************************
* calcGain
*
* Calculate the energy correction gain
**************************************************************************/
static Float calcGain( Float L_ener, Float R_ener, Float M_ener, Short Qcm) 
{
    Float L_temp, L_temp2;
    Short tmp1;
	Float gain;

    gain = 1.0f; 
    if(M_ener > 0) 
    {
        L_temp2 = roundFto32F(L_ener + R_ener);
		L_temp  = roundFto32F(L_temp2 * Pow(0.5f, (Qcm + 1.0f)));

        if(L_temp >= M_ener) 
        {
            gain = 2.0f; 
            tmp1 = norm_l(roundFto32(M_ener));

            L_temp  = roundFto32F(M_ener * Pow(2.0f, (Float)tmp1));
            L_temp2 = roundFto32F(L_temp2 * Pow(2.0f, (tmp1 - (Qcm + 2.0f))));

            if(L_temp2 < L_temp) 
            {
			    gain = 2.0f * L_temp2 / L_temp;
            }
        }
    }

    return(gain);
}

/*************************************************************************
* g711_stereo_encode_const
*
* g711 stereo encoder constructor
**************************************************************************/
void *g711_stereo_encode_const()
{
    g711_stereo_encode_WORK *w = NULL;

    /* Static memory allocation */
    w = (g711_stereo_encode_WORK *)malloc(sizeof(g711_stereo_encode_WORK));

    if (w != NULL)
    {
        g711_stereo_encode_reset((void *)w);
    }
    return (void *)w;
}

/*************************************************************************
* g711_stereo_encode_dest
*
* g711 stereo encoder destructor
**************************************************************************/
void g711_stereo_encode_dest( void*  p_work)   /* (i): Work space */
{
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)p_work;

    if (w != NULL)
    {
        free(w);
    }
    return;
}

/*************************************************************************
* g711_stereo_encode_reset
*
* g711 stereo encoder reset
**************************************************************************/
void  g711_stereo_encode_reset( void*  p_work)   /* (i/o): Work space */
{
    g711_stereo_encode_WORK *w=(g711_stereo_encode_WORK *)p_work;

    if (w != NULL)
    {
        /* L channel */
        zeroF(G711_WB_DMX_DELAY, w->mem_input_left);
        /* R channel */
        zeroF(G711_WB_DMX_DELAY, w->mem_input_right);

        zero32(NB_SB,w->mem_L_ener);
        zero32(NB_SB,w->mem_R_ener);

        zeroS(20,w->mem_ild_q);
        zeroS(20,w->pre_q_left_en_band);
        zeroS(20,w->pre_q_right_en_band);

        zeroF(L_FRAME_WB,w->mem_mono);
        zeroF(L_FRAME_WB,w->mem_side);

		zeroF(G711_WB_DMX_DELAY, w->mem_mono_ifft_s); /* mono signal */

        zeroF(L_FRAME_WB,w->mem_left);
        zeroF(L_FRAME_WB,w->mem_right);

		zeroF(FNUM,w->pre_ild_sum_swb);

        zeroF(FNUM,w->pre_ild_sum);
        zeroF(FNUM,w->pre_ild_sum_H);

        w->pos              = 0; 
        w->SWB_ILD_mode     = 0; 
        w->frame_flag_wb    = 0; 
        w->frame_flag_swb   = 0; 
        w->c_flag           = 0; 
        w->pre_flag         = 0; 
        w->num              = 0; 
        w->mem_q_channel_en = 0; 
        w->mem_q_mono_en    = 0; 
        w->swb_frame_idx    = 0; 

        w->mem_l_enr[0]     = 0; 
        w->mem_l_enr[1]     = 0; 
        w->mem_r_enr[0]     = 0; 
        w->mem_r_enr[1]     = 0; 
        w->mem_m_enr[0]     = 0; 
        w->mem_m_enr[1]     = 0; 

        w->fb_ITD           = 0; 
        w->ic_idx           = 0; 
        w->ic_flag          = 0; 
        w->ipd_num          = 0; 
        w->ipd_reg_num      = 0; 
        w->pre_Itd          = 0;

		w->pre_Ipd          = 0.0f;

        w->std_itd_pos_sm   = 1280;  /* 5.0f; */
        w->std_itd_neg_sm   = 1280;  /* 5.0f; */
        w->nb_idx_pos_sm    = 0; 
        w->nb_idx_neg_sm    = 0; 
        w->pre_itd_neg      = 0; 
        w->pre_itd_pos      = 0; 

        zero32(STARTBANDITD+BANDITD, w->Crxyt);
        zero32(STARTBANDITD+BANDITD, w->Cixyt);
        zero32(STARTBANDITD+BANDITD, w->Crxyt2);
        zero32(STARTBANDITD+BANDITD, w->Cixyt2);

        zeroS(10, w->phase_mean_buf);

		zeroF(10, w->phase_mean_buf1);

        w->phase_num = 0; 
        w->pos1      = 0; 
        w->f_num     = 0; 
        zero32(STARTBANDITD + BANDITD, w->energy_bin_sm);

        w->en_ratio_sm          = 0; 

		w->phase_mean_std_sm_ct = 0.0f;

        w->mem_energyL          = 0; 
        w->mem_energyR          = 0; 
        w->pre_ipd_mean         = 0; 
        w->ipd_reg_num_sm       = 0; 

		w->phase_mean_std_sm    = 0.0f;
        w->ipd_mean_sm          = 0.0f;
    }
    return;
}

/*************************************************************************
* downmix_swb
*
* Downmix stereo to mono of superwideband part
**************************************************************************/
void downmix_swb(Float*    input_left,  /* i: input L channel*/
                 Float*    input_right, /* i: input R channel*/
                 Float*    mono,        /* o: mono signal */
                 Float*    side,
                 void*      ptr
                 )
{
    Short i;

    Float tmp_l,tmp_r;
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr;

    for(i = 0; i < L_FRAME_WB; i ++)
    {
        tmp_l = w->mem_left[i] * 0.5f;
        tmp_r = w->mem_right[i] * 0.5f;

        mono[i] = tmp_l + tmp_r;
        side[i] = tmp_l - tmp_r;
    }

    movF(L_FRAME_WB, input_left, w->mem_left);
    movF(L_FRAME_WB, input_right, w->mem_right);
}

static Short getIPD(Short swb_flag, Float *L_real, Float *L_imag, 
                     Float *R_real, Float *R_imag, Short *IPD, 
                     Float *eLeftS, Float *eRightS);

static Short computeMonoDownmix(Short swb_flag, Short q_left, Short q_right, 
                                 Short *mem_ild_q, Short *IPD, Short fb_IPD, 
                                 Float *mono_real, Float *mono_imag, 
                                 Float *eLeftS, Float *eRightS, 
                                 Float *L_real, Float *L_imag);

static void calcPhaseDownmix(Short nbCoef, Float mem_ild_dq, Short *IPD, 
                             Short fb_IPD, Float *L_real, Float *L_imag,
                             Short iTmpHi, Float *L_ptr, Float *L_ptr2, 
                             Float *mono_real, Float *mono_imag);

static void quantIPD(Short mode, Short swb_flag, Short SWB_ILD_mode, 
                     Short *IPD, Short *idx);

/*************************************************************************
* downmix
*
* Downmix stereo to mono in frequency domain
**************************************************************************/
void downmix(Float *input_left,  /* i: input L channel*/
             Float *input_right, /* i: input R channel*/
             Short *mono,    /* o: mono signal */
             void   *ptr,
             Short *bpt_stereo,
             Short mode,
             Short *frame_idx,
             Short Ops
             )
{
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr;
    Short i;

    Float f_L_real[NFFT + 2];
    Float f_R_real[NFFT + 2];

    Float *f_L_imag = &f_L_real[81],*f_R_imag = &f_R_real[81];

    Short q_left;
    Short q_right;
    /* downmix in FFT domain */
	Float f_mono_real[NFFT + 2];
	Float *f_mono_imag = &f_mono_real[NFFT/2 + 1]; 

    Short IPD[NFFT/2 + 1];
    Short q_mono;

    Float eLeftS[81], eRightS[81];

    Short swb_flag;
    Short nbCoef;

    swb_flag = (Ops == 32000);

    windowStereoF(input_left,  w->mem_input_left,  f_L_real);
    windowStereoF(input_right, w->mem_input_right, f_R_real);

    sDoRFFTx(f_L_real, &q_left);
    sDoRFFTx(f_R_real, &q_right);

	nbCoef = getIPD(swb_flag, f_L_real, f_L_imag, f_R_real, f_R_imag, IPD, eLeftS, eRightS);

    /*extract full band ITD,IPD and IC */
    get_interchannel_difference(w, f_L_real, f_L_imag, q_left, f_R_real, 
                                f_R_imag, q_right, &w->ic_idx, &w->ic_flag);

    quantIPD(mode, swb_flag, w->SWB_ILD_mode,  IPD, w->idx);

    /*mainloop for ILD estimation, quantization and stereo bitstream writing*/
    g711_stereo_encode(f_L_real, f_L_imag, f_R_real, f_R_imag, q_left, q_right, bpt_stereo, w, frame_idx, mode ,Ops);

    q_mono = computeMonoDownmix(swb_flag, q_left, q_right, w->mem_ild_q, IPD, w->fb_IPD, 
                                f_mono_real, f_mono_imag, eLeftS, eRightS, f_L_real, f_L_imag);

	sDoRiFFTx(f_mono_real, &q_mono);

    /* overlap and add downmix mono */
	f_OLA( &f_mono_real[15], w->mem_mono_ifft_s, mono);

    /* update memory */
    for(i=0; i<50; i++)
    {
        w->mem_input_left[i]  = input_left[i + 30];  
        w->mem_input_right[i] = input_right[i + 30];
		w->mem_mono_ifft_s[i] = f_mono_real[i + 95] * win_D[49 - i]; 
    }
}

/*************************************************************************
* quantIPD
*
* Quantize IPD
**************************************************************************/
static void quantIPD(Short mode, Short swb_flag, Short SWB_ILD_mode,  
                     Short *IPD, Short *idx)
{
    Short nbBand, j;
    Short *ptrIPD, *ptrIdx;

	nbBand = IPD_SYN_WB_END_WB+1 - IPD_SYN_START - swb_flag * 2;

    ptrIPD = IPD + IPD_SYN_START;
    ptrIdx = idx + IPD_SYN_START;
  
    for(j=0; j<nbBand; j++)
    {
        *ptrIPD = quantUniform(*ptrIPD, paramQuantPhase,tab_phase_q5, ptrIdx); 
        ptrIPD++; ptrIdx++;
    }

    if(swb_flag)
    {
        /*if swb_ILD_mode =0  IPD[8] quantized on 4 bits  else swb_ILD_mode =1 IPD[8] quantized on 5 bits */
        if(SWB_ILD_mode == 0)
        {
            *ptrIPD = quantUniform(*ptrIPD, paramQuantPhase+5,tab_phase_q4, ptrIdx); 
        }
        else
        {
            *ptrIPD = quantUniform(*ptrIPD, paramQuantPhase,tab_phase_q5, ptrIdx); 
        }
        if(mode == MODE_R6ss || mode == MODE_R6sss || mode == MODE_R7sss)
        { /* for R6ss, R6sss and R7sss only : quantize 16 IPDs - bins 9 to 24 - each quantized with 5 bits*/
			nbBand = IPD_SYN_SWB_END_SWB - IPD_SYN_WB_END_SWB;
            ptrIPD++; ptrIdx++;

            for(j=0; j<nbBand; j++)
            {
                *ptrIPD = quantUniform(*ptrIPD, paramQuantPhase,tab_phase_q5, ptrIdx); 
                ptrIPD++; ptrIdx++;
            }
        }
    }
    if(mode == MODE_R5sws)
    { /* for R5sws only : quantize 16 IPDs - bins 10 to 25 - each quantized with 5 bits*/
        nbBand = (IPD_SYN_SWB_END_SWB+1 - IPD_SYN_WB_END_WB);

        for(j=0; j<nbBand; j++)
        {
            *ptrIPD = quantUniform(*ptrIPD, paramQuantPhase,tab_phase_q5, ptrIdx);
            ptrIPD++; ptrIdx++;
        }
    }
    return;
}

/*************************************************************************
* getIPD
*
* Compute IPD per frequency bin
**************************************************************************/
static Short getIPD(Short swb_flag, Float *L_real, Float *L_imag, 
                     Float *R_real, Float *R_imag, Short *IPD, 
                     Float *eLeftS, Float *eRightS)
{
    Short j, nbCoef;
    Float f_tmp, f_tmp2;

    nbCoef = 81; 
    if(swb_flag == 0)
    {
        nbCoef = 71; 
        /* zeroing the interval [7000, 8000 Hz] */
		for(j=71; j<81; j++)
        {
            L_real[j]  = 0.0f; 
            L_imag[j]  = 0.0f; 
            R_real[j]  = 0.0f; 
            R_imag[j]  = 0.0f;
            IPD[j]     = 0; 
            eLeftS[j]  = 0.0f; 
            eRightS[j] = 0.0f; 
        }
    }

    /*  Get IPD of current frame */
    for(j= 0;j< nbCoef ;j++)
    {
		eLeftS[j] = Sqrt(L_real[j] * L_real[j] + L_imag[j] * L_imag[j]);
		eRightS[j] = Sqrt(R_real[j] * R_real[j] + R_imag[j] * R_imag[j]);

        f_tmp2      = 1.0f + L_real[j] * R_real[j] + L_imag[j] * R_imag[j];
        f_tmp      = L_imag[j] * R_real[j] - L_real[j] * R_imag[j];
		IPD[j] = roundFto16((Float)atan2(f_tmp, f_tmp2) * 4096.0f);
    }
    
    return (nbCoef);
}

/*************************************************************************
* computeMonoDownmix
*
* Compute mono downmix
**************************************************************************/
static Short computeMonoDownmix(Short swb_flag, Short q_left, Short q_right, Short *mem_ild_q,
                                 Short *IPD, Short fb_IPD, Float *mono_real, Float *mono_imag, 
                                 Float *eLeftS, Float *eRightS, Float *L_real, Float *L_imag)
{
    Short iTmpHi, q_mono, nbCoef, i, j;
	Float mem_ild_dq;

    Float *L_ptr, *L_ptr2;
    Short *ptrIPD;
	Float*ptrReal, *ptrImag, *ptr_mono_real, *ptr_mono_imag;

    const Float *ptr0 = c_table10 + 80;

    iTmpHi = (q_left - q_right);
    L_ptr  = eLeftS;
    L_ptr2 = eRightS;
    if(iTmpHi < 0)
    {
        L_ptr  = eRightS;
        L_ptr2 = eLeftS;
    }
    q_mono = minS(q_left, q_right);
    q_mono = (q_mono - 16);

	iTmpHi = absS(iTmpHi) + 1;

    ptrIPD  = IPD;
    ptrReal = L_real;
    ptrImag = L_imag;
    ptr_mono_real = mono_real;
    ptr_mono_imag = mono_imag;

    for (i = 0; i < 19; i++)
    {
		j = (mem_ild_q[i] >> 9);

        mem_ild_dq = ptr0[j]; 
        nbCoef = nbCoefBand[i]; 
        calcPhaseDownmix(nbCoef, mem_ild_dq, ptrIPD, fb_IPD, ptrReal, ptrImag,
                         iTmpHi, L_ptr, L_ptr2, ptr_mono_real, ptr_mono_imag) ;
        ptrIPD  += nbCoef;
        ptrReal += nbCoef;
        ptrImag += nbCoef;
        L_ptr   += nbCoef;
        L_ptr2  += nbCoef;
        ptr_mono_real += nbCoef;
        ptr_mono_imag += nbCoef;
    }

    nbCoef = nbCoefBand[19];

	j = (mem_ild_q[19] >> 9);

    mem_ild_dq = ptr0[j]; 
    if (swb_flag == 0)
    {
        /* zeroing the interval [7000, 8000 Hz] */
        for(j=71; j<81; j++)
        {
            mono_real[j] = 0; 
            mono_imag[j] = 0; 
        }
        nbCoef = (nbCoef - 10);
    }
    calcPhaseDownmix(nbCoef, mem_ild_dq, ptrIPD, fb_IPD, ptrReal, ptrImag,
                     iTmpHi, L_ptr, L_ptr2, ptr_mono_real, ptr_mono_imag) ;
    
    return (q_mono);
}

/*************************************************************************
* calcPhaseDownmix
*
* Compute phase of the mono downmix
**************************************************************************/
static void calcPhaseDownmix(Short nbCoef, Float mem_ild_dq, Short *IPD, 
                             Short fb_IPD, Float *L_real, Float *L_imag,
                             Short iTmpHi, Float *L_ptr, Float *L_ptr2, 
                             Float *mono_real, Float *mono_imag) 
{
    Short j;
	Float tmp16;

	Float iPhaseCos, iPhaseSin;
	Float iCPhase, Dmx_arg, L_arg, iTmpPhase;
	Float mono_mag;

	Float pow_tmp = Pow(0.5f, iTmpHi);
	Float pow_tmp2 = Pow(0.5f, 12);

    for(j = 0; j < nbCoef; j++)
    {
        /*calculate the phase of downmix signal*/
        tmp16   = (Float)IPD[j] - fb_IPD;
        IPD[j]  = (Short)Round_Phase(tmp16); 

		iCPhase = (Float)mem_ild_dq * IPD[j] * pow_tmp2;

		L_arg = (Float)atan2(L_imag[j], L_real[j]);

        Dmx_arg = (L_arg - iCPhase);

		iPhaseCos =  Cos(Dmx_arg);

        iTmpPhase =  ( 1.57079632f - Dmx_arg ) ;

		iPhaseSin =  Cos(iTmpPhase)  ;

        /*calculate the amplitude of downmix signal*/
		mono_mag = ( *L_ptr++) * pow_tmp + (*L_ptr2++) * 0.5f;

        /*calculate the real and imag of downmix signal*/
		mono_real[j] = mono_mag * iPhaseCos;
		mono_imag[j] = mono_mag * iPhaseSin;
    }

    return;
}

static void calcEnerBandShb(Short *mono_mdct, Short *side_mdct, 
                            Short norm_mono, Short norm_side, 
                            Float *enerM, Float *enerL,  Float *enerR,
                            Short *q_mono_en, Short *q_channel_en);
static Float calcEnerOneBandSwb0(Short n, Short *ptr);
static Float calcEnerOneBandSwb1(Short n, Short *ptr, Short nbShr);
static Float calcXYOneBandSwb0(Short n, Short *ptr0, Short *ptr1);
static Float calcXYOneBandSwb1(Short n, Short *ptr0, Short *ptr1, Short nbShr);
static void calcEnerLRSwb(Short nbShM, Short nbShS, Short nbShMS,
                          Float enerM, Float enerS, Float enerMS, 
                          Float *enerL, Float *enerR, Short *q_channel_en);
static Short setSameQval(Short diffQ, Short *nbSh, Float *ener);
static Short setSameQval2(Short diffQ, Short *nbSh, Float *enerL, Float *enerR );

/*************************************************************************
* calcEnerBandShb
* routine called by g711_stereo_encoder_shb
* Calculation of energy in the 2 SHB sub bands: mono, left and right channels
**************************************************************************/
static void calcEnerBandShb(Short *mono_mdct, Short *side_mdct, 
                            Short norm_mono, Short norm_side, 
                            Float *enerM, Float *enerL, Float *enerR, 
                            Short *q_mono_en, Short *q_channel_en)
{
    Float *ptrE;
    Short q_mono_en_loc[2], q_channel_en_loc[2];
    Float ener_loc[4], *enerS, *enerMS;
    Short nbSh[4], *nbShM, *nbShS, *nbShMS;
    Short *ptr, *ptr_sh, tmp, normM, normS, normMS;
    Short norm_mono2, norm_side2, norm_ms;
    Short *ptrm, *ptrs;

    enerS  = ener_loc;
    enerMS = ener_loc+2;
    nbShM  = q_mono_en_loc;
    nbShS  = nbSh;
    nbShMS = nbSh+2;
    normM  = ExpSArray(60, mono_mdct);
    norm_mono2 = (norm_mono * 2);
    norm_side2 = (norm_side * 2);
    norm_ms    = (norm_mono + norm_side);

    /* compute ener mono */
    ptr_sh = nbShM;
    ptr    = mono_mdct;
    ptrE   = enerM;
    tmp    = (2 - normM);
    if(tmp<=0)
    {
        *ptrE++ = calcEnerOneBandSwb0(20, ptr); 
        *ptr_sh++ = norm_mono2; 
    }
    else
    {
        tmp = (tmp * 2);
        *ptrE++ = calcEnerOneBandSwb1(20, ptr,tmp); 
        *ptr_sh++ = (norm_mono2 - tmp); 
    }
    ptr += 20;
    tmp = (3 - normM);
    if(tmp<=0)
    {
        *ptrE++ = calcEnerOneBandSwb0(40, ptr); 
        *ptr_sh++ = norm_mono2; 
    }
    else
    {
        tmp = ((tmp * 2) - 1);
        *ptrE++ = calcEnerOneBandSwb1(40, ptr,tmp); 
        *ptr_sh++ = (norm_mono2 - tmp); 
    }
    /* compute ener side */
    normS  = ExpSArray(60, side_mdct);
    ptr_sh = nbSh;
    ptr    = side_mdct;
    ptrE   = ener_loc;
    tmp    = (2 - normS);
    if(tmp<=0)
    {
        *ptrE++ = calcEnerOneBandSwb0(20, ptr); 
        *ptr_sh++ = norm_side2; 
    }
    else
    {
        tmp = (tmp * 2);
        *ptrE++ = calcEnerOneBandSwb1(20, ptr,tmp); 
        *ptr_sh++ = (norm_side2 - tmp); 
    }
    ptr += 20;
    tmp = (3 - normS);
    if(tmp<=0)
    {
        *ptrE++ = calcEnerOneBandSwb0(40, ptr); 
        *ptr_sh++ = norm_side2; 
    }
    else
    {
        tmp = ((tmp * 2) - 1);
        *ptrE++ = calcEnerOneBandSwb1(40, ptr,tmp); 
        *ptr_sh++ = (norm_side2 - tmp); 
    }

    /* compute M*S */
    ptrm   = mono_mdct;
    ptrs   = side_mdct;
    ptrE   = enerMS;
    normMS = (normM + normS);

    tmp = (4 - normMS);
    if(tmp<=0)
    {
        *ptrE++ = calcXYOneBandSwb0(20, ptrm, ptrs); 
        *ptr_sh++ = norm_ms; 
    }
    else
    {
        *ptrE++ = calcXYOneBandSwb1(20, ptrm, ptrs, tmp); 
        *ptr_sh++ = (norm_ms - tmp); 
    }
    ptrm += 20;
    ptrs += 20;

    tmp = (5 - normMS);
    if(tmp<=0)
    {
        *ptrE++ = calcXYOneBandSwb0(40, ptrm, ptrs); 
        *ptr_sh++ = norm_ms; 
    }
    else
    {
        *ptrE++ = calcXYOneBandSwb1(40, ptrm, ptrs, tmp); 
        *ptr_sh++ = (norm_ms - tmp); 
    }

    /* compute ener left and right and and update q_en shr */
    calcEnerLRSwb(nbShM[0], nbShS[0],nbShMS[0],enerM[0],enerS[0], enerMS[0],
                  &enerL[0], &enerR[0],&q_channel_en_loc[0]);

    calcEnerLRSwb(nbShM[1], nbShS[1],nbShMS[1],enerM[1],enerS[1], enerMS[1],
                  &enerL[1], &enerR[1],&q_channel_en_loc[1]);

    /*set QVal for both bands */
    tmp = (q_mono_en_loc[0] - q_mono_en_loc[1]);
    *q_mono_en = q_mono_en_loc[0];
    if(tmp > 0)
    {
        *q_mono_en = setSameQval(tmp, nbShM, enerM);
    }
    tmp = (q_channel_en_loc[0] - q_channel_en_loc[1]);
    *q_channel_en = q_channel_en_loc[0];
    if(tmp > 0)
    {
        *q_channel_en = setSameQval2(tmp, q_channel_en_loc, enerL, enerR );
    }
    *q_channel_en = (*q_channel_en - 2); 

    return;
}

/*************************************************************************
* setSameQval
* routine called by calcEnerBandShb
* set the two SHB sub band energies to the same Q value
**************************************************************************/
static Short setSameQval(Short diffQ, Short *nbSh, Float *ener)
{
    Short qVal;
    Short norm1, tmp;

    qVal = nbSh[0]; 
    if(ener[1] != 0)
    {
        norm1 = norm_l(roundFto32(ener[1]));
        tmp = (norm1 - diffQ);
        if(tmp >=0) 
        {
			ener[1] *= powT[60 + diffQ];
        }
        else
        {
            ener[0] *= powT[60 + tmp];
            ener[1] *= powT[60 + norm1];

            qVal = (nbSh[0] + tmp);
        }
    }

    return(qVal);
}

/*************************************************************************
* setSameQval2
* routine called by calcEnerBandShb
* set the SHB sub bands  of the left and right channles to the same Q value
**************************************************************************/
static Short setSameQval2(Short diffQ, Short *nbSh, Float *enerL, Float *enerR )
{
    Short qVal;
    Short norm1, tmp;
    Word32 Lmax;

    Lmax = roundFto32(f_max(enerL[1], enerR[1]));

    qVal = nbSh[0]; 
    if(Lmax !=0)
    {
        norm1 = norm_l(Lmax);
        tmp   = (norm1 - diffQ);
        if(tmp >= 0) 
        {
            enerL[1] *= powT[60 + diffQ];
            enerR[1] *= powT[60 + diffQ];
        }
        else
        {
            enerL[0] *= powT[60 + tmp];
            enerL[1] *= powT[60 + norm1];
            enerR[0] *= powT[60 + tmp];
            enerR[1] *= powT[60 + norm1];
            qVal = (nbSh[0] + tmp);
        }
    }

    return(qVal);
}

/*************************************************************************
* calcEnerLRSwb
* routine called by calcEnerBandShb
* compute the SHB sub band energies of left and right channels
**************************************************************************/
static void calcEnerLRSwb(Short nbShM, Short nbShS, Short nbShMS,
                          Float enerM, Float enerS, Float enerMS, 
                          Float *enerL, Float *enerR, Short *q_channel_en) 
{
    Short tmp, tmp1, tmp2;
    Float enerM_S, Ltemp, Ltemp2;

    tmp = (nbShM - nbShS);
    if(tmp >= 0) 
    {
		enerM_S = enerM * Pow(0.5f, tmp + 1.0f) + enerS * 0.5f;
    }
    else
    {
		enerM_S = enerM * 0.5f + enerS * Pow(0.5f, 1.0f - tmp);
    }
	tmp1 = minS(nbShM, nbShS);

    tmp2 = (tmp1 - nbShMS);
    if(tmp2 >= 0) 
    {
        Ltemp  = enerM_S * Pow(0.5f, tmp2 + 1.0f);
        Ltemp2 = enerMS * 0.5f;
    }
    else
    {
        tmp2   = -(tmp2);

		Ltemp  = enerM_S * 0.5f;
		Ltemp2 = (enerMS * Pow(0.5f, tmp2 + 1.0f));
    }
    *enerL = Ltemp + Ltemp2;
    *enerR = Ltemp - Ltemp2;

	*q_channel_en = minS(tmp1, nbShMS);

    return;
}

/*************************************************************************
* calcXYOneBandSwb0
* routine called by calcEnerBandShb
* compute  mono and side signals cross-correlation SUM mono(i)*side(i)
* without saturation (no need to shift right )
**************************************************************************/
static Float calcXYOneBandSwb0(Short n, Short *ptr0, Short *ptr1)
{
    Float L_temp;
    Short j;

    L_temp = (Float)(*ptr0++) * (*ptr1++);
    for(j=1; j<n; j++) 
    {
        L_temp += (Float)(*ptr0++) * (*ptr1++);
    }

    return(L_temp);
}

/*************************************************************************
* calcXYOneBandSwb1
* routine called by calcEnerBandShb
* compute  mono and side signals cross-correlation SUM mono(i)*side(i)
* with right shift to avoid saturation
**************************************************************************/
static Float calcXYOneBandSwb1(Short n, Short *ptr0, Short *ptr1, Short nbShr)
{
    Float L_temp, fact;
    Short j;

    L_temp  = (Float)(*ptr0++) * (*ptr1++);

	fact = Pow(0.5f, (Float)nbShr);

    for(j=1; j<n; j++) 
    {
        L_temp  += (Float)(*ptr0++) * (*ptr1++);
    }

    return L_temp * fact;
}

/*************************************************************************
* calcEnerOneBandSwb0
* routine called by calcEnerBandShb
* compute  SHB sub band energies of  mono and side signals 
* without saturation (no need to shift right )
**************************************************************************/
static Float calcEnerOneBandSwb0(Short n, Short *ptr)
{
    Float L_temp;
    Short j;

    L_temp = 1;
    for(j=0; j<n; j++) 
    {
        L_temp += (Float)(*ptr) * (*ptr);
        ptr++;
    }

    return(L_temp);
}

/*************************************************************************
* calcEnerOneBandSwb1
* routine called by calcEnerBandShb
* compute  SHB sub band energies of  mono and side signals 
* with right shift to avoid saturation
**************************************************************************/
static Float calcEnerOneBandSwb1(Short n, Short *ptr, Short nbShr)
{
    Float L_temp, fact;
    Short j;

	fact = Pow(0.5f, (Float)nbShr);
	L_temp = (Float)(*ptr) * (*ptr);
	ptr++;
    for(j=1; j<n; j++) 
    {
        L_temp += (Float)(*ptr) * (*ptr);
        ptr++;
    }

    return L_temp * fact + 1.0f;
}

static Short smoothEnerSHB_LR(Float *L_ener, Float *R_ener, Short nbShCur,
                               Float *mem_L_ener, Float *mem_R_ener, Short nbShPre);
static Short smoothEnerSHB_M(Float *M_ener, Short nbShCur, Float *mem_M_ener, Short nbShPre);

/*************************************************************************
* G711_stereo_encoder_shb
*
* G711 super higher band stereo encoder
**************************************************************************/
void G711_stereo_encoder_shb(Float* mono_in,
                             Float* side_in,
                             void*   ptr,
                             Short* bpt_stereo_swb,
                             Short  mode,
                             Float  *gain
                             )
{
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr;
    Short mono_mdct[L_FRAME_WB],side_mdct[L_FRAME_WB];
    Short i;
    Short *swb_pt = bpt_stereo_swb;

    Short norm_mono,norm_side;
    Short q_channel_en,q_mono_en;
    Short idx;
    Short tmp,diffQ;
    Short nbShCur, nbShPre;

    Float f_L_ener[SWB_BN],f_R_ener[SWB_BN]; 
    Float f_M_ener[SWB_BN];

	Float f_mono[80], f_mono_mdct[80];
	Float f_side_mdct[80];

	Float f_tmp;

    for(i=0; i<L_FRAME_WB; i+=2)
    {
        f_mono[i]    = -mono_in[i]; 
        f_mono[i+1]  = mono_in[i+1];
        side_in[i]    = -(Float)side_in[i]; 
    }
    /*mdct of mono and side signal*/
	f_mdct_point80(w->mem_mono, f_mono, f_mono_mdct);

	norm_mono = ExpFto16Array(80, f_mono_mdct);
	movFSQ(80, f_mono_mdct, mono_mdct, norm_mono);

	f_mdct_point80(w->mem_side, side_in, f_side_mdct);

	norm_side = ExpFto16Array(80, f_side_mdct);
	movFSQ(80, f_side_mdct, side_mdct, norm_side);

    calcEnerBandShb(mono_mdct, side_mdct, norm_mono, norm_side, f_M_ener, 
                    f_L_ener, f_R_ener, &q_mono_en, &q_channel_en);
    /* ILD attack detection for SHB*/
    w->SWB_ILD_mode = ild_attack_detect_shb(f_L_ener, f_R_ener, q_channel_en, q_channel_en, w);

    if(w->SWB_ILD_mode == 1) /*1 frames mode*/
    {
        swb_pt += 74; /*make room for the wb stereo bits*/
        w->swb_frame_idx = 0;

        f_L_ener[0] = (f_L_ener[0] + f_L_ener[1]) * 0.5f;
        f_R_ener[0] = (f_R_ener[0] + f_R_ener[1]) * 0.5f;
        f_M_ener[0] = (f_M_ener[0] + f_M_ener[1]) * 0.5f;

        /*calculate and quantize ILD in SHB with 5bits*/
		f_tmp = ild_calculation(f_L_ener[0],f_R_ener[0]);
		idx = searchIdxPWQU_5seg_5bits(f_tmp * 512.0f); 

        write_index5(swb_pt, idx);

        /* update memory last SHB band*/
        w->mem_l_enr[1] = f_L_ener[0];
        w->mem_r_enr[1] = f_R_ener[0];
        w->mem_m_enr[1] = f_M_ener[0];
    }
    else /*2 frames mode*/
    {
        swb_pt += 73; /*make room for the wb stereo bits*/

        if(w->frame_flag_swb == 0)
        {
            w->mem_q_channel_en = q_channel_en; 
            w->mem_q_mono_en    = q_mono_en;    
            w->frame_flag_swb   = 1;            
        }

        /*smooth the energy between two consecutive frames*/
        diffQ = (w->mem_q_channel_en - q_channel_en);
        nbShCur = maxS(1, (1 - diffQ));
        nbShPre = maxS(1, (1 + diffQ));
        tmp = smoothEnerSHB_LR(f_L_ener, f_R_ener, nbShCur, w->mem_l_enr, w->mem_r_enr, nbShPre);
        q_channel_en = (q_channel_en + tmp);
        
        diffQ = (w->mem_q_mono_en - q_mono_en);
        nbShCur = maxS(1, (1 - diffQ));
        nbShPre = maxS(1, (1 + diffQ));
        tmp = smoothEnerSHB_M(f_M_ener, nbShCur, w->mem_m_enr, nbShPre);
        q_mono_en = (q_mono_en + tmp);

        /* update memory last SHB band*/
        w->mem_l_enr[1] = f_L_ener[1]; 
        w->mem_r_enr[1] = f_R_ener[1]; 
        w->mem_m_enr[1] = f_M_ener[1]; 

        write_index1(swb_pt, w->swb_frame_idx);
#if 1//test
		{
			static int frame_c = 0;
			printf("frame %d\n", frame_c++);
			printf("w->swb_frame_idx %d\n", w->swb_frame_idx);
		}
#endif
        swb_pt += 1;
        /*calculate and quantize the ILD in SHB with 5 bits*/
		f_tmp = ild_calculation(f_L_ener[w->swb_frame_idx],f_R_ener[w->swb_frame_idx]);
        idx = searchIdxPWQU_5seg_5bits( f_tmp * 512.0f);

        write_index5(swb_pt, idx);
#if 1//test
		{
			printf("idx %d\n", idx);
		}
#endif
        w->swb_frame_idx = (w->swb_frame_idx + 1) & 1;
    }

    /*calculate the energy correction gain*/
    tmp = (q_channel_en - q_mono_en);

    gain[0] = calcGain(f_L_ener[0], f_R_ener[0], f_M_ener[0], tmp); 
    gain[1] = calcGain(f_L_ener[1], f_R_ener[1], f_M_ener[1], tmp);

    /* update memory 1st SHB band and Q values mono and channel */
    w->mem_l_enr[0] = f_L_ener[0]; 
    w->mem_r_enr[0] = f_R_ener[0]; 
    w->mem_m_enr[0] = f_M_ener[0];

    w->mem_q_mono_en    = q_mono_en;    
    w->mem_q_channel_en = q_channel_en; 
}

/*************************************************************************
* smoothEnerSHB_M
* routine called by g711_stereo_encoder_shb
* smooth energies of SHB sub-bands of mono signals with previous frame 
**************************************************************************/
static Short smoothEnerSHB_M(Float *M_ener, Short nbShCur, Float *mem_M_ener, Short nbShPre)
{
    Float LtmpM0, LtmpM1, tmp1, tmp2;
    Short nbShE;
    Word32 enerMax;

	tmp1 = Pow(0.5f, (Float)nbShPre);
	tmp2 = Pow(0.5f, (Float)nbShCur);

    LtmpM0 = (mem_M_ener[0] * tmp1 + M_ener[0] * tmp2); 
    LtmpM1 = (mem_M_ener[1] * tmp1 + M_ener[1] * tmp2);

    enerMax = roundFto32(f_max(LtmpM0, LtmpM1)); 
    nbShE   = norm_l(enerMax);
	tmp1 = Pow(2.0, nbShE);
    M_ener[0] = LtmpM0 * tmp1;
    M_ener[1] = LtmpM1 * tmp1;

    return (nbShE);
}

/*************************************************************************
* smoothEnerSHB_LR
* routine called by g711_stereo_encoder_shb
* smooth energies of SHB sub-bands of left and right channels with previous frame 
**************************************************************************/
static Short smoothEnerSHB_LR(Float *L_ener, Float *R_ener, Short nbShCur,
                               Float *mem_L_ener, Float *mem_R_ener, Short nbShPre)
{
    Float LtmpL0, LtmpR0, LtmpL1, LtmpR1;
    Float enerMax;
    Short nbShE;

	Float tmp1, tmp2;

	tmp1 = Pow(0.5f, (Float)nbShPre);
	tmp2 = Pow(0.5f, (Float)nbShCur);

    LtmpL0 = mem_L_ener[0] * tmp1 + L_ener[0] * tmp2; 
    LtmpR0 = mem_R_ener[0] * tmp1 + R_ener[0] * tmp2; 

    LtmpL1 = mem_L_ener[1] * tmp1 + L_ener[1] * tmp2;
    LtmpR1 = mem_R_ener[1] * tmp1 + R_ener[1] * tmp2;

    enerMax = f_max(LtmpL0, LtmpL1); 
    enerMax = f_max(enerMax, LtmpR0);
    enerMax = f_max(enerMax, LtmpR1);
    nbShE   = norm_l(roundFto32(enerMax));

	tmp1 = Pow(2.0f, (Float)nbShE);

    L_ener[0] = LtmpL0 * tmp1;
    L_ener[1] = LtmpL1 * tmp1;
    R_ener[0] = LtmpR0 * tmp1;
    R_ener[1] = LtmpR1 * tmp1;
    
    return (nbShE);
}

/*************************************************************************
* calcEnerOneBand0
* routine calleb by calcEnerBand
* compute one WB sub-band energy (of left or right channel)
* without saturation (no need to shift right )
**************************************************************************/
static Word32 calcEnerOneBand0(Short nb, Float *ptr_r, Float *ptr_i)
{
    Float L_temp;
    Short i;

    L_temp = 1.0f + (*ptr_r) * (*ptr_r) + (*ptr_i) * (*ptr_i);
    ptr_r++; ptr_i++;
    for(i = 1; i < nb; i++)
    {
        L_temp += (*ptr_r) * (*ptr_r) + (*ptr_i) * (*ptr_i);
        ptr_r++; ptr_i++;
    }

	return roundFto32(L_temp);
}

/*************************************************************************
* calcEnerOneBand1
* routine called calcEnerBand
* with right shift to avoid saturation
**************************************************************************/
static Word32 calcEnerOneBand1(Short nb, Float *ptr_r, Float *ptr_i, Short nbSh) {
    Float L_temp, fact;
    Short i;

	fact = Pow(0.5f, (Float)nbSh);
    L_temp  = (*ptr_r) * (*ptr_r) + (*ptr_i) * (*ptr_i);

    ptr_r++; ptr_i++;
    for(i = 1; i < nb; i++)
    {
        L_temp  += (*ptr_r) * (*ptr_r) + (*ptr_i) * (*ptr_i);

        ptr_r++; ptr_i++;
    }

    return roundFto32(L_temp * fact + 1.0f);
}

/*************************************************************************
* calcEnerBand
* routine called by g711_stereo_encode
* compute WB sub-band energies of left and right channels
**************************************************************************/
static void calcEnerBand(Float *real, Float *imag, Word32 *ener, Short q_en, Short *nbSh) {
    Short b, normQ, tmp;
    Float *ptr_r, *ptr_i;
	Short *ptr_sh;
    const Short *ptr_b, *ptr_nb, *ptr_nbShQ;
    Word32 *ptrE;

    ptr_r  = real;
    ptr_i  = imag;
    ptrE   = ener;
    ptr_b  = band_region+7;
    ptr_nb = nbCoefBand+7;
    ptr_sh = nbSh;
    ptr_nbShQ = nbShQ;

    for(b=START_ILD; b<7; b++)
    {
		*ptrE++ = roundFto32(1.0f + (*ptr_r) * (*ptr_r) + (*ptr_i) * (*ptr_i));

        ptr_r++; ptr_i++;
        *ptr_sh++ = q_en; 
    }

    for(b=7; b<NB_SB; b++)
    {
        normQ = Exp16Array_stereoF(*ptr_nb, ptr_r, ptr_i); 
        tmp = (maxQ[b] - normQ);
        if(tmp<=0)
        {
            *ptrE++ = calcEnerOneBand0(*ptr_nb, ptr_r, ptr_i); 
            *ptr_sh++ = q_en; 
        }
        else
        {
            tmp = (*ptr_nbShQ - (normQ * 2));
            *ptrE++ = calcEnerOneBand1(*ptr_nb, ptr_r, ptr_i, tmp); 
            *ptr_sh++ = (q_en - tmp); 
        }
        ptr_r += *ptr_nb;
        ptr_i += *ptr_nb;
        ptr_nb++;
    }

    return;
}

static void smoothEnerWB(Word32 *L_ener, Short *q_left_en_band, 
                         Word32 *R_ener, Short *q_right_en_band,
                         Word32 *mem_L_ener, Short *pre_q_left_en_band, 
                         Word32 *mem_R_ener, Short *pre_q_right_en_band);
static Word32 smoothEnerWBOneBand( Word32 enerCur, Short *qCur, Word32 memEner, Short qPre);

void quantILD(Short frame_idx, Word32 *L_ener, Word32 *R_ener, 
              Short *q_left_en_band, Short *q_right_en_band, Float *ILD, 
              Short *ILD_q, Short *mem_ild_q, Short *r1ws_pt);

void quantILD0(Short nb4, Short nb3, Float *L_ener, Float *R_ener, 
              Float *ILD, Short *ILD_q, Short *mem_ild_q, Short *r1ws_pt);
static Short selectRefineILD(Short frame_idx,Word32 *L_ener, Word32 *R_ener, 
              Short *q_left_en_band, Short *q_right_en_band,
              Float *ILD, Short *mem_ild_q);
static Short quantRefineILD(Short Ops, Short swb_flag, Short ic_flag, Short frame_idx, 
              Short idx, Float *ILD, Short *mem_ild_q, Short *r1ws_pt);
static Short calc_quantILD_abs(Short b, Word32 *L_ener, Word32 *R_ener, 
              Short *q_left_en_band, Short *q_right_en_band,
              Float *ILD, Short *ILD_q, Short *mem_ild_q, Short *r1ws_pt);
static Short calc_quantILD_diff(Short b, Word32 *L_ener, Word32 *R_ener, 
              Short *q_left_en_band, Short *q_right_en_band,
              Float *ILD, Short *ILD_q, Short *mem_ild_q, Short preILDq, Short *r1ws_pt);


void quantWholeWB_ITDorIPD(Short fb_ITD, Short fb_IPD, Short *r1ws_pt);

/*************************************************************************
* g711_stereo_encode
*
* G.722 wideband stereo encoder
**************************************************************************/
void g711_stereo_encode(Float* L_real,
                        Float* L_imag,
                        Float* R_real,
                        Float* R_imag,
                        Short  q_left,
                        Short  q_right,
                        Short* bpt_stereo,
                        void *  ptr, 
                        Short* frame_idx,
                        Short  mode,
                        Short  Ops
                        )
{
    g711_stereo_encode_WORK *w = (g711_stereo_encode_WORK *)ptr;

	Float ILD[NB_SB];/* ILD per subband */

    Short ILD_q[NB_SB];
    Short fac;
    Short i, j;
    Short flag;
    Short idx;
    Short *r1ws_pt;
    Short fb_ITD;
    Short fb_IPD;

    Short tmp, tmp2, tmp3;
    Short q_left_en,q_right_en;
    Short q_left_en_band[20],q_right_en_band[20];

    Word32 L_ener[NB_SB];      
    Word32 R_ener[NB_SB]; 
    Short swb_flag;
    Short nbBitRefineILD;
	Float f_L_ener[20], f_R_ener[20];

    swb_flag = (Ops == 32000);

    /* compute energy in each subband */
    q_left_en  = (q_left * 2);
    q_right_en = (q_right * 2);
    calcEnerBand(L_real, L_imag, L_ener, q_left_en,  q_left_en_band); 
    calcEnerBand(R_real, R_imag, R_ener, q_right_en, q_right_en_band);
    fb_ITD = w->fb_ITD; 
    fb_IPD = w->fb_IPD; 
    r1ws_pt = bpt_stereo;
    /*ILD attack detection in WB*/
    w->num = (w->num - 1);

	for(i = 0; i < 20; i++)
	{
		f_L_ener[i] = L_ener[i] * Pow(0.5f, (Float)q_left_en_band[i]);
		f_R_ener[i] = R_ener[i] * Pow(0.5f, (Float)q_right_en_band[i]);
	}
	flag = ild_attack_detect(f_L_ener, f_R_ener, w);

    tmp = (w->pre_flag && w->num == 0);
    if (tmp)
    {
        flag = 1;
    }
    if(!tmp)
    {
        w->num = 1; 
    }

    write_index1(r1ws_pt, flag);
    r1ws_pt += 1;

    if(flag)/*ILD quantization in 2 frames mode*/
    {
        fac = 2; 
        if(flag != w->pre_flag)
        {
            *frame_idx = 0;
        }
        write_index1(r1ws_pt, *frame_idx);
        r1ws_pt += 1;
        /*calculate and quantize ILD for 10 sub-bands with regular increment (either all even or all odd)*/
        quantILD0((5 - swb_flag), (4 + swb_flag), &f_L_ener[*frame_idx], &f_R_ener[*frame_idx], &ILD[*frame_idx], 
                  &ILD_q[*frame_idx], &w->mem_ild_q[*frame_idx], r1ws_pt);

        r1ws_pt += (37 - swb_flag);

        /*if it is the first frame of first 2 frames mode,replace the non-transmitted ild by the ild in the adjacent subbands*/
        if(w->c_flag)
        {
            if( *frame_idx == 0)
            {
                for(i = 0; i < 19 ; i += 2)
                {
                    w->mem_ild_q[i + 1] = w->mem_ild_q[i];
                }
                w->c_flag = 0;
            }
        }
        /*update the memory*/
        if(*frame_idx == 1) 
        {
            for(i = 0; i < 20; i++)
            {
                tmp2 = norm_l(L_ener[i]);
                tmp3 = norm_l(R_ener[i]);

				w->mem_L_ener[i] = L_ener[i] << tmp2;
                w->mem_R_ener[i] = R_ener[i] << tmp3;

                w->pre_q_left_en_band[i]  = (q_left_en_band[i] + tmp2); 
                w->pre_q_right_en_band[i] = (q_right_en_band[i] + tmp3); 
            }
        }
    }
    else /*ILD quantization in 4 frames mode*/
    {
        fac = 4;       
        w->c_flag = 1; 
        if(flag != w->pre_flag)
        {
            *frame_idx = 0; 
        }
        write_index2(r1ws_pt, *frame_idx);
        r1ws_pt += 2;

        if(w->frame_flag_wb == 0)
        {
            for(i = 0; i < 20; i++)
            {
                w->pre_q_left_en_band[i]  = (q_left_en_band[i] + norm_l(L_ener[i])); 
                w->pre_q_right_en_band[i] = (q_right_en_band[i] + norm_l(R_ener[i])); 
            }
            w->frame_flag_wb = 1;
        }
        smoothEnerWB(L_ener, q_left_en_band, R_ener, q_right_en_band, w->mem_L_ener, 
                     w->pre_q_left_en_band, w->mem_R_ener, w->pre_q_right_en_band);
        /*calculate and quantize ILD for each sub band*/
        quantILD(*frame_idx, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                 ILD, ILD_q, w->mem_ild_q, r1ws_pt);
        r1ws_pt += 22;
        /*inter-channel diference selection*/
        if(w->ic_flag) /*whole wideband IC is selected*/
        {
            write_index1(r1ws_pt,1);  
            r1ws_pt += 1;
            idx = 15; 
            write_index4(r1ws_pt,idx);
            r1ws_pt += 4;
            write_index2(r1ws_pt,w->ic_idx);
            r1ws_pt += 2;
        }
        else
        {
            quantWholeWB_ITDorIPD(fb_ITD, fb_IPD, r1ws_pt);
            r1ws_pt += 5;
        }

        /*ILD refinement */
        idx = selectRefineILD(*frame_idx, L_ener, R_ener, q_left_en_band, 
                              q_right_en_band, ILD, w->mem_ild_q);
        write_index2(r1ws_pt, idx);
        r1ws_pt += 2;

        /*The number of bits used for ILD refinement is determined by IC flag*/
        nbBitRefineILD = quantRefineILD(Ops, swb_flag, w->ic_flag, *frame_idx, 
                                        idx, ILD, w->mem_ild_q, r1ws_pt);
        r1ws_pt  += nbBitRefineILD ;
    }

    w->pre_flag = flag; 
    *frame_idx = (*frame_idx + 1) % fac;
    if(swb_flag)
    {
        write_index1(r1ws_pt, w->SWB_ILD_mode); 
        r1ws_pt += 1;
    }

    bpt_stereo += 39;

    /*write the IPD information into the bitstream*/ 
    if (mode == MODE_R3ws || mode == MODE_R5sws) 
    {
        for(j=IPD_SYN_START; j<=IPD_SYN_WB_END_WB; j++)
        {
            write_index5( bpt_stereo, w->idx[j]);
            bpt_stereo += 5;
        }
    }
    if(swb_flag)
    {
        for(j=IPD_SYN_START; j<IPD_SYN_WB_END_SWB; j++)
        {
            write_index5( bpt_stereo, w->idx[j]);
            bpt_stereo += 5;
        }
        if(w->SWB_ILD_mode == 0)
        {
            write_index4( bpt_stereo, w->idx[IPD_SYN_WB_END_SWB]);
            bpt_stereo += 4;
        }
        else
        {
            write_index5( bpt_stereo, w->idx[IPD_SYN_WB_END_SWB]);
            bpt_stereo += 5;
        }
    }
    /*write the IPD information into the bitstream for R6ss R6sss R7sss*/
    if (mode == MODE_R6ss || mode == MODE_R6sss || mode == MODE_R7sss)
    {  
        bpt_stereo += 5;
        if (w->SWB_ILD_mode == 0)
        {
            bpt_stereo += 1;
        }

        for(j = IPD_SYN_WB_END_SWB + 1; j <= IPD_SYN_SWB_END_SWB; j++)
        {
            write_index5( bpt_stereo, w->idx[j]);
            bpt_stereo += 5;
        }
    }
    /*write the IPD information into the bitstream for R5sws*/
    if(mode == MODE_R5sws)
    {
        for(j = IPD_SYN_WB_END_WB + 1; j <= IPD_SYN_SWB_END_SWB + 1; j++)
        {
            write_index5( bpt_stereo, w->idx[j]);
            bpt_stereo += 5;
        }
    }
    return;
}

/*************************************************************************
* quantRefineILD
*
* refinement of ILD quantization
**************************************************************************/
static Short quantRefineILD(Short Ops, Short swb_flag, Short ic_flag, Short frame_idx, 
                             Short idx, Float *ILD, Short *mem_ild_q, Short *r1ws_pt)
{
    Short i, nbBitRefineILD;
    Short parityFrame_idx, parityIdx, flagNbBand, incBand, b0;

	Short idx1;
	Float diff;

    /* case 4* Frame_idx + idx */
    i = (frame_idx * 4);
    i = (i + idx);
    incBand = 1;  /* increment index subband 1  case parityFrame_idx !=parityIdx*/
    flagNbBand = 0;  /* =0 if 3 sub band to be quantized Frame_idx != idx, otherwise 2 subbands */

    parityFrame_idx = (frame_idx & 0x01);
    parityIdx = (idx & 0x01);

    if(parityFrame_idx ==  parityIdx )
    {
        incBand++; /* increment index subband 2 case parityFrame_idx= parityIdx*/
    }
    if(frame_idx ==  idx )
    {
        flagNbBand++; /* only 2 subband to quantize */
    }

    b0 = startBand[i];  /* 1st subband to be quantized */
    /* The number of bits used for ILD refinement is determined by IC flag */
    if(ic_flag)
    { /* case ic transmitted */
        nbBitRefineILD = 4; 
        if(Ops == 16000)
        {
            /* WB and case ic transmitted */
            nbBitRefineILD++;

            /* only 2 subbands to quantize on 3 and 2 bits */ 
			diff = ILD[b0] - mem_ild_q[b0];

            idx1 = searchIdxPWQU_3seg_3bits(diff);
            mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q3[idx1]); 
            write_index3(r1ws_pt, idx1);
            r1ws_pt += 3;

            b0 += incBand;

			diff = ILD[b0] - mem_ild_q[b0];

            idx1 = searchSegQ_2bits (diff);
            mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q2[idx1]);
            write_index2(r1ws_pt, idx1);
        } /* end WB and case ic transmitted */
        else
        { /* SWB and case ic transmitted */
            /* only 2 subbands to quantize both on 2 bits */
			diff = ILD[b0] - mem_ild_q[b0];

            idx1 = searchSegQ_2bits (diff);
            mem_ild_q[b0] = (mem_ild_q[b0] + tab_ild_q2[idx1]);
            write_index2(r1ws_pt, idx1);
            r1ws_pt += 2;

            b0 += incBand;

			diff = ILD[b0] - mem_ild_q[b0];

            idx1 = searchSegQ_2bits (diff);
            mem_ild_q[b0] = (mem_ild_q[b0] + tab_ild_q2[idx1]);
            write_index2(r1ws_pt, idx1);
        } /* end SWB and case ic transmitted */
    } /* end case ic transmitted */
    else
    { /* case ic non transmitted */
        nbBitRefineILD = 6; 

        if (swb_flag == 0)
        { /* WB and case ic non transmitted */
            nbBitRefineILD++;
            if( flagNbBand == 0)
            {  /* case 3 subbands quantized first on 3 bits , last two subbands on 2 bits */
				diff = ILD[b0] - mem_ild_q[b0];

                idx1 = searchIdxPWQU_3seg_3bits(diff);
                mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q3[idx1]); 
                write_index3(r1ws_pt, idx1);
                r1ws_pt += 3;
                b0 += incBand;
                for(i = 0; i < 2; i++)
                {
					diff = ILD[b0] - mem_ild_q[b0];

                    idx1 = searchSegQ_2bits (diff);
                    mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q2[idx1]); 
                    write_index2(r1ws_pt, idx1);
                    r1ws_pt += 2;
                    b0 += incBand;
                }
            } /* end case 3 subbands quantized first on 3 bits , last two subbands on 2 bits */
            else
            { /* case 2 subbands quantized first on 4 bits, last on 3 bits */
				diff = ILD[b0] - mem_ild_q[b0];

                idx1 = searchIdxPWQU_3seg_4bits( diff); 
                mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q4[idx1]); 
                write_index4(r1ws_pt, idx1);
                r1ws_pt += 4;
                b0 += incBand;

				diff = ILD[b0] - mem_ild_q[b0];

                idx1 = searchIdxPWQU_3seg_3bits(diff);
                mem_ild_q[b0] = roundFto16((Float)mem_ild_q[b0] + tab_ild_q3[idx1]); 
                write_index3(r1ws_pt, idx1);
            } /* end case 2 subbands quantized first on 4 bits, last on 3 bits */
        } /* end  WB and case ic non transmitted */
        else
        { /* SWB and case ic non transmitted */
            if( flagNbBand == 0)
            {  /* case 3 subband quantized all on 2 bits */
                for(i = 0; i < 3; i++)
                {
					diff = ILD[b0] - mem_ild_q[b0];

                    idx1 = searchSegQ_2bits (diff);
                    mem_ild_q[b0] = (mem_ild_q[b0] + tab_ild_q2[idx1]); 
                    write_index2(r1ws_pt, idx1);
                    r1ws_pt += 2;
                    b0 += incBand;
                }
            } /* end case 3 subband quantized all on 2 bits */
            else
            { /* case 2 subband quantized all on 3 bits */
                for(i = 0; i < 2; i++)
                {
					diff = ILD[b0] - mem_ild_q[b0];

                    idx1 = searchIdxPWQU_3seg_3bits(diff);
                    mem_ild_q[b0] = (mem_ild_q[b0] + tab_ild_q3[idx1]); 
                    write_index3(r1ws_pt, idx1);
                    r1ws_pt += 3;
                    b0 += incBand;
                }
            } /* end case 2 subband quantized all on 3 bits */
        } /* end SWB and case ic non transmitted */
    } /* end case ic non transmitted */

    return (nbBitRefineILD );
}

/*************************************************************************
* selectRefineILD
*
* selection of ILD group to be refined
**************************************************************************/
static Short selectRefineILD(Short frame_idx, Word32 *L_ener, Word32 *R_ener, 
                              Short *q_left_en_band, Short *q_right_en_band,
                              Float *ILD, Short *mem_ild_q)
{
    Short ild_diff_sum[4], *ptr1;
    Short max_diff_sum;
    Short idx, i, k, j;
    const Short *ptr0, *ptr2;
	Float f_L_ener;
	Float f_R_ener;
	Float f_tmp, tmp;

    ptr0 = (Short *)(band_stat2 + frame_idx * 16);
    ptr1 = ild_diff_sum; 
    ptr2 = (Short *)(nbBand_stat + frame_idx * 4); 
    for(k = 0; k < 4; k++)
    {
        tmp = 0.0f; 
        for(j = 0; j < *ptr2; j++)
        {
            i= *ptr0++; 

			f_L_ener = (Float)(L_ener[i] * pow(0.5f, (Float)q_left_en_band[i]));
			f_R_ener = (Float)(R_ener[i] * pow(0.5f, (Float)q_right_en_band[i]));

			f_tmp = ild_calculation(f_L_ener,f_R_ener);
			ILD[i] = 512.0f * f_tmp;

			tmp = tmp + abs_f(ILD[i] - mem_ild_q[i]) * band_region_ref[i];
        }

		*ptr1++ = roundFto16(tmp * band_num[frame_idx][k] * 0.000030517578125f);

        ptr2++;
    }

    max_diff_sum = ild_diff_sum[0];
    idx = 0;
    for (i = 1; i< 4; i++)
    {
        if(max_diff_sum < ild_diff_sum[i])
        {
            idx = i;
        }
        max_diff_sum = maxS(max_diff_sum, ild_diff_sum[i]);
    }

    return (idx);
}

/*************************************************************************
* quantWholeWB_ITDorIPD
*
* quantize whole WB parameter ITD or IPD
**************************************************************************/
void quantWholeWB_ITDorIPD(Short fb_ITD, Short fb_IPD, Short *r1ws_pt)
{
    Short idx;

    idx = fb_ITD + 23; /* case: whole wideband ITD is selected: index=  MSB "1" + 4 LSB "fb_ITD+7" */
    if(!fb_ITD) 
    { /* case whole wideband IPD is selected index=  MSB "0" + 4 LSB "idx_quand_fb_IPD" */
        idx = searchIdxQU(fb_IPD,paramQuantPhase+5, tab_phase_q4); 
    }
    /* write 5 bits index */
    write_index5( r1ws_pt, idx);

    return;
}

/*************************************************************************
* quantILD0
*
* calculate and quantize sub band ILD with regular subband increment (+2)
**************************************************************************/
void quantILD0(Short nb4, Short nb3, Float *L_ener, Float *R_ener, 
               Float *ILD, Short *ILD_q, Short *mem_ild_q, Short *r1ws_pt)
{
    Short idx, b, preILDq;
	Float diff;
	Float f_tmp;

    /*calculate and quantize ILD on first sub-band with 5 bits */
	f_tmp = ild_calculation(*L_ener,*R_ener);
	*ILD = 512.0f * f_tmp;

    idx = searchIdxPWQU_5seg_5bits( (Float)(*ILD));  
    preILDq = tab_ild_q5[idx]; 

    *ILD_q = preILDq; 
    *mem_ild_q = preILDq;
    write_index5(r1ws_pt, idx);
    r1ws_pt += 5;
    for(b = 0; b < nb4; b++)
    {
        ILD             += 2;
        mem_ild_q       += 2;
        L_ener          += 2;
        R_ener          += 2;

        /*calculate and quantize ILD on following  sub-bands with 4 bits */
		f_tmp = ild_calculation(*L_ener,*R_ener);
		*ILD = 512.0f * f_tmp;

        diff = (*ILD - preILDq );
        idx = searchIdxPWQU_3seg_4bits( diff);
        write_index4(r1ws_pt, idx);
        r1ws_pt += 4;
        preILDq = roundFto16((Float)preILDq + tab_ild_q4[idx]); 
        *ILD_q = preILDq; 
        *mem_ild_q= preILDq;
    }
    for(b=0; b < nb3; b ++)
    {
        ILD             += 2;
        mem_ild_q       += 2;
        L_ener          += 2;
        R_ener          += 2;

		f_tmp = ild_calculation(*L_ener,*R_ener);
		*ILD = 512.0f * f_tmp;

        diff = (*ILD - preILDq );
        idx = searchIdxPWQU_3seg_3bits(diff);
        write_index3(r1ws_pt, idx);
        r1ws_pt += 3;
        preILDq = (preILDq + tab_ild_q3[idx]); 
        *ILD_q = preILDq; 
        *mem_ild_q= preILDq;
    }

    return;
}

/*************************************************************************
* quantILD
*
* calculate and quantize sub band ILD with irregular  subband increment 
* (subband index read in array band_index)
**************************************************************************/
void quantILD(Short frame_idx, Word32 *L_ener, Word32 *R_ener, 
              Short *q_left_en_band, Short *q_right_en_band,
              Float *ILD, Short *ILD_q, Short *mem_ild_q, Short *r1ws_pt)
{
    Short b, preILDq;
    const Short *ptrBand;

    ptrBand = &band_index[frame_idx][0];
    /* 1st band in category absolute quantization */
    b = *ptrBand++; 
    preILDq = calc_quantILD_abs(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                ILD, ILD_q, mem_ild_q, r1ws_pt);
    r1ws_pt += 5;

    /* 2nd band in category  differential quantization  */
    b = *ptrBand++; 
    preILDq = calc_quantILD_diff(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                 ILD, ILD_q, mem_ild_q, preILDq, r1ws_pt);
    r1ws_pt += 4;

    b = *ptrBand++; 
    if(frame_idx < 2) 
    {        /* frame_idx= 0 or 1 */
        /* 3rd band in category  differential quantization  */
        preILDq = calc_quantILD_diff(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                     ILD, ILD_q, mem_ild_q, preILDq, r1ws_pt);
        r1ws_pt += 4;

        /*4th band in category absolute quantization */
        b = *ptrBand++; 
        preILDq = calc_quantILD_abs(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                    ILD, ILD_q, mem_ild_q, r1ws_pt);
        r1ws_pt += 5;
    }
    else
    {        /* frame_idx= 2 or 3 */
        /* 3rd band in category  absolutequantization  */
        preILDq = calc_quantILD_abs(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                    ILD, ILD_q, mem_ild_q, r1ws_pt);
        r1ws_pt += 5;

        /*4th band in category differential  quantization */
        b = *ptrBand++; 
        preILDq = calc_quantILD_diff(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                     ILD, ILD_q, mem_ild_q, preILDq, r1ws_pt);
        r1ws_pt += 4;
    }

    b = *ptrBand++; 
    /* last band in category differential quantization  */
    preILDq = calc_quantILD_diff(b, L_ener, R_ener, q_left_en_band, q_right_en_band, 
                                 ILD, ILD_q, mem_ild_q, preILDq, r1ws_pt);
    return;
}

/*************************************************************************
* calc_quantILD_abs
*
* ILD computation of subband b by absolute quantization
**************************************************************************/
static Short calc_quantILD_abs(Short b, Word32 *L_ener, Word32 *R_ener, 
                                Short *q_left_en_band, Short *q_right_en_band,
                                Float *ILD, Short *ILD_q, Short *mem_ild_q, 
                                Short *r1ws_pt)
{
    Short idx, preILDq;
    Float *ptrILD;
	Short *ptrILDq, *ptrMemILDq;
	Float f_L_ener;
	Float f_R_ener;
	Float f_tmp;

    ptrILD     = ILD+b;
    ptrILDq    = ILD_q+b;
    ptrMemILDq = mem_ild_q+b;

	f_L_ener = (L_ener[b] * Pow(0.5f, (Float)q_left_en_band[b]));
	f_R_ener = (R_ener[b] * Pow(0.5f, (Float)q_right_en_band[b]));

	f_tmp = ild_calculation(f_L_ener,f_R_ener);
	*ptrILD = 512.0f * f_tmp;

    idx = searchIdxPWQU_5seg_5bits( (Float)(*ptrILD)); 
    write_index5(r1ws_pt, idx);
    preILDq = tab_ild_q5[idx]; 
    *ptrILDq    = preILDq; 
    *ptrMemILDq = preILDq; 

    return(preILDq);
}

/*************************************************************************
* calc_quantILD_diff
*
* ILD computation of subband b by differential quantization
**************************************************************************/
static Short calc_quantILD_diff(Short b, Word32 *L_ener, Word32 *R_ener, 
                                 Short *q_left_en_band, Short *q_right_en_band,
                                 Float *ILD, Short *ILD_q, Short *mem_ild_q, 
                                 Short preILDq, Short *r1ws_pt)
{
    Short idx;
	Float diff;
    Float *ptrILD;
	Short *ptrILDq, *ptrMemILDq;
	Float f_L_ener;
	Float f_R_ener;
	Float f_tmp;

    ptrILD     = ILD+b;
    ptrILDq    = ILD_q+b;
    ptrMemILDq = mem_ild_q+b;

	f_L_ener = (L_ener[b] * Pow(0.5f, (Float)q_left_en_band[b]));
	f_R_ener = (R_ener[b] * Pow(0.5f, (Float)q_right_en_band[b]));

	f_tmp = ild_calculation(f_L_ener,f_R_ener);
	*ptrILD = 512.0f * f_tmp;

    diff = (*ptrILD - preILDq);
    idx = searchIdxPWQU_3seg_4bits( diff); 
    preILDq = (preILDq + tab_ild_q4[idx]);
    write_index4(r1ws_pt, idx);
    *ptrILDq    = preILDq; 
    *ptrMemILDq = preILDq; 

    return(preILDq);
}

/*************************************************************************
* smoothEnerWB
*
* smoothing of Left and Right channels enery for all WB subbands
**************************************************************************/
static void smoothEnerWB(Word32 *L_ener, Short *q_left_en_band, 
                         Word32 *R_ener, Short *q_right_en_band,
                         Word32 *mem_L_ener, Short *pre_q_left_en_band, 
                         Word32 *mem_R_ener, Short *pre_q_right_en_band)
{
    Short b;

    for(b = 0; b < NB_SB; b++)
    {
        L_ener[b] = smoothEnerWBOneBand(L_ener[b] , &q_left_en_band[b], 
                                        mem_L_ener[b], pre_q_left_en_band[b]); 
        R_ener[b] = smoothEnerWBOneBand(R_ener[b] , &q_right_en_band[b], 
                                        mem_R_ener[b], pre_q_right_en_band[b]); 
    }
    /* update memory */
    for(b = 0; b < NB_SB; b++)
    {
        mem_L_ener[b]          = L_ener[b]; 
        mem_R_ener[b]          = R_ener[b]; 
        pre_q_left_en_band[b]  = q_left_en_band[b];
        pre_q_right_en_band[b] = q_right_en_band[b];
    }    

    return;
}

/*************************************************************************
* smoothEnerWB
*
* smoothing of Left and Right channels enery for one WB subband
**************************************************************************/
static Word32 smoothEnerWBOneBand( Word32 enerCur, Short *qCur, Word32 memEner, Short qPre)
{
    Short nbSh, diffQ;

    nbSh  = norm_l(enerCur);

    enerCur = (Word32)(enerCur * pow(2.0,nbSh));
    nbSh  = (*qCur + nbSh); 
    diffQ = (qPre - nbSh);
    /*smooth the energy between two consecutive frames*/
	enerCur = roundFto32(memEner * Pow(0.5f, f_max(1.0f,(diffQ + 1.0f))) + enerCur * Pow(0.5f, f_max((1.0f - diffQ),1.0f)));

    *qCur = minS(nbSh, qPre); 

    return(enerCur);
}
#endif /* LAYER_STEREO */
