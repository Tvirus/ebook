/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

#ifdef LAYER_STEREO

#include <math.h>
#include "g711_stereo.h"
#include "fft.h"
#include "qmfilt.h"
#include "stereo_tools.h"
#include "pcmswb_common.h"
#include "mdct.h"
#include "bwe.h"
#include "fec_highband.h"
#include "rom.h"

static Short calcIPD(Short mode, Short stereo_mono_flag, Short fb_ipd, 
                      Short fb_itd, Short *c, Short *mono_dec_real, 
                      Short *mono_dec_imag, Short *L_mag, Short *R_mag, 
                      Short *L_real_syn, Short *L_imag_syn, 
                      Short *R_real_syn, Short *R_imag_syn);

static void postProcStereo(Short n, Float *gainPost, Float *monoReal, Float *monoImag);
static void boundPostProc(Float boundPost, Float *monoReal, Float *monoImag);
 
static void dequantILD(Short frame_idx, Short *mem_ILD_q, Short *r1ws_pt);
static Short dequantRefineILD(Short swb_flag, Short ic_flag, Short frame_idx, Short idx, 
                               Short *mem_ILD_q, Short *r1ws_pt);
static void dequantILD0(Short nb4, Short nb3, Short *mem_ild_q, Short *r1ws_pt);
static void calc_ICSyntScaleFactors(Short n, Short *pre_ild_q, Short icSq, 
                                    Short *w1_d_c1, Short *w2_d_c2, Short *w3);
static Short calcRelPowerLR(Short icSq, Short pre_ild_q);
static Short calcScaleFacCorrel(Short val1, Word32 Lval2, Short val3);
static Short calcScaleFacUncorrel(Short val1, Short val3);
static void decorrel(Short n, Short region_ic, Short *w3, 
                     Short *w1_d_c1, Short *w2_d_c2,
					 Float *memDecorrReal, Float *memDecorrImag,
                     Float *L_real_syn, Float *L_imag_syn, Short q_left,
                     Float *R_real_syn, Float *R_imag_syn, Short q_right);
static Float decorrelOnePoint(Float mem, Float val_io, Short val3, Short val1, Short qVal);


static Short decod_smoothIC(Short ic_flag, Short ic_idx, Float *ic_sm);
static Short stereoSynth_ITD_IPD(Short mode, Short SWB_WB_flag, 
                                  Short stereo_mono_flag, Short *bpt_stereo,
                                  Short fb_ipd, Short fb_itd, Short *pre_ild_q, 
                                  Short *pre_ipd_q, Short *pre2_ipd_q, Short swb_ILD_mode,
                                  Short *swb_frame_idx, Float *c,
                                  Float *mono_dec_real, Float *mono_dec_imag, 
                                  Float *L_mag, Float *R_mag, Float *L_real_syn,
                                  Float *L_imag_syn, Float *R_real_syn, Float *R_imag_syn);

static void calc_Phase_syn_ITD(Short nb, Float iAngleStep,
                               Float iAngleRotate, Float *mono_dec_real,
                               Float *mono_dec_imag, Float *c,
                               const Short *ptr_cidx, Float *L_mag, Float *R_mag,
                               Float *L_real_syn, Float *L_imag_syn, 
                               Float *R_real_syn, Float *R_imag_syn);

static void calc_Phase_syn_ITD0(Short nb, Float *mono_dec_real,
	                            Float *mono_dec_imag,
                                const Short *ptr_cidx, Float *L_mag, Float *R_mag,
                                Float *L_real_syn, Float *L_imag_syn,
                                Float *R_real_syn, Float *R_imag_syn);

static void dequantIPD(Short mode, Short SWB_WB_flag, Short *bpt_stereo, 
                       Short fb_ipd, Short *pre_ipd_q, Short *pre2_ipd_q,
                       Short stereo_mono_flag, Short swb_ILD_mode,  
                       Short *swb_frame_idx,Float *mono_dec_real,
                       Float *mono_dec_imag, Float *c, Float *L_mag,
                       Float *R_mag, Float *L_real_syn, Float *L_imag_syn,
                       Float *R_real_syn, Float *R_imag_syn);

static void dequantIPD_5bits(Short nb, Short *bpt_stereo, Short fb_ipd, 
	                         Short *pre_ipd_q, Short *pre2_ipd_q, 
							 Float *mono_dec_real, Float *mono_dec_imag,
                             const Short *c_idx, Float *c, Float *L_mag, Float *R_mag,
                             Float *L_real_syn, Float *L_imag_syn,
                             Float *R_real_syn, Float *R_imag_syn);

static void dequantOneIPD_5bits(Short *bpt_stereo, Short fb_ipd, 
                                Short *pre_ipd_q, Short *pre2_ipd_q,
								Float mono_dec_real, Float mono_dec_imag,
								Float c, Float L_mag, Float R_mag,
                                Float *L_real_syn, Float *L_imag_syn, 
                                Float *R_real_syn, Float *R_imag_syn);

/* prototype for stereo_mono_flag = 0 */
static void dequantIPD_5bits_0(Short nb, Short *bpt_stereo, Short fb_ipd, 
                               Short *pre_ipd_q, Short *pre2_ipd_q,Float *mono_dec_real, 
                               Float *mono_dec_imag, const Short *c_idx,
                               Float *c, Float *L_mag, Float *R_mag,
                               Float *L_real_syn, Float *L_imag_syn,
                               Float *R_real_syn, Float *R_imag_syn);

static void dequantOneIPD_5bits_0(Short *bpt_stereo, Short fb_ipd,
	                              Short *pre_ipd_q, Short *pre2_ipd_q,Float mono_dec_real, Float mono_dec_imag,
								  Float c, Float L_mag, Float R_mag,
                                  Float *L_real_syn, Float *L_imag_syn, 
                                  Float *R_real_syn, Float *R_imag_syn);

void Phase_syn_IPD0(Short IPD_q,Float mono_dec_real,Float mono_dec_imag,
	                Float L_mag,Float R_mag,Float *L_real_syn,
                    Float *L_imag_syn,Float *R_real_syn,Float *R_imag_syn);

void Phase_syn_ITD0(Float mono_dec_real, Float mono_dec_imag,
                    Float L_mag,Float R_mag,Float *L_real_syn,Float *L_imag_syn,
                    Float *R_real_syn,Float *R_imag_syn);

/*************************************************************************
* g711_stereo_decode_const
*
* g711 stereo decoder constructor
**************************************************************************/
void *g711_stereo_decode_const()
{
    g711_stereo_decode_WORK *w = NULL;

    w = (g711_stereo_decode_WORK *)malloc(sizeof(g711_stereo_decode_WORK));
    if (w != NULL) {
        g711_stereo_decode_reset((void *)w);
    }
    return (void *)w;
}

/*************************************************************************
* g711_stereo_decode_dest
*
* g711 stereo decoder destructor
**************************************************************************/
void g711_stereo_decode_dest( void* ptr )
{
    g711_stereo_decode_WORK *w = (g711_stereo_decode_WORK *)ptr;
    if (w != NULL) {
        free(w);
    }
    return;
}

/*************************************************************************
* g711_stereo_decode_reset
*
* g711 stereo decoder reset
**************************************************************************/
void g711_stereo_decode_reset( void* ptr )
{
    g711_stereo_decode_WORK *w = (g711_stereo_decode_WORK *)ptr;
    if (w != NULL)
    {
        w->c1_swb[0]        = 0.5f;
        w->c2_swb[0]        = 0.5f;
        w->c1_swb[1]        = 0.5f;
        w->c2_swb[1]        = 0.5f;

        w->swb_ILD_mode     = 0;
        w->pre_swb_ILD_mode = 0;
        w->delay            = 0;
        w->swb_frame_idx    = 0;
        w->c_flag           = 0;
        w->pre_flag         = 0;
        w->pre_fb_itd       = 0;
		w->pre2_fb_itd      = 0;

        w->fb_ipd           = 0;
        w->fb_itd           = 0;
        w->pre_fb_ipd       = 0;
		w->pre2_fb_ipd      = 0;
		
        w->pre_norm_left    = 0;
        w->pre_norm_right   = 0;


        zeroS(20,w->mem_ILD_q);
        zeroS(20,w->pre_ild_q);

        zeroS(20,w->pre2_ild_q);

        zeroS(IPD_SYN_SWB_END_SWB + 2,w->pre_ipd_q);
        zeroS(IPD_SYN_SWB_END_SWB + 2,w->pre2_ipd_q);

        zeroF(50, w->mem_output_L);
        zeroF(50, w->mem_output_R);

		zeroF(50, w->mem_mono_win);

        zeroF(L_FRAME_WB, w->sCurSave_left);
        zeroF(L_FRAME_WB, w->sCurSave_right);

        zeroS(L_FRAME_WB, w->mem_mono);

        zeroF(L_FRAME_WB, w->mem_left_mdct);
        zeroF(L_FRAME_WB, w->mem_right_mdct);

        zeroF(G711_WB_DMX_DELAY,w->mem_left);
        zeroF(G711_WB_DMX_DELAY,w->mem_right);

        w->pre_ic_flag  = 0;
		w->pre2_ic_flag = 0;
        w->pre_ic_idx   = 0;
		w->pre2_ic_idx  = 0;

        zeroF(324,w->mem_decorr_real);
        zeroF(324,w->mem_decorr_imag);

        w->ic_sm = 0.0f; 
        zeroS(4,w->q_mem);
    }
    return;
}

/*************************************************************************
* g711_stereo_decode
*
* G.722 stereo decoder
**************************************************************************/
void g711_stereo_decode(Short* bpt_stereo,
	                    Float* mono_dec,
                        Short* L_syn,
                        Short* R_syn,
                        void*   ptr,
                        Short  mode,
                        Short  SWB_WB_flag,
                        Short  ploss_status,
                        Short  cod_Mode,
                        Short  stereo_mono_flag
                        )
{
    g711_stereo_decode_WORK *w = (g711_stereo_decode_WORK *)ptr;        
    Short i, j;
    Short flag;
    Short *r1ws_pt = bpt_stereo;
    Short frame_idx;
    Short idx0, idx1;
    Short region_ic;

    Float f_mono_dec_real[NFFT + 2];

    Float *f_mono_dec_imag = &f_mono_dec_real[NFFT/2 + 1]; 

    Short q_mono;

	Float f_L_real_syn[NFFT + 2]; 

    Float *f_L_imag_syn = &f_L_real_syn[81];

	Float f_R_real_syn[NFFT + 2];

	Float *f_R_imag_syn = &f_R_real_syn[NFFT/2 + 1];

    Short q_left, q_right;

    Float c[20];

    Float L_mag[81],R_mag[81];

    Short ic_flag = 0;
    Short ic_idx = 0;
    Short tmp16;
    Short w1_d_c1[IC_END_BAND - IC_BEGIN_BAND];
    Short w2_d_c2[IC_END_BAND - IC_BEGIN_BAND];
    Short w3[IC_END_BAND - IC_BEGIN_BAND];
	Short nbBit;

    /* windowing + FFT decoded mono */
	windowStereoF(mono_dec, w->mem_mono_win, f_mono_dec_real);

    sDoRFFTx(f_mono_dec_real,&q_mono);

    if(SWB_WB_flag == 0)
    { /* WB case */ 
        /* zeroing the interval [7000, 8000 Hz] */
        for(j=71; j<81; j++)
        {
            f_mono_dec_real[j] = 0.0f;
            f_mono_dec_imag[j] = 0.0f;
        }
    } /* end WB case */ 

    if(ploss_status == 0)       
    {
        /*read the frame mode indication*/
        w->fb_ipd      = w->pre_fb_ipd;     
        w->fb_itd      = w->pre_fb_itd;     
        ic_flag        = w->pre_ic_flag;
        w->pre_ic_flag = w->pre2_ic_flag;
        w->pre_fb_itd  = w->pre2_fb_itd;
        w->pre_fb_ipd  = w->pre2_fb_ipd;

        read_index1(r1ws_pt,&flag);
        r1ws_pt += 1;
        if (flag == 0) /*4 frames mode*/
        {
            w->c_flag = 1;
            read_index2( r1ws_pt, &frame_idx);
            r1ws_pt += 2;  
            /*decoded ILD*/
            dequantILD(frame_idx, w->mem_ILD_q, r1ws_pt);
            r1ws_pt += 22;
            /* decod whether whole IPD or ITD in frame */
            read_index1(r1ws_pt, &idx0);
            r1ws_pt += 1;

            /*decode selected inter-channel difference*/
            read_index4(r1ws_pt, &idx1);
            r1ws_pt += 4;

            w->pre2_fb_itd = 0; 
            if( idx0 )
            {
                w->pre2_fb_ipd  = 0;                        
                /* assume whole wideband ITD is selected */
                w->pre2_ic_flag = 0;                        
                w->pre2_fb_itd  = (idx1 - 7);             
                if(idx1 == 15) /* whole wideband IC is selected */
                {
                    ic_idx        = w->pre_ic_idx;
					w->pre_ic_idx = w->pre2_ic_idx;
                    read_index2( r1ws_pt, &w->pre_ic_idx);
                    r1ws_pt += 2;
                    w->pre2_ic_flag = 1;                    
                    w->pre2_fb_itd  = 0;                    
                }
            }
            else /* whole wideband IPD is selected */
            {
                w->pre2_fb_ipd  = tab_phase_q4[idx1];       
                w->pre2_ic_flag = 0;                        
            }
            w->delay = w->fb_itd;                          
            read_index2(r1ws_pt, &idx1);
            r1ws_pt += 2;
            nbBit = dequantRefineILD(SWB_WB_flag, w->pre2_ic_flag, frame_idx, 
                                     idx1, w->mem_ILD_q, r1ws_pt);
            r1ws_pt  += nbBit;
        }
        else /*decode ILD in 2 frames mode*/
        {
            read_index1( r1ws_pt, &frame_idx);
            r1ws_pt += 1;  
            dequantILD0((5 - SWB_WB_flag), (4 + SWB_WB_flag), &w->mem_ILD_q[frame_idx], r1ws_pt);
            r1ws_pt += (37 - SWB_WB_flag);
            /* Switch from 4 frames mode to 2 frames mode => change all bands */
            if(w->c_flag)
            {
                if(frame_idx == 0)
                {
                    movS_ext(10, w->mem_ILD_q, 2, &w->mem_ILD_q[1], 2);
                    w->c_flag = 0;                   
                }
            }

            /* reset full band itd and full band IPD when 2 frames mode (quick change of ILD) */
            w->pre2_fb_itd  = 0;                      
            w->pre2_fb_ipd  = 0;                      
            w->pre2_ic_flag = 0;                      
        }

        if(SWB_WB_flag)
        {
            read_index1( r1ws_pt, &w->swb_ILD_mode);
            r1ws_pt += 1;
        }
    }

    bpt_stereo += 39;

    /*recover the amplitudes of left and right channels*/
    stereo_synthesis(w->pre_ild_q, f_mono_dec_real, f_mono_dec_imag, q_mono, 
                     f_L_real_syn, f_L_imag_syn, f_R_real_syn, f_R_imag_syn,
                     &q_left, &q_right, L_mag, R_mag, ploss_status);

    /* IPD synthesis */
    if(ploss_status == 0)
    {
        region_ic = stereoSynth_ITD_IPD(mode, SWB_WB_flag, stereo_mono_flag, bpt_stereo,
                                        w->fb_ipd,w->fb_itd, w->pre_ild_q,
                                        w->pre_ipd_q, w->pre2_ipd_q,w->swb_ILD_mode, &w->swb_frame_idx,
                                        c, f_mono_dec_real, f_mono_dec_imag, L_mag, R_mag,
                                        f_L_real_syn, f_L_imag_syn, f_R_real_syn, f_R_imag_syn);
    }
    /*IC synthesis*/
    if(ploss_status == 0)
    {
        tmp16 = decod_smoothIC(ic_flag, ic_idx, &w->ic_sm);
        /*Calculate the relative power of left and right channels*/
        i = c_idx[region_ic]; 
        j = (IC_END_BAND - i);
        /*calculate the scale factor*/
        calc_ICSyntScaleFactors(j, &w->pre_ild_q[i], (32767 - tmp16),
                                &w1_d_c1[i],&w2_d_c2[i], &w3[i]);

        decorrel((81 - region_ic), region_ic,w3, w1_d_c1,
                 w2_d_c2, w->mem_decorr_real, w->mem_decorr_imag, 
                 f_L_real_syn, f_L_imag_syn, (q_left - w->q_mem[0]),
                 f_R_real_syn, f_R_imag_syn, (q_right - w->q_mem[2]));

        for(i = 0; i< 20; i++)
        {
			w->pre_ild_q[i]  = w->pre2_ild_q[i];
			w->pre2_ild_q[i] = w->mem_ILD_q[i] >> 9;
        }

        /*update the memory*/
        for(i=0;i<243;i++)
        {
            w->mem_decorr_real[i] = w->mem_decorr_real[81 + i]; 
            w->mem_decorr_imag[i] = w->mem_decorr_imag[81 + i]; 
        }

        /*different delays are applied to the decoded mono signal to generate the de-correlated signals*/
        if(cod_Mode != TRANSIENT)
        {
            for(i=0;i<81;i++)
            {
                w->mem_decorr_real[243 + i] = f_mono_dec_real[i]; 
                w->mem_decorr_imag[243 + i] = f_mono_dec_imag[i];
            }
        }
        else /*if the mono signal is classified as transient signal, update the memory by zeros*/
        {
            zeroF(80,&w->mem_decorr_real[243]);
            zeroF(80,&w->mem_decorr_imag[243]);
        }
        w->q_mem[0] = w->q_mem[1]; 
        w->q_mem[1] = w->q_mem[2]; 
        w->q_mem[2] = w->q_mem[3]; 
        w->q_mem[3] = q_mono; 
    }
    else
    {
        zeroF(80,&w->mem_decorr_real[243]);
        zeroF(80,&w->mem_decorr_imag[243]);
    }

    /*IFFT decoded left and right channel signal*/
    q_left  = (q_left - 16);
    q_right = (q_right - 16);

    sDoRiFFTx(f_L_real_syn,&q_left);
    sDoRiFFTx(f_R_real_syn,&q_right);

    /* Windowing */
    /* overlap and add  left and right channels */
    f_OLA( &f_L_real_syn[15], w->mem_output_L, L_syn);
    f_OLA( &f_R_real_syn[15], w->mem_output_R, R_syn);

    /* update memory */
    for(i=0; i< 50; i++)
    {
        w->mem_mono_win[i] = mono_dec[i + 30]; 
        w->mem_output_L[i] = f_L_real_syn[i + 95] * win_D[49 - i];
        w->mem_output_R[i] = f_R_real_syn[i + 95] * win_D[49 - i];
    }

    return;
}

/*************************************************************************
* decod_smoothIC
*
* inverse quantization of IC and smoothing
**************************************************************************/
static Short decod_smoothIC(Short ic_flag, Short ic_idx, Float *ic_sm)
{
    Short icSq;
	Float icLoc;

    /*decode full band IC*/
    icLoc = 1.0f;
    if(ic_flag)
    {
        icLoc = ic_table[ic_idx]; 
        icLoc = (*ic_sm) * 0.984f + icLoc * 0.016f; 
    }
    *ic_sm = icLoc; 
    icSq = roundFto16(icLoc * icLoc * 32767.0f);

    return(icSq);
}

/*************************************************************************
* stereoSynth_ITD_IPD
*
* phase computation from ITD and IPD of frequency bins left and right channels
**************************************************************************/
static Short stereoSynth_ITD_IPD(Short mode, Short SWB_WB_flag, 
                                  Short stereo_mono_flag, Short *bpt_stereo,
                                  Short fb_ipd, Short fb_itd, Short *pre_ild_q,
                                  Short *pre_ipd_q, Short *pre2_ipd_q,Short swb_ILD_mode,
                                  Short *swb_frame_idx, Float *c,
								  Float *mono_dec_real, Float *mono_dec_imag,
                                  Float *L_mag, Float *R_mag, Float *L_real_syn,
                                  Float *L_imag_syn, Float *R_real_syn, Float *R_imag_syn)
{
    Short i, j, region_ic;
    Short iAngleStep, iAngleRotate;
    const Short *ptr_cidx; 

    for (i = 2; i < 17; i++)
    {
        c[i] = c_table10[80 + pre_ild_q[i]];
    }
	region_ic = IPD_SYN_WB_END_WB+1 - SWB_WB_flag;

	//iAngleStep = roundFto16(fb_itd * 160.75f); /* CPIDNFFT_FQ15 / 4 */

    if(mode == MODE_R5sws)
    {   /* case R1ws*/
        region_ic = IPD_SYN_SWB_END_SWB + 2;
    }

        if(mode == MODE_R6ss || mode == MODE_R6sss || mode == MODE_R7sss)
        {
            region_ic = IPD_SYN_SWB_END_SWB + 1;
        }

        j = (bands[17] - region_ic); /* number of bins */
        ptr_cidx = c_idx + region_ic; 
        if(stereo_mono_flag == 0)
        {
            calc_Phase_syn_ITD0(j, &mono_dec_real[region_ic], &mono_dec_imag[region_ic], 
                                ptr_cidx, &L_mag[region_ic], &R_mag[region_ic],

                                &L_real_syn[region_ic], &L_imag_syn[region_ic], 
                                &R_real_syn[region_ic], &R_imag_syn[region_ic]);
        }
        else 
        {
			iAngleStep = roundFto16(fb_itd * 160.75f); /* CPIDNFFT_FQ15 / 4 */
            iAngleRotate = (Short)(fb_itd * region_ic);
            while(iAngleRotate >= NFFT)
            {
                iAngleRotate = iAngleRotate - NFFT;
            }

            while(iAngleRotate <= -NFFT)
            {
                iAngleRotate = ( iAngleRotate + NFFT );
            }
            iAngleRotate = (Short)(iAngleRotate * CPIDNFFT_FQ15_2); //  Q12  -pi ~ pi
            iAngleRotate = ( fb_ipd  - iAngleRotate ); // Q12

            calc_Phase_syn_ITD(j, iAngleStep, iAngleRotate, &mono_dec_real[region_ic], 
                               &mono_dec_imag[region_ic], c, ptr_cidx, &L_mag[region_ic], &R_mag[region_ic],
                               &L_real_syn[region_ic], &L_imag_syn[region_ic], 
                               &R_real_syn[region_ic], &R_imag_syn[region_ic]);
        }
        dequantIPD(mode, SWB_WB_flag, bpt_stereo, fb_ipd, pre_ipd_q, pre2_ipd_q,
                   stereo_mono_flag, swb_ILD_mode,  swb_frame_idx,            
                   mono_dec_real, mono_dec_imag, c, L_mag, R_mag, 
                   L_real_syn, L_imag_syn, R_real_syn, R_imag_syn);

    return(region_ic);
}

/*************************************************************************
* calc_Phase_syn_ITD
*
* phase computation from whole WB ITD and IPD for frequency bins with 
* no transmitted individual IPD
**************************************************************************/
static void calc_Phase_syn_ITD(Short nb, Float iAngleStep, 
                               Float iAangleRotate, Float *mono_dec_real,
							   Float *mono_dec_imag, Float *c,
                               const Short *ptr_cidx, Float *L_mag, Float *R_mag,
                               Float *L_real_syn, Float *L_imag_syn, 
                               Float *R_real_syn, Float *R_imag_syn)
{
    Short j; 
    Float ipd_diff_q;

    for(j = 0; j< nb; j++)
    {
        ipd_diff_q = Round_Phase(iAangleRotate);
        iAangleRotate = iAangleRotate - iAngleStep; // Q12
        Phase_syn_ITD(ipd_diff_q, mono_dec_real[j], mono_dec_imag[j], c[ptr_cidx[j]], L_mag[j], R_mag[j],
                      &L_real_syn[j], &L_imag_syn[j], &R_real_syn[j], &R_imag_syn[j]);
    }

    return;
}

/*************************************************************************
* calc_Phase_syn_ITD0
*
* phase synthesis case swb_mono_flag = 0
**************************************************************************/
static void calc_Phase_syn_ITD0(Short nb, Float *mono_dec_real,
                               Float *mono_dec_imag,
                               const Short *ptr_cidx, Float *L_mag, Float *R_mag,
                               Float *L_real_syn, Float *L_imag_syn,
                               Float *R_real_syn, Float *R_imag_syn)
{
    Short j; 

    for(j = 0; j< nb; j++)
    {
		Phase_syn_ITD0(mono_dec_real[j], mono_dec_imag[j], L_mag[j], R_mag[j],
                       &L_real_syn[j], &L_imag_syn[j], &R_real_syn[j], &R_imag_syn[j]);
    }

    return;
}

/*************************************************************************
* dequantIPD
*
* decoding of all quantized IPDs
**************************************************************************/
static void dequantIPD(Short mode, Short SWB_WB_flag, Short *bpt_stereo, Short fb_ipd, 
                       Short *pre_ipd_q, Short *pre2_ipd_q, Short stereo_mono_flag, 
                       Short swb_ILD_mode,  Short *swb_frame_idx,
                       Float *mono_dec_real, Float *mono_dec_imag,
                       Float *c, Float *L_mag, Float *R_mag,
                       Float *L_real_syn, Float *L_imag_syn,
                       Float *R_real_syn, Float *R_imag_syn)
{
    Short nbBand, nbBit, IPD_q, idx;
	Float ipd_diff_q;

    /* if WB IPD from bin 2 to 9 quantized with 5 bits 
        otherwise IPD from bin 2 to 7 quantized with 5 bits */
    nbBand = ((IPD_SYN_WB_END_WB+1 - IPD_SYN_START) - (SWB_WB_flag * 2) );
    if(stereo_mono_flag != 0)
    {
        dequantIPD_5bits(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_START], &pre2_ipd_q[IPD_SYN_START], 
                         &mono_dec_real[IPD_SYN_START], &mono_dec_imag[IPD_SYN_START], 
                         &c_idx[IPD_SYN_START], c, &L_mag[IPD_SYN_START], &R_mag[IPD_SYN_START],
                         &L_real_syn[IPD_SYN_START], &L_imag_syn[IPD_SYN_START], 
                         &R_real_syn[IPD_SYN_START], &R_imag_syn[IPD_SYN_START]);
    }
    else
    {
        dequantIPD_5bits_0(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_START], &pre2_ipd_q[IPD_SYN_START], 
                           &mono_dec_real[IPD_SYN_START], &mono_dec_imag[IPD_SYN_START], 
                           &c_idx[IPD_SYN_START], c, &L_mag[IPD_SYN_START], &R_mag[IPD_SYN_START],
                           &L_real_syn[IPD_SYN_START], &L_imag_syn[IPD_SYN_START], 
                           &R_real_syn[IPD_SYN_START], &R_imag_syn[IPD_SYN_START]);
    }

    nbBit = 40; /* if WB IPD from bin 2 to 9 quantized with 5 bits => 40 bits (8*5 ) */ 
    if(SWB_WB_flag !=0)
    {   /* SWB case */
        nbBit = (nbBit - 10);
        /*IPD synthesis for SWB stereo*/
        bpt_stereo += nbBit;
        /* decode IPD for bin 8 */
        IPD_q = pre_ipd_q[IPD_SYN_WB_END_SWB];
		pre_ipd_q[IPD_SYN_WB_END_SWB] = pre2_ipd_q[IPD_SYN_WB_END_SWB];
        /*if swb_ILD_mode =0  IPD[8] quantized on 4 bits , next  bit frame_idx 
        else swb_ILD_mode =1 IPD[8] quantized on 5 bits */
        read_index5( bpt_stereo, &idx);
        bpt_stereo += 5;
        nbBit = (nbBit + 5);
        pre2_ipd_q[IPD_SYN_WB_END_SWB] = tab_phase_q5[idx];

        if(swb_ILD_mode == 0)
        {
            *swb_frame_idx = (idx & 0x1); 

			idx /= 2;

            pre2_ipd_q[IPD_SYN_WB_END_SWB] = tab_phase_q4[idx];
        }
        ipd_diff_q = (Float)IPD_q - fb_ipd;
        ipd_diff_q = Round_Phase(ipd_diff_q);
        if(stereo_mono_flag == 0)
        {
            ipd_diff_q = 0; 
        }
        Phase_syn_IPD(ipd_diff_q, IPD_q, mono_dec_real[IPD_SYN_WB_END_SWB], mono_dec_imag[IPD_SYN_WB_END_SWB],
                      c[c_idx[IPD_SYN_WB_END_SWB]], L_mag[IPD_SYN_WB_END_SWB], R_mag[IPD_SYN_WB_END_SWB],
                      &L_real_syn[IPD_SYN_WB_END_SWB], &L_imag_syn[IPD_SYN_WB_END_SWB],
                      &R_real_syn[IPD_SYN_WB_END_SWB], &R_imag_syn[IPD_SYN_WB_END_SWB]);
        if(mode == MODE_R6ss || mode == MODE_R6sss || mode == MODE_R7sss)
        { /* IPD synthesis for R6ss, R6sss and R7sss only decode 16 IPDs bins 9 to 24 each quantized with 5 bits*/
            bpt_stereo += 5;   /* skip SHB ILD in SL1 to read SL2*/ 
            nbBand = IPD_SYN_SWB_END_SWB - IPD_SYN_WB_END_SWB;
            if(stereo_mono_flag != 0)
            {
                dequantIPD_5bits(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_WB_END_SWB + 1], 
                                 &pre2_ipd_q[IPD_SYN_WB_END_SWB + 1], &mono_dec_real[IPD_SYN_WB_END_SWB + 1], 
                                 &mono_dec_imag[IPD_SYN_WB_END_SWB + 1], &c_idx[IPD_SYN_WB_END_SWB + 1], c,
                                 &L_mag[IPD_SYN_WB_END_SWB + 1], &R_mag[IPD_SYN_WB_END_SWB + 1],
                                 &L_real_syn[IPD_SYN_WB_END_SWB + 1], &L_imag_syn[IPD_SYN_WB_END_SWB + 1], 
                                 &R_real_syn[IPD_SYN_WB_END_SWB + 1], &R_imag_syn[IPD_SYN_WB_END_SWB + 1]);
            }
			else
            {
                dequantIPD_5bits_0(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_WB_END_SWB + 1],
                                   &pre2_ipd_q[IPD_SYN_WB_END_SWB + 1], &mono_dec_real[IPD_SYN_WB_END_SWB + 1], 
                                   &mono_dec_imag[IPD_SYN_WB_END_SWB + 1], &c_idx[IPD_SYN_WB_END_SWB + 1], c,
                                   &L_mag[IPD_SYN_WB_END_SWB + 1], &R_mag[IPD_SYN_WB_END_SWB + 1],
                                   &L_real_syn[IPD_SYN_WB_END_SWB + 1], &L_imag_syn[IPD_SYN_WB_END_SWB + 1], 
                                   &R_real_syn[IPD_SYN_WB_END_SWB + 1], &R_imag_syn[IPD_SYN_WB_END_SWB + 1]);
            }
        }
    }

    if(mode == MODE_R5sws)
    { /* IPD synthesis for R5sws only decode 16 IPDs bins 10 to 25 each quantized with 5 bits*/
        bpt_stereo += nbBit;
        nbBand = IPD_SYN_SWB_END_SWB+1 - IPD_SYN_WB_END_WB;
        if(stereo_mono_flag != 0)
        {
            dequantIPD_5bits(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_WB_END_WB + 1], 
                             &pre2_ipd_q[IPD_SYN_WB_END_WB + 1], &mono_dec_real[IPD_SYN_WB_END_WB + 1], 
                             &mono_dec_imag[IPD_SYN_WB_END_WB + 1], &c_idx[IPD_SYN_WB_END_WB + 1], c,
                             &L_mag[IPD_SYN_WB_END_WB + 1], &R_mag[IPD_SYN_WB_END_WB + 1],
                             &L_real_syn[IPD_SYN_WB_END_WB + 1], &L_imag_syn[IPD_SYN_WB_END_WB + 1], 
                             &R_real_syn[IPD_SYN_WB_END_WB + 1], &R_imag_syn[IPD_SYN_WB_END_WB + 1]);
        }
		else
        {
            dequantIPD_5bits_0(nbBand, bpt_stereo, fb_ipd, &pre_ipd_q[IPD_SYN_WB_END_WB + 1],
                               &pre2_ipd_q[IPD_SYN_WB_END_WB + 1], &mono_dec_real[IPD_SYN_WB_END_WB + 1], 
                               &mono_dec_imag[IPD_SYN_WB_END_WB + 1], &c_idx[IPD_SYN_WB_END_WB + 1], c,
                               &L_mag[IPD_SYN_WB_END_WB + 1], &R_mag[IPD_SYN_WB_END_WB + 1],
                               &L_real_syn[IPD_SYN_WB_END_WB + 1], &L_imag_syn[IPD_SYN_WB_END_WB + 1], 
                               &R_real_syn[IPD_SYN_WB_END_WB + 1], &R_imag_syn[IPD_SYN_WB_END_WB + 1]);
        }
    }

    return;
}

/*************************************************************************
* dequantIPD_5bits
*
* decoding and synthesis for nb consecutive bins
**************************************************************************/
static void dequantIPD_5bits(Short nb, Short *bpt_stereo, Short fb_ipd,
	                         Short *pre_ipd_q, Short *pre2_ipd_q, Float *mono_dec_real, Float *mono_dec_imag,
							 const Short *c_idx, Float *c,
                             Float *L_mag, Float *R_mag,
                             Float *L_real_syn, Float *L_imag_syn, 
                             Float *R_real_syn, Float *R_imag_syn)
{
    Short b;
    for(b=0; b<nb; b++)
    {
        dequantOneIPD_5bits(bpt_stereo, fb_ipd, &pre_ipd_q[b], &pre2_ipd_q[b],
                            mono_dec_real[b], mono_dec_imag[b], c[c_idx[b]], L_mag[b], R_mag[b],
                            &L_real_syn[b], &L_imag_syn[b], &R_real_syn[b], &R_imag_syn[b]);
        bpt_stereo += 5;
    }

    return;
}

/*************************************************************************
* dequantIPD_5bits_0
*
* decoding and synthesis for nb consecutive bins case stereo_mono_flag = 0
**************************************************************************/
static void dequantIPD_5bits_0(Short nb, Short *bpt_stereo, Short fb_ipd,
	                           Short *pre_ipd_q, Short *pre2_ipd_q, Float *mono_dec_real, Float *mono_dec_imag,
                               const Short *c_idx, Float *c,
                               Float *L_mag, Float *R_mag,
                               Float *L_real_syn, Float *L_imag_syn, 
                               Float *R_real_syn, Float *R_imag_syn)
{
    Short b;

    for(b=0; b<nb; b++)
    {
        dequantOneIPD_5bits_0(bpt_stereo, fb_ipd, &pre_ipd_q[b], &pre2_ipd_q[b], mono_dec_real[b], mono_dec_imag[b], 
                              c[c_idx[b]], L_mag[b], R_mag[b], &L_real_syn[b], &L_imag_syn[b], 
                              &R_real_syn[b], &R_imag_syn[b]);
        bpt_stereo += 5;
    }

    return;
}

/*************************************************************************
* dequantOneIPD_5bits
*
* decoding and synthesis for one bin
**************************************************************************/
static void dequantOneIPD_5bits(Short *bpt_stereo, Short fb_ipd,
	                            Short *pre_ipd_q, Short *pre2_ipd_q, Float mono_dec_real, Float mono_dec_imag,
								Float c, Float L_mag, Float R_mag,
                                Float *L_real_syn, Float *L_imag_syn,
                                Float *R_real_syn, Float *R_imag_syn)
{
    Short idx, IPD_q;
	Float ipd_diff_q ;

    read_index5( bpt_stereo, &idx);
    IPD_q = *pre_ipd_q ; 
	*pre_ipd_q = *pre2_ipd_q;
    *pre2_ipd_q = tab_phase_q5[idx];

    ipd_diff_q = (Float)IPD_q - fb_ipd;

    ipd_diff_q = Round_Phase(ipd_diff_q);
    Phase_syn_IPD(ipd_diff_q, IPD_q, mono_dec_real, mono_dec_imag, c, L_mag, R_mag, 
                  L_real_syn, L_imag_syn, R_real_syn, R_imag_syn);

    return;
}

/*************************************************************************
* dequantOneIPD_5bits_0
*
* decoding and synthesis for one bin case stereo_mono_flag = 0
**************************************************************************/
static void dequantOneIPD_5bits_0(Short *bpt_stereo, Short fb_ipd,
	                              Short *pre_ipd_q, Short *pre2_ipd_q, Float mono_dec_real, Float mono_dec_imag,
								  Float c, Float L_mag, Float R_mag,
                                  Float *L_real_syn, Float *L_imag_syn, 
                                  Float *R_real_syn, Float *R_imag_syn)
{
    Short idx, IPD_q ;

    read_index5(bpt_stereo, &idx);
    IPD_q      = *pre_ipd_q ;
	*pre_ipd_q = *pre2_ipd_q;
    *pre2_ipd_q = tab_phase_q5[idx];

    Phase_syn_IPD0(IPD_q, mono_dec_real, mono_dec_imag, L_mag, R_mag, 
                   L_real_syn, L_imag_syn, R_real_syn, R_imag_syn);

    return;
}

/*************************************************************************
* postProcStereo
*
* apply postprocessing to n point
**************************************************************************/
static void postProcStereo(Short n, Float *gainPost, Float *monoReal, Float *monoImag) 
{
    Short i;
    Float *ptrGain;
	Float *ptrR, *ptrI;

    ptrGain = gainPost;
    ptrR = monoReal;
    ptrI = monoImag;
    for(i=0; i<n; i++)
    {
        boundPostProc(*ptrGain, ptrR, ptrI);
        ptrGain++; ptrR++; ptrI++;
    }

    return;
}

/*************************************************************************
* boundPostProc
*
* apply postprocessing to one point
**************************************************************************/
static void boundPostProc(Float boundPost, Float *monoReal, Float *monoImag) 
{

    if (boundPost < 1.15f)
    {
		*monoReal = (*monoReal) * boundPost; /* Q(q_mono) */
		*monoImag = (*monoImag) * boundPost; /* Q(q_mono) */
    }

    return;
}

/*************************************************************************
* dequantILD0
*
* decoded sub band ILDs with regular subband increment (+2 )
**************************************************************************/
static void dequantILD0(Short nb4, Short nb3, Short *mem_ILD_q, Short *r1ws_pt)
{
    Short idx, b;
    Short *ptrILD, *ptrILDmem; 

    /*dequantize ILD in each sub-band*/
    ptrILD    = mem_ILD_q;
    ptrILDmem = ptrILD; 
    
    read_index5(r1ws_pt, &idx);
    r1ws_pt += 5; 
    *ptrILD = tab_ild_q5[idx]; 
    ptrILD += 2;
    /* Differential quantization of following ILD */
    for(b = 0; b < nb4; b++)
    {
        read_index4(r1ws_pt, &idx);
        r1ws_pt += 4;
        *ptrILD = roundFto16((Float)(*ptrILDmem) + tab_ild_q4[idx]); 
        ptrILD += 2;
        ptrILDmem += 2;
    }
    for(b=0; b < nb3; b ++)
    {
        read_index3(r1ws_pt, &idx);
        r1ws_pt += 3;
        *ptrILD = (*ptrILDmem + tab_ild_q3[idx]); 
        ptrILD += 2;
        ptrILDmem += 2;
    }

    return;
}

/*************************************************************************
* dequantILD
*
* decoded sub band ILDs with irregular subband increment
**************************************************************************/
static void dequantILD(Short frame_idx, Short *mem_ILD_q, Short *r1ws_pt)
{
    Short b, preILDq, idx;
    const Short *ptrBand;

    ptrBand = &band_index[frame_idx][0];
    /* 1st band in category absolute quantization */
    b = *ptrBand++; 
    read_index5( r1ws_pt, &idx);
    preILDq      = tab_ild_q5[idx]; 
    mem_ILD_q[b] = preILDq ; 
    r1ws_pt += 5;   

    /* 2nd band in category  differential quantization  */
    b = *ptrBand++; 
    read_index4( r1ws_pt, &idx);
    preILDq      = (preILDq + tab_ild_q4[idx]); 
    mem_ILD_q[b] = preILDq; 
    r1ws_pt += 4;  
                
    b = *ptrBand++; 
    if(frame_idx < 2) 
    { /* frame_idx= 0 or 1 */
        /* 3rd band in category  differential quantization  */
        read_index4( r1ws_pt, &idx);
        preILDq      = (preILDq  + tab_ild_q4[idx]); 
        mem_ILD_q[b] = preILDq ; 
        r1ws_pt += 4;

        /*4th band in category absolute quantization */
        b = *ptrBand++; 
        read_index5( r1ws_pt, &idx);
        preILDq      = tab_ild_q5[idx]; 
        mem_ILD_q[b] = preILDq ; 
        r1ws_pt += 5;
    }
    else
    {        /* frame_idx= 2 or 3 */
        /* 3rd band in category  absolute quantization  */
        read_index5( r1ws_pt, &idx);
        preILDq      = tab_ild_q5[idx]; 
        mem_ILD_q[b] = preILDq ; 
        r1ws_pt += 5;

        /*4th band in category differential  quantization */
        b = *ptrBand++; 
        read_index4( r1ws_pt, &idx);
        preILDq      = (preILDq + tab_ild_q4[idx]); 
        mem_ILD_q[b] = preILDq ; 
        r1ws_pt += 4;
    }

    b = *ptrBand++; 
    /* last band in category  differential quantization  */
    read_index4( r1ws_pt, &idx);
    preILDq      = (preILDq + tab_ild_q4[idx]); 
    mem_ILD_q[b] = preILDq ; 
    r1ws_pt += 4;
    return;
}

/*************************************************************************
* dequantRefineILD
*
* dequantization of ILD refinement
**************************************************************************/
static Short dequantRefineILD(Short swb_flag, Short ic_flag, Short frame_idx, Short idx, 
                               Short *mem_ILD_q, Short *r1ws_pt)
{
    Short nbBitRefineILD, i;
    Short parityFrame_idx, parityIdx, flagNbBand, incBand, b0;
    Short idx1;

    /* case 4* Frame_idx + idx */
    i = (frame_idx * 4);
    i = (i + idx);
    incBand = 1;  /* increment index subband 1  case parityFrame_idx !=parityIdx*/
    flagNbBand = 0;  /* =0 if 3 sub band to be quantized Frame_idx != idx, otherwise 2 subbands */

    parityFrame_idx = (frame_idx & 0x01);
    parityIdx = (idx & 0x01);
    if(parityFrame_idx ==  parityIdx )
    {
        incBand++; /* increment index subband 2 case parityFrame_idx= parityIdx*/
    }
    if(frame_idx ==  idx)
    {
        flagNbBand++; /* only 2 subband to quantize */
    }
    b0 = startBand[i];  /* 1st subband to be quantized */

    /*The number of bits used for ILD refinement is determined by IC flag*/
    if(ic_flag)
    { /* case ic transmitted */
        nbBitRefineILD = 4; 
        if(swb_flag == 0)
        { /* WB and case ic transmitted */
            nbBitRefineILD++;
            /* only 2 subbands to quantize on 3 and 2 bits */ 
            read_index3(r1ws_pt, &idx1);
            r1ws_pt += 3;
            mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q3[idx1]); 

            b0 += incBand;
            read_index2(r1ws_pt, &idx1);
            r1ws_pt += 2;
            mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q2[idx1]); 
        } /*     end WB and case ic transmitted */
        else
        {   /* SWB and case ic transmitted */
            /* only 2 subbands to quantize both on 2 bits */ 
            read_index2(r1ws_pt, &idx1);
            r1ws_pt += 2;
            mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q2[idx1]); 

            b0 += incBand;
            read_index2(r1ws_pt, &idx1);
            r1ws_pt += 2;
            mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q2[idx1]); 
        } /* end SWB and case ic transmitted */
    } /* end case ic transmitted */
    else
    { /* case ic non transmitted */
        nbBitRefineILD = 6; 

        if (swb_flag == 0)
        { /* WB and case ic non transmitted */
            nbBitRefineILD++;
            if( flagNbBand == 0)
            {  /* case 3 subbands quantized first on 3 bits , last two subbands on 2 bits */
                read_index3(r1ws_pt, &idx1);
                r1ws_pt += 3;
                mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q3[idx1]); 
                for(i = 0; i < 2; i++)
                {
                    b0 += incBand;
                    read_index2(r1ws_pt, &idx1);
                    r1ws_pt += 2;
                    mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q2[idx1]); 
                }
            } /* end case 3 subbands quantized first on 3 bits , last two subbands on 2 bits */
            else
            { /* case 2 subbands quantized first on 4 bits, last on 3 bits */
                read_index4(r1ws_pt, &idx1);
                r1ws_pt += 4;
                mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q4[idx1]); 

                b0 += incBand;
                read_index3(r1ws_pt, &idx1);
                r1ws_pt += 3;
                mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q3[idx1]); 
            } /* end case 2 subbands quantized first on 4 bits, last on 3 bits */
        } /* end  WB and case ic non transmitted */
        else
        { /* SWB and case ic non transmitted */
            if( flagNbBand == 0)
            {  /* case 3 subband quantized all on 2 bits */
                for(i = 0; i < 3; i++)
                {
                    read_index2(r1ws_pt, &idx1);
                    r1ws_pt += 2;
                    mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q2[idx1]); 
                    b0 += incBand;
                }
            } /* end case 3 subband quantized all on 2 bits */
            else
            { /* case 2 subband quantized all on 3 bits */
                for(i = 0; i < 2; i++)
                {
                    read_index3(r1ws_pt, &idx1);
                    r1ws_pt += 3;
                    mem_ILD_q[b0] = roundFto16((Float)mem_ILD_q[b0] + tab_ild_q3[idx1]); 
                    b0 += incBand;
                }
            } /* end case 2 subband quantized all on 3 bits */
        } /* end SWB and case ic non transmitted */
    } /* end case ic non transmitted */

    return (nbBitRefineILD );
}

/*************************************************************************
* calc_ICSyntScaleFactors
*
* calculate the scale factors for Inter Channel Coherence Synthesis
**************************************************************************/
static void calc_ICSyntScaleFactors(Short n, Short *pre_ild_q, Short icSq, 
                                    Short *w1_d_c1, Short *w2_d_c2, Short *w3)
{
    Short i;
    Short preILD, relPow;
    Short *ptrILDq;
    Short *ptr1, *ptr2, *ptr3;
    const Short *ptr_c_table10_1, *ptr_c_d_table_factor;
    const Word32 *ptr_c_d_table_factor_d_c1;

    ptr1 = w1_d_c1;
    ptr2 = w2_d_c2;
    ptr3 = w3;

    ptr_c_table10_1 = &c_table10_1[110];
    ptr_c_d_table_factor_d_c1 = &c_d_table_factor_d_c1[110];
    ptr_c_d_table_factor = &c_d_table_factor[110];
    ptrILDq = pre_ild_q;

    for(i = 0; i < n; i++)
    {
        preILD  = *ptrILDq++; 
        relPow  = calcRelPowerLR(icSq, preILD); 
        *ptr1++ = calcScaleFacCorrel(ptr_c_table10_1[preILD], ptr_c_d_table_factor_d_c1[preILD], relPow); 
        *ptr3++ = calcScaleFacUncorrel(ptr_c_d_table_factor[preILD], relPow); 
        preILD  = -(preILD);
        *ptr2++ = calcScaleFacCorrel(ptr_c_table10_1[preILD], ptr_c_d_table_factor_d_c1[preILD], relPow); 
    }

    return;
}

/*************************************************************************
* calcRelPowerLR
*
* calculate the relative power of left and right channels
**************************************************************************/
static Short calcRelPowerLR(Short icSq, Short preILD)
{
    Float valp, valn;
    const Short *ptr_c_table10_1;
    Float tmp32;
    Float tmp16;

    ptr_c_table10_1 = &c_table10_1[110];
    valp  = (Float)ptr_c_table10_1[preILD]; 
    valn  = (Float)ptr_c_table10_1[-preILD]; 
    tmp32 = valp * valn;

	tmp32 = (tmp32 * icSq * 0.0001220703125f);

    tmp32 = (1073741824.0f - tmp32);

	tmp16 = Sqrt(tmp32);

	tmp16 = (32768.0f - tmp16) * 0.5f;

	tmp16 = f_max(f_min(f_min(tmp16, valp), valn), 0.0f);

    return roundFto16(tmp16);
}

/*************************************************************************
* calcScaleFacCorrel
*
* calculate a scale factors for one bin correlated signal
**************************************************************************/
static Short calcScaleFacCorrel(Short val1, Word32 Lval2, Short val3)
{
    Float tmp16;
    Float tmp32_2;

    tmp16 = (Float)val1 - val3;

    tmp32_2 = (tmp16 * 0.00048828125f);
	tmp16 = Sqrt(tmp32_2);
	tmp16 = Lval2 * tmp16;

    return roundFto16(tmp16);
}

/*************************************************************************
* calcScaleFacUncorrel
*
* calculate a scale factors for one bin uncorrelated signal
**************************************************************************/
static Short calcScaleFacUncorrel(Short val1, Short val3)
{
    Float tmp16;
    Float tmp32_2;

    tmp32_2 = val3 * 0.000030517578125f;
	tmp16 = Sqrt(tmp32_2);
	tmp16 = tmp16 * val1;//Q14

    return roundFto16(tmp16);
}

/*************************************************************************
* decorrel
*
* de-correlated signals are added to the left and right channel respectively
**************************************************************************/
static void decorrel(Short n, Short region_ic , Short *w3, 
                     Short *w1_d_c1, Short *w2_d_c2,
                     Float *memDecorrReal, Float *memDecorrImag, 
                     Float *L_real_syn, Float *L_imag_syn, Short q_left,
                     Float *R_real_syn, Float *R_imag_syn, Short q_right)
{
    Short i, j;
	Float tmp16;
    Float *ptrMemR0, *ptrMemI0, *ptrMemR1, *ptrMemI1;
    Float *ptr_l_real, *ptr_l_imag, *ptr_r_real, *ptr_r_imag ;
    const Short *ptr_c_idx;

    ptrMemR0 = memDecorrReal + region_ic;
    ptrMemI0 = memDecorrImag + region_ic;
    ptrMemR1 = ptrMemR0 + 162;
    ptrMemI1 = ptrMemI0 + 162;

    ptr_l_real = L_real_syn+region_ic;
    ptr_l_imag = L_imag_syn+region_ic;
    ptr_r_real = R_real_syn+region_ic;
    ptr_r_imag = R_imag_syn+region_ic;

    ptr_c_idx = c_idx+region_ic;
    for(i=0; i<n; i++)
    {
        j = *ptr_c_idx++; 
        tmp16 = decorrelOnePoint(*ptrMemR0++, *ptr_l_real, w3[j], w1_d_c1[j], q_left); 
        *ptr_l_real++ = tmp16; 
        tmp16 = decorrelOnePoint(*ptrMemI0++, *ptr_l_imag, w3[j], w1_d_c1[j], q_left); 
        *ptr_l_imag++ = tmp16; 
        tmp16 = decorrelOnePoint(*ptrMemR1++, *ptr_r_real, w3[j], w2_d_c2[j], q_right); 
        *ptr_r_real++ = tmp16; 
        tmp16 = decorrelOnePoint(*ptrMemI1++, *ptr_r_imag,  w3[j], w2_d_c2[j], q_right); 
        *ptr_r_imag++ = tmp16; 
    }

    return;
}

/*************************************************************************
* decorrelOnePoint
*
* de-correlation for one frequency bin
**************************************************************************/
static Float decorrelOnePoint(Float mem, Float val_io, Short val3, Short val1, Short qVal)
{
	return (val1 * val_io * 0.00006103515625f + mem * val3 * powT[46 + qVal]);
}

/*************************************************************************
* stereo_dec_timepos
*
* Super higher band stereo post processing
**************************************************************************/
Short stereo_dec_timepos( Short sig_Mode,
                        Float *Tenv_SWB,
                        Float *sIn_Out,    /* (i/o): time domain signal        */
                        void *work,         /* (i/o): Pointer to work space        */
                        Short T_modify_flag,
                        Short channel_flag,
                        Short delay,
                        Float ratio
                       )
{
    BWE_state_dec *dec_st = (BWE_state_dec *)work;
    Short i, pos;
    Float enn[SWB_TENV];
    Float *pit;
    Float max_env, ener_prev, atteu;
    Float *tPre;

    Float tEnvelope[SWB_T_WIDTH],tmp_Tenv_SWB[SWB_TENV];

    if(channel_flag == 1) /*left channel*/
    {
        tPre = dec_st->left_tPre_s;
    }
    else
    {
        tPre = dec_st->right_tPre_s;
    }

    pit = sIn_Out;
    for (i = 0; i < SWB_TENV; i++)
    {
        enn[i] = 0.001f;
        for (pos = 0; pos < SWB_TENV_WIDTH; pos++)
        {
            enn[i] += (*pit) * (*pit);
            pit++;
        }   
		enn[i] *= 1.6f; 
		enn[i] = Sqrt(SWB_TENV_WIDTH / enn[i]);
		tmp_Tenv_SWB[i] = enn[i] * Tenv_SWB[i];
    }


    /*Calculate the time evelope of the input signal*/
    for (pos = 0; pos < delay; pos++)
    {
        tEnvelope[pos] = tmp_Tenv_SWB[0];
    }
    for (i = 0; i < SWB_TENV - 1; i++)
    {
        for (pos = 0; pos < SWB_TENV_WIDTH; pos++)
        {
            tEnvelope[i * SWB_TENV_WIDTH + delay + pos] = tmp_Tenv_SWB[i];
        }
    }
    for (pos = 0; pos < SWB_TENV_WIDTH - delay; pos++)
    {
        tEnvelope[(SWB_TENV - 1) * SWB_TENV_WIDTH + delay + pos] = tmp_Tenv_SWB[SWB_TENV - 1];
    }

    if (T_modify_flag == 1)
    {
        max_env = Tenv_SWB[0];
        pos = 0;
        for (i = 1; i < SWB_TENV; i++)
        {
            if (Tenv_SWB[i] > max_env)
            {
                max_env = Tenv_SWB[i];
                pos = i;
            }
        }

        if (pos != 0)
        {
            pit = &tEnvelope[SUB_SWB_T_WIDTH * pos + delay];
            atteu = Tenv_SWB[pos - 1] / Tenv_SWB[pos];
            for (i = 0; i < HALF_SUB_SWB_T_WIDTH; i++)
            {
                *pit *= atteu;
                pit++;
            }
        }
        else
        {
            pit = tPre;
            ener_prev = 0.0001f;
            for(i = 0; i < HALF_SUB_SWB_T_WIDTH; i++)
            {
                ener_prev = (*pit) * (*pit);
                pit++;
            }
            ener_prev = Sqrt(ener_prev / HALF_SUB_SWB_T_WIDTH);

            pit = tEnvelope;
            atteu = ener_prev / Tenv_SWB[pos];
            for(i = 0; i < HALF_SUB_SWB_T_WIDTH + delay; i++)
            {
                *pit *= atteu;
                pit++;
            }
        }
    }
    for(pos = 0; pos < SWB_T_WIDTH; pos++)
    {
        tEnvelope[pos] *= ratio;
    }
    /* temporal domain post-processing */
    pit = sIn_Out;

    for (pos = 0; pos < SWB_T_WIDTH; pos++)
    {
        *pit *= tEnvelope[pos];
        pit++;
    } 

    for(i=0; i<SWB_T_WIDTH; i+=2)
    {
        sIn_Out[i] *= (-1.0f);
    }

    /* copy decoded sound data to output buffer */
    movF( HALF_SUB_SWB_T_WIDTH, &sIn_Out[SWB_T_WIDTH-HALF_SUB_SWB_T_WIDTH], tPre );
    if (sig_Mode == TRANSIENT)
    {
        dec_st->pre_tEnv = (short)Tenv_SWB[3];
    }
    dec_st->pre_mode = sig_Mode;

    return 2;
}

/*************************************************************************
* g711_stereo_decoder_shb
*
* g711 super higher band stereo decoder
**************************************************************************/
void g711_stereo_decoder_shb(Short* bpt_stereo_swb,
                             Float* coef_SWB_s,
                             Float* syn_left_swb_s,
                             Float* syn_right_swb_s,
                             void*   ptr,
                             Short  ploss_status,
                             Short  Mode
                             )
{
    Short* bpt = bpt_stereo_swb; 
    g711_stereo_decode_WORK *w = (g711_stereo_decode_WORK *)ptr; 
    Short i;

    Float left_mdct_s[L_FRAME_WB],right_mdct_s[L_FRAME_WB];

    Short idx;

    Float mono_mdct[80];

    Short tmp;

	Float pow_tmp1, pow_tmp2;
	HBFEC_State *dummy = NULL;

    if(ploss_status == 0)
    {
        if(w->swb_ILD_mode)
        {
            read_index5( bpt, &idx);
            bpt += 5;

			tmp = tab_ild_q5[idx] >> 9;

            w->c1_swb[0] = c_table20[80 + tmp]; 
            w->c2_swb[0] = c_table20[80 - tmp]; 
            w->c1_swb[1] = w->c1_swb[0]; 
            w->c2_swb[1] = w->c2_swb[0]; 
        }
        else
        {
            read_index5( bpt, &idx);
            bpt += 5;

			tmp = tab_ild_q5[idx] >> 9;

            w->c1_swb[w->swb_frame_idx] = c_table20[80 + tmp]; 
            w->c2_swb[w->swb_frame_idx] = c_table20[80 - tmp]; 
        }
    }

    for (i = 0; i < 60; i++) 
    {
		mono_mdct[i] = coef_SWB_s[i] * 0.055901699f;/* 1/(8.0f * Sqrt(5.0f)) */
    }

    /* L and R channels reconstructed */
	pow_tmp1 = w->c1_swb[0];
	pow_tmp2 = w->c2_swb[0];
    for(i=swb_bands[0]; i<swb_bands[1]; i++)
    {
        left_mdct_s[i]  = mono_mdct[i] * pow_tmp1; 
        right_mdct_s[i] = mono_mdct[i] * pow_tmp2; 
    }

	pow_tmp1 = w->c1_swb[1];
	pow_tmp2 = w->c2_swb[1];
    for(i=swb_bands[1]; i<swb_bands[2]; i++)
    {
        left_mdct_s[i]  = mono_mdct[i] * pow_tmp1; 
        right_mdct_s[i] = mono_mdct[i] * pow_tmp2; 
    }

    zeroF(20, &left_mdct_s[60]);
    zeroF(20, &right_mdct_s[60]);

    f_inv_mdct_point80(syn_left_swb_s,left_mdct_s,w->mem_left_mdct, 0,w->sCurSave_left, dummy);
    f_inv_mdct_point80(syn_right_swb_s,right_mdct_s,w->mem_right_mdct, 0,w->sCurSave_right, dummy);
}

/*************************************************************************
* Syn_FFT_bin
*
* FFT bin synthesis based on the amplitude and the phase
**************************************************************************/
static void Syn_FFT_bin(Float iRPhase,
                        Float mag,
                        Float *real,
                        Float *imag)
{
	Float iPhaseCos,iPhaseSin,iTmpPhase;

	iPhaseCos = Cos(iRPhase);
	iTmpPhase = ( PID2 - iRPhase ) ;
	iPhaseSin = Cos(iTmpPhase);

	*real = mag * iPhaseCos;
	*imag = mag * iPhaseSin;
}

/*************************************************************************
* Phase_syn_ITD
*
* left and right channel signals synthesis based on the whole wideband ITD 
**************************************************************************/
void Phase_syn_ITD(Float ipd_diff_q,
                   Float mono_dec_real,
                   Float mono_dec_imag,
                   Float c,
                   Float L_mag,
                   Float R_mag,
                   Float *L_real_syn,
                   Float *L_imag_syn,
                   Float *R_real_syn,
                   Float *R_imag_syn
                   )
{
    Float M_phase;
    Float iCPhase,iC1Phase,iRPhase;
	Float ipd_diff_q_f = ipd_diff_q * 0.000244140625f;

	M_phase = (Float)atan2(mono_dec_imag, mono_dec_real);

	iCPhase = c * ipd_diff_q_f;

    iRPhase = (M_phase + iCPhase );
    Syn_FFT_bin(iRPhase, L_mag, L_real_syn, L_imag_syn);

    iC1Phase = ( ipd_diff_q_f - iCPhase );
    iRPhase = (M_phase - iC1Phase );

    Syn_FFT_bin(iRPhase, R_mag, R_real_syn, R_imag_syn);
}
/*************************************************************************
* Phase_syn_ITD0  case stereo_mono_flag = 0
* left and right channel signals synthesis based on the whole wideband ITD 
* as ipd_diff_q =0 then iCPhase = iC1Phase= 0; iRPhase = M_phase; 
*
**************************************************************************/
void Phase_syn_ITD0(Float mono_dec_real,
                    Float mono_dec_imag,
                    Float L_mag,
                    Float R_mag,
                    Float *L_real_syn,
                    Float *L_imag_syn,
                    Float *R_real_syn,
                    Float *R_imag_syn
                    )
{
    Float M_phase;

	M_phase = (Float)atan2(mono_dec_imag, mono_dec_real);

    Syn_FFT_bin(M_phase, L_mag, L_real_syn, L_imag_syn);
    Syn_FFT_bin(M_phase, R_mag, R_real_syn, R_imag_syn);
}

/*************************************************************************
* Phase_syn_IPD
*
* left and right channel signals synthesis based on the whole wideband IPD
**************************************************************************/
void Phase_syn_IPD(Float ipd_diff_q,
                   Short IPD_q,
                   Float mono_dec_real,
                   Float mono_dec_imag,
				   Float c,
                   Float L_mag,
                   Float R_mag,
                   Float *L_real_syn,
                   Float *L_imag_syn,
                   Float *R_real_syn,
                   Float *R_imag_syn
                   )
{
    Float M_phase, iCPhase;
	Float f_iRPhase;

	M_phase = (Float)atan2(mono_dec_imag, mono_dec_real);

	iCPhase = c * ipd_diff_q * 0.000244140625f;

    f_iRPhase = M_phase + iCPhase;

    Syn_FFT_bin(f_iRPhase, L_mag, L_real_syn, L_imag_syn);

	f_iRPhase = (Round_Phase(f_iRPhase * 4096.0f) - IPD_q) * 0.000244140625f;

    Syn_FFT_bin(f_iRPhase, R_mag, R_real_syn, R_imag_syn);
}

/*************************************************************************
* Phase_syn_IPD0
* 
* Phase synthesis case stereo_mono_flag = 0
* left and right channel signals synthesis based on the whole wideband IPD
* as ipd_diff_q =0 so iCPhase = 0; and
* left channel iRPhase = M_phase; 
* right channel iRPhase = sub(Round_Phase(M_phase),IPD_q);; 
**************************************************************************/
void Phase_syn_IPD0(Short IPD_q,
                    Float mono_dec_real,
                    Float mono_dec_imag,
                    Float L_mag,
                    Float R_mag,
                    Float *L_real_syn,
                    Float *L_imag_syn,
                    Float *R_real_syn,
                    Float *R_imag_syn
                    )
{
	Float f_M_phase;
	Float f_iRPhase;

	f_M_phase = (Float)atan2(mono_dec_imag, mono_dec_real);
    Syn_FFT_bin(f_M_phase, L_mag, L_real_syn, L_imag_syn);

	f_iRPhase = (Round_Phase(f_M_phase * 4096.0f) - IPD_q) * 0.000244140625f;

    Syn_FFT_bin(f_iRPhase, R_mag, R_real_syn, R_imag_syn);
}

/*************************************************************************
* stereo_synthesis
*
* left and right channel signals synthesis based on the wideband ILD
**************************************************************************/
void stereo_synthesis(Short* ILD_q,          /* i: ILD quantized */
                      Float* mono_real,  /* i: mono signal */
                      Float* mono_imag,
                      Short  q_mono,
                      Float* L_real_syn, /* o: L signal synthesis */
                      Float* L_imag_syn, 
                      Float* R_real_syn, /* o: R signal synthesis */
                      Float* R_imag_syn,
                      Short* q_left,
                      Short* q_right,
                      Float* L_mag,
                      Float* R_mag,
                      Short  ploss_status
                      )
{
    Short   b, i;
    Float tmp;

	Short tmpS;

    if(ploss_status == 0)
    {
        for(i=0; i< IPD_SYN_START; i++)
        {
			tmpS = ILD_q[c_idx[i]];
			tmp = c_table20[80 + tmpS];
            L_real_syn[i] = mono_real[i] * tmp;
            L_imag_syn[i] = mono_imag[i] * tmp;
			tmp = c_table20[80 - tmpS];

            R_real_syn[i] = mono_real[i] * tmp;
            R_imag_syn[i] = mono_imag[i] * tmp;
        }

        for(b=17; b<NB_SB; b++)
        {
			tmpS = ILD_q[b];
            for(i=bands[b]; i<bands[b+1]; i++)
            {
				tmp = c_table20[80 + tmpS];
                L_real_syn[i] = mono_real[i] * tmp; 
                L_imag_syn[i] = mono_imag[i] * tmp;
				tmp = c_table20[80 - tmpS];

                R_real_syn[i] = mono_real[i] * tmp;
                R_imag_syn[i] = mono_imag[i] * tmp;
            }
        }

        for(b=START_ILD; b<NB_SB; b++)
        {
			tmpS = ILD_q[b];
            for(i=bands[b]; i<bands[b+1]; i++)
            {
		        tmp = Sqrt(mono_real[i] * mono_real[i] + mono_imag[i] * mono_imag[i]);
                L_mag[i] = tmp * c_table20[80 + tmpS];
                R_mag[i] = tmp * c_table20[80 - tmpS];
            }
        }
    }
    else
    {
        for(i=0; i< 81; i++)
        {
			tmpS = ILD_q[c_idx[i]];
			tmp = c_table20[80 + tmpS];
            L_real_syn[i] = mono_real[i] * tmp; 
            L_imag_syn[i] = mono_imag[i] * tmp;
			tmp = c_table20[80 - tmpS];

            R_real_syn[i] = mono_real[i] * tmp; 
            R_imag_syn[i] = mono_imag[i] * tmp;
        }
    }
    *q_left = (q_mono - 1);
    *q_right = (q_mono - 1);
}
#endif /* LAYER_STEREO */
