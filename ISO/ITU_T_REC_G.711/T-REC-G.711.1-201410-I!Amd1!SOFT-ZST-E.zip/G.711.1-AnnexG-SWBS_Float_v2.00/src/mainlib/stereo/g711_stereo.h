/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: g711_stereo.h
 *  Function: Header of stereo function
 *------------------------------------------------------------------------
 */

#ifndef G711_STEREO_H
#define G711_STEREO_H

#ifdef LAYER_STEREO
#include "pcmswb_common.h"
#include "dsputil.h"


#define WMOPS_ALL
//#define WMOPS_IDX

#define INIT_STEREO_MONO          100
#define INIT_STEREO_MONO_FEC      10

#define IPD_SYN_START             2
#define IPD_SYN_WB_END_WB         (IPD_SYN_START + 7)
#define IPD_SYN_WB_END_SWB        (IPD_SYN_START + 6)
#define IPD_SYN_SWB_END_SWB       (IPD_SYN_WB_END_SWB + 16)

#define IC_BEGIN_BAND             0
#define IC_END_BAND               20

#define inv_LOG2_10               24660     /* 10/log2(10) (Q13) */
#define LOG2_10                   5443      /* log2(10)/20 (Q15) */
#define LOG2_20                   10885     /* log2(10)/10 (Q15) */
#define inv_FNUM                  4681      /* 1/FNUM (Q15) */
#define NFFT                      160       /* window length for FFT */
#define NB_SB                     20        /* number of subbands in Bark scale */
#define SWB_BN                    2         /* number of sunbans for super higher band */
#define START_ILD                 0           
/*----Fixed constant----------------*/
#define PID2_FQ12                 6434
#define NGPID2_FQ12               -6434
#define PI_FQ12                   12868
#define NGPI_FQ12                 -12868    
#define PI3D2_FQ12                19302
#define PI2_FQ12                  25736
#define NGPI2_FQ12                -25736

#define C04_FQ12                  1638
#define C06_FQ12                  2458
#define C20_FQ12                  8192
#define PID4_FQ12                 3217

#define C002_FQ15                 655
#define C098_FQ15                 32113

#define C098_FQ15_N               -32113

#define C08_FQ15                  26214
#define CPIDNFFT_FQ15             643
#define CPIDNFFT_FQ15_2           161
#define C0025_FQ15                819
#define C03_FQ15                  9830
#define C06_FQ15                  19661

#define M1                        32767
#define M2                        -21
#define M3                        -11943
#define M4                        4936
#define K1                        8192
#define K2                        -4096
#define K3                        340
#define K4                        -10
#define FNUM                      7
#define G711_WB_DMX_DELAY         50

#define ZERO_LEN                  15

#define C_fx51                    -20480    /* [cos(2*pi/5)+cos(2*2*pi/5)]/2-1 (Q14) */
#define C_fx52                    18318     /* [cos(2*pi/5)-cos(2*2*pi/5)]/2 (Q15) */
#define C_fx53                    -31164    /* -sin(2*pi/5) (Q15) */
#define C_fx54                    -25212    /* -[sin(2*pi/5)+sin(2*2*pi/5)] (Q14) */
#define C_fx55                    11904     /* [sin(2*pi/5)-sin(2*2*pi/5)] (Q15) */
#define C_fx81                    23170     /* 1/sqrt(2) (Q15) */
#define C_fx162                   12540     /* cos(pi*6/16) (Q15) */
#define C_fx163                   21407     /* cos(pi*2/16)*sqrt(2) (Q14) */
#define C_fx164                   17734     /* cos(pi*6/16)*sqrt(2) (Q15) */
#define C_fx165                   30274     /* cos(pi*2/16) (Q15) */
#define G_FX                      26214     /* 1/1.25 (Q15) */
#define NG_FX                     -26214

#define NB_SEG5                   5
#define NB_SEG234                 3
#define HALFSTEPQ3                1024

#define STARTBANDITD              3
#define BANDITD                   10
#define PI_D8_4096                1608
#define PI_2_4096                 25736
#define PI_4096_D_4               3217
#define PI_4096                   12868
#define PI_08_4096                10294
#define PI_1D5_4096               19302
#define STARTBANDPHA              1
#define BANDPHA                   6
#define PHA                       10
#define IPD_FNUM                  10

#define     PID2                    1.5707963268f

extern const Short nbCoefBand[20];
extern const Short maxQ[20]; 
extern const Short nbShQ[20]; 

extern const Short NFFT_D_2_PI_I[10]; 
extern const Short MAX_PHASE_I[10];
extern const Short INV_nb_idx[13];

extern const Short bands[NB_SB+1];      /* sub-bands in Bark scale */
extern const Short tab_ild_q5[31];      /* table for ILD quantization with 5 bits */
extern const Short tab_ild_q4[15];      /* table for ILD quantization with 4 bits */
extern const Short tab_ild_q3[7];       /* table for ILD quantization with 3 bits */
extern const Short tab_ild_q2[4];       /* table for ILD quantization with 2 bits */
extern const Short band_region[20];
extern const Float band_region_ref[20];

extern const Short startBand[4*4];
extern const Short band_num[4][4];
extern const Short band_index[4][5];

extern const Short swb_bands[SWB_BN+1];
extern const Short swb_int_bands[4];
extern const Short tab_phase_q5[32];    /* table for phase quantization with 5 bits */
extern const Short tab_phase_q4[16];    /* table for phase quantization with 4 bits */
extern const Float win_D[50]; 

extern const Short c_idx[81];

extern const Float c_table10[161];

extern Float c_table20[161];

extern const Short indPWQU5[NB_SEG5+1]; 
extern const Short bSeg5[NB_SEG5]; 
extern const Short ind0Seg5[NB_SEG5];

extern const Float invStepQ5_QN15[NB_SEG5]; 

extern const Short halfStepQ5[NB_SEG5]; 
extern const Short threshPWQU5[NB_SEG5-1];
extern const Short indPWQU4[NB_SEG234+1]; 
extern const Short bSeg4[NB_SEG234]; 
extern const Short ind0Seg4[NB_SEG234];

extern const Float *invStepQ4_QN15;

extern const Short *halfStepQ4; 
extern const Short *threshPWQU4;
extern const Short indPWQU3[2];
extern const Short threshPWQU3[NB_SEG234-1]; 
extern const Short initIdxQ3[NB_SEG234]; 
extern const Short threshPWQU2[NB_SEG234];
extern const Short paramQuantPhase[10];

extern const Short c_table10_1[221];
extern const Short c_d_table_factor[221];
extern const Word32 c_d_table_factor_d_c1[221];
extern const Float ic_table[4];

extern const Short band_stat2[4*16]; 
extern const Short nbBand_stat[4*4]; 

extern const Short threshPhaseMeanStdSMct[3];

extern const unsigned char initial_switch[40];
extern const unsigned char initial_switch3[10];

/* Pow table */
extern const Float powT[121];

typedef struct{
    /* left channel */
    Float mem_input_left[50];
    Word32 mem_L_ener[20];     /* energy per subband */

    /* right channel */
    Float mem_input_right[50]; 
    Word32 mem_R_ener[20];     /* energy per subband */

    /* mono signal */
    Float mem_mono_ifft_s[50]; 
    Short pre_q_left_en_band[20];
    Short pre_q_right_en_band[20];

    Short mem_ild_q[20];
    Short fb_ITD;
    Short fb_IPD;

    Float mem_mono[L_FRAME_WB];
    Float mem_side[L_FRAME_WB];

    Float mem_left[L_FRAME_WB];
    Float mem_right[L_FRAME_WB];

    Short SWB_ILD_mode;

    Short frame_flag_wb;
    Short frame_flag_swb;
    Short c_flag;
    Short pre_flag;
    Short num;
    Short mem_q_channel_en,mem_q_mono_en;
    Short swb_frame_idx;

	Float mem_l_enr[SWB_BN],mem_r_enr[SWB_BN],mem_m_enr[SWB_BN];

    //--------------ITD realted-------------------
    Word32 Crxyt[STARTBANDITD+BANDITD];
    Word32 Cixyt[STARTBANDITD+BANDITD];

    Float pre_ild_sum_swb[FNUM];
	Float pre_ild_sum[FNUM];
	Float pre_ild_sum_H[FNUM];
    Short pos;

    Short idx[IPD_SYN_SWB_END_SWB + 2];

    Short ic_idx;
    Short ic_flag;
    Short ipd_num,ipd_reg_num;
    Short pre_Itd;

    Float pre_Ipd;

    Short std_itd_pos_sm;
    Short std_itd_neg_sm;
    Short nb_idx_pos_sm;
    Short nb_idx_neg_sm;
    Short pre_itd_neg;
    Short pre_itd_pos;

    Word32 Crxyt2[STARTBANDITD+BANDITD];
    Word32 Cixyt2[STARTBANDITD+BANDITD];
    Short phase_mean_buf[10];

    Float phase_mean_buf1[10];

    Short phase_num;
    Short pos1;
    Short f_num;
    Word32 energy_bin_sm[STARTBANDITD + BANDITD];

    Short en_ratio_sm;

    Float phase_mean_std_sm_ct;

    Word32 mem_energyL;
    Word32 mem_energyR;

    Short pre_ipd_mean;
    Short ipd_reg_num_sm;

    Float phase_mean_std_sm;
    Float ipd_mean_sm;
}g711_stereo_encode_WORK;

typedef struct {
    Float mem_output_L[50];                  
    Float mem_output_R[50];                  
    Float mem_mono_win[50];           

    Short mem_ILD_q[20];        /* ILD quantized per sub-band */

    Float c1_swb[SWB_BN];
    Float c2_swb[SWB_BN];

    Short frame_idx;
    Short swb_ILD_mode;
    Short pre_swb_ILD_mode;
    Short swb_frame_idx;
    Short delay;

    Short c_flag;
    Short pre_flag;
    Short pre_ipd_q[IPD_SYN_SWB_END_SWB + 2];
    Short pre2_ipd_q[IPD_SYN_SWB_END_SWB + 2];
    Short pre_fb_itd;
    Short pre2_fb_itd;
    Short fb_ipd;
    Short fb_itd;
    Short pre_fb_ipd;
    Short pre2_fb_ipd;
    Short pre_ild_q[20];
    Short pre2_ild_q[20];
    Short mem_mono[L_FRAME_WB];

    Float mem_left_mdct[L_FRAME_WB],mem_right_mdct[L_FRAME_WB];

    Short pre_norm_left,pre_norm_right;
    Float sCurSave_left[L_FRAME_WB],sCurSave_right[L_FRAME_WB];
    Float mem_left[G711_WB_DMX_DELAY];
    Float mem_right[G711_WB_DMX_DELAY];
    Float ic_sm;

    Short pre_ic_flag;
    Short pre2_ic_flag;
    Short pre_ic_idx;
    Short pre2_ic_idx;

    Float mem_decorr_real[(NFFT/2 + 1) * 4], mem_decorr_imag[(NFFT/2 + 1) * 4];
    Short q_mem[4];

} g711_stereo_decode_WORK;

Short Exp16Array_stereoF(Short n, Float *s_real, Float *s_imag);

void get_interchannel_difference(g711_stereo_encode_WORK *w,
                                 Float* L_real,
                                 Float* L_imag,
                                 Short  q_left,
                                 Float* R_real,
                                 Float* R_imag,
                                 Short  q_right,
                                 Short* ic_idx,
                                 Short* ic_flag
                                 );

Float ild_calculation(Float L_ener,Float R_ener);

void Phase_syn_ITD(Float ipd_diff_q,
                   Float mono_dec_real,
                   Float mono_dec_imag,
                   Float c,
                   Float L_mag,
                   Float R_mag,
                   Float *L_real_syn,
                   Float *L_imag_syn,
                   Float *R_real_syn,
                   Float *R_imag_syn
                   );

void Phase_syn_IPD(Float ipd_diff_q,
                   Short IPD_q,
                   Float mono_dec_real,
                   Float mono_dec_imag,
				   Float c,
                   Float L_mag,
                   Float R_mag,
                   Float *L_real_syn,
                   Float *L_imag_syn,
                   Float *R_real_syn,
                   Float *R_imag_syn
                   );
void  g711_stereo_encode_reset( void* ptr );
void* g711_stereo_encode_const();
void  g711_stereo_encode_dest( void* ptr );
void downmix(Float* input_left,   /* i: input L channel */
             Float* input_right,  /* i: input R channel */
             Short* mono,         /* o: output mono downmix */
             void*   ptr,
             Short* bpt_stereo,
             Short  mode,
             Short* frame_idx,
             Short  Ops
             );
void g711_stereo_encode(Float* L_real,
                        Float* L_imag,
                        Float* R_real,
                        Float* R_imag,
                        Short  q_left,
                        Short  q_right,
                        Short* bpt_stereo,
                        void*   ptr, 
                        Short* frame_idx,
                        Short  mode,
                        Short  Ops
                        );

int ild_attack_detect(			   
            float* L_ener, /* i: energy per sub-band of L channel */
			float* R_ener, /* i: energy per sub-band of R channel */
			void*   ptr
            );

Short ild_attack_detect_shb( Float* L_ener, /* i: energy per sub-band of L channel */
                             Float* R_ener, /* i: energy per sub-band of R channel */
                             Short q_left_en,
                             Short q_right_en,
                             void* ptr
                             );

void *g711_stereo_decode_const();
void g711_stereo_decode_dest( void* ptr );
void g711_stereo_decode_reset( void* ptr );
void g711_stereo_decode(Short* bpt_stereo,
                        Float* mono_dec,
                        Short* left_syn,
                        Short* right_syn,
                        void*   ptr,
                        Short  mode,
                        Short  SWB_WB_flag,
                        Short  ploss_status,
                        Short  cod_Mode,
                        Short  stereo_mono_flag
                        );

void stereo_synthesis(Short* ILD_q,      /* i: ILD quantized */
	                  Float* mono_real,  /* i: mono signal */
                      Float* mono_imag,
                      Short  q_mono,
                      Float* L_real_syn, /* o: L signal synthesis */
                      Float* L_imag_syn,
                      Float* R_real_syn, /* o: R signal synthesis */
                      Float* R_imag_syn,
                      Short* q_left,
                      Short* q_right,
                      Float* L_mag,
                      Float* R_mag,
                      Short  ploss_status
                      );

void downmix_swb(Float* input_left, 
                 Float* input_right,
                 Float* mono_swb,
                 Float* side_swb,
                 void*   ptr
                 );

void G711_stereo_encoder_shb(Float* mono_in,
                             Float* side_in,
                             void*   prt,
                             short*  bpt_stereo_swb,
                             Short  mode,
                             Float* gain
                             );

void g711_stereo_decoder_shb(Short* bpt_stereo_swb, 
                             Float* coef_SWB, 
                             Float* syn_left_swb_s,
                             Float* syn_right_swb_s,
                             void*   ptr,
                             Short  ploss_status,
                             Short  Mode
                             );

Short stereo_dec_timepos(Short  sig_Mode,
                        Float *Tenv_SWB,
                        Float *sIn_Out,    /* (i/o): time domain signal        */
                        void *work,         /* (i/o): Pointer to work space        */
                        Short T_modify_flag,
                        Short channel_flag,
                        Short delay,
                        Float ratio
                          );

Float Round_Phase(Float x);

#endif /* LAYER_STEREO */
#endif /* G711_STEREO_H */
