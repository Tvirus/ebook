/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

#ifdef LAYER_STEREO
#include <math.h>
#include <stdio.h>
#include <string.h>

#include "stereo_tools.h"
#include "pcmswb.h"
#include "softbit.h"
#include "g711_stereo.h"

/*************************************************************************
* deinterleave
*
* Splits an interleaved stereo signal of length N into two separated 
* signals of length N/2
**************************************************************************/
void deinterleave(const Short* input, /* i: Interleaved input signal */
                        Short* left,  /* o: Left output channel */
                        Short* right, /* o: Right output channel */
                        Short  N      /* Number of samples in input frame */
                        )
{
    Short i;

	N /= 2;
    for(i = 0; i < N; i++)
    {
        left[i]  = input[2*i];  
        right[i] = input[2*i+1];
    }

    return;
}

/*************************************************************************
* interleave
*
* Creates a stereo interleaved signal of length 2*N from two separated 
* signals of length N
**************************************************************************/
void interleave(Short* left,   /* i: Left input channel */
                Short* right,  /* i: Right input channel */
                Short* output, /* o: Interleaved output signal */
                Short  N       /* Number of samples in input frames */
                )
{
    Short i;

    for(i = N-1; i >= 0; i--)
    {
        output[2*i+1] = right[i];
        output[2*i]   = left[i]; 
    }

    return;
}

/*************************************************************************
* OLA
*
* overlap and add for mono signal
**************************************************************************/
void f_OLA(Float *cur_real, /* i: current frame */
         Float *mem_real, /* i: past frame */
         Short *cur_ola   /* o: ouptut overlap and add */
         )
{
    Short i;
	Float tmp;
    Float *ptr0, *ptr0b;
	Short *ptr1;
    const Float *ptrwin;

    ptrwin = win_D;
    ptr0   = cur_real;
    ptr0b  = mem_real;
    ptr1   = cur_ola;

    for(i=0; i< 50 ; i++)
    {
        tmp = (*ptr0++) * (*ptrwin++); 
        *ptr1++ = roundFto16((*ptr0b++) + tmp); 
    }
    movFS(30, ptr0, ptr1);
    
    return;
}

/*************************************************************************
* windowStereoF
*
* Windowing left or right channels
**************************************************************************/
void windowStereoF(Float *input,      /* i: input L/R channel */
                  Float *mem_input,  /* i: mem input L/R */
				  Float *output      /* o: windoww input L/R channel */
                  )
{
   Short i;
   Float *ptr0;
   Float *ptr1;

   const Float *ptrwin;

    ptr1 = output;
    /* zeroing first and last 15 points [0, 14] U [145,159]*/
    zeroF(15, output);
    zeroF(15, &output[NFFT - 15]);

    /* windowing next 50 points [15, 64] <- mem [0, 49] *win [0, 49]*/
    ptr0 = mem_input;
    ptr1 += 15;
    ptrwin = win_D;
    for(i=15 ; i< 65; i++)
    {
		*ptr1++ = (*ptr0++) * (*ptrwin++);
    }

    /* copy 30 middle points [65,94] <- input [0, 29] */
    ptr0 = input;
	movF(30, ptr0, ptr1);

    ptr0 += 30;
    ptr1 += 30;
    /* windowing next 50 points [95, 144] <- input [30, 79] * win[49,0] */
    ptrwin = win_D+49;
    for(i=95 ; i< 145; i++)
    {
		*ptr1++ = (*ptr0++) * (*ptrwin--);
    }

    return;
}

/*************************************************************************
* write_index
*
* write index in the stereo bitstream
**************************************************************************/
void write_index1(Short* bpt_stereo, /* O */
                  Short  index       /* I */
                  )
{
    Short tmp;

    tmp = index & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    return;
}
void write_index2(Short* bpt_stereo, /* O */
                  Short  index       /* I */
                  )
{
    Short tmp;

    tmp = index / 2;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    return;
}

void write_index3(Short* bpt_stereo, /* O */
                  Short  index       /* I */
                  )
{
    Short tmp;

    tmp = index / 4;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 2;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    return;
}

void write_index4(Short* bpt_stereo, /* O */
                  Short  index       /* I */
                  )
{
    Short tmp;

    tmp = index / 8;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 4;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 2;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    return;
}

void write_index5(Short* bpt_stereo, /* O */
                  Short  index       /* I */
                  )
{
    Short tmp;

    tmp = index / 16;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 8;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 4;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index / 2;
    tmp = tmp & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    tmp = index & 0x01;
    if(tmp == 0)
    {
        *bpt_stereo++ = G192_BITZERO; 
    }
    if(tmp != 0)
    {
        *bpt_stereo++ = G192_BITONE; 
    }

    return;
}

void read_index1(Short* bpt_stereo, /* I */
                 Short* index       /* O */
                 )
{
    Short tmp1, tmp2, bit;

    tmp1 = 0; 

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 1);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    *index = tmp1;

    return;
}

void read_index2(Short* bpt_stereo, /* I */
                 Short* index       /* O */
                 )
{
    Short tmp1, tmp2, bit;

    tmp1 = 0; 

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 2);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 1);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    *index = tmp1;

    return;
}

void read_index3(Short* bpt_stereo, /* I */
                 Short* index       /* O */
                 )
{
    Short tmp1, tmp2, bit;

    tmp1 = 0; 

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 4);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 2);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 1);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    *index = tmp1;

    return;
}

void read_index4(Short* bpt_stereo, /* I */
                 Short* index       /* O */
                 )
{
    Short tmp1, tmp2, bit;

    tmp1 = 0; 

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 8);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 4);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 2);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 1);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    *index = tmp1;

    return;
}

void read_index5(Short* bpt_stereo, /* I */
                 Short* index       /* O */
                 )
{
    Short tmp1, tmp2, bit;

    tmp1 = 0; 

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 16);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 8);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 4);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 2);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    bit  = *bpt_stereo++;
    tmp2 = (tmp1 + 1);
    if(bit == G192_BITONE)
    {
        tmp1 = tmp2;
    }

    *index = tmp1;

    return;
}

/*************************************************************************
* zero32
*
* write n (Word32)0 in array sx
**************************************************************************/
void zero32(Short  n,    /* I : */
            Word32* sx    /* O : */
            )
{
    Short k;

    for (k = 0; k < n; k++)
    {
        sx[k] = 0; 
    }
}

/*************************************************************************
* Round_Phase
*
* make sure that phase x belongs to interval [-pi,pi]
*       Input:  x
*       Output: x is limited to [-pi,pi] with modulo 2 pi
**************************************************************************/
Float Round_Phase(Float x)
{   
  if( x < NGPI_FQ12)
  {
    x = (x + PI2_FQ12);
  }
  if(x > PI_FQ12)
  {
    x = (x - PI2_FQ12);
  }

  return(x);
}

Word32    L_sum_mul_Array(
                       Short     n,      /* (i): Array size    */
                       Short  *sx,       /* (i): Data array 1  */
                       Short  *sy        /* (i): Data array 2  */
                       )
{
  Word32     x;
  Short     k;

  x = sx[0] * sy[0]; 

  for ( k = 1; k < n; k++ )
  {
    x = (x + sx[k] * sy[k]);
  }

  return x;
}

Short multSFtoS(Short s, Float f)
{
	return roundFto16((Float)s * f);
}
/* Max function for Short data */
Short maxS( Short var1, Short var2) 
{
  Short var_out;

  if( var1 >= var2)
    var_out = var1;
  else
    var_out = var2;

  return( var_out);
}

/* Min function for Short data */
Short minS(Short var1, Short var2)
{
  Short var_out;

  if( var1 <= var2)
    var_out = var1;
  else
    var_out = var2;

  return( var_out);
}

/* Abs function for Short data */
Short absS (Short var1)
{
  if (var1 < 0)
  {
	  if(var1 == -32768)
		  return 32767;
      var1 = -var1;
  }
  return (var1);
}

/* Max function for Long data */
Word32 maxL( Word32 var1, Word32 var2) 
{
  Word32 var_out;

  if( var1 >= var2)
    var_out = var1;
  else
    var_out = var2;

  return( var_out);
}

/* Abs function for Long data */
Word32 absL (Word32 var1)
{
  if (var1 < 0)
  {
	  if(var1 == (Word32)0x80000000L)
		  return 2147483647;
      var1 = -var1;
  }
  return (var1);
}

Float roundFto16F(Float x)
{
  if (x >= 32767.0) {
    return 32767.0f;
  }
  else if (x <= -32768.0) {
    return -32768.0f;
  }
  else if (x >= 0.0) {
    return (Float)(Short)(x + 0.5);
  }
  else {
    return (Float)(Short)(x - 0.5);
  }
}
Float roundFto32F(Float x)
{
  if (x >= 2147483647.0) {
    return 2147483647.0f;
  }
  else if (x <= -2147483648.0) {
    return -2147483648.0f;
  }
  else if (x >= 0.0) {
    return (Float)(Word32)(x + 0.5);
  }
  else {
    return (Float)(Word32)(x - 0.5);
  }
}
void movFL(
             int     n,  /* I : */
             Float   *x, /* I : */
             Word32  *y  /* O : */
             )
{
  int k;

  for( k = 0; k < n; k++ )
  {
    y[k] = roundFto32(x[k]);
  }
}
#endif /*LAYER_STEREO*/
