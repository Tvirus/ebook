/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

#ifdef LAYER_STEREO
#include <math.h>

#include "g711_stereo.h"
#include "fft.h"
#include "dsputil.h"

extern Short cosw[80],sinw[80],sinw_p1[80],sinw_s1[80];

#define CFFT5_R1   (Short)(5063)
#define CFFT5_R2   (Short)(-13255)
#define CFFT5_I1   (Short) (-15582)
#define CFFT5_I2   (Short)(-9630)
#define CFFT5_I3   (Short)(-9630)

static void fft_5_format_2(Float *pRe, Float *pIm, Float *psRe, Float *psIm, Float pow_QVal);

static Float calc_R0 (Float ps0, Float *pL, Float ar14, Float ar32, Float pow_QVal);
static Float calcR4  (Float L_temp0, Float arx, Float ary);
static Float calcI4  (const Short cx, const Short cy, Float six, Float siy);
static void   calcRI4 (Float L_temp0, Float arx, Float ary, const Short cx, 
                       const Float cy, Short six, Float siy, Float *L_a, 
                       Float *L_s, Float pow_QVal);

static void calc_fft5R(Float ps0, Float *pL, Float ar14, Float si14, 
                       Float ar32, Float si32, Float pow_QVal);
static void calc_fft5I(Float ps0, Float *pL, Float ar14, Float si14, 
                       Float ar32, Float si32, Float pow_QVal);

static void fft16R    (Float *sumReIm4, Float *sumReIm, Float *Re);
static void fft16I    (Float *sumReIm4, Float *sumReIm, Float *Im);
static void calcSum2  (Float *Re, Float *sumRe);
static void calcSum4RI(Float *ReIm, Float *sumReIm);

static void calc_RiFFTx   (Float *x, Float *sRe, Float *sIm, Short norm_shift);
static void calc_RiFFT_1_4(Float *x0, Float *x0f, Short norm_shift, 
                           Short sinw_s1, Short sinw_p1, Short cosw, 
                           Float *Re, Float *Ref, Float *Im, Float *Imf);
static void calc_RiFFT_1_2(Float *x0, Float *x0f, Short norm_shift, 
                           Short sinw_s1, Short sinw_p1, Short cosw, 
                           Float *Ref, Float *Imf);

static void s_calcSum2(Float *Re, Float *sumRe, Short QVal);
static void s_calcSum4RI(Float *ReIm, Float *sumReIm);
static void s_fft16R(Float *sumReIm4, Float *sumReIm, Float *Re, Short shift);
static void s_fft16I(Float *sumReIm4, Float *sumReIm, Float *Im, Short shift);
static void s_fft16Ri(Float *sumReIm4, Float *sumReIm, Short shift, Float *x);
static void s_fft16Ii(Float *sumReIm4, Float *sumReIm, Short shift, Float *x);
static Float axplusby0(Float x, Float y, const Short ca, const Short cb);
static Float axpmy_bzpmt0(Float x, Float y, const Short cax, const Short cay,
                           Float z, Float t, const Short cbz, const Short cbt);

static void fft_16x_format_2(Float *ReIm, Short QVal);

static void fft_16x_format_2i(Float *ReIm, Short QVal, Float *x, Short x_q);

static void endRfft(Float *ReIm, Float *x, Short Qfft16);
static void subEndRfft(Float *ptrReIm, Float *ptrReImf, Float *ptr0, Float *ptr0f, 
                       Short Qfft16, Short Qff16_1, Short *ptr_cos, Short *ptr_sin, 
                       Short n);
static void twiddleReIm(Float *pLRe, Float *pLIm, Float *pRe, Float *pIm, 
                        Short *ptr_twiddleRe, Short *ptr_twiddleIm,
                        Short Qfft5, Short Qfft51);

Short    Exp16ArrayF(
                     Short     n,     /* (i): Array size   */
                     Float  *sx    /* (i): Data array   */
                     )
{
  Short     k;
  Short     exp;
  Float  sMax;
  Float  sAbs;

  sMax = abs_f( sx[0] ); 

  for ( k = 1; k < n; k++ )
  {
    sAbs = abs_f( (Float)sx[k] );
    sMax = f_max( sMax, sAbs );
  }

  exp = norm_s( roundFto16(sMax) );
  return exp;
}

Short    Exp32ArrayF(
                     Short     n,     /* (i): Array size   */
                     Float  *sx    /* (i): Data array   */
                     )
{
  Short     k;
  Short     exp;
  Float  L_Max;
  Float  L_Abs;

  L_Max = abs_f( sx[0] );
  for ( k = 1; k < n; k++ )
  {
    L_Abs = abs_f( sx[k] );
    L_Max = f_max( L_Max, L_Abs );
  }
  exp = norm_l( roundFto32(L_Max) );

  if(L_Max == 0)
  {
      exp = 31; 
  }
  return exp;
}
/*************************************************************************
* sDoRFFTx
*
* Do 160-points real FFT
**************************************************************************/
void sDoRFFTx(Float x[], Short *x_q)
{   
    Short i;
    Short dataNo,groupNo;
    Float ReIm2[160],*Re, *Im;
    Float *pRe,*pIm;
    Float *pRe0,*pIm0;
    Float *pLRe,*pLIm;
    Float s_Re[80], s_Im[80], *psRe, *psIm;
	Short QVal; 
    Float *ptrRe, *ptrIm;
    Float *ptr_x;
    Short Qfft16, Qfft5, Qfft51;
    Float ReIm[5*32], *ptrReIm;
    Short *ptr_twiddleRe, *ptr_twiddleIm;
	Float pow_tmp;

    *x_q  = Exp16ArrayF(160,x);
    Re    = ReIm2;
    Im    = ReIm2+80;
    QVal  = (*x_q - 1);
    ptr_x = x;
    ptrRe = s_Re;
    ptrIm = s_Im;
	pow_tmp = powT[60 + QVal];
    for (dataNo=0; dataNo<5; dataNo++)
    {   
        psRe = ptrRe++;
        psIm = ptrIm++;
        for (groupNo=0; groupNo<16; groupNo++)
        { 
            *psRe = *ptr_x++ * pow_tmp;
            *psIm = *ptr_x++ * pow_tmp;

            psRe += 5;
            psIm += 5;
        }
    }

    pRe  = Re ;
    pIm  = Im ;
    psRe = s_Re;
    psIm = s_Im;
    for (groupNo=0; groupNo<16; groupNo++)
    {  
		fft_5_format_2(pRe, pIm, psRe, psIm, 0.0001220703125f);

        pRe += 5;
        pIm += 5;
        psRe += 5;
        psIm += 5;
    }
    Qfft5  = Exp32ArrayF(160,ReIm2);
    Qfft5 --;
    Qfft51 =Qfft5 - 1;

    ptrReIm = ReIm;
    pRe0 = ptrReIm;
    pIm0 = ptrReIm+16;
    pRe  = Re ;
    pIm  = Im ;
    for(i=0; i<16; i++)
    {
        *pRe0++ = *pRe;
        *pIm0++ = *pIm;
        pRe += 5;
        pIm += 5;
    }

    fft_16x_format_2(ptrReIm, Qfft5);
    QVal = Qfft51 - 3;
    ptrReIm += 32;
    pRe0 = Re + 1;
    pIm0 = Im + 1;

    ptr_twiddleRe = twiddleRe;
    ptr_twiddleIm = twiddleIm;

    for (dataNo=1; dataNo<5; dataNo++)
    {   
        pRe = pRe0++;
        pIm = pIm0++;
        pLRe = ptrReIm;
        pLIm = ptrReIm+16;
        *pLRe++ = *pRe;
        *pLIm++ = *pIm;

        twiddleReIm(pLRe, pLIm, pRe, pIm, ptr_twiddleRe+1, ptr_twiddleIm+1,
                    Qfft5, Qfft51);
        ptr_twiddleRe += 16;
        ptr_twiddleIm += 16;
        fft_16x_format_2(ptrReIm, Qfft5);
        ptrReIm += 32;
    }

    Qfft16 = Exp32ArrayF(160,ReIm);
    Qfft16 = Qfft16 - 2;

    *x_q = (*x_q) + Qfft16;

    endRfft(ReIm, x, Qfft16);
    return;
}

/*************************************************************************
* twiddleReIm
*
* Twiddle factor calculation for mix-factor fft
**************************************************************************/
static void twiddleReIm(Float *pLRe, Float *pLIm, Float *pRe, Float *pIm, 
                        Short *ptr_twiddleRe, Short *ptr_twiddleIm,
                        Short Qfft5, Short Qfft51)
{
    Float tmp, tmp1;
    Float L_tmp, L_tmp1;
    Short blockNo;

	Float pow_tmp1 = Pow(2.0f, Qfft5 - 16.0f);
	Float pow_tmp2 = Pow(0.5f, (Float)Qfft51);
    for(blockNo=1;blockNo<16;blockNo++)
    {   
        pRe += 5;
        pIm += 5;

        tmp  = (*pRe) * pow_tmp1;
        tmp1 = (*pIm) * pow_tmp1;

        L_tmp   = tmp * (*ptr_twiddleRe);
        L_tmp   = (L_tmp - tmp1 * (*ptr_twiddleIm) );

		L_tmp   = L_tmp * pow_tmp2;

        *pLRe++ = L_tmp;

        L_tmp1  = tmp1 * (*ptr_twiddleRe);

        L_tmp1  = (L_tmp1 + tmp * (*ptr_twiddleIm));

        L_tmp1  = L_tmp1 * pow_tmp2;

        *pLIm++ = L_tmp1;
        ptr_twiddleRe++;
        ptr_twiddleIm++;
    }

    return;
}

/*************************************************************************
* endRfft
* subroutine called at the end of sDoRFFTx
* to compute the real and imaginary part of 80 FFT coefficients
* (by groups of 8 coefficients)
**************************************************************************/
static void endRfft(Float *ReIm, Float *x, Short Qfft16)
{
    Short dataNo;
    Float *pRe0,*pIm0, *pRef,*pImf;
    Float *ptr0, *ptr0f, *ptr1, *ptr1f;
    Float s_sRe, s_aIm;
    Short *ptr_cos, *ptr_sin;
    Float *ptrReIm, *ptrReImf;
    Float L_temp0, L_temp1, La, Ls, L_temp;
    Short Qfft16_1;

	Float pow_tmp1 = Pow(2.0f, Qfft16 - 16.0f);
	Float pow_tmp2;
	Float pow_tmp3;

    Qfft16_1 = Qfft16 - 1;
	pow_tmp2 = Pow(2.0f, (Float)-Qfft16_1);
	pow_tmp3 = Pow(2.0f, Qfft16_1 - 16.0f);

    ptr0  = x;
    ptr0f = ptr0 +80;
    ptr1  = ptr0f+1;
    ptr1f = ptr1+80;

    /* data0 */
    ptrReIm = ReIm; 
    pRe0 = ptrReIm; 
    pIm0 = ptrReIm+16;

    L_temp0 = (Float)(*pRe0) + *pIm0;
    L_temp1 = (Float)(*pRe0) - *pIm0;

	*ptr0  = L_temp0 * pow_tmp1;
    *ptr0f = L_temp1 * pow_tmp1;

    pRe0++; 
    pIm0++;
    *ptr1 = *ptr1f = 0;

    ptr_cos = cosw;
    ptr_sin = sinw;
    subEndRfft(ptrReIm+1, ptrReIm+31, ptr0+5, ptr0f-5, Qfft16, Qfft16_1, ptr_cos+5, ptr_sin+5, 7);
    pRe0 += 7;
    pIm0 = pRe0 + 16;
    pImf = ReIm + 24;
    pRef = pImf - 16;

    ptr_cos = cosw + 40;
    ptr_sin = sinw + 40;

    La = (*pRe0) + *pRef;
    Ls = (*pIm0) - *pImf;

    s_sRe    = (*pRe0 - *pRef) * pow_tmp1;
    s_aIm    = (*pIm0 + *pImf) * pow_tmp1;

    L_temp   = (*ptr_sin) * s_sRe;
    L_temp   = L_temp * pow_tmp2;
    L_temp0  = La - L_temp;

	ptr0[40] = L_temp0 * pow_tmp3;

    L_temp   = (*ptr_sin) * s_aIm;
    L_temp   = L_temp * pow_tmp2;
    L_temp0  = Ls - L_temp;

	ptr0[121] = L_temp0 * pow_tmp3;

    /* datax */
    ptrReImf= ReIm+159;
    ptr_cos = cosw;
    ptr_sin = sinw;
    for (dataNo=1; dataNo<5; dataNo++)
    {
        ptrReIm += 32; 
        ptr0++;
        ptr0f--;
        ptr_cos++;
        ptr_sin++;
        subEndRfft(ptrReIm, ptrReImf, ptr0, ptr0f, Qfft16, Qfft16_1, ptr_cos, ptr_sin, 8);
        ptrReImf -= 32;
    }

    return;
}

/*************************************************************************
* subEndRfft
* subroutine called  by endRfft
* to compute the real and imaginary part of n (=7 or 8) FFT coefficients
* with windowing
**************************************************************************/
static void subEndRfft(Float *ptrReIm, Float *ptrReImf, Float *ptr0, Float *ptr0f, 
                       Short Qfft16, Short Qfft16_1, Short *ptr_cos, Short *ptr_sin, 
                       Short n)
{
    Float *ptr1, *ptr1f;
    Float *pRe0, *pIm0;
    Float *pRef, *pImf;
    Short i;
    Float L_temp0, L_temp1, La, Ls, L_temp;
    Float s_sRe, s_aIm;

	Float pow_tmp1 = Pow(2.0f, Qfft16 - 16.0f);
	Float pow_tmp2 = Pow(2.0f, (Float)-Qfft16_1);
	Float pow_tmp3 = Pow(2.0f, Qfft16_1 - 16.0f);

    ptr1  = ptr0 +81;
    ptr1f = ptr0f +81;

    pRe0 = ptrReIm; 
    pIm0 = pRe0 +16;
    pImf = ptrReImf;
    pRef = pImf -16;

    for(i=0; i<n; i++) {
        La = (*pRe0) + *pRef;
        Ls = (*pIm0) - *pImf;

        s_sRe = (*pRe0 - *pRef) * pow_tmp1;
        s_aIm = (*pIm0 + *pImf) * pow_tmp1;

        L_temp  = (*ptr_cos) * s_aIm;
        L_temp  = L_temp - (*ptr_sin) * s_sRe;
        L_temp  = L_temp * pow_tmp2;
        L_temp0 = La + L_temp;
        *ptr0   = L_temp0 * pow_tmp3;
        L_temp1 = La - L_temp;
        *ptr0f  = L_temp1 * pow_tmp3;

        L_temp  = (*ptr_sin) * s_aIm;
        L_temp  = L_temp + (*ptr_cos) * s_sRe;

        L_temp  = -L_temp * pow_tmp2;

        L_temp0 = L_temp + Ls;
        *ptr1   = L_temp0 * pow_tmp3;
        L_temp1 = L_temp - Ls;
        *ptr1f  = L_temp1 * pow_tmp3;

        ptr_cos += 5;
        ptr_sin += 5;

        pRe0++; pRef--;
        pIm0++; pImf--;

        ptr0  += 5;
        ptr0f -= 5;
        ptr1  += 5;
        ptr1f -= 5;
    }

    return;
}

/*************************************************************************
* fft_5_format_2
* subroutine called by sDoRFFTx
* Do 5-points complex FFT
**************************************************************************/
static void fft_5_format_2(Float *pRe, Float *pIm, Float *psRe, Float *psIm, Float pow_QVal)
{   
    Float   ar14, sr14, ai14, si14, ar32, sr32, ai32, si32 ;

    ar14 = (psRe[1] + psRe[4]);
    sr14 = (psRe[1] - psRe[4]);
    ar32 = (psRe[3] + psRe[2]);
    sr32 = (psRe[3] - psRe[2]);

    ai14 = (psIm[1] + psIm[4]);
    si14 = (psIm[1] - psIm[4]);
    ai32 = (psIm[3] + psIm[2]);
    si32 = (psIm[3] - psIm[2]);

    calc_fft5R(psRe[0], pRe, ar14, si14, ar32, si32, pow_QVal);
    calc_fft5I(psIm[0], pIm, ai14, sr14, ai32, sr32, pow_QVal);

    return;
}

/*************************************************************************
* calc_R0: 
* subroutine called by calc_fft5R & calc_fft5I
* Compute real/imaginary part of a point in 5-complex FTT  : ps0 + ar14 + ar32
**************************************************************************/
static Float calc_R0(Float ps0, Float *pL, Float ar14, Float ar32, Float pow_QVal)
{
    Float L_temp0, L_temp;

    L_temp0 = (ps0 * 16384.0f);
    L_temp  = L_temp0 + (ar14 + ar32) * 16384.0f;

	pL[0]   = L_temp * pow_QVal;

    return L_temp0;
}

/*************************************************************************
* calcR4
* subroutine called by calc_RI4
* Compute real part of a point in 5-complex FTT : L_temp+ arx *CFFT5_R1 +ary *CFFT5_R2
**************************************************************************/
static Float calcR4 (Float L_temp0, Float arx, Float ary)
{
    return (L_temp0 + arx * CFFT5_R1 + ary * CFFT5_R2);
}

/*************************************************************************
* calcI4
* subroutine called by calc_RI4
* Compute imaginary  part of a point in 5-complex FTT : six* cx +siy * cy;
**************************************************************************/
static Float calcI4 (const Short cx, const Short cy, Float six, Float siy)
{
    return six * cx + siy * cy;
}

/*************************************************************************
* calcRI4
* subroutine called by calc_fft5R & calc_fft5I
* Compute 4 real (or imaginary parts) of 4 points in 5-complex FTT : 
* Compute: (L_temp0+ arx *CFFT5_R1 +ary *CFFT5_R2) +/- (six* cx +siy * cy)
**************************************************************************/
static void calcRI4 (Float L_temp0, Float arx, Float ary, const Short cx, 
                     const Float cy, Short six, Float siy, Float *L_a, 
                     Float *L_s, Float pow_QVal)
{
    Float L_tempR, L_tempI, L_temp;

    L_tempR = calcR4 (L_temp0, arx, ary);
    L_tempI = calcI4 (cx, six, cy, siy);
    L_temp  = (L_tempR - L_tempI); 

    *L_s    = L_temp * pow_QVal;
    L_temp  = (L_tempR + L_tempI); 
    *L_a    = L_temp * pow_QVal;

    return;
}

/*************************************************************************
* calc_fft5R
* subroutine called by ffft_5_format_2
* Calculate the real parts of 5 points of 5-points complex FFT
**************************************************************************/
static void calc_fft5R(Float ps0, Float *pL, Float ar14, Float si14, 
                       Float ar32, Float si32, Float pow_QVal)
{
    Float L_temp0;

    L_temp0 = calc_R0(ps0, pL, ar14, ar32, pow_QVal);
    calcRI4(L_temp0, ar14, ar32,CFFT5_I1, si14, -CFFT5_I2, si32, &pL[4], 
            &pL[1], pow_QVal);
    calcRI4(L_temp0, ar32, ar14, CFFT5_I3, si14, CFFT5_I1, si32, &pL[3], 
            &pL[2], pow_QVal);

    return;
}

/*************************************************************************
* calc_fft5I
* subroutine called by ffft_5_format_2
* Calculate the imaginary part of 5-points complex FFT
**************************************************************************/
static void calc_fft5I(Float ps0, Float *pL, Float ar14, Float si14, 
                       Float ar32, Float si32, Float pow_QVal)
{
    Float L_temp0;

    L_temp0 = calc_R0(ps0, pL, ar14, ar32, pow_QVal);
    calcRI4(L_temp0, ar14, ar32,CFFT5_I1, si14, -CFFT5_I2, si32, &pL[1], &pL[4], pow_QVal);
    calcRI4(L_temp0, ar32, ar14, CFFT5_I3, si14, CFFT5_I1, si32, &pL[2], &pL[3], pow_QVal);

    return;
}

/*************************************************************************
* fft_16x_format_2
* subroutine called by sDoRFFTx
* Do 16-points complex FFT for 80-points complex FFT
**************************************************************************/
static void fft_16x_format_2(Float *ReIm, Short QVal)
{
    Float *Re0, *Im0;

	Float s_sumReIm[2*16], *s_sumRe, *s_sumIm;
    Float s_sumReIm4[2*14], *s_sumRe4, *s_sumIm4;

    Short shift;

    QVal= QVal - 2;
    Re0 = ReIm;
    Im0 = ReIm+16;

    s_sumRe = s_sumReIm;
    s_sumIm = s_sumReIm+16;
    s_calcSum2(Re0, s_sumRe, QVal);
    s_calcSum2(Im0, s_sumIm, QVal);

    s_sumRe4 = s_sumReIm4;
    s_sumIm4 = s_sumReIm4+14;
    s_calcSum4RI(s_sumRe, s_sumRe4);
    s_calcSum4RI(s_sumIm, s_sumIm4);

    shift = QVal - 1;
    s_fft16R(s_sumReIm4, s_sumReIm, Re0, shift);
    s_fft16I(s_sumReIm4, s_sumReIm, Im0, shift);

    return;
}

/*************************************************************************
* fft_16x_format_2i
* subroutine called by fixDORiFFTx
* Do 16-points complex FFT for 80-points complex iFFT
**************************************************************************/
static void fft_16x_format_2i(Float *ReIm, Short QVal, Float *x, Short x_q)
{
    Float *Re0, *Im0;

	Float s_sumReIm[2*16], *s_sumRe, *s_sumIm;
    Float s_sumReIm4[2*14], *s_sumRe4, *s_sumIm4;

    Short shift;

    QVal= QVal - 2;
    Re0 = ReIm;
    Im0 = ReIm+16;

    s_sumRe = s_sumReIm;
    s_sumIm = s_sumReIm+16;
    s_calcSum2(Re0, s_sumRe, QVal);
    s_calcSum2(Im0, s_sumIm, QVal);

    s_sumRe4 = s_sumReIm4;
    s_sumIm4 = s_sumReIm4+14;
    s_calcSum4RI(s_sumRe, s_sumRe4);
    s_calcSum4RI(s_sumIm, s_sumIm4);

    shift = ((QVal + x_q) - 11);
    s_fft16Ri(s_sumReIm4, s_sumReIm, shift, x);
    s_fft16Ii(s_sumReIm4, s_sumReIm, shift, x+1);

    return;
}

/*************************************************************************
* s_calcSum2
*
* subroutine called by fft_16x_format_2 and fft_16x_format_2i
* compute and store 8 sums and differences of 2 points distants from 8 
* (e.g. Re[0]+/- Re[8],  Re[1]+/- Re[9],  ...
**************************************************************************/
static void s_calcSum2(Float *Re, Float *sumRe, Short QVal)
{
    Float *ptrS;
    Float *ptr0, *ptr1, L_tmp;
    Short i;
	Float pow_tmp = powT[44 + QVal];

    ptr0 = Re;
    ptr1 = Re + 8;
    ptrS = sumRe;

    for(i=0; i<8; i++)
    {
        L_tmp   = (*ptr0 + *ptr1);
        *ptrS++ = L_tmp * pow_tmp;
        L_tmp   = (*ptr0 - *ptr1); 
        *ptrS++ = L_tmp * pow_tmp;

        ptr0 += 1;
        ptr1 += 1;
    }

    return;
}

/*************************************************************************
* s_calcSum4RI
*
* subroutine called by fft_16x_format_2 and fft_16x_format_2i
* compute and store 4 sums and differences of 4 points 
* from the sums/differences of 2 points computed by s_calcSum2
**************************************************************************/
static void s_calcSum4RI(Float *ReIm, Float *sumReIm)
{
    Float *ptrS;
    Float *ptr0, *ptr1;
    Short i;

    ptr0 = ReIm;
    ptr1 = ptr0 + 8;
    ptrS = sumReIm;

    /* r0, r8, r4, r12 */
    *ptrS++ = (*ptr0 - *ptr1);
    *ptrS++ = (*ptr0 + *ptr1);
    ptr0 += 2;
    ptr1 += 6;

    /* r1, r9, r7, r15 */
    for(i=0; i<3; i++)
    {
        *ptrS   = (*ptr0 - *ptr1);
        ptrS[3] = (*ptr0 + *ptr1);
        ptrS++;
        ptr0++;
        ptr1++;
        *ptrS++ = (*ptr0 + *ptr1);
        *ptrS++ = (*ptr0 - *ptr1);
        ptr0++;
        ptr1 -= 3;
        ptrS++;
    }

    return;
}

/*************************************************************************
* s_fft16R
*  subroutine called by fft_16x_format_2 
* Calculate the real part of 16-points complex FFT for 80-points complex FFT
**************************************************************************/
static void s_fft16R(Float *sumReIm4, Float *sumReIm, Float *Re, Short shift)
{
    Float L_temp0, L_temp0b, L_temp1, L_temp2, L_temp3, L_temp2b, L_temp3b, L_temp4;

    Float *sumRe, *sumIm;
    Float *sumRe4, *sumIm4;
	Float pow_tmp, pow_tmp_32768;

	pow_tmp = powT[60 - shift];

	pow_tmp_32768 = powT[75 - shift];

    sumRe = sumReIm;
    sumIm = sumReIm+16;

    sumRe4 = sumReIm4;
    sumIm4 = sumReIm4+14;

    /* D0 + D2 */
    L_temp0 = (sumRe4[1] + sumRe4[9]) * pow_tmp_32768;
    /* D1 + D3*/
    L_temp1 = (sumRe4[5] + sumRe4[13]) * pow_tmp_32768;

    Re[0]   = L_temp0 + L_temp1; 
    Re[8]   = L_temp0 - L_temp1; 

    /* D0 - D2 */
    L_temp0 = (sumRe4[1] - sumRe4[9]) * pow_tmp_32768;
    /* A'1 - A'3 */
    L_temp2 = (sumIm4[2] - sumIm4[10]) * pow_tmp_32768;

    Re[4]   = L_temp0 + L_temp2; 
    Re[12]  = L_temp0 - L_temp2; 

    /* D1 - D3 */
    L_temp0 = axplusby0 (sumRe4[5], sumRe4[13], C_fx81, -C_fx81);
    /* A'1 + A'3 */
    L_temp1 = axplusby0 (sumIm4[2], sumIm4[10], C_fx81, C_fx81); 

    /*  c81 * (D1 - D3 + (A'1 + A'3)) */
    L_temp2 = (L_temp0 + L_temp1) * pow_tmp;
    /*  c81 * (D1 - D3 - (A'1 + A'3)) */
    L_temp2b = (L_temp0 - L_temp1) * pow_tmp;  

    /*  A0 +A'2*/
    L_temp3 = (sumRe4[0] + sumIm4[6]) * pow_tmp_32768;
    /*  A0 -A'2*/
    L_temp3b = (sumRe4[0] - sumIm4[6]) * pow_tmp_32768;

    Re[2]   = L_temp3  + L_temp2; 
    Re[14]  = L_temp3b + L_temp2b; 
    Re[6]   = L_temp3b - L_temp2b; 
    Re[10]  = L_temp3  - L_temp2; 

    /* c81* (C2 -B'2)*/
    L_temp0 = axplusby0(sumRe4[8],  sumIm4[7], C_fx81, -C_fx81 );

    /* c162* (C1 - B'3)*/
    /* c165* (C3 - B'1)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[4], sumIm4[11], C_fx162, -C_fx162,
                           sumRe4[12], sumIm4[3], -C_fx165, C_fx165);

    L_temp1 = (sumRe[1] - sumIm[9]) * 32768.0f;

    L_temp4 = (L_temp1 - L_temp0);

    Re[3]   = (L_temp4 + L_temp3) * pow_tmp; 
    Re[11]  = (L_temp4 - L_temp3) * pow_tmp; 

    /* c81* (C2 +B'2)*/
    L_temp0b = axplusby0(sumRe4[8], sumIm4[7], C_fx81, C_fx81);

    /* c162* (C1 + B'3)*/
    /* c165* (C3 + B'1)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[4], sumIm4[11] , C_fx162, C_fx162,
                           sumRe4[12], sumIm4[3], -C_fx165, -C_fx165);

	L_temp2 = (sumRe[1] + sumIm[9]) * 32768.0f;

    L_temp4 = (L_temp2 - L_temp0b);

    Re[13]  = (L_temp4 + L_temp3) * pow_tmp; 
    Re[5]   = (L_temp4 - L_temp3) * pow_tmp; 

    /* c162* (C3 + B'1)*/
    /* c165* (C1 + B'3)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[12], sumIm4[3], C_fx162, C_fx162,
                           sumRe4[4], sumIm4[11], C_fx165, C_fx165);

    L_temp4 = (L_temp2 + L_temp0b);

    Re[1]   = (L_temp4 + L_temp3) * pow_tmp;
    Re[9]   = (L_temp4 - L_temp3) * pow_tmp;

    /* c162* (C3-B'1)*/
    /* c165* (C1 - B'3)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[12], sumIm4[3], C_fx162, -C_fx162,
                           sumRe4[4], sumIm4[11], C_fx165, -C_fx165);

    L_temp4 = (L_temp1 + L_temp0);
    L_temp3 = L_temp3 * pow_tmp;
    L_temp4 = L_temp4 * pow_tmp;

    Re[7]   = L_temp4 - L_temp3; 
    Re[15]  = L_temp4 + L_temp3; 

    return;
}

/*************************************************************************
* s_fft16I
*  subroutine called by fft_16x_format_2 
* Calculate the imaginary part of 16-points complex FFT for 80-points complex FFT
**************************************************************************/
static void s_fft16I(Float *sumReIm4, Float *sumReIm, Float *Im, Short shift)
{
    Float L_temp0, L_temp1, L_temp2, L_temp3, L_temp4;

    Float L_tempb, L_temp0b, L_temp2b, L_temp3b;
    Float *sumRe, *sumIm;
    Float *sumRe4, *sumIm4;
	Float pow_tmp, pow_tmp1_16384;

	pow_tmp = powT[60 - shift];
	pow_tmp1_16384 = powT[75 - shift];

    sumRe  = sumReIm;
    sumIm  = sumReIm+16;
    sumRe4 = sumReIm4;
    sumIm4 = sumReIm4+14;

    /* D'0 + D'2 */
    L_temp0 = (sumIm4[1] + sumIm4[9]) * pow_tmp1_16384;

    /* D1 + D3*/
    L_temp1 = (sumIm4[5] + sumIm4[13]) * pow_tmp1_16384;

    Im[0]   = L_temp0 + L_temp1; 
    Im[8]   = L_temp0 - L_temp1; 

    /* D'0 - D'2 */
    L_temp0 = (sumIm4[1] - sumIm4[9]) * pow_tmp1_16384;

    /* A1 - A3 */
    L_temp2 = (sumRe4[2] - sumRe4[10]) * pow_tmp1_16384;

    Im[4]   = L_temp0 - L_temp2; 
    Im[12]  = L_temp0 + L_temp2; 

    /* D'1 - D'3 */
	L_temp0 = axplusby0(sumIm4[5], sumIm4[13], C_fx81, -C_fx81);

    /* A1 + A3 */
    L_temp1 = axplusby0(sumRe4[2], sumRe4[10], C_fx81, C_fx81); 

    /*  c81 * (D'1 - D'3 + (A1 + A3)) */
    L_temp2 = (L_temp0 + L_temp1) * pow_tmp;
    /*  c81 * (D'1 - D'3 - (A1 + A3)) */
    L_temp2b = (L_temp0 - L_temp1) * pow_tmp;

    /*  A'0 +A2*/
    L_temp3 = (sumIm4[0] + sumRe4[6]) * 32768.0f * pow_tmp;
    /*  A'0 -A2*/
    L_temp3b = (sumIm4[0] - sumRe4[6]) * 32768.0f * pow_tmp;  

    Im[14]  = L_temp3 + L_temp2; 
    Im[2]   = L_temp3b + L_temp2b; 
    Im[10]  = L_temp3b - L_temp2b; 
    Im[6]   = L_temp3 - L_temp2; 

    /* c81* (C2 -B'2)*/
    L_temp0 = axplusby0(sumIm4[8], sumRe4[7], C_fx81, -C_fx81);
    /* c162* (C1 - B'3)*/
    /* c165* (C3 - B'1)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[4], sumRe4[11], C_fx162, -C_fx162,
                                 sumIm4[12], sumRe4[3], -C_fx165, C_fx165) * pow_tmp;

    L_temp1 = (sumIm[1] - sumRe[9]) * 32768.0f;

    L_temp4 = (L_temp1 - L_temp0) * pow_tmp;

    Im[13]  = L_temp4 + L_temp3; 
    Im[5]   = L_temp4 - L_temp3; 

    /* c81* (C2 +B'2)*/
    L_temp0b = axplusby0(sumIm4[8], sumRe4[7], C_fx81, C_fx81);

    /* c162* (C1 + B'3)*/
    /* c165* (C3 + B'1)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[4], sumRe4[11], C_fx162, C_fx162,
                                 sumIm4[12], sumRe4[3], -C_fx165, -C_fx165) * pow_tmp;

    L_tempb = (sumIm[1] + sumRe[9]) * 32768.0f;

    L_temp4 = (L_tempb - L_temp0b) * pow_tmp;

    Im[3]   = L_temp4 + L_temp3; 
    Im[11]  = L_temp4 - L_temp3; 

    /* c162* (C3 + B'1)*/
    /* c165* (C1 + B'3)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[12], sumRe4[3], C_fx162, C_fx162,
                           sumIm4[4], sumRe4[11], C_fx165 ,C_fx165);

    L_temp4 = (L_tempb + L_temp0b);
    L_temp3 = L_temp3 * pow_tmp;
    L_temp4 = L_temp4 * pow_tmp;

    Im[15]  = L_temp4 + L_temp3; 
    Im[7]   = L_temp4 - L_temp3; 

    /* c162* (C3-B'1)*/
    /* c165* (C1 - B'3)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[12], sumRe4[3], C_fx162,-C_fx162,
                           sumIm4[4], sumRe4[11], C_fx165, -C_fx165);

    L_temp4 = (L_temp1 + L_temp0);
    L_temp3 = (L_temp3 * pow_tmp);
    L_temp4 = (L_temp4 * pow_tmp);

    Im[9]   = L_temp4 - L_temp3; 
    Im[1]   = L_temp4 + L_temp3; 

    return;
}

/*************************************************************************
* s_fft16Ri
*  subroutine called by fft_16x_format_2i 
* Calculate the real part of 16-points complex FFT for 80-points complex iFFT
**************************************************************************/
static void s_fft16Ri(Float *sumReIm4, Float *sumReIm, Short shift, Float *x)
{
    Float L_temp0, L_temp0b, L_temp1, L_temp2, L_temp3, L_temp2b, L_temp3b, L_temp4;

    Float *sumRe, *sumIm;
    Float *sumRe4, *sumIm4;

	Float pow_tmp_G_FX_pow_tmp2_16384, pow_tmp1_G_FX_pow_tmp2;

	pow_tmp_G_FX_pow_tmp2_16384 = powT[44 - shift] * G_FX;
	pow_tmp1_G_FX_pow_tmp2 = powT[29 - shift] * G_FX;

    sumRe = sumReIm;
    sumIm = sumReIm+16;

    sumRe4 = sumReIm4;
    sumIm4 = sumReIm4+14;

    /* D0 + D2 */
    L_temp0 = sumRe4[1] + sumRe4[9];
    /* D1 + D3*/
    L_temp1 = sumRe4[5] + sumRe4[13];

    x[0]      = (L_temp0 + L_temp1)* pow_tmp_G_FX_pow_tmp2_16384;

    x[80]  = (L_temp0 - L_temp1)* pow_tmp_G_FX_pow_tmp2_16384; 

    /* D0 - D2 */
    L_temp0 = sumRe4[1] - sumRe4[9];
    /* A'1 - A'3 */
    L_temp2 = sumIm4[2] - sumIm4[10];

    x[40]  = (L_temp0 + L_temp2) * pow_tmp_G_FX_pow_tmp2_16384;  
    x[120] = (L_temp0 - L_temp2) * pow_tmp_G_FX_pow_tmp2_16384;

    /* D1 - D3 */
    L_temp0 = axplusby0(sumRe4[5], sumRe4[13], C_fx81, -C_fx81);
    /* A'1 + A'3 */
    L_temp1 = axplusby0(sumIm4[2], sumIm4[10], C_fx81, C_fx81); 

    /*  c81 * (D1 - D3 + (A'1 + A'3)) */
    L_temp2 = (L_temp0 + L_temp1);  
    /*  c81 * (D1 - D3 - (A'1 + A'3)) */
    L_temp2b = (L_temp0 - L_temp1);  

    /*  A0 +A'2*/
    L_temp3 = (sumRe4[0] + sumIm4[6]) * 32768.0f;
    /*  A0 -A'2*/
    L_temp3b = (sumRe4[0] - sumIm4[6]) * 32768.0f;

    x[20]  = (L_temp3 + L_temp2) * pow_tmp1_G_FX_pow_tmp2; 
    x[140] = (L_temp3b + L_temp2b) * pow_tmp1_G_FX_pow_tmp2;
    x[60]  = (L_temp3b - L_temp2b) * pow_tmp1_G_FX_pow_tmp2;
    x[100] = (L_temp3 - L_temp2) * pow_tmp1_G_FX_pow_tmp2;

    /* c81* (C2 -B'2)*/
    L_temp0 = axplusby0(sumRe4[8],  sumIm4[7], C_fx81, -C_fx81 );
    /* c162* (C1 - B'3)*/
    /* c165* (C3 - B'1)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[4], sumIm4[11], C_fx162, -C_fx162,
                           sumRe4[12], sumIm4[3], -C_fx165, C_fx165);

    L_temp1 = (sumRe[1] - sumIm[9]) * 32768.0f;

    L_temp4 = (L_temp1 - L_temp0);

    x[3*2*5]  = (L_temp4 + L_temp3) * pow_tmp1_G_FX_pow_tmp2; 
    x[11*2*5] = (L_temp4 - L_temp3) * pow_tmp1_G_FX_pow_tmp2; 

    /* c81* (C2 +B'2)*/
    L_temp0b = axplusby0(sumRe4[8], sumIm4[7], C_fx81, C_fx81);
    /* c162* (C1 + B'3)*/
    /* c165* (C3 + B'1)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[4], sumIm4[11] , C_fx162, C_fx162,
                           sumRe4[12], sumIm4[3], -C_fx165, -C_fx165);

    L_temp2 = (sumRe[1] + sumIm[9]) * 32768.0f;

    L_temp4 = (L_temp2 - L_temp0b);

    x[130] = (L_temp4 + L_temp3) * pow_tmp1_G_FX_pow_tmp2; 
    x[50]  = (L_temp4 - L_temp3) * pow_tmp1_G_FX_pow_tmp2;  

    /* c162* (C3 + B'1)*/
    /* c165* (C1 + B'3)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[12], sumIm4[3], C_fx162, C_fx162,
                           sumRe4[4], sumIm4[11], C_fx165, C_fx165);

    L_temp4 = (L_temp2 + L_temp0b);

    x[10]  = (L_temp4 + L_temp3) * pow_tmp1_G_FX_pow_tmp2; 
    x[90]  = (L_temp4 - L_temp3) * pow_tmp1_G_FX_pow_tmp2;

    /* c162* (C3-B'1)*/
    /* c165* (C1 - B'3)*/
    L_temp3 = axpmy_bzpmt0(sumRe4[12], sumIm4[3], C_fx162, -C_fx162,
                           sumRe4[4], sumIm4[11], C_fx165, -C_fx165);

    L_temp4 = (L_temp1 + L_temp0);

    x[70]  = (L_temp4 - L_temp3) * pow_tmp1_G_FX_pow_tmp2;
    x[150] = (L_temp4 + L_temp3) * pow_tmp1_G_FX_pow_tmp2;

    return;
}

/*************************************************************************
* s_fft16Ii
*  subroutine called by fft_16x_format_2i 
* Calculate the imaginary part of 16-points complex FFT for 80-points complex iFFT
**************************************************************************/
static void s_fft16Ii(Float *sumReIm4, Float *sumReIm, Short shift, Float *x)
{
    Float L_temp0, L_temp1, L_temp2, L_temp3, L_temp4;

    Float L_tempb, L_temp0b, L_temp2b, L_temp3b;
    Float *sumRe, *sumIm;
    Float *sumRe4, *sumIm4;

	Float pow_tmp1_NG_FX_pow_tmp2, pow_tmp_NG_FX_pow_tmp2_16384;

	pow_tmp_NG_FX_pow_tmp2_16384 = powT[44 - shift] * NG_FX;
	pow_tmp1_NG_FX_pow_tmp2 = powT[29 - shift] * NG_FX;

    sumRe = sumReIm;
    sumIm = sumReIm+16;

    sumRe4 = sumReIm4;
    sumIm4 = sumReIm4+14;

    /* D'0 + D'2 */
    L_temp0 = sumIm4[1] + sumIm4[9];

    /* D1 + D3*/
    L_temp1 = sumIm4[5] + sumIm4[13];

    x[0]  = (L_temp0 + L_temp1)* pow_tmp_NG_FX_pow_tmp2_16384; 
    x[80]  = (L_temp0 - L_temp1)* pow_tmp_NG_FX_pow_tmp2_16384; 

    /* D'0 - D'2 */
    L_temp0 = sumIm4[1] - sumIm4[9];
    /* A1 - A3 */
    L_temp2 = sumRe4[2] - sumRe4[10];

    x[40]  = (L_temp0 - L_temp2)* pow_tmp_NG_FX_pow_tmp2_16384;
    x[120] = (L_temp0 + L_temp2)* pow_tmp_NG_FX_pow_tmp2_16384;

    /* D'1 - D'3 */
    L_temp0 = axplusby0(sumIm4[5], sumIm4[13], C_fx81, -C_fx81);
    /* A1 + A3 */
    L_temp1 = axplusby0(sumRe4[2], sumRe4[10], C_fx81, C_fx81); 

    /*  c81 * (D'1 - D'3 + (A1 + A3)) */
    L_temp2 = (L_temp0 + L_temp1);  
    /*  c81 * (D'1 - D'3 - (A1 + A3)) */
    L_temp2b = (L_temp0 - L_temp1);  

    /*  A'0 +A2*/
    L_temp3 = (sumIm4[0] + sumRe4[6]) * 32768.0f;
    /*  A'0 -A2*/
    L_temp3b = (sumIm4[0] - sumRe4[6]) * 32768.0f;

    x[140] = (L_temp3 + L_temp2)* pow_tmp1_NG_FX_pow_tmp2; 
    x[20]  = (L_temp3b + L_temp2b)* pow_tmp1_NG_FX_pow_tmp2; 
    x[100] = (L_temp3b - L_temp2b)* pow_tmp1_NG_FX_pow_tmp2; 
    x[60]  = (L_temp3 - L_temp2)* pow_tmp1_NG_FX_pow_tmp2; 

    /* c81* (C2 -B'2)*/
    L_temp0 = axplusby0(sumIm4[8], sumRe4[7], C_fx81, -C_fx81);
    /* c162* (C1 - B'3)*/
    /* c165* (C3 - B'1)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[4], sumRe4[11], C_fx162, -C_fx162,
                           sumIm4[12], sumRe4[3], -C_fx165, C_fx165);

    L_temp1 = (sumIm[1] - sumRe[9]) * 32768.0f;
    L_temp4 = (L_temp1 - L_temp0);

    x[130] = (L_temp4 + L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 
    x[50]  = (L_temp4 - L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 

    /* c81* (C2 +B'2)*/
    L_temp0b = axplusby0(sumIm4[8], sumRe4[7], C_fx81, C_fx81);
    /* c162* (C1 + B'3)*/
    /* c165* (C3 + B'1)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[4], sumRe4[11], C_fx162, C_fx162,
                           sumIm4[12], sumRe4[3], -C_fx165, -C_fx165);

    L_tempb = (sumIm[1] + sumRe[9]) * 32768.0f;
    L_temp4 = (L_tempb - L_temp0b);

    x[3*2*5]  = (L_temp4 + L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 
    x[11*2*5] = (L_temp4 - L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 

    /* c162* (C3 + B'1)*/
    /* c165* (C1 + B'3)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[12], sumRe4[3], C_fx162, C_fx162,
                           sumIm4[4], sumRe4[11], C_fx165 ,C_fx165);

    L_temp4 = (L_tempb + L_temp0b);

    x[150] = (L_temp4 + L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 
    x[70]  = (L_temp4 - L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 

    /* c162* (C3-B'1)*/
    /* c165* (C1 - B'3)*/
    L_temp3 = axpmy_bzpmt0(sumIm4[12], sumRe4[3], C_fx162,-C_fx162,
                           sumIm4[4], sumRe4[11], C_fx165, -C_fx165);

    L_temp4 = (L_temp1 + L_temp0);

    x[90]  = (L_temp4 - L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 
    x[10]  = (L_temp4 + L_temp3)* pow_tmp1_NG_FX_pow_tmp2; 

    return;
}

/*************************************************************************
* axplusby0
* subroutine called by s_fft16R, s_fft16I, s_fft16Ri, s_fft16Ii
* calculate ca*x+ cb*y
**************************************************************************/
static Float axplusby0 (Float x, Float y, const Short ca, const Short cb)
{
    return(x * ca + y * cb);
}

/*************************************************************************
* axpmy_bzpmt0
* subroutine called by s_fft16R, s_fft16I, s_fft16Ri, s_fft16Ii
* calculate ca*x+ cay*y+cbz*z + cbt*t
**************************************************************************/
static Float axpmy_bzpmt0 (Float x, Float y, const Short cax, const Short cay,
                            Float z, Float t, const Short cbz, const Short cbt)
{
    return(x * cax + y * cay + z * cbz + t * cbt);
}

/*************************************************************************
* calc_RiFFTx
* subroutine called by sDoRiFFTx
* Calculate real and imaginary part of 80-point complex iFFT
**************************************************************************/
static void calc_RiFFTx(Float *x, Float *sRe, Float *sIm, Short norm_shift)
{
    Short dataNo, blockNo, QVal;
    Float *psRe, *psIm; 
    Float tmp, tmp1;

    Float *psRe0, *psIm0, *psRe0f, *psIm0f;
	Float *ptr0, *ptr0f;
    Float *psRef, *psImf; 
    Short *ptr_sinw_s1, *ptr_sinw_p1, *ptr_cosw;

    psRe0  = sRe;
    psIm0  = sIm;
    psRe0f = psRe0 + 79;
    psIm0f = psIm0 + 79;

    ptr0   = x;
    ptr0f  = x + 80;

    QVal   = (norm_shift - 1);

    tmp    = (*ptr0++ * powT[60 + QVal]);
    tmp1   = (*ptr0f-- * powT[60 + QVal]);

    *psRe0 = tmp + tmp1; 
    *psIm0 = tmp1 - tmp; 

    ptr_sinw_s1 = sinw_s1 + 1;
    ptr_sinw_p1 = sinw_p1 + 1;
    ptr_cosw    = cosw + 1;

    for (dataNo=1; dataNo<3; dataNo++)
    {   
        psRe  = psRe0++; 
        psIm  = psIm0++;
        psRef = psRe0f--;
        psImf = psIm0f--;

        for(blockNo=1;blockNo<16;blockNo++)
        {   
            psRe += 5;
            psIm += 5;
            calc_RiFFT_1_4(ptr0, ptr0f, norm_shift, *ptr_sinw_s1, *ptr_sinw_p1, 
                           *ptr_cosw, psRe, psRef, psIm, psImf);
            ptr0++; ptr0f--;
            psRef -= 5;
            psImf -= 5;
            ptr_sinw_s1++;
            ptr_sinw_p1++; 
            ptr_cosw++; 
        }
        calc_RiFFT_1_4(ptr0, ptr0f, norm_shift, *ptr_sinw_s1, *ptr_sinw_p1, 
                       *ptr_cosw, psRe0, psRef, psIm0, psImf);
        ptr0++;
        ptr0f--;
        ptr_sinw_s1++;
        ptr_sinw_p1++; 
        ptr_cosw++;
    }

    psRe  = psRe0++; 
    psIm  = psIm0++;
    psRef = psRe0f--;
    psImf = psIm0f--;
    for(blockNo=1;blockNo<8;blockNo++)
    {   
        psRe += 5;
        psIm += 5;
        calc_RiFFT_1_4(ptr0, ptr0f, norm_shift, *ptr_sinw_s1, *ptr_sinw_p1, 
                       *ptr_cosw, psRe, psRef, psIm, psImf);
        ptr0++;
        ptr0f--;
        psRef -= 5;
        psImf -= 5;
        ptr_sinw_s1++;
        ptr_sinw_p1++; 
        ptr_cosw++; 
    }

    calc_RiFFT_1_2(ptr0, ptr0f, norm_shift, *ptr_sinw_s1, *ptr_sinw_p1, 
                   *ptr_cosw, psRef, psImf);
    return;
}

/*************************************************************************
* calc_RiFFT_1_4
* subroutine called by calc_RiFFTx
* Calculate real and imaginary part of of 2 points in 80-point complex iFFT
**************************************************************************/
static void calc_RiFFT_1_4(Float *x0, Float *x0f, Short norm_shift, 
                           Short sinw_s1, Short sinw_p1, Short cosw, 
                           Float *Re, Float *Ref, Float *Im, Float *Imf)
{
    Float L_temp, L_temp1;
	Float pow_tmp = powT[44 + norm_shift];

    L_temp  = cosw * (x0[81] + x0f[81]);

    L_temp1 = L_temp + sinw_s1 * x0f[0];

    L_temp1 = (L_temp1 + 2.0f * sinw_p1 * x0[0]);
    *Ref    = L_temp1 * pow_tmp; 

    L_temp1 = sinw_s1 * x0[0];
    L_temp1 = L_temp1 + 2.0f * sinw_p1 * x0f[0];
    L_temp1 = L_temp1 - L_temp;
    *Re     = L_temp1 * pow_tmp; 

    L_temp  = cosw * (x0f[0] - x0[0]);

    L_temp1 = L_temp - sinw_s1 * x0[81];
    L_temp1 = L_temp1 + 2.0f * sinw_p1 * x0f[81];
    *Im     = L_temp1 * pow_tmp; 

    L_temp1 = L_temp - sinw_s1 * x0f[81];
    L_temp1 = L_temp1 + 2.0f * sinw_p1 * x0[81];
    *Imf    = L_temp1 * pow_tmp; 

    return;
}

/*************************************************************************
* calc_RiFFT_1_2
* subroutine called by calc_RiFFTx
* Calculate real and imaginary part of of 1 point in 80-point complex iFFT
**************************************************************************/
static void calc_RiFFT_1_2(Float *x0, Float *x0f, Short norm_shift, 
                           Short sinw_s1, Short sinw_p1, Short cosw, 
                           Float *Ref, Float *Imf)
{
    Float L_temp;
	Float pow_tmp = powT[44 + norm_shift];

    L_temp = cosw * (x0[81] + x0f[81]);

    L_temp = L_temp + sinw_s1 * x0f[0];

    L_temp = L_temp + 2.0f * sinw_p1 * x0[0];
    *Ref   = L_temp * pow_tmp; 

    L_temp = cosw * (x0f[0] - x0[0]);

    L_temp = L_temp - sinw_s1 * x0f[81];
    L_temp = L_temp + 2.0f * sinw_p1 * x0[81];
    *Imf   = L_temp * pow_tmp; 

    return;
}

/*************************************************************************
* sDoRiFFTx
*
* Do 160-points real iFFT
**************************************************************************/
void sDoRiFFTx(Float x[], Short *x_q)
{   

    Short i;

    Short dataNo,groupNo;
    Float ReIm[160], ReIm2[32], *Re, *Im;
    Float *pRe,*pIm, *pLRe,*pLIm;
    Float sRe[80],sIm[80];
    Float *psRe,*psIm;
    Float *pRe0,*pIm0;
    Short Qfft5, Qfft51;
    Float *ptr_x;
    Short norm_shift;
    Short *ptr_twiddleRe, *ptr_twiddleIm;

    norm_shift = Exp16ArrayF(162,x);

    norm_shift = (norm_shift - 2);
    *x_q = (*x_q + norm_shift);

    calc_RiFFTx(x, sRe, sIm, norm_shift);

    pRe0 = ReIm ;
    pIm0 = ReIm +80 ;
    psRe = sRe;
    psIm = sIm;
    for (groupNo=0; groupNo<16; groupNo++)
    {  
		fft_5_format_2(pRe0, pIm0, psRe, psIm, 0.00006103515625f);

        pRe0 += 5;
        pIm0 += 5;
        psRe += 5;
        psIm += 5;
    }

    Qfft5  = Exp32ArrayF(160,ReIm);

    Qfft5  = (Qfft5 - 1);
    Qfft51 = (Qfft5 - 1);

    Re   = ReIm;
    Im   = ReIm + 80;
    pRe0 = ReIm2;
    pIm0 = ReIm2+16;
    pRe  = Re++;
    pIm  = Im++ ;
    for(i=0; i<16; i++)
    {
        *pRe0++ = *pRe; 
        *pIm0++ = *pIm; 
        pRe += 5;
        pIm += 5;
    }
    ptr_x = x;
    fft_16x_format_2i(ReIm2, Qfft5, ptr_x, *x_q);
    ptr_twiddleRe = twiddleRe;
    ptr_twiddleIm = twiddleIm;

    for (dataNo=1; dataNo<5; dataNo++)
    {   
        ptr_x += 2;
        pRe  = Re++;
        pIm  = Im++;
        pLRe = ReIm2;
        pLIm = ReIm2+16;
        *pLRe++ = *pRe; 
        *pLIm++ = *pIm; 
        twiddleReIm(pLRe, pLIm, pRe, pIm, ptr_twiddleRe+1, ptr_twiddleIm+1,
                    Qfft5, Qfft51);
        ptr_twiddleRe += 16;
        ptr_twiddleIm += 16;
        fft_16x_format_2i(ReIm2, Qfft5, ptr_x, *x_q);
    }

    return;
}
#endif /*LAYER_STEREO*/
