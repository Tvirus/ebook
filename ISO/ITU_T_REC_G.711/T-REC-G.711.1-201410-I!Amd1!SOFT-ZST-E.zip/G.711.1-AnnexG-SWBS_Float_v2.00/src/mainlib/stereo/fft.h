/* ITU G.711.1 2nd Edition (2012-09) */

/* --------------------------------------------------------------------------------------
 ITU-T G.711.1-SWBS / G.711.1 Annex F - Reference C code for fixed-point implementation          
 Version 1.0
 Copyright (c) 2012,
 Huawei Technologies, France Telecom
---------------------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: fft.h
 *  Function: Header of FFT for stereo
 *------------------------------------------------------------------------
 */

#ifndef FFTSTEREO_H
#define FFTSTEREO_H

#ifdef LAYER_STEREO

extern Short twiddleRe[64],twiddleIm[64];

void sDoRFFTx(Float x[], Short *x_q);

void sDoRiFFTx(Float x[], Short *x_q);

#endif /*LAYER_STEREO*/

#endif  /* FFTSTEREO_H */
