/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "pcmswb.h"
#include "softbit.h"
#ifdef LAYER_STEREO
#include "g711_stereo.h"
#endif

/***************************************************************************
* usage()
***************************************************************************/
static void usage(char progname[])
{
  fprintf(stderr, "\n");
  fprintf(stderr, " Usage: %s [-options] -c <core> <codefile> <outfile> <bitrate> [-bitrateswitch <mode>]\n", progname);
  fprintf(stderr, "\n");
  fprintf(stderr, " where:\n" );
  fprintf(stderr, "   core         is the desired core:\n");
  fprintf(stderr, "                \"1a\"  for G.711.1 A-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1u\"  for G.711.1 u-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
  fprintf(stderr, "                \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
  fprintf(stderr, "   codefile     is the name of the output bitstream file.\n");
  fprintf(stderr, "   outfile      is the name of the decoded output file.\n");
  fprintf(stderr, "   bitrate      is the maximum decoded bitrate:\n");
  fprintf(stderr, "                \"112\",  \"96\" for G.711.1 core at 80 kbit/s,\n");
  fprintf(stderr, "                \"128\", \"112\" for G.711.1 core at 96 kbit/s,\n");
#ifdef LAYER_STEREO
    fprintf(stderr, "                 \"96\"  for G.711 wb stereo core at 80 kbit/s.\n");
    fprintf(stderr, "                 \"128\" for G.711 wb stereo core at 96 kbit/s.\n");
    fprintf(stderr, "  \"112\" \"128\" \"144\"for G.711 swb stereo core at 80 kbit/s.\n");
    fprintf(stderr, "  \"128\" \"144\" \"160\"for G.711 swb stereo core at 96 kbit/s.\n");
#endif
  fprintf(stderr, "\n");
}

typedef struct {
  int  quiet;
  int  core;
  int  core_bitrate;
  int  mode_bst;
  int  mode_dec;
  char *code_fname;
  char *output_fname;
  int  format;
  int bitrateswitch;
#ifdef LAYER_STEREO
    int channel;
#endif
} DECODER_PARAMS;

static void  get_commandline_params(
                                    int            argc,
                                    char           *argv[],
                                    DECODER_PARAMS *params
                                    ) 
{
  char  *progname=argv[0];

  if (argc < 6) {
    fprintf(stderr, "Error: Too few arguments.\n");
    usage(progname);
    exit(1);
  }

  /* Default mode */
  params->quiet = 0;
  params->format = 0;    /* Default is G.192 softbit format */
  params->mode_dec = -1;
  params->mode_bst = -1;
  params->bitrateswitch = -1;
  params->core = 0;
  params->core_bitrate = 0;
#ifdef LAYER_STEREO
  params->channel = 1;
#endif

  while (argc > 1 && argv[1][0] == '-') {
    /* check law character */
    if (strcmp(argv[1], "-c") == 0) {
      if (strcmp(argv[2], "1u") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_80;
      }
      else if (strcmp(argv[2], "1a") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_80;
      }
      else if (strcmp(argv[2], "1us") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_96;
      }
      else if (strcmp(argv[2], "1as") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_96;
      }
      else {
        fprintf(stderr, "Error: Invalid core specification: %s\n", argv[2]);
        fprintf(stderr, "  Core must be either \"1a\" for G.711.1 A-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1u\" for G.711.1 u-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
        fprintf(stderr, "                      \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
        /* Display help message */
        usage(progname);
        exit(-1);
      }
      /* Move arg{c,v} over the option to the next argument */
      argc -= 2;
      argv += 2;
    }
#ifdef LAYER_STEREO
    else if (strcmp(argv[1], "-stereo") == 0) {
        /* Set the stereo mode flag */
        params->channel = 2;

        /* Move arg{c,v} over the option to the next argument */
        argc--;
        argv++;
    }
#endif
    else if (strcmp(argv[1], "-quiet") == 0) {
      /* Set the quiet mode flag */
      params->quiet=1;

      /* Move arg{c,v} over the option to the next argument */
      argc--;
      argv++;
    }
    else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-?") == 0) {
      /* Display help message */
      usage(progname);
      exit(1);
    }
    else {
      fprintf(stderr, "Error: Invalid option \"%s\"\n\n",argv[1]);
      usage(progname);
      exit(1);
    }
  }

  /* Open input code, output signal files. */
  params->code_fname   = argv[1];
  params->output_fname = argv[2];
#ifdef LAYER_STEREO
  if(params->channel == 1)
  {
#endif
  /* bitrate */
  if      ((strcmp(argv[3],  "96") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode_bst = MODE_R3sm;
  }
  else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode_bst = MODE_R4sm;
  }
  else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode_bst = MODE_R4ssm;
  }
  else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode_bst = MODE_R5ssm;
  }
  else {
    fprintf(stderr, "Error: Invalid bitrate number %s\n", argv[3]);
    fprintf(stderr, "  Bitrate number must be: \"112\", \"96\" for G.711.1 core at 80 kbit/s,\n");
    fprintf(stderr, "                          \"128\", \"112\" for G.711.1 core at 96 kbit/s,\n");
    usage(progname);
    exit(-1);
  }
#ifdef LAYER_STEREO
    }
    else
    {
        /* bitrate */
        if      ((strcmp(argv[3],  "96") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
            params->mode_bst = MODE_R3ws;
        }
        else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
            params->mode_bst = MODE_R4ss;
        }
        else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
            params->mode_bst = MODE_R5ss;
        }
        else if ((strcmp(argv[3], "144") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
            params->mode_bst = MODE_R6ss;
        }
        else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
            params->mode_bst = MODE_R5sws;
        }
        else if ((strcmp(argv[3], "144") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
            params->mode_bst = MODE_R6sss;
        }
        else if ((strcmp(argv[3], "160") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
            params->mode_bst = MODE_R7sss;
        }
        else {
            fprintf(stderr, "Error: Invalid bitrate number %s\n", argv[3]);
            fprintf(stderr, "  Bitrate number must be: \"96\", \"112\" , \"128\" , \"144\"for G.711.1 stereo core at 80 kbit/s,\n");
            fprintf(stderr, "                          \"128\", \"144\" , \"160\"for G.711.1 stereo core at 96 kbit/s,\n");
            usage(progname);
            exit(-1);
        }
    }

    if(argc > 5) /*to have argv[4] and [5] */
    {
        if (strcmp(argv[4], "-bitrateswitch") == 0) 
        {
            if (strcmp(argv[5], "0") == 0) 
            {
                params->bitrateswitch = 0;
            }
            else {
                fprintf(stderr, "Error: Invalid mode number %s\n", argv[4]);
                fprintf(stderr, "  Mode must be either \"0\" ,\n");
                fprintf(stderr, "               or     \"1\" \n");
                /* Display help message */
                usage(progname);
                exit(-1);
            }
        }
    }
#endif
  params->mode_dec = params->mode_bst;

  /* check for core/mode compatibility */
  if (params->core == G711ULAW_CORE || params->core == G711ALAW_CORE) {
    switch (params->mode_dec) {
      case MODE_R1nm  : break;
      case MODE_R2nm  : break;
      case MODE_R2wm  : break;
      case MODE_R3wm  : break;
      case MODE_R3sm  : break;
      case MODE_R4sm  : break;
      case MODE_R4ssm : break;
      case MODE_R5ssm  : break;
#ifdef LAYER_STEREO
      case MODE_R3ws  : break;
      case MODE_R5sws : break;
      case MODE_R4ss  : break;
      case MODE_R5ss  : break;
      case MODE_R6ss  : break;
      case MODE_R6sss : break;
      case MODE_R7sss : break;
#endif
      default : fprintf(stderr, "Error: Inconsitency in core and bitrate.\n");
      usage(progname); exit(-1);
    }
  }

  return;
}

/***************************************************************************
* main()
***************************************************************************/
int
main(int argc, char *argv[])
{
  DECODER_PARAMS  params;
  int             nbitsIn;
  int nbitsIn_commandline; /*to memorise the command line bitrate */
  int             nbytesIn;
  int             nsamplesOut=0;
  FILE            *fpcode, *fpout;

  void            *theDecoder=0;
  int             status;
#ifdef LAYER_STEREO
  short           sbufOut[NSamplesPerFrame32k * 2];
  short           highest_mode;
#else
  short           sbufOut[NSamplesPerFrame32k];
#endif
  unsigned short  sbufIn[G192_HeaderSize+MaxBitsPerFrame];
  unsigned char   cbufIn[MaxBytesPerFrame];
  int             payloadsize;
  int             ploss_status=0;

  /* Set parameters from argv[]. */
  get_commandline_params( argc, argv, &params );
#ifdef LAYER_STEREO
  highest_mode = -1;
  if(params.bitrateswitch != -1)
      highest_mode = params.mode_bst;
#endif
  switch (params.mode_bst) {
    case MODE_R1nm  : nbitsIn = NBITS_MODE_R1nm;  break;
    case MODE_R2nm  : nbitsIn = NBITS_MODE_R2nm;  break;
    case MODE_R2wm  : nbitsIn = NBITS_MODE_R2wm;  break;
    case MODE_R3wm  : nbitsIn = NBITS_MODE_R3wm;  break;
    case MODE_R3sm  : nbitsIn = NBITS_MODE_R3sm;  break;
    case MODE_R4sm  : nbitsIn = NBITS_MODE_R4sm;  break;
    case MODE_R4ssm : nbitsIn = NBITS_MODE_R4ssm; break;
    case MODE_R5ssm : nbitsIn = NBITS_MODE_R5ssm; break;
#ifdef LAYER_STEREO
    case MODE_R3ws   : nbitsIn = NBITS_MODE_R3ws ;  break;
    case MODE_R5sws  : nbitsIn = NBITS_MODE_R5sws;  break;
    case MODE_R4ss   : nbitsIn = NBITS_MODE_R4ss ;  break;
    case MODE_R5ss   : nbitsIn = NBITS_MODE_R5ss ;  break;
    case MODE_R6ss   : nbitsIn = NBITS_MODE_R6ss ;  break;
    case MODE_R6sss  : nbitsIn = NBITS_MODE_R6sss;  break;
    case MODE_R7sss  : nbitsIn = NBITS_MODE_R7sss;  break;
#endif
    default : fprintf(stderr, "Mode specification error.\n"); exit(-1);
  }
  nbitsIn_commandline = nbitsIn; /*memorise the command line bitrate not yet modified*/
  nbytesIn = nbitsIn/CHAR_BIT;

  if (params.core == G711ULAW_CORE || params.core == G711ALAW_CORE) {
    switch (params.mode_dec) {
      case MODE_R1nm  : nsamplesOut = NSamplesPerFrame08k; break;
      case MODE_R2nm  : nsamplesOut = NSamplesPerFrame08k; break;
      case MODE_R2wm  : nsamplesOut = NSamplesPerFrame16k; break;
      case MODE_R3wm  : nsamplesOut = NSamplesPerFrame16k; break;
      case MODE_R3sm  : nsamplesOut = NSamplesPerFrame32k; break;
      case MODE_R4sm  : nsamplesOut = NSamplesPerFrame32k; break;
      case MODE_R4ssm : nsamplesOut = NSamplesPerFrame32k; break;
      case MODE_R5ssm : nsamplesOut = NSamplesPerFrame32k; break;
#ifdef LAYER_STEREO
      case MODE_R3ws  : nsamplesOut = NSamplesPerFrame16k * 2;  break;
      case MODE_R5sws : nsamplesOut = NSamplesPerFrame16k * 2;  break;
      case MODE_R4ss  : nsamplesOut = NSamplesPerFrame32k * 2;  break;
      case MODE_R5ss  : nsamplesOut = NSamplesPerFrame32k * 2;  break;
      case MODE_R6ss  : nsamplesOut = NSamplesPerFrame32k * 2;  break;
      case MODE_R6sss : nsamplesOut = NSamplesPerFrame32k * 2;  break;
      case MODE_R7sss : nsamplesOut = NSamplesPerFrame32k * 2;  break;
#endif
      default : fprintf(stderr, "Mode specification error.\n"); exit(-1);
    }
  }

  /* Open input bitstream */
  fpcode   = fopen(params.code_fname, "rb");
  if (fpcode == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Open output speech file. */
  fpout  = fopen(params.output_fname, "wb");
  if (fpout == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Instanciate an decoder. */
  theDecoder = pcmswbDecode_const(params.core, params.mode_dec);

  if (theDecoder == 0) {
    fprintf(stderr, "Decoder init error.\n");
    exit(1);
  }

  /* Reset (unnecessary if right after instantiation!). */
  pcmswbDecode_reset( theDecoder );

  while (1)
  {
    if( params.format == 0 )    /* G.192 softbit output format */
    {
      /* Read bitstream. */
      int nbitsIn_bst;
      nbitsIn = nbitsIn_commandline; /*reset in nbitsIn the command line bitrate*/
      nbytesIn = nbitsIn/CHAR_BIT;

      if (fread(sbufIn, sizeof(short), G192_HeaderSize, fpcode) <  G192_HeaderSize)
        break;

      nbitsIn_bst = sbufIn[1];
#ifndef LAYER_STEREO
      nsamplesOut = NSamplesPerFrame32k; /*only SWB (32 kHz sampled) output, even for WB orNB, for witching*/
#endif
      if (fread(sbufIn+G192_HeaderSize, sizeof(short), nbitsIn_bst, fpcode) !=  (unsigned) nbitsIn_bst)
        break;
      if(nbitsIn_bst < nbitsIn)
      {
        nbitsIn = nbitsIn_bst; /* min of the 2*/
        nbytesIn = nbitsIn/CHAR_BIT;
      }
#ifdef LAYER_STEREO
      if (params.channel == 1)
      {
#endif
      if (params.bitrateswitch == -1) /*default mode, no bitrateswitch in command line*/
      {
        if (params.core_bitrate == G711ALAW_CORE_80 || params.core_bitrate == G711ULAW_CORE_80) { /*G711.1 core at 80 kbit/s*/
          switch (nbitsIn)
          {
          case 320  : 
            params.mode_dec = params.mode_bst = MODE_R1nm;
            break; /*MODE_R1nm*/
          case 400  : 
            params.mode_dec = params.mode_bst = MODE_R2wm;
            break; /*MODE_R2wm*/
          case 480  : 
            params.mode_dec = params.mode_bst = MODE_R3sm;
            break; /*MODE_R3sm*/
          case 560  : 
            params.mode_dec = params.mode_bst = MODE_R4sm;
            break; /*MODE_R4sm*/
          default : 
            fprintf(stderr, "Error: bitrate (%d kbps) not supported for G711.1 core at 80 kbit/s.\n", nbitsIn_bst/5);
            exit(-1);
          }
        }
        else { /*G711.1 core at 96 kbit/s*/
          switch (nbitsIn)
          {
          case 320  : 
            params.mode_dec = params.mode_bst = MODE_R1nm;
            break; /*MODE_R1nm*/
          case 400  : 
            params.mode_dec = params.mode_bst = MODE_R2nm;
            break; /*MODE_R2nm*/
          case 480  : 
            params.mode_dec = params.mode_bst = MODE_R3wm;
            break; /*MODE_R3wm*/
          case 560  : 
            params.mode_dec = params.mode_bst = MODE_R4ssm;
            break; /*MODE_R4ssm*/
          case 640  : 
            params.mode_dec = params.mode_bst = MODE_R5ssm;
            break; /*MODE_R5ssm*/
          default : 
            fprintf(stderr, "Error: bitrate (%d kbps) not supported for G711.1 core at 96 kbit/s.\n", nbitsIn_bst/5);
            exit(-1);
          }
        }
      }
#ifdef LAYER_STEREO
    }
    else
    {
        if (params.bitrateswitch == -1) /*default mode, no bitrateswitch in command line*/
        {
            if (params.core_bitrate == G711ALAW_CORE_80 || params.core_bitrate == G711ULAW_CORE_80) { /*G711.1 core at 80 kbit/s*/
                switch (nbitsIn)
                {
                case 480  : 
                    params.mode_dec = params.mode_bst = MODE_R3ws;
                    break; /*MODE_R3ws*/
                case 560  : 
                    params.mode_dec = params.mode_bst = MODE_R4ss;
                    break; /*MODE_R4ss*/
                case 640  : 
                    params.mode_dec = params.mode_bst = MODE_R5ss;
                    break; /*MODE_R5ss*/
                case 720  : 
                    params.mode_dec = params.mode_bst = MODE_R6ss;
                    break; /*MODE_R6ss*/
                default : 
                    fprintf(stderr, "Error: bitrate (%d kbps) not supported for G711.1 core at 80 kbit/s.\n", nbitsIn_bst/5);
                    exit(-1);
                }
            }
            else { /*G711.1 core at 96 kbit/s*/
                switch (nbitsIn)
                {
                case 640  : 
                    params.mode_dec = params.mode_bst = MODE_R5sws;
                    break; /*MODE_R5sws*/
                case 720  : 
                    params.mode_dec = params.mode_bst = MODE_R6sss;
                    break; /*MODE_R6sss*/
                case 800  : 
                    params.mode_dec = params.mode_bst = MODE_R7sss;
                    break; /*MODE_R7sss*/
                default : 
                    fprintf(stderr, "Error: bitrate (%d kbps) not supported for G711.1 core at 96 kbit/s.\n", nbitsIn_bst/5);
                    exit(-1);
                }
            }
        }
        else if (params.bitrateswitch == 0) /*stereo rate switching*/
        {
            if (params.core_bitrate == G711ALAW_CORE_80 || params.core_bitrate == G711ULAW_CORE_80) { /*G711.1 core at 80 kbit/s*/
                switch (nbitsIn)
                {
                case 400  : 
                    params.mode_dec = params.mode_bst = MODE_R2wm;
                    break; /*MODE_R2wm*/
                case 480  : 
                    params.mode_dec = params.mode_bst = MODE_R3sm;
                    if(highest_mode == MODE_R3ws)
                    {
                        params.mode_dec = params.mode_bst = MODE_R3ws;
                    }
                    break; /*MODE_R3sm*/
                case 560  : 
                    params.mode_dec = params.mode_bst = MODE_R4sm;
                    if(highest_mode == MODE_R4ss)
                    {
                        params.mode_dec = params.mode_bst = MODE_R4ss;
                    }
                    break; /*MODE_R4sm*/
                case 640  : 
                    params.mode_dec = params.mode_bst = MODE_R5ss;
                    break; /*MODE_R5ss*/
                case 720  : 
                    params.mode_dec = params.mode_bst = MODE_R6ss;
                    break; /*MODE_R6ss*/
                default : 
                    fprintf(stderr, "Error: bitrate (%d kbps) not supported for rate switching with G711.1 core at 80 kbit/s.\n", nbitsIn_bst/5);
                    exit(-1);
                }
            }
            else if (params.core_bitrate == G711ALAW_CORE_96 || params.core_bitrate == G711ULAW_CORE_96) { /*G711.1 core at 96 kbit/s*/
                switch (nbitsIn)
                {
                    case 480:
                        params.mode_dec = params.mode_bst = MODE_R3wm;
                        break; /*MODE_R3wm*/
                    case 560:
                        params.mode_dec = params.mode_bst = MODE_R4ssm;
                        break; /*MODE_R4ssm*/
                    case 640:
                        if(highest_mode == MODE_R5sws)
                        {
                            params.mode_dec = params.mode_bst = MODE_R5sws;
                        }
                        else if (highest_mode == MODE_R7sss)
                        {
                            params.mode_dec = params.mode_bst = MODE_R5ssm;
                        }
                        break;
                    case 720:
                        params.mode_dec = params.mode_bst = MODE_R6sss;
                        break; /*MODE_R6sss*/
                    case 800:
                        params.mode_dec = params.mode_bst = MODE_R7sss;
                        break; /*MODE_R7sss*/
                }
            }
        }
    }
#endif
      pcmswbDecode_set (params.mode_dec, theDecoder);

      /* Check FER and payload size */
      payloadsize = checksoftbit( sbufIn );

      ploss_status = 0; /* False: No FER */
      if( payloadsize <= 0 )  /* Frame erasure */
      {
        ploss_status = 1; /* True: FER */
      }

      /* Convert from softbit to hardbit */
      softbit2hardbit( nbytesIn, &sbufIn[G192_HeaderSize], cbufIn );
    }
    else
    {
      /* Read bitstream. */
      if (fread(cbufIn, sizeof(char), nbytesIn, fpcode) ==  0)
        break;
      ploss_status = 0; /* False: No FER */
      /* When FER is detected, set ploss_status=1 */
    }

	/* Decode. */
    status = pcmswbDecode( cbufIn, sbufOut, theDecoder, ploss_status 
#ifdef LAYER_STEREO
                 , &highest_mode
#endif
		);

    if ( status ) {
      fprintf(stderr, "Decoder NG. Exiting.\n");
      exit(1);
    }

    /* Write output signal to fout. */
    fwrite(sbufOut, sizeof(short), nsamplesOut, fpout);
  }

  /* Close files. */
  fclose(fpcode);
  fclose(fpout);

  /* Delete the decoder. */ 
  pcmswbDecode_dest( theDecoder );

  return 0;
}
