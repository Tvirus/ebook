/* ITU G.711.1 2nd Edition (2012-09) */

/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex G (ex G.711.1-SWB-Float) Source Code
 Software Release 1.01 (2012-07)
 (C) 2012 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp., NTT.
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "pcmswb.h"
#include "softbit.h"

/***************************************************************************
* usage()
***************************************************************************/
static void usage(char progname[])
{
  fprintf(stderr, "\n");
  fprintf(stderr, " Usage: %s [-options] -c <core> <infile> <codefile> <bitrate>\n", progname);
  fprintf(stderr, "\n");
  fprintf(stderr, " where:\n" );
  fprintf(stderr, "   core         is the desired core:\n");
  fprintf(stderr, "                \"1a\"  for G.711.1 A-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1u\"  for G.711.1 u-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
  fprintf(stderr, "                \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
  fprintf(stderr, "   infile       is the name of the input file to be encoded.\n");
  fprintf(stderr, "   codefile     is the name of the output bitstream file.\n");
  fprintf(stderr, "   bitrate      is the desired bitrate:\n");
  fprintf(stderr, "                \"112 (R4sm),   96 (R3sm)\" for G.711.1 core at 80 kbit/s,\n");
  fprintf(stderr, "                \"128 (R5ssm), 112 (R4ssm)\" for G.711.1 core at 96 kbit/s,\n");
#ifdef LAYER_STEREO
  fprintf(stderr, "                 \"96\" for G.711.1 wb stereo core at 80 kbit/s,\n");
  fprintf(stderr, "                 \"128\" for G.711.1 wb stereo core at 96 kbit/s,\n");
  fprintf(stderr, "                 \"112\" for G.711.1 swb stereo core at 80 kbit/s,\n");
  fprintf(stderr, "                 \"128\" for G.711.1 swb stereo core at 80 kbit/s,\n");
  fprintf(stderr, "                 \"144\" for G.711.1 swb stereo core at 80 kbit/s,\n");
  fprintf(stderr, "                 \"144\" for G.711.1 swb stereo core at 96 kbit/s.\n");
  fprintf(stderr, "                 \"160\" for G.711.1 swb stereo core at 96 kbit/s.\n");
#endif
  fprintf(stderr, "\n");
  fprintf(stderr, " Options:\n");
  fprintf(stderr, "   -quiet       quiet processing.\n");
#ifdef LAYER_STEREO
  fprintf(stderr, "  -wb indicates that input signal is either narrow band,\n");
  fprintf(stderr, "                wideband, or superwideband (default is -swb).\n");
  fprintf(stderr, "  -stereo  indicates that input signal is either mono,\n");
  fprintf(stderr, "                , or stereo (default is mono).\n");
#endif
  fprintf(stderr, "\n");
}

typedef struct {
  int  mode;
  int  quiet;
  int  format;
  unsigned short  inputSF;
  int  core;
  int  core_bitrate;
  char *input_fname;
  char *code_fname;
#ifdef LAYER_STEREO
  short channel;
#endif
} ENCODER_PARAMS;

static void  get_commandline_params(
                                    int            argc,
                                    char           *argv[],
                                    ENCODER_PARAMS *params
                                    ) 
{
  char  *progname=argv[0];

  if (argc < 6) {
    fprintf(stderr, "Error: Too few arguments.\n");
    usage(progname);
    exit(1);
  }

  /* Default mode */
  params->mode = -1;
  params->quiet = 0;
  params->format = 0;        /* Default is G.192 softbit format */
  params->inputSF = 32000;   /* Default is super-wideband input */
  params->core = 0;
  params->core_bitrate = 0;
#ifdef LAYER_STEREO
  params->channel = 1;
#endif

  /* Search options */
  while (argc > 1 && argv[1][0] == '-') {
    /* check law character */
    if (strcmp(argv[1],"-c") == 0) {
      if (strcmp(argv[2], "1u") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_80;
      }
      else if (strcmp(argv[2], "1a") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_80;
      }
      else if (strcmp(argv[2], "1us") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_96;
      }
      else if (strcmp(argv[2], "1as") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_96;
      }
      else {
        fprintf(stderr, "Error: Invalid core specification: %s\n", argv[2]);
        fprintf(stderr, "  Core must be either \"1a\" for G.711.1 A-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1u\" for G.711.1 u-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
        fprintf(stderr, "                      \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
        /* Display help message */
        usage(progname);
        exit(-1);
      }
      /* Move arg{c,v} over the option to the next argument */
      argc -= 2;
      argv += 2;
    }
    else if (strcmp(argv[1],"-quiet") == 0) {
      /* Set the quiet mode flag */
      params->quiet=1;
      /* Move arg{c,v} over the option to the next argument */
      argc--;
      argv++;
    }
#ifdef LAYER_STEREO
    else if (strcmp(argv[1],"-stereo") == 0) {
      /* Set the stereo mode flag */
      params->channel=2;
      /* Move arg{c,v} over the option to the next argument */
      argc--;
      argv++;
    }
    else if (strcmp(argv[1],"-wb") == 0) {
      /* Set the quiet mode flag */
      params->inputSF=16000;
      /* Move arg{c,v} over the option to the next argument */
      argc--;
      argv++;
    }
#endif
    else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-?") == 0) {
      /* Display help message */
      usage(progname);
      exit(1);
    }
    else {
      fprintf(stderr, "Error: Invalid option \"%s\"\n\n",argv[1]);
      usage(progname);
      exit(1);
    }
  }

  /* Open input signal and output code files. */
  params->input_fname  = argv[1];
  params->code_fname   = argv[2];
#ifdef LAYER_STEREO
  if(params->channel == 1)
  {
#endif
  /* bitrate */
  if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode = MODE_R4sm;
  }
  else if ((strcmp(argv[3], "96") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode = MODE_R3sm;
  }
  else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode = MODE_R5ssm;
  }
  else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode = MODE_R4ssm;
  }
  else {
    fprintf(stderr, "Error: Invalid bitrate number %s\n", argv[3]);
    fprintf(stderr, "  Bitrate number must be: \"112,  96\" for G.711.1 core at 80 kbit/s,\n");
    fprintf(stderr, "                          \"128, 112\" for G.711.1 core at 96 kbit/s,\n");
    usage(progname);
    exit(-1);
  }
#ifdef LAYER_STEREO
  }
  else
  {
    if ((strcmp(argv[3], "96") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
        params->mode = MODE_R3ws;
    }
    else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
        params->mode = MODE_R4ss;
    }
    else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
        params->mode = MODE_R5ss;
    }
    else if ((strcmp(argv[3], "144") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
        params->mode = MODE_R6ss;
    }
    else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
        params->mode = MODE_R5sws;
    }
    else if ((strcmp(argv[3], "144") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
        params->mode = MODE_R6sss;
    }
    else if ((strcmp(argv[3], "160") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
        params->mode = MODE_R7sss;
    }
    else 
    {
        fprintf(stderr, "Error: Invalid bitrate number %s\n", argv[3]);
        fprintf(stderr, "  Bitrate number must be: \"112\" for G.711.1 core at 80 kbit/s,\n");
        fprintf(stderr, "                          \"128\" for G.711.1 core at 96 kbit/s,\n");
        usage(progname);
        exit(-1);
    }
  }
#endif
  /* check for core/mode compatibility */
  if (params->core == G711ULAW_CORE || params->core == G711ALAW_CORE) {
    switch (params->mode) {
      case MODE_R1nm  : break;
      case MODE_R2nm  : break;
      case MODE_R2wm  : break;
      case MODE_R3wm  : break;
      case MODE_R3sm  : break;
      case MODE_R4sm  : break;
      case MODE_R4ssm : break;
      case MODE_R5ssm : break;
#ifdef LAYER_STEREO
    case MODE_R3ws  : break;
    case MODE_R5sws : break;
    case MODE_R4ss  : break;
    case MODE_R5ss  : break;
    case MODE_R6ss  : break;
    case MODE_R6sss : break;
    case MODE_R7sss : break;
#endif
      default : fprintf(stderr, "Error: Inconsitency in core and bitrate.\n");
      usage(progname); exit(-1);
    }
  }

  return;
}

/***************************************************************************
* main()
***************************************************************************/

int
main(int argc, char *argv[])
{
  int             i;
  ENCODER_PARAMS  params;
  int             nsamplesIn;
  int             nbitsOut;
  int             nbytesOut;
  FILE            *fpin, *fpcode;

  void            *theEncoder=0;

  int             status;
#ifdef LAYER_STEREO
  short           sbufIn[NSamplesPerFrame32k * 2];
#else
  short           sbufIn[NSamplesPerFrame32k];
#endif
  unsigned short  sbufOut[G192_HeaderSize+MaxBitsPerFrame];
  unsigned char   cbufOut[MaxBytesPerFrame];

  /* Set parameters from argv[]. */
  get_commandline_params( argc, argv, &params );
#ifdef LAYER_STEREO
  if (params.channel == 1)
  {
#endif
  if ( params.inputSF == 8000 )
    nsamplesIn = NSamplesPerFrame08k; /* Input sampling rate is 8 kHz. */
  else if ( params.inputSF == 16000 )
    nsamplesIn = NSamplesPerFrame16k; /* Input sampling rate is 16 kHz. */
  else 
    nsamplesIn = NSamplesPerFrame32k; /* Input sampling rate is 32 kHz in default. */
#ifdef LAYER_STEREO
  }
  else
  {
      if ( params.inputSF == 16000 )
        nsamplesIn = NSamplesPerFrame16k * 2; /* Input sampling rate is 16 kHz. */
      else 
        nsamplesIn = NSamplesPerFrame32k * 2; /* Input sampling rate is 32 kHz in default. */
  }
#endif
  switch (params.mode) {
    case MODE_R1nm  : nbitsOut = NBITS_MODE_R1nm;  break;
    case MODE_R2nm  : nbitsOut = NBITS_MODE_R2nm;  break;
    case MODE_R2wm  : nbitsOut = NBITS_MODE_R2wm;  break;
    case MODE_R3wm  : nbitsOut = NBITS_MODE_R3wm;  break;
    case MODE_R3sm  : nbitsOut = NBITS_MODE_R3sm;  break;
    case MODE_R4sm  : nbitsOut = NBITS_MODE_R4sm;  break;
    case MODE_R4ssm : nbitsOut = NBITS_MODE_R4ssm; break;
    case MODE_R5ssm : nbitsOut = NBITS_MODE_R5ssm; break;
#ifdef LAYER_STEREO
  case MODE_R3ws  : nbitsOut = NBITS_MODE_R3ws ;  break;
  case MODE_R5sws : nbitsOut = NBITS_MODE_R5sws;  break;
  case MODE_R4ss  : nbitsOut = NBITS_MODE_R4ss ;  break;
  case MODE_R5ss  : nbitsOut = NBITS_MODE_R5ss ;  break;
  case MODE_R6ss  : nbitsOut = NBITS_MODE_R6ss ;  break;
  case MODE_R6sss : nbitsOut = NBITS_MODE_R6sss;  break;
  case MODE_R7sss : nbitsOut = NBITS_MODE_R7sss;  break;
#endif
    default : fprintf(stderr, "Mode specification error.\n"); exit(-1);
  }
  nbytesOut = nbitsOut/CHAR_BIT;

  /* Open input speech file. */
  fpin = fopen(params.input_fname, "rb");
  if (fpin == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Open output bitstream. */
  fpcode = fopen(params.code_fname, "wb");
  if (fpcode == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Instanciate an encoder. */
  theEncoder = pcmswbEncode_const(params.inputSF, params.core, params.mode
#ifdef LAYER_STEREO
      ,params.channel
#endif
	  );

  if (theEncoder == 0) {
    fprintf(stderr, "Encoder init error.\n");
    exit(1);
  }

  /* Reset (unnecessary if right after instantiation!). */
  pcmswbEncode_reset( theEncoder );

  while (1) {
    /* Initialize sbuf[]. */
    for (i=0; i<nsamplesIn; i++) sbufIn[i] = 0;

    /* Read input singal from fin. */
    if ( fread( sbufIn, sizeof(short), nsamplesIn, fpin ) == 0 )
      break;

    /* Encode. */
    status = pcmswbEncode( sbufIn, cbufOut, theEncoder );

    if ( status ) {
      fprintf(stderr, "Encoder NG. Exiting.\n");
      exit(1);
    }

    if( params.format == 0 ) {   /* G.192 softbit output format */
      /* Write main header */
      sbufOut[0] = G192_SYNCHEADER;
      sbufOut[idxG192_BitstreamLength] = (unsigned short)nbitsOut;

      /* Convert from hardbit to softbit. */
      hardbit2softbit( nbytesOut, cbufOut, &sbufOut[G192_HeaderSize] );

      /* Write bitstream. */
      fwrite( sbufOut, sizeof(short), G192_HeaderSize+nbitsOut, fpcode );
    }
    else {   /* Hardbit output format */
      /* Write bitstream. */
      fwrite( cbufOut, sizeof(char), nbytesOut, fpcode );
    }
  }

  /* Close files. */
  fclose(fpin);
  fclose(fpcode);

  /* Delete the encoder. */ 
  pcmswbEncode_dest( theEncoder );

  return 0;
}
