/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include "stl.h"
#include "pcmswb.h"
#include "softbit.h"

/*****************************/
#ifdef DYN_RAM_CNT
#define MAIN_ROUTINE
#include "dyn_ram_cnt.h"
#endif
/*****************************/


/***************************************************************************
* usage()
***************************************************************************/
static void usage(char progname[])
{
  fprintf(stderr, "\n");
  fprintf(stderr, " Usage: %s [-options] -c <core> <infile> <codefile> <bitrate>\n", progname);
  fprintf(stderr, "\n");
  fprintf(stderr, " where:\n" );
  fprintf(stderr, "   core         is the desired core:\n");
  fprintf(stderr, "                \"1a\"  for G.711.1 A-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1u\"  for G.711.1 u-law core at 80 kbit/s,\n");
  fprintf(stderr, "                \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
  fprintf(stderr, "                \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
  fprintf(stderr, "   infile       is the name of the input file to be encoded.\n");
  fprintf(stderr, "   codefile     is the name of the output bitstream file.\n");
  fprintf(stderr, "   bitrate      is the desired bitrate:\n");
  fprintf(stderr, "                \"112 (R4sm),   96 (R3sm)\" for G.711.1 core at 80 kbit/s,\n");
  fprintf(stderr, "                \"128 (R5ssm), 112 (R4ssm)\" for G.711.1 core at 96 kbit/s,\n");
  fprintf(stderr, "\n");
  fprintf(stderr, " Options:\n");
  fprintf(stderr, "   -quiet       quiet processing.\n");
  fprintf(stderr, "\n");
}

typedef struct {
  int  mode;
  int  quiet;
  int  format;
  unsigned short  inputSF;
  int  core;
  int  core_bitrate;
  char *input_fname;
  char *code_fname;
} ENCODER_PARAMS;

static void  get_commandline_params(
                                    int            argc,
                                    char           *argv[],
                                    ENCODER_PARAMS *params
                                    ) 
{
  char  *progname=argv[0];

  if (argc < 6) {
    fprintf(stderr, "Error: Too few arguments.\n");
    usage(progname);
    exit(1);
  }

  /* Default mode */
  params->mode = -1;
  params->quiet = 0;
  params->format = 0;        /* Default is G.192 softbit format */
  params->inputSF = 32000;   /* Default is super-wideband input */
  params->core = 0;
  params->core_bitrate = 0;

  /* Search options */
  while (argc > 1 && argv[1][0] == '-') {
    /* check law character */
    if (strcmp(argv[1],"-c") == 0) {
      if (strcmp(argv[2], "1u") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_80;
      }
      else if (strcmp(argv[2], "1a") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_80;
      }
      else if (strcmp(argv[2], "1us") == 0) {
        params->core = G711ULAW_CORE;
        params->core_bitrate = G711ULAW_CORE_96;
      }
      else if (strcmp(argv[2], "1as") == 0) {
        params->core = G711ALAW_CORE;
        params->core_bitrate = G711ALAW_CORE_96;
      }
      else {
        fprintf(stderr, "Error: Invalid core specification: %s\n", argv[2]);
        fprintf(stderr, "  Core must be either \"1a\" for G.711.1 A-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1u\" for G.711.1 u-law core at 80 kbit/s,\n");
        fprintf(stderr, "                      \"1as\" for G.711.1 A-law core at 96 kbit/s,\n");
        fprintf(stderr, "                      \"1us\" for G.711.1 u-law core at 96 kbit/s,\n");
        /* Display help message */
        usage(progname);
        exit(-1);
      }
      /* Move arg{c,v} over the option to the next argument */
      argc -= 2;
      argv += 2;
    }
    else if (strcmp(argv[1],"-quiet") == 0) {
      /* Set the quiet mode flag */
      params->quiet=1;
      /* Move arg{c,v} over the option to the next argument */
      argc--;
      argv++;
    }
    else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-?") == 0) {
      /* Display help message */
      usage(progname);
      exit(1);
    }
    else {
      fprintf(stderr, "Error: Invalid option \"%s\"\n\n",argv[1]);
      usage(progname);
      exit(1);
    }
  }

  /* Open input signal and output code files. */
  params->input_fname  = argv[1];
  params->code_fname   = argv[2];

  /* bitrate */
  if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode = MODE_R4sm;
  }
  else if ((strcmp(argv[3], "96") == 0) && (params->core_bitrate == G711ALAW_CORE_80 || params->core_bitrate == G711ULAW_CORE_80)) {
    params->mode = MODE_R3sm;
  }
  else if ((strcmp(argv[3], "128") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode = MODE_R5ssm;
  }
  else if ((strcmp(argv[3], "112") == 0) && (params->core_bitrate == G711ALAW_CORE_96 || params->core_bitrate == G711ULAW_CORE_96)) {
    params->mode = MODE_R4ssm;
  }
  else {
    fprintf(stderr, "Error: Invalid bitrate number %s\n", argv[3]);
    fprintf(stderr, "  Bitrate number must be: \"112,  96\" for G.711.1 core at 80 kbit/s,\n");
    fprintf(stderr, "                          \"128, 112\" for G.711.1 core at 96 kbit/s,\n");

    usage(progname);
    exit(-1);
  }

  /* check for core/mode compatibility */
  if (params->core == G711ULAW_CORE || params->core == G711ALAW_CORE) {
    switch (params->mode) {
    case MODE_R1nm  : break;
    case MODE_R2nm  : break;
    case MODE_R2wm  : break;
    case MODE_R3wm  : break;
    case MODE_R3sm  : break;
    case MODE_R4sm  : break;
    case MODE_R4ssm : break;
    case MODE_R5ssm : break;
    default : fprintf(stderr, "Error: Inconsitency in core and bitrate.\n");
      usage(progname); exit(-1);
    }
  }

  return;
}

#ifdef WMOPS
short           Id = -1;
#endif

/*****************************/
#ifdef DYN_RAM_CNT
int           dyn_ram_level_cnt;
unsigned long *dyn_ram_table_ptr;
unsigned long dyn_ram_table[DYN_RAM_MAX_LEVEL];
char          dyn_ram_name_table[DYN_RAM_MAX_LEVEL][DYN_RAM_MAX_NAME_LENGTH];
unsigned long dyn_ram_current_value;
unsigned long dyn_ram_max_value;
unsigned long dyn_ram_max_counter;
#endif
/*****************************/

/***************************************************************************
* main()
***************************************************************************/

int
main(int argc, char *argv[])
{
  int             i;
  ENCODER_PARAMS  params;
  int             nsamplesIn;
  int             nbitsOut;
  int             nbytesOut;
  FILE            *fpin, *fpcode;

  void            *theEncoder=0;

  int             status;
  short           sbufIn[NSamplesPerFrame32k];
  unsigned short  sbufOut[G192_HeaderSize+MaxBitsPerFrame];
  unsigned char   cbufOut[MaxBytesPerFrame];

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_INIT();
#endif
  /*****************************/

  /* Set parameters from argv[]. */
  get_commandline_params( argc, argv, &params );

  if ( params.inputSF == 8000 )
    nsamplesIn = NSamplesPerFrame08k; /* Input sampling rate is 8 kHz. */
  else if ( params.inputSF == 16000 )
    nsamplesIn = NSamplesPerFrame16k; /* Input sampling rate is 16 kHz. */
  else 
    nsamplesIn = NSamplesPerFrame32k; /* Input sampling rate is 32 kHz in default. */

  switch (params.mode) {
  case MODE_R1nm  : nbitsOut = NBITS_MODE_R1nm;  break;
  case MODE_R2nm  : nbitsOut = NBITS_MODE_R2nm;  break;
  case MODE_R2wm  : nbitsOut = NBITS_MODE_R2wm;  break;
  case MODE_R3wm  : nbitsOut = NBITS_MODE_R3wm;  break;
  case MODE_R3sm  : nbitsOut = NBITS_MODE_R3sm;  break;
  case MODE_R4sm  : nbitsOut = NBITS_MODE_R4sm;  break;
  case MODE_R4ssm : nbitsOut = NBITS_MODE_R4ssm; break;
  case MODE_R5ssm : nbitsOut = NBITS_MODE_R5ssm; break;
  default : fprintf(stderr, "Mode specification error.\n"); exit(-1);
  }
  nbytesOut = nbitsOut/CHAR_BIT;

  /* Open input speech file. */
  fpin = fopen(params.input_fname, "rb");
  if (fpin == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Open output bitstream. */
  fpcode = fopen(params.code_fname, "wb");
  if (fpcode == (FILE *)NULL) {
    fprintf(stderr, "file open error.\n");
    exit(1);
  }

  /* Instanciate an encoder. */
  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH(0, "dummy"); /* count static memories */
#endif
  /*****************************/  
  theEncoder = pcmswbEncode_const(params.inputSF, (Word16)params.core, (Word16)params.mode);
  if (theEncoder == 0) {
    fprintf(stderr, "Encoder init error.\n");
    exit(1);
  }

  /* Reset (unnecessary if right after instantiation!). */
  pcmswbEncode_reset( theEncoder );

#ifdef WMOPS
  setFrameRate(32000, NSamplesPerFrame32k);
  Id = (short)getCounterId("Encoder");
  setCounter(Id);
  Init_WMOPS_counter();  
#endif

  while (1) {
#ifdef WMOPS
    setCounter(Id);
    fwc();
    Reset_WMOPS_counter();
    setCounter(Id);
#endif
    /* Initialize sbuf[]. */
    for (i=0; i<nsamplesIn; i++) sbufIn[i] = 0;

    /* Read input singal from fin. */
    if ( fread( sbufIn, sizeof(short), nsamplesIn, fpin ) == 0 )
      break;

    /* Encode. */
    status = pcmswbEncode( sbufIn, cbufOut, theEncoder );

    if ( status ) {
      fprintf(stderr, "Encoder NG. Exiting.\n");
      exit(1);
    }

    if( params.format == 0 ) {   /* G.192 softbit output format */
      /* Write main header */
      sbufOut[0] = G192_SYNCHEADER;
      sbufOut[idxG192_BitstreamLength] = (unsigned short)nbitsOut;

      /* Convert from hardbit to softbit. */
      hardbit2softbit( (Word16)nbytesOut, cbufOut, &sbufOut[G192_HeaderSize] );

      /* Write bitstream. */
      fwrite( sbufOut, sizeof(short), G192_HeaderSize+nbitsOut, fpcode );
    }
    else {   /* Hardbit output format */
      /* Write bitstream. */
      fwrite( cbufOut, sizeof(char), nbytesOut, fpcode );
    }
  }

#ifdef WMOPS
  setCounter(Id);
  fwc();
#ifndef SUPPRESS_COUNTER_RESULTS
  WMOPS_output(0);
#endif
#endif

  /* Close files. */
  fclose(fpin);
  fclose(fpcode);

  /* Delete the encoder. */
  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/  
  pcmswbEncode_dest( theEncoder );

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_REPORT();
#endif
  /*****************************/

  return 0;
}
