/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: highband_dec.h
 *  Function: Layer 2 (Higher-band) decoder
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "G711WB_highband.h"
#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"
#include "fec_highband.h"
#include "bwe.h"
#include "g711enh.h"


/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

#define DECODER_OK  2
#define DECODER_NG  3

/*----------------------------------------------------------------
  Function:
    Higher-band decoder constructor
  Return value
    Pointer to work space
  ----------------------------------------------------------------*/
void* highband_decode_const(void)
{
  VQD_State  *dec_st=NULL;

  dec_st = (VQD_State *)malloc( sizeof(VQD_State) );
  if (dec_st == NULL) return NULL;

  highband_decode_reset( (void *)dec_st );

  return (void *)dec_st;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void  highband_decode_dest(
  void *work        /* (i): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;

  if (dec_st != NULL)  free( dec_st );
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder reset
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
Word16   highband_decode_reset(
  void *work        /* (i/o): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;

  IF (dec_st != NULL) {
	zero16(sizeof(dec_st)/2, (Word16 *)work);
    dec_st->reset = 1;	move16();
    dec_st->hbfec_st.first_loss_frame = 1; move16();
    dec_st->hbfec_st.att_weight = 32767;   move16();

  }
  return DECODER_OK;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
Word16   highband_decode(
  const unsigned char *bitstream,  /* (i): Input bitstream                */
  Word16                 erasure,     /* (i): FER flag, 0:No FER/1:FER       */
  Word16              sBufout[],   /* (o): Output higher-band signal (Q0) */
  void                *work,       /* (i/o): Pointer to work space        */
  Word16                 cod_Mode,    /* (i): Mode information obtained in BWE */
  Word16              *snb_mdct,   /* (o): Q(sSpectrumQ) */
  Word16              *smdct_err,  /* (i): MDCT coefficetnts errors quantized in SHB layer Q(smdct_errQ) */
  const Word16         *pBit_g,     /* (i): Input bitstream for correction factors */
  Word16                 bitratemode, /* (i): Bitrate mode  */
  Word16                 bit_switch_flag,
  const Word16        sattenu,     /* (i): Q(15) */
  Word16              *smdct_errQ
) {
  VQD_State *dec_st=(VQD_State *)work;
  Word16 i;
  INDEX    index;                            /* Gain and VQ indices              */
  Word16   sSpectrum[L_FRAME_NB];      /* MDCT coefficients, Q(sQspectrum) */

  Word16   sSpectrumQ = 0;                   /* Q of sSpectrum[]                 */
  Word16   sOut[L_FRAME_NB];           /* Decoded signal, Q0               */
  Word16   diffQ, norm;
  Word16   smdct_corr[L_FRAME_NB]; /* Q14 */
  Word16   ssb_err[12];            /* Q(sSpectrumQ)) */

  Word16    s_idx, e_idx;

  move16();
  zero16( L_FRAME_NB, sSpectrum);
  zero16( L_FRAME_NB, sOut);
  zero16( L_FRAME_NB, smdct_corr);
  zero16( 12, ssb_err);


  IF (erasure == 0)    /* No FER */
  {
    /* deMUX of indices */
    demux_bitstream(&index, (unsigned char *)bitstream);

    /* De-quantize MDCT coefficients */
    VQdecode_spectrum(
        index.wvq,      /* (i) */
        index.pow,      /* (i) */
        &sSpectrum[4],  /* (o) Q(sQspectrum) */
        &sSpectrumQ     /* (o) */
    );

    /* Windowing */
    zero16(4, sSpectrum);

    sSpectrum[4] = mult_r( sSpectrum[4],  4277 ); /* *= sin(   PI/24) */
    sSpectrum[5] = mult_r( sSpectrum[5], 12540 ); /* *= sin( 3*PI/24) */
    sSpectrum[6] = mult_r( sSpectrum[6], 19948 ); /* *= sin( 5*PI/24) */
    sSpectrum[7] = mult_r( sSpectrum[7], 25997 ); /* *= sin( 7*PI/24) */
    sSpectrum[8] = mult_r( sSpectrum[8], 30274 ); /* *= sin( 9*PI/24) */
    sSpectrum[9] = mult_r( sSpectrum[9], 32488 ); /* *= sin(11*PI/24) */
    move16(); move16(); move16(); move16(); move16(); move16();

    array_oper(L_FRAME_NB, 1, sSpectrum, sSpectrum, &shr);

    sSpectrumQ = sub (sSpectrumQ, 1);

    /* add quantized error in MDCT coefficients */
    norm = Exp16Array(L_FRAME_NB, sSpectrum);
    norm = sub (norm, 2);
    sSpectrumQ = add (sSpectrumQ, norm);

    IF (sub ((Word16) cod_Mode, TRANSIENT) != 0)
    {
        diffQ = sub (*smdct_errQ, sSpectrumQ);
        array_oper(16, diffQ, smdct_err, smdct_err, &shr_r);
    }

    array_oper(L_FRAME_NB, norm, sSpectrum, sSpectrum, &shl_r);


  	IF (sub ((Word16) bit_switch_flag, 1) == 0)
	  {
		  FOR (i=6; i<16; i++)
		  {
			  smdct_err[i] = shr_r (sSpectrum[26-i], 1); move16 (); /* Q(sSpectrumQ) */	
		  }
	  }
	  ELSE IF (sub ((Word16) bit_switch_flag, 2) == 0)
	  {
          array_oper(10, sattenu, smdct_err+6, smdct_err+6, &mult_r);
	  }


    IF (sub ((Word16) cod_Mode, TRANSIENT) == 0)
    {
      FOR (i=0; i<10; i++)
      {
        sSpectrum[10-i] = add (sSpectrum[10-i], shr_r(add (smdct_err[i], sSpectrum[20-i]), 1)); move16();	
      }
    }
    ELSE
    {
      FOR (i=0; i<16; i++)
      {
        sSpectrum[15-i] = add (sSpectrum[15-i], smdct_err[i]); move16();	
      }
    }

    test();
    IF ((sub ((Word16) bitratemode, MODE_R4sm) == 0) || (sub ((Word16) bitratemode, MODE_R5ssm) == 0) )
    {
/*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_PUSH((L_FRAME_NB * SIZE_Word16 + 2 * SIZE_Word16) + (12 * SIZE_Word16 + 2 * SIZE_Word16), "dummy"); /* mdct_corr[], diffQ, norm, sb_err[], s_idx, e_idx */
#endif
/*****************************/  

      g711el1_decode (pBit_g, (const Word16*) sSpectrum, smdct_corr, ssb_err, &s_idx, &e_idx, sSpectrumQ);

      FOR (i=0; i<L_FRAME_NB; i++)
      {
        sSpectrum[i] = shl (mult_r (sSpectrum[i], smdct_corr[i]), 1); move16 (); /* Q(sSpectrumQ):sSpectrumQ+14+1-16+1 */
        
			}
      
      FOR (i = s_idx; i < e_idx; i++)
      {
        sSpectrum[i] = add (sSpectrum[i], ssb_err[i-s_idx]); move16 (); /* Q(sSpectrumQ) */	
      }

/*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_POP();
#endif
/*****************************/
    }
    mov16(L_FRAME_NB, sSpectrum, snb_mdct );
  }

  /* iMDCT */
  inv_mdct( sOut, sSpectrum, dec_st->sPrev, sSpectrumQ,
            &dec_st->sSpectrumQ_pre,
            (Word16)erasure, dec_st->sCurSave,
            &dec_st->hbfec_st  /* higher-band buffer for FERC */
			,0 
			);

  /* Mute at first frame after reset */
  IF (dec_st->reset != 0)
  {
    zero16(L_FRAME_NB, sOut);
    dec_st->reset = 0; move16();
  }

  /* Update higher-band FERC buffer */
  IF (erasure == 0) {
    update_hb_buf(dec_st->hbfec_st.hb_buf, sOut);
  }

  /* Copy decoded signal to output buffer */
  mov16(L_FRAME_NB, sOut, sBufout);
  
  return sSpectrumQ;
}
