/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"

/*----------------------------------------------------------------
  Function:
    MUX (bit-packing) of Layer 2 indices
  Return value:
    0
  ----------------------------------------------------------------*/
Word16 mux_bitstream(
  INDEX * index,
  unsigned char *bitstream
)
{
  Word16     i;
  Word16  stmp1, stmp2;
  Word16  *idx=index->wvq;


  FOR ( i=0; i<3; i++ )
  {
    stmp1 = shl (s_and(idx[0], 0x003F), 2);  /* 6 bits */
    stmp2 = shr (s_and(idx[6], 0x0030), 4);  /* 2 bits */
    bitstream[0] = (unsigned char)s_or(stmp1,stmp2); move16();

    stmp1 = shl (s_and(idx[6], 0x000F), 4);  /* 4 bits */
    stmp2 = shr (s_and(idx[1], 0x003C), 2);  /* 4 bits */
    bitstream[1] = (unsigned char)s_or(stmp1,stmp2); move16();

    stmp1 = shl (s_and(idx[1], 0x0003), 6);  /* 2 bits */
    stmp2 = s_and (idx[7], 0x003F);          /* 6 bits */
    bitstream[2] = (unsigned char)s_or(stmp1,stmp2); move16();

    idx += 2;	
    bitstream += 3;	
  }
  bitstream[0] = (unsigned char)index->pow;  move16();  /* 8 bits */

  return 0;
}

/*----------------------------------------------------------------
  Function:
    deMUX (bit-unpacking) of Layer 2 indices
  Return value:
    0
  ----------------------------------------------------------------*/
Word16 demux_bitstream(
  INDEX * index,
  unsigned char *bitstream
)
{
  Word16     i;
  Word16  stmp1, stmp2;
  Word16  *idx=index->wvq;

  FOR ( i=0; i<3; i++ )
  {
    stmp1 = shr (s_and((Word16)bitstream[0], 0x00FC), 2);  /* 6 bits */
    idx[0] = stmp1;  move16();

    stmp1 = shl (s_and((Word16)bitstream[0], 0x0003), 4);  /* 2 bits */
    stmp2 = shr (s_and((Word16)bitstream[1], 0x00F0), 4);  /* 4 bits */
    idx[6] = s_or(stmp1, stmp2);  move16();

    stmp1 = shl (s_and((Word16)bitstream[1], 0x000F), 2);  /* 4 bits */
    stmp2 = shr (s_and((Word16)bitstream[2], 0x00C0), 6);  /* 2 bits */
    idx[1] = s_or(stmp1, stmp2);  move16();

    stmp1 = s_and (bitstream[2], 0x003F);                  /* 6 bits */
    idx[7] = stmp1;  move16();

    idx += 2;
    bitstream += 3;
  }
  index->pow = bitstream[0];  move16();  /* 8 bits */

  return 0;
}
