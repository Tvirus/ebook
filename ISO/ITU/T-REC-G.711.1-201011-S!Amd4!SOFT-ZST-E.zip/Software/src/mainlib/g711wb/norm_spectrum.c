/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"
#include "oper_32b.h"

#define INV_N_FR_FREQ    29127    /* 1/36 in Q20 */

/*----------------------------------------------------------------
  Function:
    Normalizes MDCT coefficients by RMS.
  Return value:
    0
  ----------------------------------------------------------------*/
Word16 norm_spectrum(
  Word16  sSpectrum[], /* (i): MDCT coefficients, Q(sExpSpect) */
  Word16  sExpSpect,   /* (i): Q of sSpectrum[]                */
  Word16  sNormSpec[], /* (o): Normalized coefficients, Q12    */
  Word16* psGain,      /* (o): Normalizing gain, Q(sExpGain)   */
  Word16* psExpGain    /* (o): Q of sGain                      */
) {
  Word16     i;
  Word16  sNorm;
  Word32  lAcc;
  Word32  lTmp;
  Word16  hi;
  Word16  lo;
  Word16  sAcc;
  Word16  sExp;

  /* acc = sum (spectrum[] * spectrum[]) */
  lAcc = 0;  move32();
  FOR (i = 0; i < N_FR_FREQ; i++)
  {
    lTmp = L_mult0( sSpectrum[i], sSpectrum[i] ); /*Q(2*sExpSpect)   */
    lAcc = L_add( lAcc, L_shr( lTmp, 6 ) );       /*Q(-6+2*sExpSpect)*/
  }

  /* acc / N_FR_FREQ */
  L_Extract( lAcc, &hi, &lo );
  lAcc = Mpy_32_16( hi, lo, INV_N_FR_FREQ );
                          /*Q(-1+2*sExpSpect)=Q(-6+2*sExpSpect+20-15)        */
  /* rms = sqrt( acc ) */
  SqrtI31( lAcc, &lAcc ); /*Q(15+sExpSpect)=Q(31-((31-(-1+2*sExpSpect))/2)   */

  /* gain = rms+EPS */
  lAcc = L_add( lAcc, 0x8000L ); /* Q(15+sExpSpect) */
  sAcc = Cnv32toNrm16( lAcc, &sExp );
                          /*Q(-1+sExpSpect+sExp)=Q(15+sExpSpect+sExp-16)     */
  *psGain = sAcc;     move16();
  *psExpGain = add(-1,add(sExpSpect,sExp)); /* -1+sExpSpect+sExp */

  /* norm = 1.0 / gain */
  sNorm = div_s( 0x1000/*Q12*/, sAcc );
                          /*Q(28-sExpSpect-sExp)=Q(15+12-(-1+sExpSpect+sExp))*/

  /* Normalization of spectrum       */
  /* normspec[] = spectrum[] * norm  */
  FOR (i = 0; i < N_FR_FREQ; i++)
  {
    sNormSpec[i] = extract_h( L_shl( L_mult0( sSpectrum[i], sNorm ), sExp) ); move16();
                         /*Q12=Q(sExpSpect+(28-sExpSpect-sExp)+sExp-16)     */
  }

  return 0;
}
