/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: cfft.h
 *  Function: complex FFT headers
 *------------------------------------------------------------------------
 */

#ifndef CFFT_H
#define CFFT_H

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      cfft(Word16 * x1, Word16 * x2, Word16 sign, Word16 mode);

/* Tables : */

extern const Word16 MDCT_tab_map[MDCT_NP*MDCT_NPP];
extern const Word16 MDCT_tab_map2[MDCT_NP*MDCT_NPP];
extern const Word16 MDCT_tab_rev_i[MDCT_NB_REV];
extern const Word16 MDCT_tab_rev_ipp[MDCT_NB_REV];
extern const Word16 MDCT_rw1[MDCT_L_WIN4];
extern const Word16 MDCT_rw2[MDCT_L_WIN4];
extern const Word16 MDCT_xcos[25];
extern const Word16 MDCT_xsin[25];

extern const Word16 MDCT_tab_map_swb[MDCT2_NP*MDCT2_NPP];
extern const Word16 MDCT_tab_map2_swb[MDCT2_NP*MDCT2_NPP];
extern const Word16 MDCT_tab_rev_ipp_swb[MDCT2_EXP_NB_REV];
extern const Word16 MDCT_tab_rev_i_swb[MDCT2_EXP_NB_REV];
extern const Word16 MDCT_rw1_tbl_swb[MDCT2_SBARYSZ];
extern const Word16 MDCT_rw2_tbl_swb[MDCT2_SBARYSZ];
extern const Word16 MDCT_xcos_swb[MDCT2_NP*MDCT2_NP];
extern const Word16 MDCT_xsin_swb[MDCT2_NP*MDCT2_NP];

#endif /* CFFT_H */
