/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"

static void   acc_opt_gain_param(Word16*, Word16*, Word32*, Word32*);
static Word16 get_opt_gain(Word32, Word32, Word16, Word16);

/*----------------------------------------------------------------
  Function:
    Quantizes normalized MDCT coefficients.
  Return value
    0
  ----------------------------------------------------------------*/
Word16 VQencode_spectrum(
  Word16  sNormSpec[],  /* (i): Normalized coefficients, Q12   */
  Word16  index_wvq[],  /* (o): VQ indices                     */
  Word16  sGain,        /* (i): Normalization RMS, Q(sExpGain) */
  Word16  sExpGain,     /* (i): Q of sGain                     */
  Word16  *index_pow    /* (o): Gain index                     */
) {
  Word16     i, j;
  Word16     nDiv;
  Word32  lNume;                      /* Q23 */
  Word32  lDenom;                     /* Q23 */
  Word16  sTargetv[N_DIV][VECLEN];    /* Target subvectors, Q12 */
  Word32  lCanMeas0[N_CAN];           /* Q22 */
  Word32  lCanMeas1[N_CAN];           /* Q22 */
  Word16  sCanSign0[N_CAN];           /* Q14 */
  Word16  sCanSign1[N_CAN];           /* Q14 */
  Word16  sCanIndx0[N_CAN];           /* Candidate indices for channel 0 */
  Word16  sCanIndx1[N_CAN];           /* Candidate indices for channel 1 */
  Word16  sLocalv[VECLEN];            /* Locally decoded subvector, Q12  */
  Word16  sGopt;                      /* Optimal gain */

  /* Parameters for gain quantization */
  lNume  = 0;  move32();              /* Q23 */
  lDenom = 1;  move32();              /* Q23 */

  /* Interleaving */
  i = N_FR_FREQ - 1;	
  FOR (j = 0; j < VECLEN; j++)
  {
    sTargetv[0][j] = sNormSpec[i--]; move16();
    sTargetv[1][j] = sNormSpec[i--]; move16();
    sTargetv[2][j] = sNormSpec[i--]; move16();
    sTargetv[3][j] = sNormSpec[i--]; move16();
    sTargetv[4][j] = sNormSpec[i--]; move16();
    sTargetv[5][j] = sNormSpec[i--]; move16();
  }

  /* Quantize subvectors */
  FOR (nDiv = 0; nDiv < N_DIV; nDiv++)
  {
    /* Pre-selection of channel 0 */
    vq_preselect(
        sTargetv[nDiv],        /* Q12 */
        gsCodebook_0ch,        /* Q12 */
        glCodebook_0ch_pow,    /* Q22 */
        lCanMeas0,             /* Q22 */
        sCanSign0,             /* Q14: 1 or -1 */
        sCanIndx0
    );

    /* Pre-selection of channel 1 */
    vq_preselect(
        sTargetv[nDiv],        /* Q12 */
        gsCodebook_1ch,        /* Q12 */
        glCodebook_1ch_pow,    /* Q22 */
        lCanMeas1,             /* Q22 */
        sCanSign1,             /* Q14: 1 or -1 */
        sCanIndx1
    );

    /* Main selection */
    vq_mainselect(
        sCanIndx0,             /* Candidate indices of channel 0 */
        sCanIndx1,             /* Candidate indices of channel 1 */
        &index_wvq[nDiv],      /* Selected VQ indices */
        lCanMeas0,             /* Q22 */
        lCanMeas1,             /* Q22 */
        sCanSign0,             /* Q14: 1 or -1 */
        sCanSign1,             /* Q14: 1 or -1 */
        sLocalv                /* Q12 */
    );

    /* Parameter calculation for gain quantization */
    acc_opt_gain_param(
        sTargetv[nDiv],        /* Q12 */
        sLocalv,               /* Q12 */
        &lNume,                /* Q23 */
        &lDenom                /* Q23 */
    );
  }

  /* Obtain adjusted gain */
  sGopt = get_opt_gain (lNume, lDenom, sGain, sExpGain);

  /* Mu-law quantization of the adjusted gain */
  *index_pow = mulaw( sGopt );

  return 0;
}

/* Parameter calculation for gain quantization */
static void acc_opt_gain_param(
  Word16  sTargetv[],   /* (i): Target subvector, Q12          */
  Word16  sLocalv[],    /* (i): Locally decoded subvector, Q12 */
  Word32  *plNume,      /* (i/o): Q23                          */
  Word32  *plDenom      /* (i/o): Q23                          */
)
{
  Word32  lNume0;
  Word32  lDenom0;

  lNume0 = L_mac0_Array(VECLEN, sTargetv, sLocalv);
  lDenom0 = L_mac0_Array(VECLEN, sLocalv, sLocalv);

  *plNume  = L_add( *plNume,  L_shr(lNume0,1) );  /* Q23 */
  *plDenom = L_add( *plDenom, L_shr(lDenom0,1) ); /* Q23 */
}

/* Get adjusted (optimal) gain */
static Word16 get_opt_gain(
  Word32  lNume,        /* (i): Q23 */
  Word32  lDenom,       /* (i): Q23 */
  Word16  sGain,        /* (i): Normalizing RMS, Q(sExpGain) */
  Word16  sExpGain      /* (i): Q of sGain                   */
) {
  Word16  sGopt;
  Word16  sDen;
  Word16  sNum;
  Word16  sInvDen;
  Word16  sNumQ;
  Word16  sDenQ;
  Word32  lAcc;
  Word16  sAcc;

  /* gopt = nume/denom = nume*(1.0/denom) */

  sDen = Cnv32toNrm16( lDenom, &sDenQ );  /*Q(7+sDenQ) = Q(23+sDenQ-16)      */
  sInvDen = div_s( 0x2000/*Q13*/, sDen ); /*Q(21-sDenQ) = Q(15+13-(7+sDenQ)) */

  sNum = Cnv32toNrm16( lNume, &sNumQ );   /*Q(7+sNumQ) = Q(23+sNumQ-16)      */

  sNum = mult_r (sNum, sGain); /*Q(-8+sExpGain+sNumQ)=Q(7+sNumQ+sExpGain-15)     */
  sNum = mult_r (sNum, GSCALE_FACT); /*Q(-12+sExpGain+sNumQ)=Q(-8+sExpGain+sNumQ+11-15)*/

  lAcc = L_mult0(sNum, sInvDen);
                       /*Q(9+sExpGain+sNumQ-sDenQ)=Q(-12+sExpGain+sNumQ+21-sDenQ)*/

  sAcc = add( sub(sub (16-9, sExpGain), sNumQ), sDenQ);	

  sGopt = round_fx( L_shl( lAcc, sAcc ) );  /* Q0 */

  return sGopt;
}
