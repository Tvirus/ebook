/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"

/*----------------------------------------------------------------
  Function:
    Mu-law compression of gain, 8bit, u=255
  Return value
    Quantized value in log scale
  ----------------------------------------------------------------*/
Word16 mulaw(Word16 linbuf) /* in: Q0, out: Q0 */
{
  Word16  absno;
  Word16  exponent;
  Word16  mantissa;
  Word16  logbuf;

  IF ( sub(linbuf,4) < 0 )
  {
    logbuf = s_and (linbuf, 0x3);
  }
  ELSE
  {
    absno = add(linbuf, 130);

    exponent = sub(7, norm_s(absno));

    mantissa = shr(sub(shr(absno, exponent), 128), 2);
    logbuf = add(shl(exponent, 5), mantissa);

    logbuf = add( logbuf, 3 );

    logbuf = s_min(255, logbuf);

  }

  return logbuf;  /* Q0 */
}
