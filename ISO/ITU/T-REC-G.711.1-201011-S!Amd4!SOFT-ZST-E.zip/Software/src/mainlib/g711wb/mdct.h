/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: MDCT headers
 *------------------------------------------------------------------------
 */

#ifndef MDCT_H
#define MDCT_H

#include <stdio.h>
#include "stl.h"
#include "fec_highband.h"

/* Functions : */
void mdct (Word16 * mem, Word16 * input, Word16 * ykr, Word16 *norm_shift, Word16 mode);
void inv_mdct (Word16 * xr, Word16 * ykq, Word16 * ycim1, Word16 norm_shift, Word16 * norm_pre, Word16, Word16 *, HBFEC_State *, Word16 mode);

/* Tables : */

extern const Word16 MDCT_h[MDCT_L_WIN];
extern const Word16 MDCT_wcos[MDCT_L_WIN4];
extern const Word16 MDCT_wsin[MDCT_L_WIN4];
extern const Word16 MDCT_wetr[MDCT_L_WIN4];
extern const Word16 MDCT_weti[MDCT_L_WIN4];
extern const Word16 MDCT_wetrm1[MDCT_L_WIN4];
extern const Word16 MDCT_wetim1[MDCT_L_WIN4];

extern const Word16 MDCT_h_swb[MDCT2_L_WIN2];
extern const Word16 MDCT_wsin_swb[MDCT2_L_WIN4+1];
extern const Word16 MDCT_wetr_swb[MDCT2_L_WIN4];
extern const Word16 MDCT_weti_swb[MDCT2_L_WIN4];
extern const Word16 MDCT_wetrm1_swb[MDCT2_L_WIN4];
extern const Word16 MDCT_wetim1_swb[MDCT2_L_WIN4];

#endif /* MDCT_H */
