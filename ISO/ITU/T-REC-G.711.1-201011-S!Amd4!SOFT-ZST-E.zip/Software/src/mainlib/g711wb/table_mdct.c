/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
*------------------------------------------------------------------------
*  File: table_mdct.c
*  Function: tables for MDCT computation
*------------------------------------------------------------------------
*/

#include "pcmswb_common.h"
#include "defines_mdct.h"


/***************************************************************
*                                                             *
*             MDCT COMPUTATION TABLES                         *
*                                                             *
***************************************************************/

/* Cosine table for FFT, Q15 */
const Word16 MDCT_xcos[MDCT_NP*MDCT_NP] = {	
  (Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767, 
  (Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126, 
  (Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510, 
  (Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510, 
  (Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126 
};

/* Sine table for FFT, Q15 */
const Word16 MDCT_xsin[MDCT_NP*MDCT_NP] = {	
  (Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0, 
  (Word16)     0, (Word16)-31164, (Word16)-19261, (Word16) 19261, (Word16) 31164, 
  (Word16)     0, (Word16)-19261, (Word16) 31164, (Word16)-31164, (Word16) 19261, 
  (Word16)     0, (Word16) 19261, (Word16)-31164, (Word16) 31164, (Word16)-19261, 
  (Word16)     0, (Word16) 31164, (Word16) 19261, (Word16)-19261, (Word16)-31164 
};

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map[MDCT_NP*MDCT_NPP] = {	
  (Word16)     0, (Word16)     5, (Word16)    10, (Word16)    15, (Word16)    16, (Word16)     1, (Word16)     6, (Word16)    11, (Word16)    12, (Word16)    17, 
  (Word16)     2, (Word16)     7, (Word16)     8, (Word16)    13, (Word16)    18, (Word16)     3, (Word16)     4, (Word16)     9, (Word16)    14, (Word16)    19 
};

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map2[MDCT_NP*MDCT_NPP] = {
  (Word16)     0, (Word16)     5, (Word16)    10, (Word16)    15, (Word16)     4, (Word16)     9, (Word16)    14, (Word16)    19, (Word16)     8, (Word16)    13, 
  (Word16)    18, (Word16)     3, (Word16)    12, (Word16)    17, (Word16)     2, (Word16)     7, (Word16)    16, (Word16)     1, (Word16)     6, (Word16)    11 
};

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_ipp[MDCT_NB_REV] = {
  (Word16)     1 
};

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_i[MDCT_NB_REV] = {
  (Word16)     2 
};

/* FFT twiddle factors (cosine part), Q15 */
const Word16 MDCT_rw1[MDCT_L_WIN4] = {
  (Word16) 32767, (Word16) 31164, (Word16) 26510, (Word16) 19261, (Word16) 10126, 
  (Word16)     0, (Word16)-10126, (Word16)-19261, (Word16)-26510, (Word16)-31164, 
  (Word16)-32767, (Word16)-31164, (Word16)-26510, (Word16)-19261, (Word16)-10126, 
  (Word16)     0, (Word16) 10126, (Word16) 19261, (Word16) 26510, (Word16) 31164 
};

/* FFT twiddle factors (sine part), Q15 */
const Word16 MDCT_rw2[MDCT_L_WIN4] = {
  (Word16)     0, (Word16) 10126, (Word16) 19261, (Word16) 26510, (Word16) 31164, 
  (Word16) 32767, (Word16) 31164, (Word16) 26510, (Word16) 19261, (Word16) 10126, 
  (Word16)     0, (Word16)-10126, (Word16)-19261, (Word16)-26510, (Word16)-31164, 
  (Word16)-32767, (Word16)-31164, (Word16)-26510, (Word16)-19261, (Word16)-10126 
};

/* Cosine table for MDCT and iMDCT, Q15 */
/* const Word16 MDCT_wcos[MDCT_L_WIN4] is no longer used */

/* Sine table for MDCT and iMDCT, Q15 */
const Word16 MDCT_wsin[MDCT_L_WIN4+ 1] = {
  (Word16)     0, (Word16)  2571, (Word16)  5126, (Word16)  7650, (Word16) 10126, 
  (Word16) 12540, (Word16) 14876, (Word16) 17121, (Word16) 19261, (Word16) 21281, 
  (Word16) 23170, (Word16) 24917, (Word16) 26510, (Word16) 27939, (Word16) 29197, 
  (Word16) 30274, (Word16) 31164, (Word16) 31863, (Word16) 32365, (Word16) 32667 , (Word16)32767 
};

/* Table for complex post-multiplication in MDCT (real part), Q21 */
const Word16 MDCT_wetr[MDCT_L_WIN4] = {
  (Word16)-18897, (Word16) 20264, (Word16)-21506, (Word16) 22616, (Word16)-23586, 
  (Word16) 24411, (Word16)-25086, (Word16) 25605, (Word16)-25967, (Word16) 26169, 
  (Word16)-26209, (Word16) 26088, (Word16)-25806, (Word16) 25365, (Word16)-24768, 
  (Word16) 24017, (Word16)-23119, (Word16) 22078, (Word16)-20901, (Word16) 19595 
};

/* Table for complex post-multiplication in MDCT (imaginary part), Q21 */
const Word16 MDCT_weti[MDCT_L_WIN4] = {
  (Word16) 18169, (Word16)-16630, (Word16) 14989, (Word16)-13256, (Word16) 11440, 
  (Word16) -9554, (Word16)  7610, (Word16) -5618, (Word16)  3592, (Word16) -1543, 
  (Word16)  -515, (Word16)  2569, (Word16) -4608, (Word16)  6619, (Word16) -8589, 
  (Word16) 10505, (Word16)-12357, (Word16) 14133, (Word16)-15822, (Word16) 17413 
};

/* Table for complex pre-multiplication in iMDCT (real part), Q14 */
const Word16 MDCT_wetrm1[MDCT_L_WIN4] = {
  (Word16)-23621, (Word16) 25330, (Word16)-26883, (Word16) 28270, (Word16)-29483, 
  (Word16) 30514, (Word16)-31357, (Word16) 32007, (Word16)-32459, (Word16) 32711, 
  (Word16)-32762, (Word16) 32610, (Word16)-32258, (Word16) 31706, (Word16)-30959, 
  (Word16) 30022, (Word16)-28899, (Word16) 27598, (Word16)-26127, (Word16) 24494 
};

/* Table for complex pre-multiplication in iMDCT (imaginary part), Q14 */
const Word16 MDCT_wetim1[MDCT_L_WIN4] = {
  (Word16)-22711, (Word16) 20788, (Word16)-18736, (Word16) 16569, (Word16)-14300, 
  (Word16) 11943, (Word16) -9512, (Word16)  7022, (Word16) -4490, (Word16)  1929, 
  (Word16)   643, (Word16) -3212, (Word16)  5760, (Word16) -8274, (Word16) 10736, 
  (Word16)-13132, (Word16) 15447, (Word16)-17666, (Word16) 19777, (Word16)-21766 
};

/* MDCT window, Q14 */
const Word16 MDCT_h[MDCT_L_WIN] = {
  (Word16)   455, (Word16)  1364, (Word16)  2271, (Word16)  3175, (Word16)  4073, 
  (Word16)  4966, (Word16)  5850, (Word16)  6726, (Word16)  7591, (Word16)  8445, 
  (Word16)  9286, (Word16) 10112, (Word16) 10922, (Word16) 11716, (Word16) 12492, 
  (Word16) 13249, (Word16) 13985, (Word16) 14699, (Word16) 15391, (Word16) 16059, 
  (Word16) 16703, (Word16) 17320, (Word16) 17911, (Word16) 18474, (Word16) 19009, 
  (Word16) 19515, (Word16) 19990, (Word16) 20435, (Word16) 20848, (Word16) 21229, 
  (Word16) 21577, (Word16) 21892, (Word16) 22173, (Word16) 22420, (Word16) 22632, 
  (Word16) 22810, (Word16) 22952, (Word16) 23059, (Word16) 23130, (Word16) 23166, 
  (Word16) 23166, (Word16) 23130, (Word16) 23059, (Word16) 22952, (Word16) 22810, 
  (Word16) 22632, (Word16) 22420, (Word16) 22173, (Word16) 21892, (Word16) 21577, 
  (Word16) 21229, (Word16) 20848, (Word16) 20435, (Word16) 19990, (Word16) 19515, 
  (Word16) 19009, (Word16) 18474, (Word16) 17911, (Word16) 17320, (Word16) 16703, 
  (Word16) 16059, (Word16) 15391, (Word16) 14699, (Word16) 13985, (Word16) 13249, 
  (Word16) 12492, (Word16) 11716, (Word16) 10922, (Word16) 10112, (Word16)  9286, 
  (Word16)  8445, (Word16)  7591, (Word16)  6726, (Word16)  5850, (Word16)  4966, 
  (Word16)  4073, (Word16)  3175, (Word16)  2271, (Word16)  1364, (Word16)   455 
};

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map_swb[MDCT2_NP*MDCT2_NPP] = {	
  (Word16)     0, (Word16)    25, (Word16)    10, (Word16)    35, (Word16)    20, (Word16)     5, (Word16)    30, (Word16)    15,
  (Word16)    16, (Word16)     1, (Word16)    26, (Word16)    11, (Word16)    36, (Word16)    21, (Word16)     6, (Word16)    31,
  (Word16)    32, (Word16)    17, (Word16)     2, (Word16)    27, (Word16)    12, (Word16)    37, (Word16)    22, (Word16)     7,
  (Word16)     8, (Word16)    33, (Word16)    18, (Word16)     3, (Word16)    28, (Word16)    13, (Word16)    38, (Word16)    23,
  (Word16)    24, (Word16)     9, (Word16)    34, (Word16)    19, (Word16)     4, (Word16)    29, (Word16)    14, (Word16)    39
};

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map2_swb[MDCT2_NP*MDCT2_NPP] = {	
  (Word16)     0, (Word16)     5, (Word16)    10, (Word16)    15, (Word16)    20, (Word16)    25, (Word16)    30, (Word16)    35,
  (Word16)     8, (Word16)    13, (Word16)    18, (Word16)    23, (Word16)    28, (Word16)    33, (Word16)    38, (Word16)     3,
  (Word16)    16, (Word16)    21, (Word16)    26, (Word16)    31, (Word16)    36, (Word16)     1, (Word16)     6, (Word16)    11,
  (Word16)    24, (Word16)    29, (Word16)    34, (Word16)    39, (Word16)     4, (Word16)     9, (Word16)    14, (Word16)    19,
  (Word16)    32, (Word16)    37, (Word16)     2, (Word16)     7, (Word16)    12, (Word16)    17, (Word16)    22, (Word16)    27,
};

/* MDCT window, Q14 */
const Word16 MDCT_h_swb[MDCT2_L_WIN2] = {
  (Word16)   227, (Word16)   682, (Word16)  1137, (Word16)  1591, (Word16)  2045, (Word16)  2497, (Word16)  2949, (Word16)  3400, (Word16)  3849, (Word16)  4297,
  (Word16)  4743, (Word16)  5188, (Word16)  5630, (Word16)  6070, (Word16)  6508, (Word16)  6943, (Word16)  7376, (Word16)  7806, (Word16)  8233, (Word16)  8656,
  (Word16)  9077, (Word16)  9494, (Word16)  9907, (Word16) 10316, (Word16) 10721, (Word16) 11123, (Word16) 11520, (Word16) 11912, (Word16) 12300, (Word16) 12683,
  (Word16) 13061, (Word16) 13435, (Word16) 13803, (Word16) 14165, (Word16) 14523, (Word16) 14874, (Word16) 15220, (Word16) 15560, (Word16) 15894, (Word16) 16222,
  (Word16) 16544, (Word16) 16859, (Word16) 17168, (Word16) 17470, (Word16) 17766, (Word16) 18054, (Word16) 18336, (Word16) 18611, (Word16) 18878, (Word16) 19138,
  (Word16) 19391, (Word16) 19636, (Word16) 19874, (Word16) 20104, (Word16) 20326, (Word16) 20541, (Word16) 20747, (Word16) 20946, (Word16) 21136, (Word16) 21319,
  (Word16) 21493, (Word16) 21659, (Word16) 21816, (Word16) 21965, (Word16) 22106, (Word16) 22238, (Word16) 22361, (Word16) 22476, (Word16) 22582, (Word16) 22680,
  (Word16) 22769, (Word16) 22849, (Word16) 22920, (Word16) 22982, (Word16) 23035, (Word16) 23080, (Word16) 23116, (Word16) 23143, (Word16) 23160, (Word16) 23169
};

/* Sine table for MDCT and iMDCT, Q15 */
const Word16 MDCT_wsin_swb[MDCT2_L_WIN4+1] = {	
  (Word16)     0, (Word16)  1286, (Word16)  2571, (Word16)  3851, (Word16)  5126, (Word16)  6393, (Word16)  7650, (Word16)  8895, (Word16) 10126, (Word16) 11342,
  (Word16) 12540, (Word16) 13719, (Word16) 14876, (Word16) 16011, (Word16) 17121, (Word16) 18205, (Word16) 19261, (Word16) 20286, (Word16) 21281, (Word16) 22243,
  (Word16) 23170, (Word16) 24062, (Word16) 24917, (Word16) 25733, (Word16) 26510, (Word16) 27246, (Word16) 27939, (Word16) 28590, (Word16) 29197, (Word16) 29758,
  (Word16) 30274, (Word16) 30743, (Word16) 31164, (Word16) 31538, (Word16) 31863, (Word16) 32138, (Word16) 32365, (Word16) 32541, (Word16) 32667, (Word16) 32743,
  (Word16) 32767
};

/* Table for complex post-multiplication in MDCT (real part), Q21 */
const Word16 MDCT_wetr_swb[MDCT2_L_WIN4] = {
  (Word16) -9359, (Word16)  9712, (Word16)-10050, (Word16) 10372, (Word16)-10679, (Word16) 10969, (Word16)-11242, (Word16) 11498, (Word16)-11736, (Word16) 11957, 
  (Word16)-12158, (Word16) 12341, (Word16)-12505, (Word16) 12649, (Word16)-12774, (Word16) 12880, (Word16)-12965, (Word16) 13031, (Word16)-13076, (Word16) 13102,
  (Word16)-13107, (Word16) 13091, (Word16)-13056, (Word16) 13001, (Word16)-12925, (Word16) 12830, (Word16)-12714, (Word16) 12580, (Word16)-12425, (Word16) 12252,
  (Word16)-12060, (Word16) 11849, (Word16)-11620, (Word16) 11373, (Word16)-11108, (Word16) 10826, (Word16)-10528, (Word16) 10213, (Word16) -9883, (Word16)  9537
};

/* Table for complex post-multiplication in MDCT (imaginary part), Q21 */
const Word16 MDCT_weti_swb[MDCT2_L_WIN4] = {
  (Word16)  9177, (Word16) -8802, (Word16)  8414, (Word16) -8013, (Word16)  7600, (Word16) -7175, (Word16)  6738, (Word16) -6292, (Word16)  5836, (Word16) -5370,
  (Word16)  4897, (Word16) -4416, (Word16)  3928, (Word16) -3434, (Word16)  2935, (Word16) -2431, (Word16)  1923, (Word16) -1413, (Word16)   900, (Word16)  -386,
  (Word16)  -129, (Word16)   643, (Word16) -1157, (Word16)  1668, (Word16) -2177, (Word16)  2683, (Word16) -3185, (Word16)  3681, (Word16) -4173, (Word16)  4657,
  (Word16) -5135, (Word16)  5604, (Word16) -6065, (Word16)  6516, (Word16) -6958, (Word16)  7389, (Word16) -7808, (Word16)  8215, (Word16) -8610, (Word16)  8991,
};

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_ipp_swb[MDCT2_EXP_NB_REV] = { 
  (Word16)     1, (Word16)     3 
};

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_i_swb[MDCT2_EXP_NB_REV] = { 
  (Word16)     4, (Word16)     6 
};

/* FFT twiddle factors (cosine part), Q15 */
const Word16 MDCT_rw1_tbl_swb[MDCT2_SBARYSZ] = {  
 (Word16)  32767, (Word16) 23170, (Word16)     0, (Word16)-23170
};

/* FFT twiddle factors (sine part), Q15 */
const Word16 MDCT_rw2_tbl_swb[MDCT2_SBARYSZ] = {      
  (Word16)     0, (Word16) 23170, (Word16) 32767, (Word16) 23170 
};

/* Cosine table for FFT, Q15 */
const Word16 MDCT_xcos_swb[MDCT2_NP*MDCT2_NP] = {	
  (Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767,
  (Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126,
  (Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510,
  (Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510,
  (Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126
};

/* Sine table for FFT, Q15 */
const Word16 MDCT_xsin_swb[MDCT2_NP*MDCT2_NP] = {	
  (Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0,
  (Word16)     0, (Word16)-31164, (Word16)-19261, (Word16) 19261, (Word16) 31164,
  (Word16)     0, (Word16)-19261, (Word16) 31164, (Word16)-31164, (Word16) 19261,
  (Word16)     0, (Word16) 19261, (Word16)-31164, (Word16) 31164, (Word16)-19261,
  (Word16)     0, (Word16) 31164, (Word16) 19261, (Word16)-19261, (Word16)-31164
};

/* Table for complex pre-multiplication in iMDCT (real part), Q14 */
const Word16 MDCT_wetrm1_swb[MDCT2_L_WIN4] = {
  (Word16)-23397, (Word16) 24279, (Word16)-25125, (Word16) 25931, (Word16)-26698, (Word16) 27423, (Word16)-28106, (Word16) 28746, (Word16)-29341, (Word16) 29891,
  (Word16)-30395, (Word16) 30853, (Word16)-31262, (Word16) 31624, (Word16)-31936, (Word16) 32200, (Word16)-32413, (Word16) 32577, (Word16)-32691, (Word16) 32754,
  (Word16)-32766, (Word16) 32729, (Word16)-32640, (Word16) 32501, (Word16)-32313, (Word16) 32074, (Word16)-31786, (Word16) 31449, (Word16)-31063, (Word16) 30630,
  (Word16)-30149, (Word16) 29622, (Word16)-29049, (Word16) 28431, (Word16)-27770, (Word16) 27066, (Word16)-26320, (Word16) 25533, (Word16)-24707, (Word16) 23843
};

/* Table for complex pre-multiplication in iMDCT (imaginary part), Q14 */
const Word16 MDCT_wetim1_swb[MDCT2_L_WIN4] = {
  (Word16)-22942, (Word16) 22006, (Word16)-21035, (Word16) 20033, (Word16)-18999, (Word16) 17937, (Word16)-16846, (Word16) 15730, (Word16)-14589, (Word16) 13426,
  (Word16)-12242, (Word16) 11039, (Word16) -9819, (Word16)  8585, (Word16) -7336, (Word16)  6077, (Word16) -4808, (Word16)  3532, (Word16) -2250, (Word16)   965,
  (Word16)   322, (Word16) -1608, (Word16)  2892, (Word16) -4171, (Word16)  5444, (Word16) -6708, (Word16)  7962, (Word16) -9204, (Word16) 10431, (Word16)-11643,
  (Word16) 12836, (Word16)-14010, (Word16) 15162, (Word16)-16291, (Word16) 17395, (Word16)-18472, (Word16) 19520, (Word16)-20538, (Word16) 21525, (Word16)-22478
};
