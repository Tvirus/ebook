/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: 80-point MDCT
 *------------------------------------------------------------------------
 */

#include "pcmswb_common.h"
#include "defines_mdct.h"
#include "cfft.h"
#include "mdct.h"
#include "dyn_ram_cnt.h"
#include "fec_highband.h"

/*---------------------------------------------------------------------------*
 * mdct()                                                                    *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~                                                *
 * Compute MDCT                                                              *
 *                                                                           *
 * Details of the MDCT computation algorithm implemented here:               *
 *                                                                           *
 * - The signal x(n) is divided into blocks of N successive samples          *
 *   with N=80 (with 50% overlap between blocks)                             * 
 *                                                                           *
 * - The samples x(n) are windowed to obtain                                 *
 *                                                                           *
 *                            yn = x(n).h(N-1-n)                             *
 *                                                                           *
 *   where h(N-1-n) is the following weighting law:                          *
 *                                                                           *
 *        h(N-1-n) = sqrt(2)/80 * sin( pi/N * (n+0.5) ), n=0...N-1           *
 *                                                                           *
 *   The window h(n) is symmetric,                                           *
 *   i.e. h(N-1-n) = h(n), n=0...N-1                                         *
 *                                                                           *
 * - The discrete modified discrete cosine transform (MDCT) of blocks of     *
 *   x(n) is calculated using the even order transform                       *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( 2n/(4N).(2n+1).(4k+1)+(4k+1).pi/4)               *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 *  In the equation above, the cosine operand can be written:                *
 *                                                                           *
 *    2pi/(4N).(2n+1).(2(2k)+1)+(2(2k)+1).pi/4                               *
 *     = (pi/(N/2).(n+0.5) + pi/4) . ((2k)+0.5)                              *
 *     = pi/(N/2).(n+0.5+N/4).((2k)+0.5)                                     *
 *                                                                           *
 *  Therefore, the MDCT can be also written as:                              *
 *                                                                           *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( pi/(N/2).(n+0.5+N/4).((2k)+0.5) )                *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 * IMPORTANT NOTE (to obtain odd order coefficients YN-1-2k through Y2k):    *
 * YN-k = -Yk-1 for k=0...N-1                                                *
 *                                                                           *
 * - The even order coefficients Y2k are calculated in the form of an        *
 *   invertible complex transform as follows:                                *
 *                                                                           *
 *    Y2k+N/4 + jY2k =                                                       *
 *                  N/4-1                                                    *
 *                 ------                                                    *
 *     k+1    -1   \                                          (4k+1)(4n+1)   *
 * (-1)   . W8  .   |     ((y'n-y''n+N/4)+j(y''n+y'n+N/4)).W4N           ,   *
 *                 /                                                         *
 *                 ------                                                    *
 *                  n=0                                                      *
 *   for k=0...N/4-1                                                         *
 *                                                                           *
 * with                                                                      *
 *                                                                           *
 *    y'n  = x2n.h2n                                                         *
 *    y''n = xN-2n-1.hN-2n-1                                                 *
 *    W4N  = cos(2pi/4N)+j.sin(2pi/4N)                                       *
 *                                                                           *
 * - The invertible complex transform is calculated on the basis on the      *
 *   the following auxiliary calculation equation:                           *
 *                                                                           *
 *                                N/4-1                                      *
 *                                -----                                      *
 *            k+1    -1     4k+1  \            n      nk                     *
 *   zk = (-1)   . W8  . W4N    .  |     (zn.WN ).WN/4                       *
 *                                /                                          *
 *                                -----                                      *
 *                                 n=0                                       *
 * where                                                                     *
 *                                                                           *
 *    zn = (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n), for n=0...N/4-1             *
 *                                                                           *
 * This fast MDCT algorithm is also described in:                            *
 * "A fast algorithm for the implementation of Filter Banks based on Time    *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212  *
 *                                                                           *
 * Remark about main notations (mapping of notations):                       *
 *                                                                           *
 *   Details above          |   C code           |    Text of G.711WB        *
 *  ------------------------+--------------------+------------------------   *
 *     x(n)                 |     xin[n]         |     sHB(n)                *
 *     Y2k                  |     ykr[k]         |     SHB(k)                *
 *     s(n)                 | xin[n]<<norm_shift |  sHB(n) * 2^etaTDAC1HB    *
 *     h(N-1-n)* 80         |     hTDAC[n]       |       wTDAC(n)            *
 *                                                                           * 
 *---------------------------------------------------------------------------*/
void mdct(
  Word16 * mem,        /* (i): old input samples    */
  Word16 * input,      /* (i): input samples        */
  Word16 * ykr,        /* (o): MDCT coefficients    */
  Word16 * norm_shift,  /* (i): normalization factor */ 
  Word16 mode		   /* (i): mdct mode (0: 40-points, 1: 80-points) */
)
{
  Word32   ACC0;               /* ACC */

  Word16   *xin, *ycr, *yci; 
  Word16   mdct_l_win, mdct_l_win2, mdct_l_win4;

  const Word16 *ptr_h1;        /* pointer on window */
  const Word16 *ptr_h2;        /* pointer on window */
  Word16   *ptr_x1;            /* pointer on input samples */
  Word16   *ptr_x2;            /* pointer on input samples */
  Word16   *ptr_ycr;           /* pointer on ycr */
  Word16   *ptr_yci;           /* pointer on yci */

  Word16 *ptr_x3, *ptr_x4;
  const Word16   *ptr_wsin, *ptr_wcos;
  const Word16   *ptr_weti, *ptr_wetr;


  Word16   k;
  Word16   i;
  Word16   tmp16_ycr;
  Word16   tmp16_norm_shift;


  IF( mode == 0 ){
	/* 40 points MDCT */
	mdct_l_win = MDCT_L_WIN; move16();
	mdct_l_win2 = MDCT_L_WIN2; move16();
	mdct_l_win4 = MDCT_L_WIN4; move16();

    ptr_h1 = MDCT_h;                          /* Start of the window */
    ptr_h2 = MDCT_h + mdct_l_win2 - 1; /* End of the window   */	

	ptr_wsin = MDCT_wsin;                      
	ptr_wcos = MDCT_wsin + mdct_l_win4; 

	ptr_weti = MDCT_weti;
	ptr_wetr = MDCT_wetr;

  }ELSE{
	/* 80 points MDCT */
	mdct_l_win = MDCT2_L_WIN; move16();
	mdct_l_win2 = MDCT2_L_WIN2; move16();
	mdct_l_win4 = MDCT2_L_WIN4; move16();

    ptr_h1 = MDCT_h_swb;                          /* Start of the window */
    ptr_h2 = MDCT_h_swb + mdct_l_win2 - 1; /* End of the window   */	
 
	ptr_wsin = MDCT_wsin_swb;                      
	ptr_wcos = MDCT_wsin_swb + mdct_l_win4; 

	ptr_weti = MDCT_weti_swb;
	ptr_wetr = MDCT_wetr_swb;

  }
    
  xin = (Word16 *) calloc ( mdct_l_win, sizeof(Word16) );
  ycr = (Word16 *) calloc ( mdct_l_win4, sizeof(Word16) );
  yci = (Word16 *) calloc ( mdct_l_win4, sizeof(Word16) );


/*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (15 * SIZE_Ptr);
    ssize += (UWord32) ((mdct_l_win + 2 * mdct_l_win4 + 7) * SIZE_Word16);
    ssize += (UWord32) (1 * SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
/*****************************/  

  /********************************************************************************/
  /* MDCT Computation                                                             */
  /********************************************************************************/

  /* form block of length N */
  mov16(mdct_l_win2, mem, xin);
  mov16(mdct_l_win2, input, &xin[mdct_l_win2] );

  /* Step 1 --> Pre-scaling of input signal
                compute norm_shift               */
  *norm_shift = Exp16Array(mdct_l_win , xin);
  array_oper(mdct_l_win, *norm_shift, xin, xin, &shl);


   /* Step 2 --> Calculate zn =  (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n) (complex terms), 
                          for n=0...N/4-1                                         */

  {
    ptr_x1 = xin;

    ptr_x2 = xin + mdct_l_win2 - 1;	
    ptr_x3 = xin + mdct_l_win2;	
    ptr_x4 = xin + mdct_l_win - 1;	

    ptr_yci = yci;
    ptr_ycr = ycr;

    FOR (i = 0; i < mdct_l_win4; i++)
    {
      ACC0 = L_mult(*ptr_h1, *ptr_x1);
      ACC0 = L_msu(ACC0, *ptr_h2, *ptr_x2);
      *ptr_ycr++ = round_fx(ACC0);
      move16();


      ACC0 = L_mult(*ptr_h1, *ptr_x4);
      ACC0 = L_mac(ACC0, *ptr_h2, *ptr_x3);
      *ptr_yci++ = round_fx(ACC0);
      move16();

      ptr_h1 += 2;	
      ptr_h2 -= 2;	
      ptr_x1 += 2;	
      ptr_x2 -= 2;	
      ptr_x3 += 2;	
      ptr_x4 -= 2;	
    }

  }

  /* Step 3 --> Calculate z'n = zn.WN^n, for n=0...N/4-1 */

  ptr_yci = yci;
  ptr_ycr = ycr;


  FOR (k = 0; k < mdct_l_win4; k++)
  {
    tmp16_ycr = *ptr_ycr;

    ACC0 = L_mult0(tmp16_ycr, *ptr_wcos);
    ACC0 = L_msu0(ACC0, yci[k], *ptr_wsin);
    *ptr_ycr++ = round_fx(ACC0);
    move16();

    ACC0 = L_mult0(tmp16_ycr, *ptr_wsin);
    ACC0 = L_mac0(ACC0, yci[k], *ptr_wcos);
    *ptr_yci++ = round_fx(ACC0);
    move16();


    ptr_wsin++;
    ptr_wcos--;
  }

  /* Step 3 --> Inverse FFT of size N/4: Z'k = FFT-1 z'n, for k=0...N/4-1 */
  cfft(ycr, yci, -1, mode);


  /* Step 4 --> Calculate Zk = 1/80 . ((-1)^k+1.W8^-1.W4N^(4k+1)) . Z'k
  
     Step 5 --> Rearranging results:
                     Y2k       = Im[Zk]
                     Y2(k+N/4) = Re[Zk]

     Since Y2(k+N/4) =-Y(N/2-1-2k), results are actually presented as follows:
                     Y2k       = Im[Zk]
                     YN/2-1-2k = -Re[Zk]                                             
       
     Steps 4 & 5 are integrated below in a single step */

  ptr_x1 = ykr;
  ptr_x2 = ykr + mdct_l_win2 - 1;	

  FOR (k = 0; k < mdct_l_win4; k++)
  {
    tmp16_ycr = ycr[k];

    /* symetry of coeff k-1 and N-k */

    ACC0 = L_mult0(yci[k], ptr_weti[k]);         /* weti in Q21 */
    ACC0 = L_msu0(ACC0, tmp16_ycr, ptr_wetr[k]); /* wetr in Q21 */
    *ptr_x2-- = round_fx(ACC0);
    move16();

    ptr_x2--;

    ACC0 = L_mult0(tmp16_ycr, ptr_weti[k]);       /* weti in Q21 */
    ACC0 = L_mac0(ACC0, yci[k], ptr_wetr[k]);     /* wetr in Q21 */
    *ptr_x1++ = round_fx(ACC0);
    move16();

    ptr_x1++;
  }

  /* Step 6 --> Post-scaling of MDCT coefficient
                compute norm_shift               */
 
  tmp16_norm_shift = Exp16Array (mdct_l_win2, ykr);
  array_oper(mdct_l_win2, tmp16_norm_shift, ykr, ykr, &shl);

  /* compute overall normalization factor */
  *norm_shift = add(*norm_shift, tmp16_norm_shift);

  /* update memory */
  mov16(mdct_l_win2, input, mem);

  free(xin);
  free(ycr);
  free(yci);
  
  
/*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
/*****************************/

  return;
}                               /* END MDCT */


/*--------------------------------------------------------------------------*
 *  inv_mdct()                                                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute inverse MDCT and overlap-add                                    *
 * The underlying algorithm is described in                                 *
 * - "A fast algorithm for the implementation of Filter Banks based on Time *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212 *
 *                                                                          *
 * The inverse MDCT consists of:                                            *
 * - Permuting real and imaginary parts YN/4+2k, Y2k                        *
 *   of the transmitted MDCT spectrum                                       *
 * - Calculating the complex part of the forward MDCT, i.e. Re[Zk], Im[Zk]  *
 * - Permuting real and imaginary parts of this complex part                *
 * - Performing an overlap calculation to reconstruct samples               *
 *--------------------------------------------------------------------------*/
void inv_mdct(
  Word16 * xr,         /* (o):   output samples                     */
  Word16 * ykq,        /* (i):   MDCT coefficients                  */
  Word16 * ycim1,      /* (i):   previous MDCT memory               */
  Word16   norm_shift, /* (i):   norm_shift value defined by coder  */
  Word16 * norm_pre,   /* (i/o): norm_shift value of previous frame */
  Word16   loss_flag,  /* (i):   packet-loss flag                   */
  Word16 * cur_save,   /* (i/o): signal saving buffer               */
  HBFEC_State * st,     /* (i/o): work space for HB FERC             */ 
  Word16  mode		
)
{
  Word32   ACC0;

  Word16   mdct_l_win, mdct_l_win2, mdct_l_win4;
  Word16   *ycr, *yci, *sig_cur, *sig_next;
  const Word16   *mdct_h;
  const Word16   *mdct_wetrm1, *mdct_wetim1;
  const Word16   *ptr_wsin, *ptr_wcos;

  Word16   *ptr_yci;
  Word16   *ptr_ycr;
  Word16   *ptr1;
  Word16   *ptr2;
  Word16   *ptr1_next;
  Word16   *ptr2_next;
  const Word16 *ptr_h;         /* Pointer on window */

  Word16   k,n;
  Word16   tmp16;

  Word32   ACC1;
  Word16   n1;

  Word16   *hb_buf=st->hb_buf;
  Word16   *ptr_imdct;
  Word16   n2;

  IF( mode == 0 ){
	  /* 40 points MDCT */
	  mdct_l_win  = MDCT_L_WIN; move16();
	  mdct_l_win2 = MDCT_L_WIN2; move16();
	  mdct_l_win4 = MDCT_L_WIN4; move16();

	  mdct_h = MDCT_h;

	  mdct_wetrm1 = MDCT_wetrm1;
	  mdct_wetim1 = MDCT_wetim1;
    
	  ptr_wsin = MDCT_wsin;
	  ptr_wcos = MDCT_wsin + mdct_l_win4;


	  /* Higher-band frame erasure concealment (FERC) in time domain */
	  IF (loss_flag != 0)
	  {
		  st->pre_bfi = 1; move16();
		  IF (st->first_loss_frame)
		  {
			  st->hb_t0 = st->lb_t0; move16();
			  st->high_cor = 0; move16();
			  if (sub(cor_hb_fec(hb_buf, &st->hb_t0), 16056) >= 0)
			  {
				  st->high_cor = 1; move16();
			  }
		  }
		  IF (st->high_cor)
		  {   /* HBFEC based on pitch repetition and attenuation */

			  /* copy pitch for 2 HB frame */
			  IF (st->first_loss_frame)
			  {               
				  mov16(mdct_l_win, hb_buf+MAXPIT+mdct_l_win2-st->hb_t0, hb_buf+MAXPIT+mdct_l_win2);
			  }
			  ELSE
			  {
				  mov16((Word16)(MAXPIT+mdct_l_win2), hb_buf+mdct_l_win2, hb_buf);
				  mov16(mdct_l_win, hb_buf+MAXPIT+mdct_l_win2-st->hb_t0, hb_buf+MAXPIT+mdct_l_win2);
			  }

			  n1 = sub(*norm_pre, 6);
			  ptr_imdct = & hb_buf[MAXPIT + mdct_l_win2]; 
			  n2 = add(n1, 2);
              mult_r_Array_Array(mdct_l_win2, cur_save, ptr_imdct, (Word16 *)mdct_h);
              array_oper(mdct_l_win2, n2, cur_save, cur_save, &shl);
			  IF (sub(st->att_weight, 6560) >= 0)
			  {
				  ptr_h = mdct_h + mdct_l_win2; 
				  FOR (k = 0; k < mdct_l_win2; k++)
				  {
					  ACC0 = L_mult0(cur_save[k], mdct_h[k]);
					  ACC0 = L_mac0(ACC0, ycim1[k], *(--ptr_h));
					  ACC0 = L_shr(ACC0, n1);
					  xr[k] = round_fx(ACC0);
					  move16();

					  st->att_weight = sub(st->att_weight, ATT_WEIGHT_STEP);
					  xr[k] = mult_r(xr[k], st->att_weight); move16();
				  }
			  }
			  ELSE
			  {
                  zero16(mdct_l_win2, xr);
			  }
			  ptr_imdct = & hb_buf[MAXPIT + mdct_l_win];
              mult_r_Array_Array(mdct_l_win2, ycim1, ptr_imdct, (Word16 *)mdct_h+mdct_l_win2);
              array_oper(mdct_l_win2, n2, ycim1, ycim1, &shl);
		  }
		  ELSE
		  {
			  n1 = sub(*norm_pre, 6);
			  ptr_h = mdct_h + mdct_l_win2; 
			  FOR (k = 0; k < mdct_l_win2; k++)
			  {
				  cur_save[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, cur_save[k]); move16();

				  ACC0 = L_mult0(cur_save[k], mdct_h[k]);
				  ACC0 = L_mac0(ACC0, ycim1[k], *(--ptr_h));
				  ACC0  = L_shr(ACC0, n1);
				  xr[k] = round_fx(ACC0);
				  move16();

				  ycim1[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, ycim1[k]); move16();
			  }
		  }
		  st->first_loss_frame = 0; move16();

		  return;
	  }

	  IF (st->pre_bfi)
	  {
          array_oper(mdct_l_win2, st->att_weight, ycim1, ycim1, &mult_r);
		  st->first_loss_frame = 1; move16();
		  st->att_weight = 32767; move16();
		  st->pre_bfi = 0; move16();
	  }


	} ELSE {
		/* 80 points MDCT */
		mdct_l_win  = MDCT2_L_WIN; move16();
	    mdct_l_win2 = MDCT2_L_WIN2; move16();
	    mdct_l_win4 = MDCT2_L_WIN4; move16();
 
		mdct_h = MDCT_h_swb;

	    mdct_wetrm1 = MDCT_wetrm1_swb;
	    mdct_wetim1 = MDCT_wetim1_swb;

	    ptr_wsin = MDCT_wsin_swb;
	    ptr_wcos = MDCT_wsin_swb + mdct_l_win4;

		/* Higher-band frame erasure concealment (FERC) in time domain */
		IF (loss_flag != 0)
		{
			n1 = sub(*norm_pre, 6);
			ptr_h = mdct_h + mdct_l_win2;
			FOR (k = 0; k < mdct_l_win2; k++)
			{
				cur_save[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, cur_save[k]); move16();

				ACC0 = L_mult0(cur_save[k], mdct_h[k]);
				ACC0 = L_mac0(ACC0, ycim1[k], *(--ptr_h));
				ACC0  = L_shr(ACC0, n1);
				xr[k] = round_fx(ACC0);
				move16();

				ycim1[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, ycim1[k]); move16();
			}

			return;
		}


	}

  ycr = (Word16 *) calloc (mdct_l_win4, sizeof(Word16));
  yci = (Word16 *) calloc (mdct_l_win4, sizeof(Word16));
  sig_cur = (Word16 *) calloc (mdct_l_win2, sizeof(Word16));
  sig_next = (Word16 *) calloc (mdct_l_win2, sizeof(Word16));


/*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (18 * SIZE_Ptr);
    ssize += (UWord32) ((2 * mdct_l_win4 + 2 * mdct_l_win2 + 9) * SIZE_Word16);
    ssize += (UWord32) (2 * SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
/*****************************/  


  /*******************************************************************************/
  /* Inverse MDCT computation                                                    */
  /*******************************************************************************/

  /* 1 --> Input rotation = Product by wetrm1 */

  ptr1 = ykq;
  ptr2 = ykq + (mdct_l_win2 - 1); 
  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (k = 0; k < mdct_l_win4; k++)
  {
    ACC0 = L_mult0(*ptr2, mdct_wetrm1[k]);
    ACC0 = L_negate(ACC0);
    ACC0 = L_msu0(ACC0, *ptr1, mdct_wetim1[k]);
    *ptr_ycr++ = round_fx(ACC0);
    move16();

    ACC0 = L_mult0(*ptr1++, mdct_wetrm1[k]);
    ACC0 = L_msu0(ACC0, *ptr2--, mdct_wetim1[k]);
    *ptr_yci++ = round_fx(ACC0);
    move16();
    ptr1++;
    ptr2--;
  }

  /* 2 --> Forward FFT : size = 20 */
  cfft(ycr, yci, 1, mode);

  /* 3 --> Output rotation : product by a complex exponent */

  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (k = 0; k < mdct_l_win4; k++)
  {
    tmp16 = *ptr_ycr;


    ACC0 = L_mult0(tmp16, *ptr_wcos);
    ACC0 = L_mac0(ACC0, yci[k], *ptr_wsin);
    *ptr_ycr++ = round_fx(ACC0);
    move16();

    ACC0 = L_mult0(yci[k], *ptr_wcos);
    ACC0 = L_msu0(ACC0, tmp16, *ptr_wsin);
    *ptr_yci++ = round_fx(ACC0);
    move16();

	ptr_wsin++;
	ptr_wcos--;

  }

  /* 4 --> Overlap and windowing (in one step) - equivalent to complex product */

  ptr1 = sig_cur;
  ptr2 = sig_cur + mdct_l_win2 - 1; 
  ptr1_next = sig_next;
  ptr2_next = sig_next + mdct_l_win2 - 1; 

  FOR (k = 0; k < mdct_l_win4; k++)
  {
    *ptr1++ = ycr[k];              move16();
    *ptr2--      = negate(ycr[k]); move16();
	*ptr1_next++ = yci[k];         move16();
    *ptr2_next-- = yci[k];         move16();

    ptr1++;
    ptr1_next++;
    ptr2--;
    ptr2_next--;
  }

  n = sub(norm_shift, 6);
  n1 = sub(*norm_pre, 6);
  ptr_h = mdct_h + mdct_l_win2; 
  FOR (k = 0; k < mdct_l_win2; k++)
  {
    ACC0  = L_mult0(sig_cur[k], mdct_h[k]);
    ACC0  = L_shr(ACC0, n);
    ACC1  = L_mult0(ycim1[k], *(--ptr_h));
    ACC1  = L_shr(ACC1, n1);
    ACC0  = L_add(ACC0, ACC1);
    xr[k] = round_fx(ACC0);        move16();
	  ycim1[k] = sig_next[k];        move16();
  }

  /* Save sig_cur for FERC */
  mov16(mdct_l_win2, sig_cur, cur_save);
  *norm_pre = norm_shift;  move16();

  free(ycr);
  free(yci);
  free(sig_cur);
  free(sig_next);

/*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
/*****************************/

  return;
}
