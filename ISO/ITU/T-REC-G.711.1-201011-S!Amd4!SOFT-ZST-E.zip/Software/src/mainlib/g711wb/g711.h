/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  File: g711.h
 *  Function: Header of embedded lower-band PCM coders
 *------------------------------------------------------------------------
 */

#ifndef G711_H
#define G711_H


Word16 convertLin_ALaw(Word16 x, Word16 *ind2, Word16 *xq, Word16* expo);
Word16 convertALaw_Lin(Word16 ind, Word16 *expo, Word16* signo);
Word16 convertALaw_Lin_enh(Word16 code2, Word16 exp, Word16 sign, Word16 numbits);

Word16 convertLin_MuLaw(Word16 x, Word16 *ind2, Word16 *xq, Word16* expo);
Word16 convertMuLaw_Lin(Word16 ind, Word16 *expo, Word16* signo);
Word16 convertMuLaw_Lin_enh(Word16 code2, Word16 exp, Word16 sign, Word16 numbits);

#endif
