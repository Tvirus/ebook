/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "G711WB_highband.h"

/*----------------------------------------------------------------
  Function:
    Mu-law expansion of gain, 8bit, u=255
  Return value
    Reconstructed value in linear scale
  ----------------------------------------------------------------*/
Word16 mulawinv(Word16 index) /* in: Q0, out:Q0 */
{
  Word16  mantissa;
  Word16  exponent;
  Word16  logbuf;
  Word16  linbuf; 

  logbuf = s_and (index, 0x00ff);

  IF ( sub(logbuf,4) < 0 )
  {
    linbuf = s_and( logbuf, 0x3 );
  }
  ELSE
  {
    logbuf = sub( logbuf, 3 );
    exponent = s_and (shr(logbuf, 5), 0x0007);
    mantissa = s_and (logbuf, 0x001F);
    linbuf = sub(shl(add(shl(mantissa, 2), 130), exponent), 130);
  }

  return linbuf;  /* Q0 */
}
