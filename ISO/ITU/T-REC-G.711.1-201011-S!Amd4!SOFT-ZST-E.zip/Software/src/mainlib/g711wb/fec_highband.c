/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "pcmswb_common.h"
#include "fec_highband.h"

#include "fec_lowband.h"
#include "G711WB_highband.h"

/*--------------------------------------------------------------------------*
 *  Function  update_hb_buf()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  update the higherband buffer for HB FERC                                *
 *--------------------------------------------------------------------------*/
void update_hb_buf(
  Word16  *hb_buf,    /* (i/o): HB signal buffer */
  Word16  *output_hi  /* (i):   HB output signal */
)
{
  /* shift HB buffer for FERC */
  mov16(MAXPIT, hb_buf+L_FRAME_NB, hb_buf);
  mov16(L_FRAME_NB, output_hi, hb_buf+MAXPIT);
}

/*--------------------------------------------------------------------------*
 *  Function  copy_lb_pitch()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  copy the lowerband pitch for HB FERC                                    *
 *--------------------------------------------------------------------------*/
void copy_lb_pitch(
  void * SubDecoderL,  /* (i): Work space for lower-band decoder  */
  void * SubDecoderH   /* (o): Work space for higher-band decoder */
)
{
  VQD_State * vqd = (VQD_State *) SubDecoderH;
  vqd->hbfec_st.lb_t0 = get_lb_pitch(SubDecoderL);
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  cor_hb_fec()                                                  *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  search best pitch, computer the correlation for HB FERC,                *
 *--------------------------------------------------------------------------*/
Word16  cor_hb_fec(       /* returns correlation     */
  Word16 * hb_buf,        /* (i): HB signal buffer   */
  Word16 * hb_pitch_best  /* (o): Pitch delay for HB */
)
{
  Word32  hb_cor, hb_scale1, hb_scale2;
  Word16  hb_nor_cor, hb_nor_cor2, hb_nor_cor_max = 0;

  Word16  hb_cor_16, hb_scale1_16, hb_scale2_16;
  Word16  norm_cor, norm_scale1, norm_scale2, norm_tot;

  Word16  hb_pitch_min = sub(*hb_pitch_best, HB_PITCH_SEARCH_RANGE);
  Word16  hb_pitch_max = add(*hb_pitch_best, HB_PITCH_SEARCH_RANGE);
  Word16  hb_pitch;

  move16(); /* for hb_nor_cor_max */

  /* adjust the pitch search range according to the min and max pitch */
  if (hb_pitch_min < MINPIT){
	  hb_pitch_min = MINPIT; move16();
  }
  if (hb_pitch_max > MAXPIT){
    hb_pitch_max = MAXPIT;	move16();
  }

  /* calculate the self correlation of the frame*/
  hb_scale1 = L_add(1L, L_mac_Array(L_FRAME_NB, hb_buf+MAXPIT, hb_buf+MAXPIT));


  norm_scale1 = norm_l(hb_scale1);
  hb_scale1 = L_shl(hb_scale1, norm_scale1);
  hb_scale1_16 = round_fx( hb_scale1);

  /* search the best pitch */
  FOR (hb_pitch = hb_pitch_min; hb_pitch <= hb_pitch_max; hb_pitch++)
  {
    hb_cor = L_mac_Array(L_FRAME_NB, hb_buf+MAXPIT, hb_buf+MAXPIT-hb_pitch);

    norm_cor = sub(norm_l(hb_cor), 1);
    hb_cor = L_shl(hb_cor, norm_cor);
    hb_cor_16 = round_fx( hb_cor);

    IF (hb_cor > 0)
    {
      hb_scale2 = L_add(1L, L_mac_Array(L_FRAME_NB, hb_buf+MAXPIT-hb_pitch, hb_buf+MAXPIT-hb_pitch));

      norm_scale2 = norm_l(hb_scale2);
      hb_scale2 = L_shl(hb_scale2, norm_scale2);
      hb_scale2_16 = round_fx(hb_scale2);

      hb_nor_cor = div_s(hb_cor_16, hb_scale1_16);
      hb_nor_cor2 = div_s(hb_cor_16, hb_scale2_16);

      hb_nor_cor = mult_r(hb_nor_cor, hb_nor_cor2);
      norm_tot = sub( sub( shl(norm_cor, 1), norm_scale1), norm_scale2);
      hb_nor_cor = shr(hb_nor_cor, norm_tot);

      IF (hb_nor_cor > hb_nor_cor_max)
      {
        *hb_pitch_best = hb_pitch;   move16();
        hb_nor_cor_max = hb_nor_cor; move16();
      }
    }
  }

  return hb_nor_cor_max;
}
