/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#ifndef __G711ENH_H__
#define __G711ENH_H__

/*------------------------------------------------------------------------*
* Defines
*------------------------------------------------------------------------*/
#define MAX_HB_EXP      32
#define MAX_HB_ENH_BITS 3
#define MAX_HB_EXP_POS  (MAX_HB_EXP+MAX_HB_ENH_BITS)	
#define MAX_NCB_GAIN    (1<<MAX_HB_ENH_BITS)	

#define MAX_HB_EXP_1      31
#define MAX_HB_EXP_2      30
#define MINUS_MAX_HB_ENH_BITS  -3

/*------------------------------------------------------------------------*
* Prototypes
*------------------------------------------------------------------------*/
void hbe_bitalloc ( Word16*, Word16* );

void g711el1_encode (
                     const Word16*  sfSpectrum,  /* (i): Input MDCT coefficient in mid-band          */ /* Q(sfSpectrumQ) */
                     const Word16*  sfQspectrum, /* (i): Local decoded MDCT coefficient in mid-band  */ /* Q(sfSpectrumQ) */
                     UWord16*       bstr_buff,   /* (o): Output bitstream in soft bit format        */
                     const Word16   sfSpectrumQ
                     );

void g711el1_decode (
                     const Word16* bstr_buff,  /* (i): Input bitstream in soft bit format     */
                     const Word16* sQspectrum, /* (i): Q(sQspectrumQ), Input MSCT coefficients of mid-band    */
                     Word16*       smdct_corr, /* (o): Q14, Correction factors of MDCT coefficient */
                     Word16*       ssb_err,    /* (o): Q(sQspectrumQ) */
                     Word16*       s_idx,
                     Word16*       e_idx,
                     Word16        sQspectrumQ /* (i): Q of sQspectrum[] */
                     );

#endif  /* __G711ENH_H__ */
