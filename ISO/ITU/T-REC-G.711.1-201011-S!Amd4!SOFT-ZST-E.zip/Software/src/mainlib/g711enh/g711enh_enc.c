/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "g711enh.h"
#include "softbit.h"
#include "oper_32b.h"
#include "bwe.h"
#include "math_op.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/
#include "g711enh_table.h"

#define ENCODER_OK  0
#define ENCODER_NG  1

#define INV_N_FR_FREQ    26214    /* 1/80 in Q21 */

static void search_pulses(Word16* spec, Word16* pos, Word16* sign, Word16* mag_vec, Word16 rms_index, Word16 sSpecQ);

static Word16 pmag_vq(Word16* vec);

void hbe_bitalloc( Word16* expi, Word16* bit_alloc )
{
  Word16  i, tmp;
  Word16  bit_reservoir, acc_cnt_bit, thresh_expi, alloc_bit_tmp;
  Word16  cnt_exp[MAX_HB_EXP_POS], *p_cnt_exp = cnt_exp + MAX_HB_ENH_BITS, *p_tmp;	
  Word16  cnt_bit[MAX_HB_EXP_POS], *p_cnt_bit = cnt_bit + MAX_HB_ENH_BITS;	
  Word16  exp_tab_pos[L_FRAME_NB], exp_sort[L_FRAME_NB];
  Word16  offset[MAX_HB_EXP];

  zero16( L_FRAME_NB, exp_tab_pos);
  zero16( L_FRAME_NB, exp_sort);
  zero16( MAX_HB_EXP, offset);


  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH(3 * SIZE_Ptr + (L_FRAME_NB * 2 + MAX_HB_EXP_POS * 2 + MAX_HB_EXP + 6) * SIZE_Word16, "dummy");
#endif
  /*****************************/

  /* initialization */
  bit_reservoir = 21; move16();
  zero16 (L_FRAME_NB, bit_alloc);
  zero16 (MAX_HB_EXP_POS, cnt_exp);
  zero16 (MAX_HB_EXP_POS, cnt_bit);

  /* Bucket sort */ 
  /* count number of each expi */
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    p_cnt_exp[expi[i]] = add(p_cnt_exp[expi[i]], 1);
    move16();
    move16();
  }

  /* calculate offset */
  offset[MAX_HB_EXP_1] = 0; move16();
  p_tmp = &p_cnt_exp[MAX_HB_EXP_1]; move16();
  FOR (i=MAX_HB_EXP_2; i>=0; i--)
  {
    offset[i] = add(offset[i+1], *(p_tmp--));	
    sub(0,0);
    move16();
  }

  /* sorting */
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    exp_sort[offset[expi[i]]] = expi[i]; move16();move16();move16();
    exp_tab_pos[offset[expi[i]]] = i;    move16();move16();move16();
    offset[expi[i]] = add(offset[expi[i]], 1);  move16();move16();
  }

  /* Bit allocation */
  /* count the total amount of bits for each expi */
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    p_cnt_bit[exp_sort[i]] = add(p_cnt_bit[exp_sort[i]], 1);   move16();move16();
    tmp = sub(exp_sort[i], 1);
    p_cnt_bit[tmp] = add(p_cnt_bit[tmp], 1); move16();move16();
    tmp = sub(exp_sort[i], 2);
    p_cnt_bit[tmp] = add(p_cnt_bit[tmp], 1); move16();move16();
  }

  /* extract threshold of expi */
  acc_cnt_bit = p_cnt_bit[MAX_HB_EXP_1]; move16();
  thresh_expi = MAX_HB_EXP;              move16();
  FOR (i=MAX_HB_EXP_2; i>MINUS_MAX_HB_ENH_BITS; i--)
  {
    IF (sub(acc_cnt_bit, bit_reservoir) > 0)
    {
      acc_cnt_bit = sub(acc_cnt_bit, p_cnt_bit[i+1]);
      thresh_expi = add(i, 1);
      BREAK;
    }
    acc_cnt_bit = add(acc_cnt_bit, p_cnt_bit[i]);
  }

  /* compute bit allocation */
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    IF (sub(exp_sort[i], thresh_expi) <= 0){ BREAK;}

    alloc_bit_tmp = s_min ((Word16)MAX_HB_ENH_BITS, sub(exp_sort[i], thresh_expi));
    bit_alloc[exp_tab_pos[i]] = alloc_bit_tmp;  move16();move16();
    bit_reservoir = sub(bit_reservoir, alloc_bit_tmp);

    IF (sub(alloc_bit_tmp, MAX_HB_ENH_BITS) != 0)
    {
      expi[exp_tab_pos[i]] = thresh_expi;
      move16();move16();
    }
  }

  FOR (i=0; bit_reservoir>0; i++)
  {
    test();
    IF (sub(expi[i], thresh_expi) == 0 && sub(bit_alloc[i], MAX_HB_ENH_BITS) < 0) 
    {
      bit_alloc[i] = add(bit_alloc[i], 1);   move16();
      bit_reservoir = sub(bit_reservoir, 1);
    }
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

  return;
}

void g711el1_encode (
                     const Word16*  sfSpectrum,  /* (i): Input MDCT coefficient in mid-band          */ /* Q(sfSpectrumQ) */
                     const Word16*  sfQspectrum, /* (i): Local decoded MDCT coefficient in mid-band  */ /* Q(sfSpectrumQ) */
                     UWord16*        bstr_buff,    /* (o): Output bitstream in soft bit format        */
                     const Word16   sfSpectrumQ
                     )
{
  Word16   i, j;
  UWord16 *pBit_g;
  Word16 exp[L_FRAME_NB], bitalloc[L_FRAME_NB];


  Word16 idx_g;
  Word16 e_qx[L_FRAME_NB], p_x_qx[L_FRAME_NB];
  Word16 max_exp;

  Word32 smax_d, sdtmp;

  Word16 pmag_idx;
  Word16 e_idx, s_idx;
  Word16 pos[3], sign[3];

  Word16 sEspectrum[L_FRAME_NB];
  Word16 *ptmp;
  Word32 max_d, e_err;
  Word16 max_i = 0;
  Word16 log_int, log_frac;
  Word16 norm;
  Word32 lacc;
  Word16 log_rms, rms_index;
  Word16 hi, lo;
  Word16 mag_vec[3];

  zero16( L_FRAME_NB, exp);
  zero16( L_FRAME_NB, bitalloc);
  zero16( L_FRAME_NB, e_qx);
  zero16( L_FRAME_NB, p_x_qx);
  zero16( L_FRAME_NB, sEspectrum);

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32)  (2 * SIZE_Ptr);
    ssize += (UWord32) ((24 + 4 * L_FRAME_NB + L_FRAME_NB) * SIZE_Word16);
    ssize += (UWord32) (5 * SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/  

  /* initialization */
  pBit_g = bstr_buff;

  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    sEspectrum[i] = sub(sfSpectrum[i], sfQspectrum[i]);    /* Q(sfSpectrumQ) */
#if (WMOPS)
    move16();
#endif
  }

  ptmp = sEspectrum;

  max_d = MIN_32;
#if (WMOPS)
  move32();
#endif

  FOR (i = 0; i < 4; i++)
  {
    e_err = L_mult0(ptmp[0], ptmp[0]);
    FOR (j = 1; j < 10; j++)
    {
      e_err = L_mac0(e_err, ptmp[j], ptmp[j]);
    }
    ptmp += 10;	

    IF (L_sub(max_d, e_err) < 0)
    {
      max_d = e_err;
      max_i = i;
#if (WMOPS)
      move32();
      move16();
#endif
    }
  }

  PushBit (max_i, (UWord16 **)(&pBit_g), 2);        /* store subband index */

  /* set subband boundaries */
  s_idx = sb_bound[max_i][0];
  e_idx = sb_bound[max_i][1];
#if (WMOPS)
  move16();
  move16();
#endif

  /* log_rms = (1/2)log2(max_d/10) */
  IF (max_d == 0)
  {
    rms_index = -8;  /* Q(0) */	move16();
  }
  ELSE
  {
    L_Extract(max_d, &hi, &lo);
    lacc = Mpy_32_16(hi, lo, 3277);            /* Q(2*sfSpectrumQ+15-15), where 3277 is 0.1f in Q15 */
    Log2(lacc, &log_int, &log_frac);
    lacc = L_Comp(sub(log_int, shl(sfSpectrumQ, 1)), log_frac);  /* Q(16) */

    norm = norm_l(lacc);
    lacc = L_shl(lacc, norm);                /* Q(16+norm) */
    log_rms = extract_h(lacc);              /* Q(norm) */
    log_rms = shr(log_rms, 1);            /* (*0.5) : Q(norm) */
    log_rms = add(log_rms, shl(1, sub(norm,1)));
    rms_index = shr(log_rms, norm);          /* Q(0) */

    IF (sub(rms_index, -8) < 0)
    {
      rms_index = -8;	move16();
    }
    ELSE IF (sub(rms_index, 7) > 0)
    {
      rms_index = 7;		move16();
    }
  }
  PushBit (add(rms_index, 8), (UWord16 **)(&pBit_g), 4);  /* store rms index */

  ptmp = sEspectrum + s_idx;                /* Q(sSpectrumQ) */	
  search_pulses(ptmp, pos, sign, mag_vec, rms_index, sfSpectrumQ);

  /* store positions, signs and magnitudes */
  FOR (i = 0; i < 3; i++)
  {
    PushBit(pos[i], (UWord16 **)(&pBit_g), 2);
    PushBit(sign[i], (UWord16 **)(&pBit_g), 1);
  }
  pmag_idx = pmag_vq(mag_vec);
  PushBit(pmag_idx, (UWord16 **)(&pBit_g), 4);

  FOR (i=0; i<L_FRAME_NB; i++)
  {
    e_qx[i]   = mult_r (sfQspectrum[i], sfQspectrum[i]); /* Q(2*sfSpectrumQ-15):sfSpectrumQ+sfSpectrumQ+1-16 */
    move16();
    p_x_qx[i] = mult_r (sfSpectrum[i], sfQspectrum[i]);  /* Q(2*sfSpectrumQ-15):sfSpectrumQ+sfSpectrumQ+1-16 */
    move16();
  }

  /* Bit allocation */
  max_exp = sub (MAX_HB_EXP, sfSpectrumQ);
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    exp[i] = sub (max_exp, norm_s (sfQspectrum[i])); move16 ();

    test();
    if (sfQspectrum[i] == 0 || exp[i] < 0)
    {
      exp[i] = 0; move16 ();
    }
  }

  /* force exp[k] to zero */
  FOR (i=0; i<3; i++)
  {
    j = add (add (s_idx, i), i_mult(pos[i], 3));
    exp[j] = 0;
#if (WMOPS)
    move16();
#endif
  }

  hbe_bitalloc (exp, bitalloc);

  FOR (i=0; i<L_FRAME_NB; i++)
  {
    IF (bitalloc[i] != 0)
    {
      move16();move16(); /* for addressing */
      smax_d = L_sub (L_mult (sg2[bitalloc[i]][0], p_x_qx[i]), L_mult (sge[bitalloc[i]][0], e_qx[i])); /* Q(2*sfSpectrumQ-17):2*sfSpectrumQ-15+13+1-16 */

      idx_g = 0; move16 ();

      move16(); /* for addressing */
      FOR (j=1; j<ncb_alloc[bitalloc[i]]; j++)
      {
        sdtmp = L_sub (L_mult (sg2[bitalloc[i]][j], p_x_qx[i]), L_mult (sge[bitalloc[i]][j], e_qx[i])); /* Q(2*sfSpectrumQ-17):2*sfSpectrumQ-15+13+1-16 */

        IF (L_sub (sdtmp, smax_d) > 0)
        {
          smax_d = sdtmp; move32 ();
          idx_g = j; move16 ();
        }
      }
      PushBit (idx_g, (UWord16 **)(&pBit_g), bitalloc[i]);
    }
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/  
}

static void search_pulses(Word16* spec,      /* Q(sSpecQ) */
                          Word16* pos,
                          Word16* sign,
                          Word16* mag_vec,
                          Word16 rms_index,
                          Word16 sSpecQ)
{
  Word16 *ptr0, *ptr1;
  Word16 magi, posi, sSpecQ_8, log_magi;
  Word16 inv_rms_q;
  Word32 Ltmp;
  Word16 log_int, log_frac;
  Word16 lo, hi, tmp;

  Word16 i, j;

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32	ssize;
    ssize = (UWord32) ((4+1+2+3+2)*SIZE_Word16);
    ssize += (UWord32) (2*SIZE_Ptr);
    ssize += (UWord32) (1*SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/
  inv_rms_q = shl(1, sub(7, rms_index));              /* Q(7) */
  sSpecQ_8 = add(sSpecQ, 8);
  /* search max and its position in each track */
  ptr0 = spec;
  FOR (i = 0; i < 3; i++)
  {
    ptr1 = ptr0++;
    posi = 0; move16();
    magi = abs_s(*ptr1);
    ptr1 += 3;
    FOR (j = 1; j < 4; j++)
    {
      tmp = abs_s(*ptr1);
      if(sub(magi, tmp) <0 ){
        posi = j; move16();
      }
      magi = s_max(magi, tmp);
      ptr1 += 3;
    }
    /* mag_vec[i] = log10(pmag[0] * inv_rms_q) */
    log_magi =  (Word16)-16384;	 move16();
    IF (magi != 0)
    {

      Ltmp = L_mult(magi, inv_rms_q);        /*
                                             Q(sSpecQ+7+1) */
      Log2(Ltmp, &log_int, &log_frac);
      Ltmp = L_Comp(sub(log_int, sSpecQ_8), log_frac); /*
                                                       Q(16) */
      L_Extract(Ltmp, &hi, &lo);
      Ltmp = Mpy_32_16(hi, lo, 2466);           /* Q(14) =
                                                Q(16+13-15), where 27213 = (log10(2))) in Q13 */
      log_magi = extract_l(L_shr(Ltmp, 2));   /* Q(12) */
    }
    pos[i] = posi; move16();
    mag_vec[i] = log_magi; move16();
    j = add(i, add(shl(posi, 1), posi));
    sign[i] = (Word16)1; move16();
    if(spec[j] < 0) 
    {
      sign[i] = (Word16)0;       move16();
    }
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

  return;
}

static Word16 pmag_vq(Word16* vec)
{
  Word16 tmp;
  Word32 dist, min_dist = MAX_32;
  Word16 min_idx = 0;
  Word16 i, j;
  Word16 *pcbk = (Word16 *)pmag_cbk;
  move16();

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32	ssize;
    ssize = (UWord32) (4*SIZE_Word16);
    ssize += (UWord32) (2*SIZE_Word32);
    ssize += (UWord32) (1*SIZE_Ptr);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/

  FOR (i = 0; i < 16; i++)
  {
    dist = (Word32)0;
#if (WMOPS)
    move32();
#endif

    FOR (j = 0; j < 3; j++)
    {
      tmp = sub(vec[j], pcbk[j]);
      dist = L_mac(dist, tmp, tmp);
    }

    IF (L_sub(dist, min_dist) < 0)
    {
      min_dist = dist;
      min_idx = i;
#if (WMOPS)
      move32();
      move16();
#endif
    }

    pcbk += 3;
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

  return min_idx;
}
