/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "g711enh.h"
#include "softbit.h"
#include "bwe.h"
#include "oper_32b.h"
#include "math_op.h"
#include "g711enh_table.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

#define DECODER_OK  2
#define DECODER_NG  3

extern const Word16 pmag_cbk[3*16];	

void g711el1_decode (
                     const Word16* bstr_buff,  /* (i): Input bitstream in soft bit format     */
                     const Word16* sQspectrum, /* (i): Q(sQspectrumQ), Input MSCT coefficients of mid-band    */
                     Word16*       smdct_corr, /* (o): Q14, Correction factors of MDCT coefficient */
                     Word16*       ssb_err,    /* (o): Q(sQspectrumQ) */
                     Word16*       s_idx,
                     Word16*       e_idx,
                     Word16        sQspectrumQ /* (i): Q of sQspectrum[] */
                     )
{
  Word16 i;
  UWord16 *pBit_g;
  Word16 exp[L_FRAME_NB], bitalloc[L_FRAME_NB];
  Word16 idx_g, max_exp;

  Word16 max_i;
  Word16 rms_index;

  Word16 rms_q;
  Word16 pos[3], sign[3];
  Word16 pos_idx, pmag_idx;
  Word16 pow_int, pow_frac;
  Word16 hi, lo, norm;

  Word32 Ltmp;
  Word16 tmp;
  Word16* pcbk;

  zero16( L_FRAME_NB, exp);
  zero16( L_FRAME_NB, bitalloc);

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize =  (UWord32) (2 * SIZE_Ptr);
    ssize += (UWord32) ((1 + 2*L_FRAME_NB + 2) * SIZE_Word16);
    ssize += (UWord32) ((3 + 2*3 + 2+2+3+1) * SIZE_Word16);
    ssize += (UWord32) (1 * SIZE_Word32);

    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/  

  /* initialization */
  pBit_g = (UWord16 *) bstr_buff;

  /* selected subband decoding */
  max_i = GetBit ((UWord16 **)(&pBit_g), 2);
  *s_idx = sb_bound[max_i][0];		
  *e_idx = sb_bound[max_i][1];
  move16(); move16();

#if (WMOPS)
  move16();
  move16();
#endif

  /* rms decoding */
  rms_index = GetBit((UWord16 **)(&pBit_g), 4);
  rms_q = shl(1, rms_index); /* Q(8) */

  FOR (i = 0; i < 3; i++)
  {
    pos[i] = GetBit((UWord16 **)(&pBit_g), 2);
    sign[i] = GetBit((UWord16 **)(&pBit_g), 1);

#if (WMOPS)
    move16();
    move16();
#endif

    if (sign[i] == 0) {
      sign[i] = (Word16)-1;	
#if (WMOPS)
      move16();
#endif
    }
  }

  pmag_idx = i_mult(GetBit((UWord16 **)(&pBit_g), 4), 3);
  pcbk = (Word16*)(pmag_cbk + pmag_idx);	
  FOR (i = 0; i < 3; i++)
  {
    /* ssb_err[pos_idx] = pow(10, *pckb) */
    pos_idx = add(i_mult(pos[i], 3), i);    /* pos[i] = 3 * pos[i] + i */
    Ltmp = L_mult((Word16)(*pcbk), 27213);  /* Q(12+13+1): 27213 is log2(10) in Q13 */
    Ltmp = L_shr(Ltmp, 10);                 /* Q(16) */
    L_Extract(Ltmp, &pow_int, &pow_frac);
    pow_int = add(pow_int, 26);
    Ltmp = Pow2(pow_int, pow_frac);				/* Q(26) */
    L_Extract(Ltmp, &hi, &lo);
    Ltmp = Mpy_32_16(hi, lo, rms_q);     /* Q(26+8-15) */
    norm = norm_l(Ltmp);
    Ltmp = L_shl(Ltmp, norm);               /* Q(19+norm) */
    tmp = extract_h(Ltmp);                  /* Q(norm+3) */
    norm = add(norm, 3);
    ssb_err[pos_idx] = i_mult(shr(tmp, sub(norm, sQspectrumQ)), sign[i]);  /* Q(sQspectrumQ) */
    pos[i] = add(*s_idx, pos_idx);
#if (WMOPS)
    move16();
    move16();
#endif

    pcbk++;		move16();
  }


  /* Bit allocation */
  max_exp = sub (MAX_HB_EXP, sQspectrumQ);
  FOR (i=0; i<L_FRAME_NB; i++)
  {
    exp[i] = sub (max_exp, norm_s (sQspectrum[i])); move16 ();

    test ();
    if (sQspectrum[i] == 0 || exp[i] < 0)
    {
      exp[i] = 0; move16 ();
    }
  }

  FOR (i = 0; i < 3; i++)
  {
    pos_idx = pos[i];
    exp[pos_idx] = 0;
#if (WMOPS)
    move16();
    move16();
#endif
  }

  hbe_bitalloc (exp, bitalloc);

  FOR (i=0; i<L_FRAME_NB; i++)
  {
    smdct_corr[i] = 16384; move16 (); /* Q14 */

    IF (bitalloc[i] != 0)
    {
      idx_g = GetBit ((UWord16 **)(&pBit_g), bitalloc[i]);
      move16(); /* for addressing */
      smdct_corr[i] = sgain[bitalloc[i]][idx_g]; move16 (); /* Q14 */
    }
  }

  FOR (i = 0; i < 3; i++)
  {
    pos_idx = pos[i];
    smdct_corr[pos_idx] = 16384;		/* (to be converted) the Q-facor of mdct_corr[] is not available */
#if (WMOPS)
    move16();
    move16();
#endif
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

}
