/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#ifndef __G711ENH_TABLE_H__
#define __G711ENH_TABLE_H__

extern Word16 sb_bound[4][2];
extern const Word16 pmag_cbk[];
extern Word16 ncb_alloc[MAX_HB_ENH_BITS+1];
extern Word16 sg2[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];
extern Word16 sge[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];
extern Word16 sgain[MAX_HB_ENH_BITS+1][MAX_NCB_GAIN];
extern Word16 tabpow[];

#endif	/* __G711ENH_TABLE_H__ */
