/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "bwe.h"
#include "avq.h"
#include "math_op.h"
#include "rom.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

void read_FEnv0(
                UWord16 *bptpt,
                UWord16 *index_gain,
                Word16  *FEnv0,
                Word16	*exp
                )
{
  Word16 index_fEnv_codebook, index_fEnv_codeword;
  Word16 *Pit_Fen;

#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) (2 * SIZE_Word16 + SIZE_Ptr), "dummy");
#endif

  *index_gain = GetBit( &bptpt, 5);    /* read & decode global gain */
  index_fEnv_codebook = GetBit( &bptpt, 1);
  bptpt++;    /* skip 2nd index_fEnv_codebook reading */
  index_fEnv_codeword = GetBit( &bptpt, 6);

  Pit_Fen = CodeBookH;  move16();
  *exp = 12;            move16();

  IF( index_fEnv_codebook==0 )
  {
    Pit_Fen = CodeBookL;  move16();
    *exp = 14;            move16();
  }

  *FEnv0 = Pit_Fen[shl(index_fEnv_codeword, 2)];

#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif

  return;
}

/*--------------------------------------------------------------------------*
*  Function  g711el0_decode_AVQ()		                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
*  Enhancement layer G711EL0 decoding, AVQ decoding of 6.4-8kHz band       *
*--------------------------------------------------------------------------*/
void g711el0_decode_AVQ (
                         UWord16      *bstr_EL0,   /* i:   Input bitstream for G711EL0 in soft bit format  */
                         Word16       smdct_err[], /* o:   Output MDCT coefficietns for mid-band           */ /* Q(smdct_errQ) */
                         const UWord16 *bstr_BWE,  /* i:   Input bitstream for SWBL0 in soft bit format    */
                         Word16       *smdct_errQ
                         ) 
{
#define QYFB 5

  Word16 i, mode;
  UWord16 *bptpt;
  UWord16 index_gain;
  Word16 unbits, sign[2], index_coefs;
  Word16 Yfb[NB_COEF_711_EL0];
  Word16 FEnv0;
  Word16 Gain, exp, exp2;
  Word32 L_tmp, L_tmp2, L_ener;

#ifdef DYN_RAM_CNT
  {
    UWord32	ssize;
    ssize = (UWord32) ((11+NB_COEF_711_EL0)*SIZE_Word16);
    ssize += (UWord32) (1*SIZE_Ptr);
    ssize += (UWord32) (3*SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif

  index_gain = 0;    move16();
  FEnv0 = 0;         move16();
  exp = 14;          move16();

  /* decode frequency envelope for 1st SWB subband */
  bptpt = (UWord16*)bstr_BWE;


  mode = GetBit( &bptpt, 1);
  IF( mode==NORMAL ) /* normal frame */
  {
    bptpt++;    /* skip noise_flag reading */
    read_FEnv0( bptpt, &index_gain, &FEnv0, &exp );
  }
  ELSE
  {
    mode = GetBit( &bptpt, 1 );
    IF( mode==0 ) /* sharp frame */
    {
      read_FEnv0( bptpt, &index_gain, &FEnv0, &exp );
    }
  }
  exp = sub(index_gain, exp);

  bptpt = (UWord16 *)bstr_EL0;

  /***** MB decoding *****/

  /* decode MB gain */
  index_gain = GetBit( &bptpt, N_BITS_G_MB );

  Gain = DQ_Gain_Norm[index_gain];move16();
  exp2 = DQ_Gain_Exp[index_gain]; move16();
  exp = sub(exp, exp2);
  exp2 = norm_s(FEnv0);
  FEnv0 = shl(FEnv0, exp2);
  exp = sub(exp, exp2);
  Gain = mult_r(Gain, FEnv0);

  /* read and decode AVQ parameters from G711EL0 */
  unbits = AVQ_Demuxdec_Bstr( bptpt, Yfb, N_BITS_AVQ_MB, N_SV_MB );
  bptpt += N_BITS_AVQ_MB;

  exp = add(exp, 15+QYFB); /* +15 because of round & QYFB */
  /* reconstruct output MDCT MB coefficients */
  FOR( i=0; i<NB_COEF_711_EL0; i++ )
  {
    smdct_err[i] = round_fx_L_shl_L_mult( Gain, Yfb[i], exp );
    move16();
  }

  L_ener = Sum_vect_E( smdct_err, NB_COEF_711_EL0/2 );

  /* reconstruct missing coefficients */
  IF( sub(unbits, N_BITS_FILL_MB) >= 0 )
  {
    bptpt -= unbits;

    /* read from the bitstream */
    sign[0] = GetBit( &bptpt, 1 ); move16();
    sign[1] = GetBit( &bptpt, 1 ); move16();
    index_coefs = GetBit( &bptpt, N_BITS_FILL_MB-1 );

    /* dequantize 2 coeficients */
    index_coefs = shl(index_coefs, 1);

    /* Both 'T_Qua_MB_Coef' in Q13 */
    L_tmp = L_mult(T_Qua_MB_Coef[index_coefs], Gain);
    L_tmp2 = L_mult(T_Qua_MB_Coef[index_coefs + 1], Gain);

    exp2 = sub(13, exp);
    /* After shift both in QYFB+16, after round will be in QYFB */
    L_tmp = L_shr(L_tmp, exp2);
    L_tmp2 = L_shr(L_tmp2, exp2);

    if( sign[0] == 0 )
      L_tmp = L_negate(L_tmp);
    if( sign[1] == 0 )
      L_tmp2 = L_negate(L_tmp2);

    IF( L_ener == 0 )
    {
      smdct_err[6] = round_fx(L_tmp);
      smdct_err[7] = round_fx(L_tmp2);
      move16();
      move16();
    }
    ELSE
    {
      smdct_err[8] = round_fx(L_tmp);
      smdct_err[9] = round_fx(L_tmp2);
      move16();
      move16();
    }
  }
  ELSE
  {
    i = GetBit( &bptpt, 1 );

    /* fill missing coefficients */
    IF( L_ener == 0 )
    {
      IF( i != 0)
      {
        L_tmp2 = L_mult0(29491, smdct_err[8]);
        L_tmp = L_mult0(22938, smdct_err[8]);                
      }
      ELSE
      {
        L_tmp2 = L_mult0(22938, smdct_err[8]);
        L_tmp = L_mult0(29491, smdct_err[8]);                
      }
      smdct_err[6] = round_fx(L_tmp2);
      smdct_err[7] = round_fx(L_tmp);
      move16();
      move16();
    }
  }

  *smdct_errQ = QYFB; move16();

#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
}

