/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "bwe.h"
#include "avq.h"
#include "math_op.h"
#include "rom.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

/*-----------------------------------------------------------------*
*   Funtion  Gain_Quant                                           *
*            ~~~~~~~~~~~~                                         *
*   Quantization of gains between the specified range             *
*   using the specified number of levels.                         *
*-----------------------------------------------------------------*/
static Word16 Gain_Quant(/* o:   quantization index            */
                         Word32 *L_gain   /* Q31 */
                         )
{
  Word16 idx;
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) SIZE_Word16, "dummy");
#endif

  idx = 0;                  move16();
  if (*L_gain != 0)
  {
    idx = -1;                 move16();
    DO
    {
      idx = add(idx, 1);
    }
    WHILE (L_sub(*L_gain, L_Gain_In[idx]) > 0);
    *L_gain = L_deposit_h(Gain_Out[idx]);
    move16();
  }

#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  return idx;
}

/*-----------------------------------------------------------------*
*  Function  g711el0_encode_AVQ()		                              *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
*  Enhancement layer G711EL0 encoding                             *
*-----------------------------------------------------------------*/
void g711el0_encode_AVQ(
                        const Word16   *smdct_err,       /* i:   Input MDCT coefficient error in mid-band    */ /* Q(smdctQ) */
                        unsigned short *bstr_buff,       /* o:   Output bitstream in soft bit format         */
                        Word16         *smdct_err_loc,   /* o:   Output MDCT coefficietns for mid-band       */ /* Q(smdctQ) */
                        const Word16   sfEnv_BWE0,       /* i:   Frequency envelope for 1st SWB subband      */ /* Q(scoef_SWBQ) */
                        const Word16   smdctQ,
                        const Word16   scoef_SWBQ
                        )
{
  Word16 i;
  UWord16 *bstr_tmp;
  Word16 unbits;

  Word16 index_gain, exp1, exp_num, exp_den;
  Word16 Yb_norm[(8+1)*N_SV_MB];
  Word16 Coef[2], Dist_min, Dist, *spt;
  Word16 iGain16, Gain16, tmp16,tmp16_2, tmpA;
  Word32 L_ener, L_Gain, L_tmp;
  Word32 L_tmp1;
  Word32 L_tmp2;
  Word16 Yb[NB_COEF_711_EL0];

  UWord16 *bptpt;
  Word16 index_fEnv_codebook, index_fEnv_codeword, FEnv0, ixg;
  Word16 *ptr0, *ptr1;
  Word16 sign16, tmp, tmp2;

  move16();
  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (5 * SIZE_Ptr);
    ssize += (UWord32) ((22 + (8+1)*N_SV_MB + NB_COEF_711_EL0)*SIZE_Word16);
    ssize += (UWord32) (5*SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/

  bstr_tmp = bstr_buff; move16();
  mov16( NB_COEF_711_EL0, (Word16 *) smdct_err, Yb );
  L_ener = 1; move32();
  FOR( i=0; i<NB_COEF_711_EL0; i++ )
  {
    L_ener = L_mac(L_ener, Yb[i], Yb[i]);
  }

  /*1.0f/(Sqrt((16.0*fEnv_BWE0*fEnv_BWE0)/ene));*/
  L_tmp = L_mult(sfEnv_BWE0, sfEnv_BWE0);
  exp_num = norm_l(L_tmp);
  tmp16_2 = round_fx(L_shl(L_tmp, exp_num));
  exp_num = sub(30 ,exp_num);
  exp_num = sub(exp_num, shl(scoef_SWBQ,1));  

  exp_den = norm_l(L_ener);                      
  tmp16 = extract_h_L_shl(L_ener, exp_den);
  exp_den = sub(30, exp_den);
  exp_den = sub(exp_den, shl(smdctQ,1));

  tmpA = shr(sub(tmp16, tmp16_2), 15);
  tmp16_2 = shl(tmp16_2, tmpA);
  exp_num = sub(exp_num, tmpA);
  tmp16 = div_s(tmp16_2, tmp16);
  L_tmp = L_deposit_h(tmp16);
  exp_den = sub(exp_num,exp_den);

  L_tmp1 = Isqrt_lc(L_tmp, &exp_den);
  L_Gain = L_shl(L_tmp1, add(exp_den,-2));      

  /* L_gain is in Q31 (-2 is for /NB_COEF_711_EL0) */
  /* minimum gain is 0.01 and maximum gain is 0.8 */
  index_gain = Gain_Quant(&L_Gain);

  L_tmp = L_mult(round_fx(L_Gain), sfEnv_BWE0);

  L_tmp = L_max(1, L_tmp); /* To avoid 0 */
  exp1 = norm_l(L_tmp);
  L_tmp = L_shl(L_tmp, exp1);
  /* Invert Gain */
  tmp16 = div_s(0x4000, extract_h(L_tmp));
  exp1 = sub(14, add(exp1,scoef_SWBQ)); /* last substract by 1 is for 0x4000 which is not 0x7FFF */

  iGain16 = round_fx(L_mult(tmp16, INV_CNST_WEAK_FX));  /*Qx*Q5 -> Q17*/
  exp1 = add(exp1, 5); /* to get gain in Q0 */

  exp1 = add(exp1,sub(smdctQ,15)); /* to get Yb in Q0 */
  FOR(i=0; i<NB_COEF_711_EL0; i++)
  {
    Yb[i] = round_fx_L_shr_L_mult( Yb[i], iGain16, exp1 );
    move16();
  }

  AVQ_Cod( Yb, Yb_norm, N_BITS_AVQ_MB, N_SV_MB );

  /* write MB AVQ parameters to the bitstream */
  PushBit( index_gain, &bstr_tmp, N_BITS_G_MB );
  unbits = AVQ_Encmux_Bstr( Yb_norm, &bstr_tmp, N_BITS_AVQ_MB, N_SV_MB );

  tmp16 = sub(add(smdctQ,16),scoef_SWBQ); 

  bptpt = bstr_buff-NBITS_MODE_R1SM_BWE; move16();
  tmp16 = GetBit( &bptpt, 8); 
  index_fEnv_codebook = s_and(tmp16, 1);
  tmp16 = shr(tmp16,1);
  ixg = s_and(tmp16, 0x1F);
  tmp16 = GetBit( &bptpt, 7); 
  index_fEnv_codeword = s_and(tmp16, 0x3F);
  tmp16 = shl(index_fEnv_codeword, 2);

  exp1 = sub(ixg, 12);
  FEnv0 = CodeBookH[tmp16]; move16();

  IF( index_fEnv_codebook==0 ) {
    exp1 = sub(ixg, 14);
    FEnv0 = CodeBookL[tmp16]; move16();
  }

  Gain16 = DQ_Gain_Norm[index_gain];    move16();
  tmp16 = sub(exp1, DQ_Gain_Exp[index_gain]); 
  tmp16_2 = norm_s(FEnv0);
  tmpA = shl(FEnv0, tmp16_2);
  tmp16 = sub(tmp16, tmp16_2); 

  Gain16 = mult_r(Gain16, tmpA);

  tmp16 = add(tmp16, 20);

  FOR( i=0; i<NB_COEF_711_EL0; i++ )
  {
    smdct_err_loc[i] = round_fx_L_shl_L_mult( Yb_norm[i], Gain16, tmp16 );
    move16();
  }

  /* fill missing coefficients */
  IF( sub(unbits, N_BITS_FILL_MB) >= 0 )
  {
    bstr_tmp -= unbits;

    L_ener = Sum_vect_E( smdct_err_loc, NB_COEF_711_EL0/2 );
    ptr0 = Yb + 6;
    ptr1 = smdct_err_loc + 6;
    IF(L_ener != 0) {
      ptr0 += 2;
      ptr1 += 2;
    }
    sign16 = 0; move16();
    if(*ptr0 >= 0) sign16 = add(sign16, 1);
    Coef[0] = round_fx(L_shl(L_mult0(abs_s(*ptr0++),CNST_WEAK_FX),5));    /*Q13 */ 
    move16();
    sign16 = shl(sign16, 1);
    if(*ptr0 >= 0) sign16 = add(sign16, 1);
    Coef[1] = round_fx(L_shl(L_mult0(abs_s(*ptr0--),CNST_WEAK_FX),5));    /*Q13 */ 
    move16();

    /* quantize 2 coeficients */
    spt = (Word16 *) T_Qua_MB_Coef;    
    index_gain = 0;                             move16();
    Dist_min = MAX_16;                          move16();

    FOR( i = 0; i<8; i++ )
    {
      Dist  = abs_s(sub(Coef[0], *spt) );
      spt++;
      Dist = add(Dist, abs_s(sub(Coef[1], *spt) ));
      spt++;

      if (sub(Dist,  Dist_min )< 0 )
      {
        index_gain = i;                     move16();
      }
      Dist_min = s_min(Dist, Dist_min) ;
    }
    /* dequantize 2 coeficients */
    spt = (Word16 *) T_Qua_MB_Coef + shl(index_gain,1);

    Coef[0] = *spt; move16();
    Coef[1] = *(spt+1); move16();

    tmp16 = sub(tmp16, 13); 
    L_tmp = L_shl(L_mult(Coef[0], Gain16),tmp16);
    L_tmp2= L_shl(L_mult(Coef[1], Gain16),tmp16);

    if( s_and(sign16, 2) == 0 )
      L_tmp = L_negate(L_tmp);
    if( s_and(sign16, 1) == 0 )
      L_tmp2 = L_negate(L_tmp2);
    *ptr1 = round_fx(L_tmp); move16();
    *(ptr1+1) = round_fx(L_tmp2); move16();

    /* Write to the bitstream */
    /* sign[n] > 0 ==> '1' otherwise '0' */
    PushBit( sign16, &bstr_tmp, 2 );
    PushBit( index_gain, &bstr_tmp, N_BITS_FILL_MB-1 );
  }
  ELSE
  {
    i = 0; move16();
    if( sub(abs_s(Yb[6]),abs_s(Yb[7])) > 0 )
    {
      i = 1; move16();
    }
    PushBit( i, &bstr_tmp, 1 );

    IF( Sum_vect_E( smdct_err_loc, NB_COEF_711_EL0/2 ) == 0 )
    {
      tmp = round_fx(L_mult0(29491, smdct_err_loc[8]));
      tmp2 = round_fx(L_mult0(22938, smdct_err_loc[8]));

      IF( i )
      {
        smdct_err_loc[6] = tmp; move16();
        smdct_err_loc[7] = tmp2; move16();
      }
      ELSE
      {
        smdct_err_loc[6] = tmp2; move16();
        smdct_err_loc[7] = tmp; move16();
      }
    }
  }
  /* Bring the vector back from Q5 to smdctQ */
  tmp = sub(5, smdctQ);
  array_oper( NB_COEF_711_EL0, tmp, smdct_err_loc, smdct_err_loc, shr_r );

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/
  return;

}
