/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "pcmswb_common.h"
#include "re8.h"
#include "avq.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

/*-------------------------------------------------------------------*
* Function prototypes
*-------------------------------------------------------------------*/

static void RE8_Dec(
                    Word16 n,     /* i  : codebook number (*n is an integer defined in {0,2,3,4,..,n_max})*/
                    UWord16 I,     /* i  : index of c (pointer to unsigned 16-bit word)            */
                    Word16 k[],   /* i  : index of v (8-dimensional vector of binary indices) = Voronoi index */
                    Word16 y[]    /* o  : point in RE8 (8-dimensional integer vector)             */
);

/*-----------------------------------------------------------------*
*   Function  AVQ_Demuxdec_Bstr                                   *
*            ~~~~~~~~~~~~~~~~~~                                   *
*   Read indexes from one bitstream and decode subvectors.        *
*-----------------------------------------------------------------*/

Word16 AVQ_Demuxdec_Bstr(
                         UWord16 *pBst,    /* i/o: pointer to the bitstream buffer */
                         Word16  xriq[],  /* o:   decoded subvectors [0..8*Nsv-1] */
                         const Word16  nb_bits, /* i:   number of allocated bits        */
                         const Word16  Nsv      /* i:   number of subvectors            */
                         )
{
  Word16 i,j, bits, order_v;

  UWord16 I[NSV_MAX];
  Word16 nq[NSV_MAX], *kv, code[8];
  Word16 tmp16;

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) (((13 + 2 * NSV_MAX) * SIZE_Word16) + SIZE_Ptr), "dummy");
#endif
  /*****************************/

  zero16( NSV_MAX, (Word16*)I);
  zero16( 8, code);

  kv = xriq;        /* reuse vector to save memory */	move16();	
  bits = nb_bits;     move16();

  FOR( i=0; i<Nsv; i++ )
  {
    nq[i] = 0;      move16();/* initialization and also forced if the budget is exceeded */

    IF( sub(bits, 8) > 0 )
    {
      /* read the unary code including the stop bit for nq[i] */
      WHILE( sub(*pBst++, ITU_G192_BIT_1) == 0 )
      {
        nq[i] = add(nq[i], 1); move16();
        /* 5*nq[i]+4 == bits */
        tmp16 = sub(add(add(shl(nq[i], 2), nq[i]), 4), bits);
        if(tmp16 == 0) /* check the overflow */
        {
          bits = add(bits, 1);     /* overflown stop bit */
          BREAK;
        }

      }
      bits = sub(bits, nq[i]);
      bits = sub(bits, 1);     /* count the stop bit */

      if( nq[i] > 0 )
      {
        nq[i] = add(nq[i], 1); move16();
      }

      /* read codebook indices (rank I and event. Voronoi index kv) */
      IF( nq[i] != 0 )    /* for Q0 nothing to read */
      {
        IF( sub(nq[i], 5) < 0 )    /* Q2, Q3, Q4 */
        {
          tmp16 = shl(nq[i], 2);
          order_v = 0;                        move16();
        }
        ELSE            /* for Q3/Q4 + Voronoi extensions r=1,2 */
        {
          j = 1;                              move16();
          if( s_and(nq[i], 1) == 0 )    
          {
            j = add(j,1);
          }
          order_v = sub(shr(nq[i], 1), j);  /* Voronoi order determination */
          tmp16 = shl(add(j, 2), 2);
        }

        I[i] = (Word16)GetBitLong( &pBst, tmp16 );		move16();	
        bits = sub(bits, tmp16);

        IF( order_v > 0 )
        {
          tmp16 = shl(i, 3);
          FOR( j=0; j<8; j++ )
          {
            kv[tmp16+j] = (Word16)GetBitLong( &pBst, order_v ); move16();
          }
          bits = sub(bits, shl(order_v, 3));
        }
      }
    }
  }

  pBst += bits;       /* skip the rest of the bitstream */

  /* decode all subvectors */
  FOR( i=0; i<Nsv; i++ )
  {
    /* multi-rate RE8 decoder */
    RE8_Dec( nq[i], I[i], kv, code );
    kv += 8;

    /* write decoded RE8 vector to decoded subvector #i */
    mov16( 8, code, xriq);
    xriq += 8;
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/ 

  return bits;
}


/*--------------------------------------------------------------------------
* RE8_dec:
*
* MULTI-RATE INDEXING OF A POINT y in THE LATTICE RE8 (INDEX DECODING)
* note: the index I is defined as a 32-bit word, but only
* 16 bits are required (long can be replaced by unsigned integer)
*--------------------------------------------------------------------------*/
void RE8_Dec(
             Word16 n,     /* i  : codebook number (*n is an integer defined in {0,2,3,4,..,n_max})*/
             UWord16 I,     /* i  : index of c (pointer to unsigned 16-bit word)            */
             Word16 k[],   /* i  : index of v (8-dimensional vector of binary indices) = Voronoi index */
             Word16 y[]    /* o  : point in RE8 (8-dimensional integer vector)             */
)
{
  Word16 i, m, v[8];

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) (10 * SIZE_Word16), "dummy");
#endif
  /*****************************/

  /*------------------------------------------------------------------------*
  * decode the sub-indices I and kv[] according to the codebook number n:
  *  if n=0,2,3,4, decode I (no Voronoi extension)
  *  if n>4, Voronoi extension is used, decode I and kv[]
  *------------------------------------------------------------------------*/
  IF (sub(n, 4) <= 0)
  {
    re8_decode_base_index(n, I, y);
  }
  ELSE
  {
    /*--------------------------------------------------------------------*
    * compute the Voronoi modulo m = 2^r where r is extension order
    *--------------------------------------------------------------------*/
    m = 0;                               move16();

    WHILE (sub(n, 4) > 0)
    {
      m = add(m, 1);
      n = sub(n, 2);
    }

    /*--------------------------------------------------------------------*
    * decode base codebook index I into c (c is an element of Q3 or Q4)
    *  [here c is stored in y to save memory]
    *--------------------------------------------------------------------*/

    re8_decode_base_index(n, I, y);

    /*--------------------------------------------------------------------*
    * decode Voronoi index k[] into v
    *--------------------------------------------------------------------*/
    RE8_k2y(k, m, v);

    /*--------------------------------------------------------------------*
    * reconstruct y as y = m c + v (with m=2^r, r integer >=1)
    *--------------------------------------------------------------------*/
    FOR (i=0; i<8; i++)
    {
      /* y[i] = m*y[i] + v[i] */
      y[i] = add(shl(y[i], m), v[i]);  move16();
    }
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/ 

}
