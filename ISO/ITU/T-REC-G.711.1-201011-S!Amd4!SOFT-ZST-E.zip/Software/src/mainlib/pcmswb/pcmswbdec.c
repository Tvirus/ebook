/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "bit_op.h"
#include "errexit.h"
#include "pcmswb_common.h"
#include "softbit.h"
#include "qmfilt.h"
#include "G711WB_lowband.h"
#include "G711WB_highband.h"
#include "bwe.h"
#include "avq.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

#define OK  0
#define NG  1

#define moveADDR()      move16()

#ifdef WMOPS
extern Word16           Id;
#endif

typedef struct {
  Word16  Mode;               /* Decoding mode */
  Word16  OpFs;               /* Sampling frequency */
  Word16  law;                /* Logarithmic law */
  Word16  gain_ns;            /* Noise shaping gain */
  void*   G711WB_SubDecoderL; /* Work space for G.711.1 lower-band */
  void*   G711WB_SubDecoderH; /* Work space for G.711.1 higher-band */
  void*   SubDecoderSH;       /* Work space for super-higher-band sub-decoder */
  void*   SubDecoderBWE;      /* Work space for 8kbps swb extension */
  void*   pQMFBuf_SWB;        /* QMF filter buffer for SWB */
  void*   pQMFBuf_WB;         /* QMF filter buffer for WB */
  Word16  sDiffMDCTCoefHigh[16]; /* Differential MDCT coefficients in G.711.1 higher-band Q(sDiffMDCTCoefHighQ) */
  Word16  sDiffMDCTCoefHighQ;
  Word16 prev_Mode;
  Word16 prev2_Mode;
  Word16 prev_ploss_status;
  Word16 sattenu; /* Q(15) */
  Word16 sattenu1;/* Q(15) */
  Word16 sattenu3;/* Q(15) */
  Word16 sprev_fenv[8];
  Word16 prev_bit_switch_flag, bit_switch_count;
  Word16 bit_switch_status;
} pcmswbDecoder_WORK;

/*----------------------------------------------------------------
Function:
PCM SWB decoder constructor
Return value:
Pointer to work space
----------------------------------------------------------------*/
void *pcmswbDecode_const(
                         Word16  core,  /* (i): Core mode (G711ALAW_CORE / G711ULAW_CORE) */
                         Word16  mode   /* (i): Decoding mode      */
                         )
{
  pcmswbDecoder_WORK *w=NULL;
  Word16 law;

  /* Static memory allocation */
  w = (void *)malloc( sizeof(pcmswbDecoder_WORK) );
  if ( w == NULL )  return NULL;

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (0);
#ifdef MEM_STT
    ssize += (UWord32) (sizeof(pcmswbDecoder_WORK));
#endif
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/
  w->Mode = mode; move16();
  w->prev_Mode = -1; move16();
  w->prev2_Mode = -1; move16();
  test();
  IF (sub(core, G711ULAW_CORE) != 0 && sub(core, G711ALAW_CORE)) {
    error_exit("Core specification error.");
  }

  SWITCH (w->Mode) {
  case MODE_R1nm  : w->OpFs =  8000; move16(); BREAK;
  case MODE_R2nm  : w->OpFs =  8000; move16(); BREAK;
  case MODE_R2wm  : w->OpFs = 16000; move16(); BREAK;
  case MODE_R3wm  : w->OpFs = 16000; move16(); BREAK;
  case MODE_R3sm  : w->OpFs = 32000; move16(); BREAK;
  case MODE_R4sm  : w->OpFs = 32000; move16(); BREAK;
  case MODE_R4ssm : w->OpFs = 32000; move16(); BREAK;
  case MODE_R5ssm : w->OpFs = 32000; move16(); BREAK;
  default : error_exit("Decoding mode error.");
  }

  law = MODE_ULAW;	move16();
  if (sub(core, G711ALAW_CORE) == 0)
  {
    law = MODE_ALAW;	move16();
  }

  w->G711WB_SubDecoderL = lowband_decode_const(law);
  IF ( w->G711WB_SubDecoderL == NULL )  error_exit( "Lower band init error." );

  w->G711WB_SubDecoderH = highband_decode_const();
  IF ( w->G711WB_SubDecoderH == NULL )  error_exit( "Higher band init error." );

  w->pQMFBuf_WB = QMFilt_const(NTAP_QMF_WB, sSWBQmf0, sSWBQmf1);

  IF ( w->pQMFBuf_WB == NULL )  error_exit( "QMF init error." );
  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize = 0;
#ifdef MEM_STT
    /* static RAM for G.711.1 core */
    ssize += (UWord32) (3000);
#endif
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/

  w->pQMFBuf_SWB = QMFilt_const(NTAP_QMF_SWB, sSWBQmf0, sSWBQmf1);

  IF ( w->pQMFBuf_SWB == NULL )  error_exit( "QMF init error." );

  w->SubDecoderBWE = bwe_decode_const();

  IF (w->SubDecoderBWE == NULL)  error_exit( "BWE init error." );

  /* constructor for AVQ decoder */
  IF (sub(w->Mode, MODE_R3sm) >= 0)
  {
    w->SubDecoderSH = avq_decode_const();
    if (w->SubDecoderSH == NULL) error_exit( "AVQ decoder init error." );
  }

  pcmswbDecode_reset( (void *)w );

  return (void *)w;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder set mode and output SF in bitrateswitch mode
Return value:
Pointer to work space
----------------------------------------------------------------*/
Word16 pcmswbDecode_set(
                        Word16  mode,  /* (i): Decoding mode      */
                        void*  p_work  /* (i/o): Work space */
                        )
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) SIZE_Ptr, "dummy");
#endif
  w->Mode = mode; move16();
  w->OpFs = 32000; move16();

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/  
  return OK;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder destructor
Return value:
None
----------------------------------------------------------------*/
void pcmswbDecode_dest(
                       void*  p_work  /* (i): Work space */
                       )
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

  if( w != NULL ) {
    lowband_decode_dest( w->G711WB_SubDecoderL );    /* Lower band */
    highband_decode_dest( w->G711WB_SubDecoderH );   /* Higher band */
    QMFilt_dest( w->pQMFBuf_WB );                    /* QMF for WB */
    /*****************************/
#ifdef DYN_RAM_CNT
    /* static RAM for G.711.1 core */
    DYN_RAM_POP();
#endif
    /*****************************/  
    QMFilt_dest( w->pQMFBuf_SWB );              /* QMF for SWB */

    bwe_decode_dest( w->SubDecoderBWE );

    /* destructor for AVQ decoder */
    IF (sub(w->Mode, MODE_R3sm) >= 0)
    {
      avq_decode_dest (w->SubDecoderSH);
    }

    free( w );

    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/  

  }
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder reset
Return value:
OK
----------------------------------------------------------------*/
Word16  pcmswbDecode_reset(
                           void*  p_work  /* (i/o): Work space */
                           )
{
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;

#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) SIZE_Ptr, "dummy");
#endif
  if( w != NULL ) {/* use if, this is implementation dependant. Should never happen */
    lowband_decode_reset( w->G711WB_SubDecoderL );    /* Lower band */
    highband_decode_reset( w->G711WB_SubDecoderH );   /* Higher band */
    QMFilt_reset( w->pQMFBuf_WB );                    /* QMF for WB */
    QMFilt_reset( w->pQMFBuf_SWB );            /* QMF for SWB */

    bwe_decode_reset( w->SubDecoderBWE );

    /* reset for AVQ decoder */
    IF (sub(w->Mode, MODE_R3sm) >= 0)
    {
      avq_decode_reset (w->SubDecoderSH);
    }
    w->gain_ns = 32767; move16();  /* start with full gain */
    w->sattenu = 3277; move16();   /* Q(15) */ 
    w->sattenu1 = 3277; move16();  /* Q(15) */ 
    w->sattenu3 = 32767; move16(); /* Q(15) */ 
    w->prev_ploss_status = 0; move16();
    w->prev_bit_switch_flag = 0; move16();
    w->bit_switch_count = 0; move16();
    w->bit_switch_status = 0; move16();
    w->sDiffMDCTCoefHighQ = 0; move16();
    zero16( 16, w->sDiffMDCTCoefHigh );        /* Differential MDCT coefficients in G.711.1 higher-band */
    zero16(8, w->sprev_fenv);
  }
  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/  
  return OK;
}

/*----------------------------------------------------------------
Function:
PCM SWB decoder
Return value:
OK/NG
----------------------------------------------------------------*/
Word16  pcmswbDecode(
                     const unsigned char*  bitstream,   /* (i):   Input bitstream  */
                     Word16*               outwave,     /* (o):   Output signal    */
                     void*                 p_work,      /* (i/o): Work space       */
                     Word16                ploss_status /* (i):   Packet-loss flag */
                     ) 
{
  unsigned char  *bpt = (unsigned char  *)bitstream, *bptmp;
  Word16  SubSigLow[L_FRAME_NB];  /* 0-4 kHz signal (low, 40 points) */
  Word16  SubSigHigh[L_FRAME_NB]; /* 4-8 kHz signal (mid, 40 points) */
  Word16  nb_sig[L_FRAME_NB];
  Word16  SubSigSuperWideLowQMF[L_FRAME_WB];
  Word16  SubSigSuperWideHighQMF[L_FRAME_WB];  /* 8-14 kHz signal (high, 80 points) */
  Word16  i, n;
  Word16  gain;
  Word32  gain32;
  Word32  powerL, powerH;
  pcmswbDecoder_WORK *w=(pcmswbDecoder_WORK *)p_work;
  UWord16 bst_buff2[NBitsPerFrame_SWB_2], *pBit_MB2 = NULL, *pBit_SVQ2;
  UWord16 *pBit_MB, *pBit_SVQ;
  UWord16 *pBit_BWE, bst_buff[NBitsPerFrame_SWB_1];
  Word16  snb_mdct[L_FRAME_NB]; /* Q(sSpectrumQ) */
  Word16  index_g; /* 5bit index of frame gain */
  Word16  sTenv_SWB[SWB_TENV]; /* Q(0) */
  Word16  scoef_SWB[SWB_F_WIDTH]; /* Q(scoef_SWBQ) */
  Word16  sFenv_SVQ[SWB_NORMAL_FENV]; /* Q(scoef_SWBQ) */
  Word16  sSpectrumQ;
  Word16  scoef_SWBQ;
  Word16  cod_Mode, T_modify_flag;
  Word16  layers_SWB;
  Word16  bit_switch_flag;
  Word16  ploss_status_buff;

  /* initialize */
  gain = 32767;          move16();
  layers_SWB = 0;        move16();
  sSpectrumQ = 0;        move16();
  scoef_SWBQ = 0;        move16();
  bit_switch_flag = 0;   move16();
  ploss_status_buff = 0; move16();
  zero16( NBitsPerFrame_SWB_1, (Word16*)bst_buff);
  zero16( NBitsPerFrame_SWB_2, (Word16*)bst_buff2);
  zero16( L_FRAME_NB, snb_mdct);
  zero16( SWB_TENV, sTenv_SWB);
  zero16( SWB_F_WIDTH, scoef_SWB);
  zero16( SWB_NORMAL_FENV, sFenv_SVQ);

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (8 * SIZE_Ptr);
    ssize += (UWord32) ((11 + 4 * L_FRAME_NB + 2 * L_FRAME_WB + SWB_TENV + SWB_F_WIDTH + SWB_NORMAL_FENV) * SIZE_Word16);
    ssize += (UWord32) ((NBitsPerFrame_SWB_1 + NBitsPerFrame_SWB_2) * SIZE_Word16); /* UWord16 */
    ssize += (UWord32) (3 * SIZE_Word32);
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/

  if (p_work == NULL)
  {
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/
    return NG;
  }

  zero16(L_FRAME_NB,SubSigHigh); 
  zero16(L_FRAME_WB,SubSigSuperWideHighQMF); 

  /* ------------------------------------------- */
  /* Super higher-band enhancement layer decoder */
  /* ------------------------------------------- */
  test();test();test();
  IF ((sub(w->Mode, MODE_R3sm) == 0)  ||  /* G.711.1 */
    (sub(w->Mode, MODE_R4sm) == 0)  ||  /* G.711.1 */
    (sub(w->Mode, MODE_R4ssm) == 0) ||  /* G.711.1 */
    (sub(w->Mode, MODE_R5ssm) == 0) )   /* G.711.1 */
  {
    test();
    IF ((sub(w->Mode, MODE_R3sm) == 0) || (sub(w->Mode, MODE_R4sm) == 0)) { /* G.711.1 CORE (R2b) */
      bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_2;	
    }
    ELSE { /* w->Mode == MODE_R4ssm || w->Mode == MODE_R5ssm */ /* G.711.1 CORE (R3) */
      bptmp = bpt + NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1 + NBytesPerFrame_G711WB_2; 
    }
    hardbit2softbit( NBytesPerFrame_SWB_1, bptmp, bst_buff );

    pBit_BWE = bst_buff;
    pBit_MB = bst_buff + NBITS_MODE_R1SM_BWE;	

    /* extract mode information */
    cod_Mode = 0;	move16();
    if (sub(bst_buff[0], G192_BITONE) == 0)
    {
      cod_Mode = 2;
      move16();
    }
    if (sub(bst_buff[1], G192_BITONE) == 0)
    {
      cod_Mode = add(cod_Mode, 1);
    }

    /* decode 6.4-8kHz subband for mid-band */
    IF (sub(cod_Mode, TRANSIENT) != 0)
    {
      g711el0_decode_AVQ( pBit_MB, w->sDiffMDCTCoefHigh, pBit_BWE, &(w->sDiffMDCTCoefHighQ) );
    }
    test();
    IF ((sub(w->Mode,MODE_R4sm)  == 0) ||
      (sub(w->Mode, MODE_R5ssm) == 0) )
    {
      bptmp += NBytesPerFrame_SWB_1;	
      hardbit2softbit( NBytesPerFrame_SWB_2, bptmp, bst_buff2 );
    }
    pBit_MB2 = bst_buff2;
  }

  /* ------------------------------------------------------------- */
  /* Lower-band decoder including both core and enhancement layers */
  /* Frame erasure concealment is integrated in the decoder.       */
  /* ------------------------------------------------------------- */
  test();test();test();
  IF ((sub(w->Mode, MODE_R2a) == 0)   ||
    (sub(w->Mode, MODE_R3) == 0)    ||
    (sub(w->Mode, MODE_R4ssm) == 0) ||
    (sub(w->Mode, MODE_R5ssm) == 0)) {

      /* Core layer + Lower band enhancement layer */
      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_PUSH(1400, "dummy"); /* max scratch RAM of G.711.1 decoder */
#endif
      /*****************************/
      lowband_decode( bpt, bpt+NBytesPerFrame_G711WB_0, ploss_status, 
        SubSigLow, &gain, w->G711WB_SubDecoderL, nb_sig );
      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_POP();
#endif
      /*****************************/
      bpt += (NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1);	
  }
  ELSE { /* w->Mode == MODE_R1 || w->Mode == MODE_R2b || w->Mode == MODE_R3sm || w->Mode == MODE_R4sm */
    /* Core layer only */
    /* When the second parameter is NULL, this decoder works as G.711 decoder. */
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_PUSH(1400, "dummy"); /* max scratch RAM of G.711.1 decoder */
#endif
    /*****************************/
    lowband_decode( bpt, NULL, ploss_status, SubSigLow, 
      &gain, w->G711WB_SubDecoderL, nb_sig );
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/
    bpt += NBytesPerFrame_G711WB_0;	
  }

  /* ------------------------------------- */
  /* Higher-band enhancement layer decoder */
  /* ------------------------------------- */
  test();test();test();test();test();
  IF ((sub(w->Mode, MODE_R2b) == 0)   ||
    (sub(w->Mode, MODE_R3) == 0)    ||
    (sub(w->Mode, MODE_R3sm) == 0)  ||
    (sub(w->Mode, MODE_R4sm) == 0)  ||
    (sub(w->Mode, MODE_R4ssm) == 0) ||
    (sub(w->Mode, MODE_R5ssm) == 0)) {

      IF (ploss_status != 0) {
        /* Get the LB pitch for HB FERC */
        copy_lb_pitch(w->G711WB_SubDecoderL, w->G711WB_SubDecoderH);
      }
      test();
      IF ((sub(w->Mode, MODE_R2b) == 0) || (sub(w->Mode, MODE_R3) == 0)) {
        zero16(16, w->sDiffMDCTCoefHigh); 
        cod_Mode = -1; /* for SWB/WB bandwidth switching */
        move16();
      }

      bit_switch_flag = 0;		move16();
      IF(w->prev_Mode >= 0)
      {
        test();
        if((sub(w->Mode, MODE_R3sm) < 0) && (sub(w->prev_Mode, MODE_R3sm) >= 0))
        {
          bit_switch_flag = 1;	move16();
        }
        test();
        if((sub(w->Mode, MODE_R3sm) >= 0) && (sub(w->prev2_Mode, MODE_R3sm) < 0))
        {
          bit_switch_flag = 2;	move16();
        }
      }

      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_PUSH(1400, "dummy"); /* max scratch RAM of G.711.1 decoder */
#endif
      /*****************************/
      sSpectrumQ = highband_decode( bpt, ploss_status, SubSigHigh, w->G711WB_SubDecoderH, 
        cod_Mode, snb_mdct /* Q(sSpectrumQ) */, w->sDiffMDCTCoefHigh, (const Word16*)pBit_MB2, w->Mode,
        bit_switch_flag, w->sattenu, &(w->sDiffMDCTCoefHighQ)  
        );

      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_POP();
#endif
      /*****************************/
      bpt += NBytesPerFrame_G711WB_2;	
  }

  /* --------------------- */
  /* Band reconstructing   */
  /* --------------------- */
  IF (sub(w->OpFs, 8000) == 0) {
    mov16( L_FRAME_NB, SubSigLow, outwave );
  }
  ELSE IF (sub(w->OpFs, 16000) == 0) {
    /* Band reconstructing with QMF */
    QMFilt_syn(L_FRAME_NB, SubSigLow, SubSigHigh, outwave, w->pQMFBuf_WB );
  }
  ELSE { /* w->OpFs == 32000 */
    /* Band reconstructing with QMF */
    QMFilt_syn(L_FRAME_NB, SubSigLow, SubSigHigh, SubSigSuperWideLowQMF, w->pQMFBuf_WB );

    test();
    IF (sub(w->Mode, MODE_R3sm) >= 0 || sub(w->prev_Mode, MODE_R3sm) >= 0)
    {
      /* Decode frequncy parameter of BWE */  
      test();test();
      IF(w->prev_Mode < 0)
      {
        w->prev2_Mode = w->Mode; move16();
        w->bit_switch_count = 0; move16();
      }
      ELSE IF((sub( w->Mode, MODE_R3sm ) < 0) && (sub( w->prev_Mode, MODE_R3sm ) >= 0))
      {
        w->prev2_Mode = w->Mode; move16();
        bit_switch_flag = 1; move16();
        w->bit_switch_count++; move16();
      }
      ELSE IF((sub( w->Mode, MODE_R3sm ) >= 0) && (sub( w->prev2_Mode, MODE_R3sm ) < 0))
      {
        bit_switch_flag = 2; move16();
        w->bit_switch_count = 0; move16();
      }
      ELSE
      {
        w->bit_switch_count = 0; move16();
      }
      pBit_BWE = bst_buff;

      cod_Mode = NORMAL; move16();
      IF(sub( w->Mode, MODE_R3sm ) >= 0)
      {
        UWord16 *pBit = pBit_BWE;
        cod_Mode = GetBit(&pBit, 2);
      }
      ploss_status_buff = ploss_status; move16();
      test();
      if (sub(w->prev_ploss_status, 1)==0 && sub(cod_Mode, 1)<=0)
      {
        ploss_status = 1; move16();
      }

      T_modify_flag =
        bwe_dec_freqcoef( &pBit_BWE, nb_sig, w->SubDecoderBWE, 
        &cod_Mode, 
        sTenv_SWB,     /* Q(0) */
        scoef_SWB,     /* Q(scoef_SWBQ) */
        &index_g, 
        sFenv_SVQ,     /* Q(scoef_SWBQ) */
        snb_mdct,      /* Q(sSpectrumQ) */
        ploss_status,
        bit_switch_flag,
        w->prev_bit_switch_flag,
        &scoef_SWBQ,
        (const Word16)sSpectrumQ
        );

      /* Decode MDCT coefficents */
      IF (sub(w->Mode, MODE_R3sm) >= 0)
      {
        test();
        IF (ploss_status == 0 && w->bit_switch_status == 0)
        {            
          layers_SWB = 1;	move16();
          test();
          if ((sub(w->Mode, MODE_R4sm) == 0) || (sub(w->Mode, MODE_R5ssm) == 0))
          {
            layers_SWB = 2;	move16();
          }
          pBit_SVQ = bst_buff + NBITS_MODE_R1SM_TOTLE;    
          pBit_SVQ2 = bst_buff2 + NBitsPerFrame_EL1;	

          swbl1_decode_AVQ( (void*)w->SubDecoderSH, pBit_SVQ, pBit_SVQ2, (const Word16*)sFenv_SVQ, scoef_SWB, index_g, cod_Mode, layers_SWB, &scoef_SWBQ );
          w->prev_ploss_status = 0; move16();
        }
        ELSE
        {
          bwe_avq_buf_reset(w->SubDecoderSH);

          w->prev_ploss_status = 1; move16();
          IF (ploss_status_buff == 0)
          {
            AVQ_state_dec *wtmp = w->SubDecoderSH;

            w->prev_ploss_status = 0; move16();
            wtmp->pre_cod_Mode = cod_Mode; move16();
          }
        }
      }

      IF(sub(bit_switch_flag, 1) == 0)
      {
        array_oper(60, w->sattenu3, scoef_SWB, scoef_SWB, &mult);
        if(sub((Word16) w->bit_switch_count, 200) > 0)
        {			  
          w->sattenu3 = sub(w->sattenu3, 655); /* Q15 */
        }
        w->sattenu3 = s_max(w->sattenu3, 16384);
      }
      ELSE
      {
        w->sattenu3 = 32767; move16();
      }

      IF(sub(bit_switch_flag, 2) == 0)
      {
        array_oper(60, w->sattenu, scoef_SWB, scoef_SWB, &mult);
        w->sattenu = add(w->sattenu, 655); /* Q15 */
        w->prev2_Mode = MODE_R2wm; move16();
        IF(sub(w->sattenu, 32767) == 0) /* if sattenu > 32767, sattenu was saturated to 32767 at last add(). */
        {
          w->sattenu = 3277; move16();
          bit_switch_flag = 0; move16();
          w->prev2_Mode = w->Mode; move16();
        }
      }

      IF(bit_switch_flag == 0) 
      {
        IF(sub((Word16) w->prev_bit_switch_flag, 1) == 0)
        {
          w->sattenu1 = 3277; move16();
        }
      }
      ELSE
      {
        IF(sub( w->sattenu1, 32767) < 0 )
        {
          array_oper(60, w->sattenu1, scoef_SWB, scoef_SWB, &mult);
          w->sattenu1 = add( w->sattenu1, 655);
        }
      }

      /* BWE-based post-processing */
      bwe_dec_timepos( cod_Mode, sTenv_SWB, scoef_SWB, SubSigSuperWideHighQMF, 
        w->SubDecoderBWE, ploss_status, T_modify_flag, &scoef_SWBQ );
    }
    QMFilt_syn( L_FRAME_WB, SubSigSuperWideLowQMF, 
      SubSigSuperWideHighQMF, outwave, w->pQMFBuf_SWB );
  }

  w->bit_switch_status = 0; move16();
  if (sub(w->Mode, MODE_R3sm) < 0)
  {
    w->bit_switch_status = 1; move16();
  }

  IF(sub( bit_switch_flag, 1 ) == 0)
  {
    w->Mode = MODE_R3sm; move16();
  }

  w->prev_Mode = w->Mode; move16();
  w->prev_bit_switch_flag = bit_switch_flag; move16();

  mov16(8, sFenv_SVQ, w->sprev_fenv);

  /* ---------------- */
  /* Apply Noise Gate */
  /* ---------------- */
  test();
  IF (sub(w->OpFs, 8000) == 0 || sub(w->OpFs, 16000) == 0) { /* Not operating in 32-kHz mode */ 
    IF (sub(w->OpFs, 16000) == 0) {
      powerL = 0;  move32();
      powerH = 0;  move32();
      FOR (i=0; i<L_FRAME_NB; i++) {
        powerL = L_mac0( powerL, 1, abs_s(SubSigLow[i]) );
        powerH = L_mac0( powerH, 1, abs_s(SubSigHigh[i]) );
      }

      test();test();
      if ( sub(gain, 32767) < 0 && L_sub(powerH, 800L) > 0 && L_sub(L_shr(powerH,4), powerL) > 0 ) {
        gain = 32767;
        move16();
      }
    }

    n = L_FRAME_WB;
    move16();
    if (sub(w->OpFs, 8000) == 0)
    {
      n = L_FRAME_NB;
      move16();
    }

    gain32 = L_add(L_mult(gain,350),32768); /* inc gain to be able to converge to 1.0 */

    FOR (i=0; i<n; ++i) {
      w->gain_ns = mac_r(gain32,w->gain_ns,32418); /* 32418 = 32768 - 350 */

      IF (sub(w->gain_ns, 32767) < 0) {
        outwave[i] = mult_r(w->gain_ns,outwave[i]);

      }
    }
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

  return OK;
}
