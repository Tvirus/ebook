/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#include "errexit.h"
#include "pcmswb_common.h"
#include "softbit.h"
#include "prehpf.h"
#include "qmfilt.h"
#include "G711WB_lowband.h"
#include "G711WB_highband.h"
#include "g711enh.h"
#include "bwe.h"
#include "avq.h"

/*****************************/
#ifdef DYN_RAM_CNT
#include "dyn_ram_cnt.h"
#endif
/*****************************/

#define OK  0
#define NG  1

/* High-pass filter cutoff definition */
#define FILT_NO_8KHZ_INPUT   5
#define FILT_NO_16KHZ_INPUT  6
#define FILT_NO_32KHZ_INPUT  7

#define moveADDR()      move16()

#ifdef WMOPS
extern Word16           Id;
#endif

typedef struct {
  Word16  Core;               /* WB-Core mode */
  Word16  Mode;               /* Encoding mode */
  Word16  OpFs;               /* Sampling frequency */
  Word16  G711DCBuf[QMF_DELAY_WB];
  void*   pHpassFiltBuf;      /* High-pass filter buffer */
  void*   G711WB_SubEncoderL; /* Work space for G.711.1 lower-band */
  void*   G711WB_SubEncoderH; /* Work space for G.711.1 higher-band */
  void*   SubEncoderSH;       /* Work space for super-higher-band sub-encoder */
  void*   SubEncoderBWE;      /* Work space for 8kbps swb extension */
  void*   pQmfBuf_WB;         /* QMF buffer for G.711.1 */
  void*   pQmfBuf_SWB;        /* QMF buffer for SWB input */
  Word16  sDiffMDCTCoefHigh[16]; /* Differential MDCT coefficients in G.711.1 higher-band Q(sMDCTCoefHighQ) */
  Word16  sLocalDecDiffMDCTCoefHigh[16]; /* Q(sMDCTCoefHighQ) */
  Word16  sMDCTCoefHighQ;
} pcmswbEncoder_WORK;

/*----------------------------------------------------------------
Function:
PCM SWB encoder constructor
Return value:
Pointer to work space
----------------------------------------------------------------*/
void *pcmswbEncode_const(
                         UWord16 sampf, /* (i): Input sampling rate (Hz) */
                         Word16 core,             /* (i): core codec (G.11 A/mu-law) */
                         Word16 mode              /* (i): Encoding mode            */
                         )
{
  pcmswbEncoder_WORK *w=NULL;
  Word16 law;

  /* Static memory allocation */
  w = (void *)malloc(sizeof(pcmswbEncoder_WORK));
  if (w == NULL)  return NULL;

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize;
    ssize = (UWord32) (0);
#ifdef MEM_STT
    ssize += (UWord32) (sizeof(pcmswbEncoder_WORK));
#endif
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/
  w->Core = core;		move16();
  w->Mode = mode;		move16();
  w->OpFs = 32000;		move16();	/* Input sampling rate is 32kHz in default */
  if (sub(sampf, 8000) == 0)
  {
    w->OpFs = 8000;		move16();   /* Input sampling rate is 8 kHz */
  }
  if (sub(sampf, 16000) == 0)
  {
    w->OpFs = 16000;	move16();  /* Input sampling rate is 16 kHz */
  }

  zero16( QMF_DELAY_WB, w->G711DCBuf);
  test();
  IF (sub(core, G711ULAW_CORE) != 0 && sub(core, G711ALAW_CORE)) {
    error_exit("Core specification error.");
  }

  test(); test(); test(); test(); test(); test(); test(); 
  IF ( sub(w->Mode, MODE_R1nm) != 0  && sub(w->Mode, MODE_R2nm) != 0  &&
    sub(w->Mode, MODE_R2wm) != 0  && sub(w->Mode, MODE_R3wm) != 0  &&
    sub(w->Mode, MODE_R3sm) != 0  && sub(w->Mode, MODE_R4sm) != 0  &&
    sub(w->Mode, MODE_R4ssm) != 0 && sub(w->Mode, MODE_R5ssm) != 0 ) {
      error_exit( "Encoding mode error." );
  }

  w->pHpassFiltBuf = highpass_1tap_iir_const();

  IF ( w->pHpassFiltBuf == NULL )  error_exit( "HPF init error." );

  w->pQmfBuf_SWB = QMFilt_const(NTAP_QMF_SWB, sSWBQmf0, sSWBQmf1);
  IF ( w->pQmfBuf_SWB == NULL )  error_exit( "SWB QMF init error." );

  law = MODE_ULAW;	move16();
  if (sub(core, G711ALAW_CORE) == 0)
  {
    law = MODE_ALAW;	move16();
  }

  w->pQmfBuf_WB = QMFilt_const(NTAP_QMF_WB, sSWBQmf0, sSWBQmf1);

  IF ( w->pQmfBuf_WB == NULL )  error_exit( "G711WB QMF init error." );

  w->G711WB_SubEncoderL = lowband_encode_const(law);

  IF ( w->G711WB_SubEncoderL == NULL )  error_exit( "G711WB lower band init error." );

  w->G711WB_SubEncoderH = highband_encode_const();
  IF ( w->G711WB_SubEncoderH == NULL )  error_exit( "G711WB higher band init error." );
  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize = 0;
#ifdef MEM_STT
    /* static RAM for G.711.1 core */
    ssize += (UWord32) (360);
#endif
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/
  w->SubEncoderBWE = bwe_encode_const();

  IF (w->SubEncoderBWE == NULL)   error_exit( "BWE init error." );

  /* constructor for AVQ encoder */
  IF (sub(w->Mode, MODE_R3sm) >= 0)
  {
    w->SubEncoderSH = avq_encode_const();
    if (w->SubEncoderSH == NULL) error_exit( "AVQ encoder init error." );
  }

  pcmswbEncode_reset( (void *)w );

  return (void *)w;
}

/*----------------------------------------------------------------
Function:
PCM SWB encoder destructor
Return value:
None
----------------------------------------------------------------*/
void pcmswbEncode_dest(
                       void*  p_work   /* (i): Work space */
                       )
{
  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;

  IF ( w != NULL ) {
    highpass_1tap_iir_dest( w->pHpassFiltBuf );
    QMFilt_dest( w->pQmfBuf_SWB );                /* QMF for SWB */
    QMFilt_dest( w->pQmfBuf_WB );                      /* QMF for WB */
    lowband_encode_dest( w->G711WB_SubEncoderL );      /* Lower band */
    highband_encode_dest( w->G711WB_SubEncoderH );     /* Higher band */
    /*****************************/
#ifdef DYN_RAM_CNT
    /* static RAM for G.711.1 core */
    DYN_RAM_POP();
#endif
    /*****************************/  
    bwe_encode_dest( w->SubEncoderBWE );

    /* destructor for AVQ encoder */
    IF (sub(w->Mode, MODE_R3sm) >= 0)
    {
      avq_encode_dest (w->SubEncoderSH);
    }

    free( w );

    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/  
  }
}

/*----------------------------------------------------------------
Function:
PCM SWB encoder reset
Return value:
OK
----------------------------------------------------------------*/
Word16  pcmswbEncode_reset(
                           void*  p_work   /* (i/o): Work space */
                           )
{
  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;
#ifdef DYN_RAM_CNT
  DYN_RAM_PUSH((UWord32) SIZE_Ptr, "dummy");
#endif

  IF ( w != NULL )
  {
    highpass_1tap_iir_reset(w->pHpassFiltBuf);
    QMFilt_reset( w->pQmfBuf_SWB );                    /* QMF for SWB */
    QMFilt_reset( w->pQmfBuf_WB );                     /* QMF for WB */
    lowband_encode_reset( w->G711WB_SubEncoderL );     /* Lower band */
    highband_encode_reset( w->G711WB_SubEncoderH );    /* Higher band */
    bwe_encode_reset( w->SubEncoderBWE );

    /* reset for AVQ encoder */
    IF (sub(w->Mode, MODE_R3sm) >= 0)
    {
      avq_encode_reset (w->SubEncoderSH);
    }
    zero16(16, w->sDiffMDCTCoefHigh);
    zero16(16, w->sLocalDecDiffMDCTCoefHigh);
    w->sMDCTCoefHighQ = 0;
    move16();
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/  
  return OK;
}


/*----------------------------------------------------------------
Function:
PCM SWB encoder
Return value:
OK/NG
----------------------------------------------------------------*/
Word16  pcmswbEncode(
                     const Word16*    inwave,
                     unsigned char*  bitstream,
                     void*           p_work
                     ) 
{
  Word16  SubSigSuperWideLow[L_FRAME_WB];
  Word16  SubSigSuperWideHigh[L_FRAME_WB];
  unsigned char  *bpt = bitstream;
  Word16 i;
  Word16  SubSigLow[L_FRAME_NB];
  Word16  SubSigHigh[L_FRAME_NB];
  Word16  SubSigSuperWideHigh_711temp[QMF_DELAY_WB];
  Word16  *SigInQMF;

  pcmswbEncoder_WORK *w=(pcmswbEncoder_WORK *)p_work;

  Word16 transi;
  BWE_state_enc *enc_st = (BWE_state_enc *)w->SubEncoderBWE;
  UWord16 bst_buff[NBitsPerFrame_SWB_1], *pBit_BWE;
  UWord16 *pBit_SVQ, *pBit_MB;
  Word16 index_g, cod_Mode, T_modify_flag = 0;
  UWord16 bst_buff2[NBitsPerFrame_SWB_2], *pBit_MB2, *pBit_SVQ2;
  Word16 layers_SWB; 
  Word16 sMDCTCoefHigh[L_FRAME_NB]; /* Q(sMDCTCoefHighQ) */ 
  Word16 sMDCTCoefLocalDecHigh[L_FRAME_NB]; /* Q(sMDCTCoefHighQ) */ 
  Word16 sFenv_SWB_unq[SWB_NORMAL_FENV]; /* Q(12) */
  Word16 stEnv[SWB_TENV]; /* Q(0) */
  Word16 scoef_SWB[SWB_F_WIDTH]; /* Q(scoef_SWBQ) */ 
  Word16 sFenv_SWB[SWB_NORMAL_FENV]; /* Q(scoef_SWBQ) */  
  Word16 scoef_SWBQ = 0;  

  /*****************************/
#ifdef DYN_RAM_CNT
  {
    UWord32 ssize = 0;
    ssize += (UWord32) ((L_FRAME_WB*2+L_FRAME_NB*4+QMF_DELAY_WB+SWB_NORMAL_FENV+SWB_TENV+SWB_F_WIDTH+SWB_NORMAL_FENV+7)*SIZE_Word16);
    ssize += (UWord32) (9*SIZE_Ptr);
    ssize += (UWord32) ((NBitsPerFrame_SWB_1+NBitsPerFrame_SWB_2)*SIZE_Word16 );	/* bstn unsigned short,Word16 */
    DYN_RAM_PUSH(ssize, "dummy");
  }
#endif
  /*****************************/

  move16();move16();	/* for initialize: T_modify_flag, scoef_SWBQ */

  zero16( NBitsPerFrame_SWB_1, (Word16*)bst_buff);
  zero16( NBitsPerFrame_SWB_2, (Word16*)bst_buff2);
  zero16( L_FRAME_NB, sMDCTCoefHigh);
  zero16( L_FRAME_NB, sMDCTCoefLocalDecHigh);
  zero16( SWB_NORMAL_FENV, sFenv_SWB_unq);
  zero16( SWB_TENV, stEnv);
  zero16( SWB_F_WIDTH, scoef_SWB);
  zero16( SWB_NORMAL_FENV, sFenv_SWB);

  SigInQMF = (Word16 *)inwave;

  if (p_work == NULL)
  {
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/
    return NG;
  }

  /* ------------------------------- */
  /* Pre-processing & band splitting */
  /* ------------------------------- */
  IF ( sub(w->OpFs, 8000) == 0 ) { /* Narrow band input */
    /* High-pass filtering */
    highpass_1tap_iir( FILT_NO_8KHZ_INPUT,
      L_FRAME_NB, (Word16 *)inwave,
      SubSigLow, w->pHpassFiltBuf );
  }
  ELSE IF ( sub(w->OpFs, 16000) == 0 ) { /* Wideband input */

    /* High-pass filtering */
    highpass_1tap_iir( FILT_NO_16KHZ_INPUT,
      L_FRAME_WB, (Word16 *)inwave,
      SigInQMF, w->pHpassFiltBuf );
    /* Band splitting with QMF for WB */
    QMFilt_ana( L_FRAME_WB, SigInQMF, SubSigLow, SubSigHigh, w->pQmfBuf_WB );
  }
  ELSE { /* w->OpFs == 32000 */  /* Super wideband input */
    /* High-pass filtering */
    highpass_1tap_iir( FILT_NO_32KHZ_INPUT,
      L_FRAME_SWB, (Word16 *)inwave,
      SigInQMF, w->pHpassFiltBuf );
    /* Band splitting with QMF (SWB) */
    QMFilt_ana( L_FRAME_SWB, SigInQMF, SubSigSuperWideLow, SubSigSuperWideHigh, w->pQmfBuf_SWB );
    QMFilt_ana( L_FRAME_WB, SubSigSuperWideLow, SubSigLow, SubSigHigh, w->pQmfBuf_WB );
  }

  mov16( QMF_DELAY_WB, &SubSigSuperWideHigh[L_FRAME_WB-QMF_DELAY_WB], SubSigSuperWideHigh_711temp );
  mov16_bwd(L_FRAME_WB-QMF_DELAY_WB, SubSigSuperWideHigh+L_FRAME_WB-1-QMF_DELAY_WB, SubSigSuperWideHigh+L_FRAME_WB-1);
  mov16(QMF_DELAY_WB, w->G711DCBuf, SubSigSuperWideHigh);
  mov16(QMF_DELAY_WB, SubSigSuperWideHigh_711temp, w->G711DCBuf);

  /* ------------------------------------------------------------- */
  /* Lower-band encoder including both core and enhancement layers */
  /* ------------------------------------------------------------- */
  test(); test(); test();
  IF ((sub(w->Mode, MODE_R2a) == 0)   ||
    (sub(w->Mode, MODE_R3) == 0)    ||
    (sub(w->Mode, MODE_R4ssm) == 0) ||
    (sub(w->Mode, MODE_R5ssm) == 0)) {
      /* Core layer + Lower band enhancement layer */

      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_PUSH(1320, "dummy"); /* max scratch RAM of G.711.1 encoder */
#endif
      /*****************************/
      lowband_encode( SubSigLow, bpt, bpt+NBytesPerFrame_G711WB_0, w->G711WB_SubEncoderL );
      /*****************************/
#ifdef DYN_RAM_CNT
      DYN_RAM_POP();
#endif
      /*****************************/
      bpt += (NBytesPerFrame_G711WB_0 + NBytesPerFrame_G711WB_1);	
  }
  ELSE { /* w->Mode == MODE_R1 || w->Mode == MODE_R2b || w->Mode == MODE_R3sm || w->Mode == MODE_R4sm */
    /* Core layer only */
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_PUSH(1320, "dummy"); /* max scratch RAM of G.711.1 encoder */
#endif
    /*****************************/
    lowband_encode( SubSigLow, bpt, NULL, w->G711WB_SubEncoderL );
    /*****************************/
#ifdef DYN_RAM_CNT
    DYN_RAM_POP();
#endif
    /*****************************/
    bpt += NBytesPerFrame_G711WB_0;	
  }
  /* ------------------------------------- */
  /* Higher-band enhancement layer encoder */
  /* ------------------------------------- */

  test(); test(); test(); test(); test();
  IF ((sub(w->Mode, MODE_R2b) == 0)   ||
    (sub(w->Mode, MODE_R3) == 0)    ||
    (sub(w->Mode, MODE_R3sm) == 0)  ||
    (sub(w->Mode, MODE_R4sm) == 0)  ||
    (sub(w->Mode, MODE_R4ssm) == 0) ||
    (sub(w->Mode, MODE_R5ssm) == 0)) {
      IF (sub(w->OpFs, 8000) == 0) {
        zero16( NBytesPerFrame_G711WB_2/2, (Word16 *)bpt );
      }
      ELSE {
        /*****************************/
#ifdef DYN_RAM_CNT
        DYN_RAM_PUSH(1320, "dummy"); /* max scratch RAM of G.711.1 encoder */
#endif
        /*****************************/
        Ihighband_encode( SubSigHigh, bpt, w->G711WB_SubEncoderH, sMDCTCoefHigh, sMDCTCoefLocalDecHigh, w->sDiffMDCTCoefHigh, &(w->sMDCTCoefHighQ) );

        /*****************************/
#ifdef DYN_RAM_CNT
        DYN_RAM_POP();
#endif
        /*****************************/
      }
      bpt += NBytesPerFrame_G711WB_2;	
  }

  test(); test(); test();
  IF ((sub(w->Mode, MODE_R3sm) == 0)  ||
    (sub(w->Mode, MODE_R4sm) == 0)  ||
    (sub(w->Mode, MODE_R4ssm) == 0) ||
    (sub(w->Mode, MODE_R5ssm) == 0))
  {
    T_modify_flag = Icalc_tEnv( SubSigSuperWideHigh, stEnv,
      &transi, enc_st->preMode
      , (void*)enc_st);
  }

  /* ------------------------------------------- */
  /* Super-higher-band enhancement layer encoder */
  /* ------------------------------------------- */
  test(); test(); test();
  IF ((sub(w->Mode, MODE_R3sm) == 0) ||
    (sub(w->Mode, MODE_R4sm) == 0) ||
    (sub(w->Mode, MODE_R4ssm) == 0)||
    (sub(w->Mode, MODE_R5ssm) == 0))

  {
    pBit_BWE = bst_buff;

    /* swb encoding */
    bwe_enc( SubSigSuperWideHigh, &pBit_BWE, w->SubEncoderBWE, stEnv, transi,
      &cod_Mode, sFenv_SWB, scoef_SWB, &index_g, T_modify_flag, sFenv_SWB_unq,
      &scoef_SWBQ );

    IF (sub(cod_Mode, TRANSIENT) != 0)
    {
      pBit_MB = bst_buff + NBITS_MODE_R1SM_BWE;
      g711el0_encode_AVQ( (const Word16 *)w->sDiffMDCTCoefHigh, pBit_MB, w->sLocalDecDiffMDCTCoefHigh, sFenv_SWB[0], (const Word16)w->sMDCTCoefHighQ, (const Word16)scoef_SWBQ);
    }

    test();
    IF (sub(w->Mode, MODE_R4sm) == 0 || sub(w->Mode, MODE_R5ssm) == 0)
    {
      IF (sub((Word16) cod_Mode, TRANSIENT) == 0)
      {
        FOR (i=0; i<10; i++)
        {
          sMDCTCoefLocalDecHigh[10-i] = add(sMDCTCoefLocalDecHigh[10-i], shr_r(add(w->sLocalDecDiffMDCTCoefHigh[i], sMDCTCoefLocalDecHigh[20-i]), 1)); /* Q(sMDCTCoefHighQ) */
          move16();
        }
      }
      ELSE
      {
        FOR (i=0; i<16; i++)
        {
          sMDCTCoefLocalDecHigh[15-i] = add(sMDCTCoefLocalDecHigh[15-i], w->sLocalDecDiffMDCTCoefHigh[i]); /* Q(sMDCTCoefHighQ) */
          move16();
        }
      }
      pBit_MB2 = bst_buff2;

      g711el1_encode ((const Word16 *)sMDCTCoefHigh, (const Word16 *)sMDCTCoefLocalDecHigh, pBit_MB2, (const Word16)w->sMDCTCoefHighQ);
    }

    test();
    layers_SWB = 1;	move16();
    if ( sub(w->Mode, MODE_R4sm) == 0 || sub(w->Mode, MODE_R5ssm) == 0 )
    {
      layers_SWB = 2;	move16();
    }

    pBit_SVQ = bst_buff + NBITS_MODE_R1SM_TOTLE;	

    pBit_SVQ2 = bst_buff2 + NBitsPerFrame_EL1; /*for 40 bits send in swbl2*/ 

    swbl1_encode_AVQ( (void*)w->SubEncoderSH, scoef_SWB, sFenv_SWB, 
      sFenv_SWB_unq,
      index_g, cod_Mode, pBit_SVQ, pBit_SVQ2, layers_SWB, (const Word16)scoef_SWBQ );
    softbit2hardbit (NBytesPerFrame_SWB_1, bst_buff, bpt);
    bpt += NBytesPerFrame_SWB_1;	
  }
  test();
  IF ((sub(w->Mode, MODE_R4sm) == 0) || (sub(w->Mode, MODE_R5ssm) == 0) ) {
    softbit2hardbit (NBytesPerFrame_SWB_2, bst_buff2, bpt);
    bpt += NBytesPerFrame_SWB_2;	
  }

  /*****************************/
#ifdef DYN_RAM_CNT
  DYN_RAM_POP();
#endif
  /*****************************/

  return OK;
}
