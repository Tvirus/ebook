/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

/*
 *------------------------------------------------------------------------
 *  Function: Common definitions for all module files
 *------------------------------------------------------------------------
 */

#ifndef COMMON_DEFS_H
#define COMMON_DEFS_H

#include "dsputil.h"
#include "pcmswb.h"

#define L_FRAME_NB  NSamplesPerFrame08k  /* Number of samples in  8 kHz */
#define L_FRAME_WB  NSamplesPerFrame16k  /* Number of samples in 16 kHz */
#define L_FRAME_SWB NSamplesPerFrame32k  /* Number of samples in 32 kHz */

#endif
