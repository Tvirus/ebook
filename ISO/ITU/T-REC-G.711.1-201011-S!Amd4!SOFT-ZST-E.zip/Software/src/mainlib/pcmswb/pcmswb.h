/*--------------------------------------------------------------------------
 ITU-T Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

#ifndef PCMSWB_H
#define PCMSWB_H

/*------------------------------------------------------------------------*
* Defines
*------------------------------------------------------------------------*/
#define MODE_R1nm    2 /* G.711        ,  NB,  64k (=R1) */
#define MODE_R2nm    5 /* G.711.1      ,  NB,  80k (=R2a) */
#define MODE_R2wm    6 /* G.711.1      ,  WB,  80k (=R2b) */
#define MODE_R3wm    8 /* G.711.1      ,  WB,  96k (=R3) */
#define MODE_R3sm    9 /* G.711.1      , SWB,  96k [R2wm+16k] */
#define MODE_R4sm   10 /* G.711.1      , SWB, 112k [R2wm+16k*2] */
#define MODE_R4ssm  11 /* G.711.1      , SWB, 112k [R3wm+16k] */
#define MODE_R5ssm  12 /* G.711.1      , SWB, 128k [R3wm+16k*2] */
/* G.711.1 aliases */
#define MODE_R1      2 /* G.711        ,  NB,  64k */
#define MODE_R2a     5 /* G.711.1      ,  NB,  80k */
#define MODE_R2b     6 /* G.711.1      ,  WB,  80k */
#define MODE_R3      8 /* G.711.1      ,  WB,  96k */

#define  MODE_ULAW           1
#define  MODE_ALAW           2

#define  G711ULAW_CORE       100
#define  G711ALAW_CORE       200

#define  G711ULAW_CORE_80    400
#define  G711ALAW_CORE_80    500
#define  G711ULAW_CORE_96    600
#define  G711ALAW_CORE_96    700

#define NBITS_MODE_R1nm  320 /* G.711      , NB, 64k (=R1) */
#define NBITS_MODE_R2nm  400 /* G.711.1    , NB, 80k (=R2a) */
#define NBITS_MODE_R2wm  400 /* G.711.1    , WB, 80k (=R2b) */
#define NBITS_MODE_R3wm  480 /* G.711.1    , WB, 96k (=R3) */
#define NBITS_MODE_R3sm  480 /* G.711.1    ,SWB, 96k [R2wm+16k] */
#define NBITS_MODE_R4sm  560 /* G.711.1    ,SWB,112k [R2wm+16k*2] */
#define NBITS_MODE_R4ssm 560 /* G.711.1    ,SWB,112k [R3wm+16k] */
#define NBITS_MODE_R5ssm 640 /* G.711.1    ,SWB,128k [R3wm+16k*2] */
/* G.711.1 aliases */
#define NBITS_MODE_R1    320 /* G.711      , NB, 64k */
#define NBITS_MODE_R2a   400 /* G.711.1    , NB, 80k */
#define NBITS_MODE_R2b   400 /* G.711.1    , WB, 80k */
#define NBITS_MODE_R3    480 /* G.711.1    , WB, 96k */

#define  NSamplesPerFrame08k  40   /* Number of samples a frame in 8kHz  */
#define  NSamplesPerFrame16k  80   /* Number of samples a frame in 16kHz */
#define  NSamplesPerFrame32k 160   /* Number of samples a frame in 32kHz */

#define  NBytesPerFrame_G711WB_0     40   /* G.711.1 Subcodec 0 */
#define  NBytesPerFrame_G711WB_1     10   /* G.711.1 Subcodec 1 */
#define  NBytesPerFrame_G711WB_2     10   /* G.711.1 Subcodec 2 */
#define  NBytesPerFrame_SWB_0         5   /* SWB Subcodec 0 */
#define  NBytesPerFrame_SWB_1        10   /* SWB Subcodec 1 */
#define  NBytesPerFrame_SWB_2        10   /* SWB Subcodec 2 */

#define  NBitsPerFrame_G711WB_0      (NBytesPerFrame_G711WB_0*8)	
#define  NBitsPerFrame_G711WB_1      (NBytesPerFrame_G711WB_1*8)	
#define  NBitsPerFrame_G711WB_2      (NBytesPerFrame_G711WB_2*8)	
#define  NBitsPerFrame_SWB_0         (NBytesPerFrame_SWB_0*8)	
#define  NBitsPerFrame_SWB_1         (NBytesPerFrame_SWB_1*8)	
#define  NBitsPerFrame_SWB_2         (NBytesPerFrame_SWB_2*8)	

#define  NBYTEPERFRAME_MAX   NBytesPerFrame0 /* Max value of NBytesPerFrameX */

#define  MaxBytesPerFrame  (NBytesPerFrame_G711WB_0+NBytesPerFrame_G711WB_1+NBytesPerFrame_G711WB_2+NBytesPerFrame_SWB_1+NBytesPerFrame_SWB_2)	
#define  MaxBitsPerFrame   (MaxBytesPerFrame*8)	

#define  L_DELAY_COMP_MAX  250 /* need to be considered */

#define NBitsPerFrame_EL1 40
#define NBitsPerFrame_SWBL2   40

/*------------------------------------------------------------------------*
* Prototypes
*------------------------------------------------------------------------*/
void* pcmswbEncode_const(UWord16 sampf, Word16 core, Word16 mode);
void  pcmswbEncode_dest(void* p_work);
Word16   pcmswbEncode_reset(void* p_work);
Word16   pcmswbEncode( const Word16* inwave, unsigned char* bitstream, void* p_work );
void* pcmswbDecode_const(Word16 core, Word16 mode);
void  pcmswbDecode_dest(void* p_work);
Word16   pcmswbDecode_reset(void* p_work);
Word16   pcmswbDecode( const unsigned char* bitstream, Word16* outwave, void* p_work, Word16 ploss_status );
Word16   pcmswbDecode_set(Word16  mode, void*  p_work);

#endif  /* PCMSWB_H */
