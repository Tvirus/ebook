TEST_DIR=src/test_codec
TEST_VEC=test_vector
OUT_DIR=out
DIFF=cmp
TRUNCATE=./tools/truncate
EID=./tools/eid-xor
FILTER=./tools/filter

if [ $1 = 'test' ]; then
PROC=1
COMP=1
fi
if [ $1 = 'proc' ]; then
PROC=1
COMP=0
fi
if [ $1 = 'comp' ]; then
PROC=0
COMP=1
fi


if [ $PROC = '1' ]; then

if [ ! -d $OUT_DIR ]; then
mkdir $OUT_DIR
fi

#
# SuperWideband Input (G.711.1 R2b core)
#
$TEST_DIR/encoder -c 1a $TEST_VEC/Signal.inp tmp.bit 112

$TRUNCATE -fl 5 -b 96000  tmp.bit $OUT_DIR/Signal_R3sm_a.bit
$TRUNCATE -fl 5 -b 112000 tmp.bit $OUT_DIR/Signal_R4sm_a.bit

$EID -fer $OUT_DIR/Signal_R3sm_a.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R3sm_FER3_a.bit
$EID -fer $OUT_DIR/Signal_R4sm_a.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R4sm_FER3_a.bit

$TEST_DIR/decoder -c 1a $OUT_DIR/Signal_R3sm_a.bit $OUT_DIR/Signal_R3sm_a.out 96
$TEST_DIR/decoder -c 1a $OUT_DIR/Signal_R4sm_a.bit $OUT_DIR/Signal_R4sm_a.out 112

$TEST_DIR/decoder -c 1a $OUT_DIR/Signal_R3sm_FER3_a.bit $OUT_DIR/Signal_R3sm_FER3_a.out 96
$TEST_DIR/decoder -c 1a $OUT_DIR/Signal_R4sm_FER3_a.bit $OUT_DIR/Signal_R4sm_FER3_a.out 112

$TEST_DIR/encoder -c 1u $TEST_VEC/Signal.inp tmp.bit 112

$TRUNCATE -fl 5 -b 96000  tmp.bit $OUT_DIR/Signal_R3sm_u.bit
$TRUNCATE -fl 5 -b 112000 tmp.bit $OUT_DIR/Signal_R4sm_u.bit

$EID -fer $OUT_DIR/Signal_R3sm_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R3sm_FER3_u.bit
$EID -fer $OUT_DIR/Signal_R4sm_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R4sm_FER3_u.bit

$TEST_DIR/decoder -c 1u $OUT_DIR/Signal_R3sm_u.bit $OUT_DIR/Signal_R3sm_u.out 96
$TEST_DIR/decoder -c 1u $OUT_DIR/Signal_R4sm_u.bit $OUT_DIR/Signal_R4sm_u.out 112

$TEST_DIR/decoder -c 1u $OUT_DIR/Signal_R3sm_FER3_u.bit $OUT_DIR/Signal_R3sm_FER3_u.out 96
$TEST_DIR/decoder -c 1u $OUT_DIR/Signal_R4sm_FER3_u.bit $OUT_DIR/Signal_R4sm_FER3_u.out 112

#
# SuperWideband Input (G.711.1 R3 core)
#
$TEST_DIR/encoder -c 1as $TEST_VEC/Signal.inp tmp.bit 128

$TRUNCATE -fl 5 -b 112000 tmp.bit $OUT_DIR/Signal_R4ssm_a.bit
$TRUNCATE -fl 5 -b 128000 tmp.bit $OUT_DIR/Signal_R5ssm_a.bit

$EID -fer $OUT_DIR/Signal_R4ssm_a.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R4ssm_FER3_a.bit
$EID -fer $OUT_DIR/Signal_R5ssm_a.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R5ssm_FER3_a.bit

$TEST_DIR/decoder -c 1as $OUT_DIR/Signal_R4ssm_a.bit $OUT_DIR/Signal_R4ssm_a.out 112
$TEST_DIR/decoder -c 1as $OUT_DIR/Signal_R5ssm_a.bit $OUT_DIR/Signal_R5ssm_a.out 128

$TEST_DIR/decoder -c 1as $OUT_DIR/Signal_R4ssm_FER3_a.bit $OUT_DIR/Signal_R4ssm_FER3_a.out 112
$TEST_DIR/decoder -c 1as $OUT_DIR/Signal_R5ssm_FER3_a.bit $OUT_DIR/Signal_R5ssm_FER3_a.out 128

$TEST_DIR/encoder -c 1us $TEST_VEC/Signal.inp tmp.bit 128

$TRUNCATE -fl 5 -b 112000 tmp.bit $OUT_DIR/Signal_R4ssm_u.bit
$TRUNCATE -fl 5 -b 128000 tmp.bit $OUT_DIR/Signal_R5ssm_u.bit

$EID -fer $OUT_DIR/Signal_R4ssm_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R4ssm_FER3_u.bit
$EID -fer $OUT_DIR/Signal_R5ssm_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R5ssm_FER3_u.bit

$TEST_DIR/decoder -c 1us $OUT_DIR/Signal_R4ssm_u.bit $OUT_DIR/Signal_R4ssm_u.out 112
$TEST_DIR/decoder -c 1us $OUT_DIR/Signal_R5ssm_u.bit $OUT_DIR/Signal_R5ssm_u.out 128

$TEST_DIR/decoder -c 1us $OUT_DIR/Signal_R4ssm_FER3_u.bit $OUT_DIR/Signal_R4ssm_FER3_u.out 112
$TEST_DIR/decoder -c 1us $OUT_DIR/Signal_R5ssm_FER3_u.bit $OUT_DIR/Signal_R5ssm_FER3_u.out 128

/bin/rm -f tmp.bit

fi

if [ $COMP = '1' ]; then

#
# SuperWideband Input (G.711.1 R2b core)
#
$DIFF $TEST_VEC/Signal_R3sm_a.bit $OUT_DIR/Signal_R3sm_a.bit
$DIFF $TEST_VEC/Signal_R4sm_a.bit $OUT_DIR/Signal_R4sm_a.bit
$DIFF $TEST_VEC/Signal_R3sm_FER3_a.bit $OUT_DIR/Signal_R3sm_FER3_a.bit
$DIFF $TEST_VEC/Signal_R4sm_FER3_a.bit $OUT_DIR/Signal_R4sm_FER3_a.bit
	
$DIFF $TEST_VEC/Signal_R3sm_a.out $OUT_DIR/Signal_R3sm_a.out
$DIFF $TEST_VEC/Signal_R4sm_a.out $OUT_DIR/Signal_R4sm_a.out
$DIFF $TEST_VEC/Signal_R3sm_FER3_a.out $OUT_DIR/Signal_R3sm_FER3_a.out
$DIFF $TEST_VEC/Signal_R4sm_FER3_a.out $OUT_DIR/Signal_R4sm_FER3_a.out

$DIFF $TEST_VEC/Signal_R3sm_u.bit $OUT_DIR/Signal_R3sm_u.bit
$DIFF $TEST_VEC/Signal_R4sm_u.bit $OUT_DIR/Signal_R4sm_u.bit
$DIFF $TEST_VEC/Signal_R3sm_FER3_u.bit $OUT_DIR/Signal_R3sm_FER3_u.bit
$DIFF $TEST_VEC/Signal_R4sm_FER3_u.bit $OUT_DIR/Signal_R4sm_FER3_u.bit
	
$DIFF $TEST_VEC/Signal_R3sm_u.out $OUT_DIR/Signal_R3sm_u.out
$DIFF $TEST_VEC/Signal_R4sm_u.out $OUT_DIR/Signal_R4sm_u.out
$DIFF $TEST_VEC/Signal_R3sm_FER3_u.out $OUT_DIR/Signal_R3sm_FER3_u.out
$DIFF $TEST_VEC/Signal_R4sm_FER3_u.out $OUT_DIR/Signal_R4sm_FER3_u.out

#
# SuperWideband Input (G.711.1 R3 core)
#
$DIFF $TEST_VEC/Signal_R4ssm_a.bit $OUT_DIR/Signal_R4ssm_a.bit
$DIFF $TEST_VEC/Signal_R5ssm_a.bit $OUT_DIR/Signal_R5ssm_a.bit
$DIFF $TEST_VEC/Signal_R4ssm_FER3_a.bit $OUT_DIR/Signal_R4ssm_FER3_a.bit
$DIFF $TEST_VEC/Signal_R5ssm_FER3_a.bit $OUT_DIR/Signal_R5ssm_FER3_a.bit
	
$DIFF $TEST_VEC/Signal_R4ssm_a.out $OUT_DIR/Signal_R4ssm_a.out
$DIFF $TEST_VEC/Signal_R5ssm_a.out $OUT_DIR/Signal_R5ssm_a.out
$DIFF $TEST_VEC/Signal_R4ssm_FER3_a.out $OUT_DIR/Signal_R4ssm_FER3_a.out
$DIFF $TEST_VEC/Signal_R5ssm_FER3_a.out $OUT_DIR/Signal_R5ssm_FER3_a.out

$DIFF $TEST_VEC/Signal_R4ssm_u.bit $OUT_DIR/Signal_R4ssm_u.bit
$DIFF $TEST_VEC/Signal_R5ssm_u.bit $OUT_DIR/Signal_R5ssm_u.bit
$DIFF $TEST_VEC/Signal_R4ssm_FER3_u.bit $OUT_DIR/Signal_R4ssm_FER3_u.bit
$DIFF $TEST_VEC/Signal_R5ssm_FER3_u.bit $OUT_DIR/Signal_R5ssm_FER3_u.bit
	
$DIFF $TEST_VEC/Signal_R4ssm_u.out $OUT_DIR/Signal_R4ssm_u.out
$DIFF $TEST_VEC/Signal_R5ssm_u.out $OUT_DIR/Signal_R5ssm_u.out
$DIFF $TEST_VEC/Signal_R4ssm_FER3_u.out $OUT_DIR/Signal_R4ssm_FER3_u.out
$DIFF $TEST_VEC/Signal_R5ssm_FER3_u.out $OUT_DIR/Signal_R5ssm_FER3_u.out

fi
