/*--------------------------------------------------------------------------
 ITU-T G.711.1 Annex D (ex G.711.1-SWB) Source Code
 Software Release 1.00 (2010-09)
 (C) 2010 ETRI, France Telecom, Huawei Technologies, VoiceAge Corp.,NTT.
--------------------------------------------------------------------------*/

These files represent the ITU-T G.711.1-SWB Coder Fixed-Point Bit-Exact C simulation.
All code is written in ANSI-C.  The coder is implemented as two separate programs:

        encoder [-options] -c [core] <infile> <codefile> [rate]
        decoder [-options] -c [core] <codefile> <outfile> [rate] 
	
The folder "test_vector" contains a set of test vectors to verify the 
proper compilation of the reference software.


                            FILE FORMATS:
                            =============

The file format of the supplied binary data is 16-bit binary data which is
read and written in 16 bit little-endian words.
The data is therefore platform DEPENDENT.

The bitstream follows the ITU-T G.192 format. For every 5-ms input speech frame,
the bitstream contains the following data:

	Word16 SyncWord
	Word16 DataLen
	Word16 1st Databit
	Word16 2nd DataBit
	.
	.
	.
	Word16 Nth DataBit

Each bit is presented as follows: Bit 0 = 0x007f, Bit 1 = 0x0081.

The SyncWord from the encoder is always 0x6b21. The SyncWord 0x6b20, on decoder side, 
indicates that the current frame was received in error (frame erasure).

The DataLen parameter gives the number of speech data bits in the frame. 


			INSTALLING THE SOFTWARE
			=======================

Installing the software on the PC:

The package includes Makefile for gcc and makefile.cl for Visual C++. 
The makefiles can be used as follows:

Linux/Cygwin: make
Visual C++  : nmake -f makefile.cl

The codec has been successfully compiled on Linux/Cygwin using gcc
and Windows using Visual C++.

NOTE: Visual C++ command prompt should be used to compile with Visual C++ on Windows.


                       RUNNING THE SOFTWARE
                       ====================

The command line for the encoder is as follows:

  encoder [-options] -c [core] <infile> <codefile> [rate]

  where:
    core       1a  for G.711.1 A-law core at 80 kbit/s,
               1u  for G.711.1 u-law core at 80 kbit/s,
               1as for G.711.1 A-law core at 96 kbit/s and
               1us for G.711.1 u-law core at 96 kbit/s
    rate       is the desired encoding bitrate in kbit/s:
               112 for G.711.1 core at 80 kbit/s and
               128 for G.711.1 core at 96 kbit/s
    infile     is the name of the input file to be encoded
    codefile   is the name of the output bitstream file

  Options:
    -quiet     quiet processing

The command line for the decoder is as follows:

  decoder [-options] -c [core] <codefile> <outfile> [rate]

  where:
    core       1a  for G.711.1 A-law core at 80 kbit/s,
               1u  for G.711.1 u-law core at 80 kbit/s,
               1as for G.711.1 A-law core at 96 kbit/s and
               1us for G.711.1 u-law core at 96 kbit/s
    rate       is the desired decoding bitrate in kbit/s:
                96 for G.711.1 R3sm,
               112 for G.711.1 R4sm and G.711.1 R4*sm,
               128 for G.711.1 R5*sm
    codefile   is the name of the input bitstream file
    outfile    is the name of the decoded output file

  Options:	
    -quiet     quiet processing

If you run the software on Windows, you can make a set of test vectors using:

Cygwin    : make proc
Visual C++: nmake -f makefile.cl proc

or

test proc

easily. The test vectors are stored in folder "out".

NOTE: This batch file is not available on non-Windows platforms, because the tools
in folder "tools" are Windows executable files.
