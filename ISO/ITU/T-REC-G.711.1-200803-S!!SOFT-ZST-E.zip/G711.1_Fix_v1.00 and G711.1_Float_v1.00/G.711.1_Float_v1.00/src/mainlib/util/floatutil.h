/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */

#ifndef FLOATUTIL_H
#define FLOATUTIL_H

#ifdef AVOID_CONFLICT
#define round(a) round32(a)     /* To avoid conflict of round */
#endif

typedef double Float;
typedef short  Short;

#define MAX_32  2147483647L
#define MIN_32 -2147483648L

#define MAX_16  32767
#define MIN_16 -32768

void   zeroF( int n, Float *x );
void   zeroS( int n, Short *x );
void   movF( int n, Float *x, Float *y );
void   movSF( int n, Short *x, Float *y );
void   movFS( int n, Float *x, Short *y );
void   movFSQ( int n, Float *x, Short *y, int q );
Short roundFto16( Float x );
Short ExpFto16Array( int n, Float *xin );
int Fnorme16(Float f);
int Fnorme32(Float f);
Float f_max( Float var1, Float var2);
Float f_min( Float var1, Float var2);
Float abs_f (Float var1);
Float sum_vect_E(      /* o:   return calculated vector energy           */
    const Float *vec,  /* i:   input vector                              */
    const Short lvec   /* i:   length of input vector                    */
);
Float  Sqrt( Float input );
Float  Pow( Float x, Float y );
Float  Floor ( Float input );

#endif
