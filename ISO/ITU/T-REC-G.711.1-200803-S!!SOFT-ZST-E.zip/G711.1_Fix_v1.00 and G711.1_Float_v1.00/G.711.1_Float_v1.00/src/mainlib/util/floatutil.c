/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */

#define  AVOID_CONFLICT
#include "floatutil.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*__________________________________________________________________________
 |                                                                          |
 | zero()                                                                   |
 |__________________________________________________________________________|
*/
void zeroF(
  int	n,	/* I : */
  Float	*x	/* O : */
)
{
  int k;
	
  for(k = 0; k < n; k++ ) {
      x[k] = 0.0f;
  }
}

void zeroS(
  int	n,	/* I : */
  Short	*x	/* O : */
)
{
  int k;

  for(k = 0; k < n; k++) {
      x[k] = 0;
  }
}

/*__________________________________________________________________________
 |                                                                          |
 | mov()                                                                    |
 |__________________________________________________________________________|
*/
void movF(
  int	n,	/* I : */
  Float	*x,	/* I : */
  Float	*y	/* O : */
)
{
  int k;
	
  for(k = 0; k < n; k++) {
      y[k] = x[k];
  }
}

void movSF(
  int	n,	/* I : */
  Short	*x,	/* I : */
  Float	*y	/* O : */
)
{
  int k;
	
  for(k = 0; k < n; k++) {
      y[k] = (Float)x[k];
  }
}

void movFS(
  int	n,	/* I : */
  Float	*x,	/* I : */
  Short	*y	/* O : */
)
{
  int k;
	
  for(k = 0; k < n; k++) {
      y[k] = roundFto16(x[k]);
  }
}

void movFSQ(
  int	n,	/* I : */
  Float	*x,	/* I : */
  Short	*y,	/* O : */
  int	q   	/* I : Q value (example 15 for Q15)*/
)
{
  int k;
  Float fact;

  fact = (Float)(pow(2, q));
  for(k = 0; k < n; k++) {
      y[k] = roundFto16(x[k] * fact);
  }
}

/*__________________________________________________________________________
 |                                                                          |
 | roundFto16()                                                             |
 |__________________________________________________________________________|
*/
Short roundFto16(Float x)
{
  Short  out;

  if (x >= 32767.0f) {
      out = 32767;
  }
  else if (x <= -32768.0f) {
      out = -32768;
  }
  else if (x >= 0.0f) {
      out = (Short)(x + 0.5f);
  }
  else {
      out = (Short)(x - 0.5f);
  }
  return out;
}

/*__________________________________________________________________________
 |                                                                          |
 | SftFto16Array()                                                          |
 |__________________________________________________________________________|
*/
void	SftFto16Array(
  int	n,
  Float	*xin,
  Short *xout,
  Short nExp
) {
  int   i;
  Float a;

  a = 1.0;
  if (nExp >= 0) {
      for(i = 0; i < nExp; i++) {
          a *= 2.0f;
      }
  }
  else {
      for(i = 0; i < (-nExp); i++) {
          a /= 2.0f;
      }
  }

  for (i = 0; i < n; i++) {
      if (xin[i] < 0.0) {
          xout[i] = -(Short)(abs_f(xin[i])*a + 0.5f);
      }
      else {
          xout[i] = (Short)(xin[i]*a + 0.5f);
      }
  }
}

/*__________________________________________________________________________
 |                                                                          |
 | ExpFto16Array()                                                          |
 |__________________________________________________________________________|
*/
Short	ExpFto16Array(
  int	n,
  Float	*xin
) {
  int   i;
  int   count;
  Float xmax, xabs;
  Float a;
	
  xmax = 0.0;
  for (i = 0; i < n; i++) {
      xabs = abs_f(xin[i]);
      if( xmax < xabs )
          xmax = xabs;
  }

//fprintf(stderr, "xmax = %f\n", xmax);
  if (xmax < 1.0f /32768.0f) {
      return 0;
  }

  if (xmax > 0xFFFFFFFFUL) {
      fprintf( stderr, "Floating utility error.\n" );
      exit(1);
  }

  count = 0;
  a = 1.0f;
  for (i = 0; i < 31; i++) {
      if ((unsigned long)(xmax*a+0.5f) < 0x4000) {
          a *= 2.0f;
          count++;
      }
      else if ((unsigned long)(xmax*a+0.5f) > 0x7FFF) {
          a /= 2.0f;
          count--;
      }
      else {
          break;
      }
  }

  if ((unsigned long)(xmax*a+0.5f) > 0x7FFF) {
      fprintf( stderr, "Floating utility error.\n" );
      exit(1);
  }

  return count;
}

/*__________________________________________________________________________
 |                                                                          |
 | Fnorme16()   simulate the 'norm16' function of stl2005                   |
 |__________________________________________________________________________|
*/
int Fnorme16(Float f)
{
  int q = 0;

  if (f == (Float)0)
  {
      return(q);
  }
  else
  {
      if (f < (Float)0)
      {
          f = -f;
      }
      while(f < 16384) /*2^14*/
      {
          f *= 2;
          q++;
      }
      return(q);
  }
}

/*__________________________________________________________________________
 |                                                                          |
 | Fnorme32()   simulate the 'norm32' function of stl2005                   |
 |__________________________________________________________________________|
*/
int Fnorme32(Float f)
{
  int q = 0;

  if (f == (Float)0)
  {
      return(q);
  }
  else
  {
      while(f < 1073741824L) /*2^30*/
      {
          f *= 2;
          q++;
      }
  }
  return(q);
}

/*__________________________________________________________________________
 |                                                                          |
 | f_max()   Max function for floating point data                           |
 |__________________________________________________________________________|
*/
Float f_max( Float var1, Float var2) 
{
  Float var_out;

  if( var1 >= var2)
      var_out = var1;
  else
      var_out = var2;

  return( var_out);
}

/*__________________________________________________________________________
 |                                                                          |
 | f_min()   Min function for floating point data                           |
 |__________________________________________________________________________|
*/
Float f_min(Float var1, Float var2)
{
  Float var_out;

  if( var1 <= var2)
      var_out = var1;
  else
     var_out = var2;

  return( var_out);
}

/*__________________________________________________________________________
 |                                                                          |
 | abs_f()   Abs function for floating point data                           |
 |__________________________________________________________________________|
*/
Float abs_f (Float var1)
{
  if (var1 < 0)
  {
      var1 = -var1;
  }
  return (var1);
}

/*__________________________________________________________________________
 |                                                                          |
 | sum_vect_E()   Find vector energy                                        |
 |__________________________________________________________________________|
*/
Float sum_vect_E(      /* o:   return calculated vector energy           */
  const Float *vec,  /* i:   input vector                              */
  const Short lvec  /* i:   length of input vector                    */
)
{
  int j;
  Float suma = 0;

  for (j = 0 ; j < lvec ; j++)
  {
      suma += vec[j] * vec[j];
  }
  return suma;
}

/*__________________________________________________________________________
 |                                                                          |
 | sqrt()                                                                    |
 |__________________________________________________________________________|
*/
Float Sqrt(Float input)
{
  return (Float)sqrt((double)input);
}

/*__________________________________________________________________________
 |                                                                          |
 | pow()                                                                    |
 |__________________________________________________________________________|
*/
Float Pow(Float x, Float y)
{
  return (Float)pow((double)x, (double)y);
}

/*__________________________________________________________________________
 |                                                                          |
 | floor ()                                                                    |
 |__________________________________________________________________________|
*/
Float Floor ( Float input )
{
  return (Float) floor ( (double)input );
}
