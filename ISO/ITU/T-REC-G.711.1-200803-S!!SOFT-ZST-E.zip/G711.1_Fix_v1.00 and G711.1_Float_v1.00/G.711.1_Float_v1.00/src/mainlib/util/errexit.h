/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */

#ifndef ERREXIT_H
#define ERREXIT_H 1

void  error_exit( char *str );

#endif
