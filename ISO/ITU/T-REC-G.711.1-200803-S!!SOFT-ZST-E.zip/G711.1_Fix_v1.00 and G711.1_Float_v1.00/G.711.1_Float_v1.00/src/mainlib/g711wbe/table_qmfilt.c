/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: table_qmfilt.c
 *  Function: Tables for Quadrature mirror filter (QMF)
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"

/* Floating point */

/* QMF filter coefficients (polyphase representation) */
const Float fQmf0[NTAP_QMF / 2] = {
  (Float) 6.5064660e-04, (Float)-1.2601150e-03, (Float) 1.4272050e-03, (Float)-1.7219030e-04,
  (Float)-4.1094160e-03, (Float) 1.4468810e-02, (Float)-3.9244910e-02, (Float) 1.2846510e-01,
  (Float) 4.6645830e-01, (Float)-9.9800110e-02, (Float) 5.2909300e-02, (Float)-3.1155320e-02,
  (Float) 1.7881950e-02, (Float)-9.3636330e-03, (Float) 4.1581240e-03, (Float)-1.3508480e-03
};

/* QMF filter coefficients (polyphase representation) */
const Float fQmf1[NTAP_QMF / 2] = {
  (Float)-1.3508480e-03, (Float) 4.1581240e-03, (Float)-9.3636330e-03, (Float) 1.7881950e-02,
  (Float)-3.1155320e-02, (Float) 5.2909300e-02, (Float)-9.9800110e-02, (Float) 4.6645830e-01,
  (Float) 1.2846510e-01, (Float)-3.9244910e-02, (Float) 1.4468810e-02, (Float)-4.1094160e-03,
  (Float)-1.7219030e-04, (Float) 1.4272050e-03, (Float)-1.2601150e-03, (Float) 6.5064660e-04
};
