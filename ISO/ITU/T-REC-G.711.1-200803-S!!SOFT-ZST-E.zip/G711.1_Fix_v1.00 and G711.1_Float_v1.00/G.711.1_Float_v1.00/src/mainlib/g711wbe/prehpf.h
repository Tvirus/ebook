/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: prehpf.h
 *  Function: Header of pre-processing 1-tap high-pass filtering
 *------------------------------------------------------------------------
 */

#ifndef FPREHPF_H
#define FPREHPF_H

void *highpass_1tap_iir_const(void);
void  highpass_1tap_iir_dest(void *);
void  highpass_1tap_iir_reset(void *);
void  highpass_1tap_iir(Short, Short, Short *, Float *, void *);

#endif /* FPREHPF_H */
