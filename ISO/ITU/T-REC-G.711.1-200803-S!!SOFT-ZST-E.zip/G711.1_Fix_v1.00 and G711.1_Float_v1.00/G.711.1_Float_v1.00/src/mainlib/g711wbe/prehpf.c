/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: prehpf.c
 *  Function: Pre-processing 1-tap high-pass filtering
 *            Cut-off (-3dB) frequency is approximately 50 Hz,
 *            if the recommended filt_no value is used.
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "prehpf.h"

typedef struct
{
  Float   memx;
  Float   memy;
} HPASSMEM;

/* Constructor */
void   *
highpass_1tap_iir_const(
  void)
{                               /* returns pointer to work space */
  HPASSMEM *hpmem;

  hpmem = (HPASSMEM *) malloc(sizeof(HPASSMEM));
  if (hpmem != NULL) {
    highpass_1tap_iir_reset((void *)hpmem);
  }
  return (void *)hpmem;
}

/* Destructor */
void
highpass_1tap_iir_dest(
  void *ptr)
{
  HPASSMEM *hpmem = (HPASSMEM *) ptr;

  if (hpmem != NULL) {
    free(hpmem);
  }
}

/* Reset */
void
highpass_1tap_iir_reset(
  void *ptr)
{
  HPASSMEM *hpmem = (HPASSMEM *) ptr;

  if (hpmem != NULL) {
    hpmem->memx = 0.0f;
    hpmem->memy = 0.0f;
  }
}

/* Filtering */
void
highpass_1tap_iir(
  Short filt_no,    /* (i):   Filter cutoff specification.                 */
  /*        Use 5 for 8-kHz input and 6 for 16-kHz input */
  Short n,          /* (i):   Number of samples                            */
  Short sigin[],    /* (i):   Input signal (Q0)  */
  Float sigout[],   /* (i):   Output signal (Q0) */
  void *ptr         /* (i/o): Work space       */
  )
{
  int     k;
  Float   sigpre;
  Float   acc;
  Float   a;
  HPASSMEM *hpmem = (HPASSMEM *) ptr;

  acc = hpmem->memy;
  sigpre = hpmem->memx;

  if (filt_no == 6) {
    a = 0.984375f;
  }
  else if (filt_no == 5) {
    a = 0.96875f;
  }
  else {
    a = 1.0f - Pow(0.5f, filt_no);
  }

  for (k = 0; k < n; k++) {
    /* y[k] = a * y[k-1] + x[k] - x[k-1] */
    acc *= a;       /* a = 0.984375 for filt_no=6 */
    /* a = 0.96875  for filt_no=5 */
    acc += (Float)*sigin;
    acc -= sigpre;
    sigpre = (Float)*sigin++;
    *sigout++ = acc;
  }
  hpmem->memx = sigpre;
  hpmem->memy = acc;
}
