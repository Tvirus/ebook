/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: g711wbe_common.h
 *  Function: Common definitions for all module files
 *------------------------------------------------------------------------
 */

#ifndef COMMON_DEFS_H
#define COMMON_DEFS_H

#include "errexit.h"
#include "floatutil.h"
#include "g711wbe.h"

#define L_FRAME_NB  NSamplesPerFrame8k  /* Number of samples in  8 kHz */
#define L_FRAME_WB  NSamplesPerFrame16k /* Number of samples in 16 kHz */

#define L_FRAME_NB2 (2*L_FRAME_NB)

#include <stdlib.h>

#endif
