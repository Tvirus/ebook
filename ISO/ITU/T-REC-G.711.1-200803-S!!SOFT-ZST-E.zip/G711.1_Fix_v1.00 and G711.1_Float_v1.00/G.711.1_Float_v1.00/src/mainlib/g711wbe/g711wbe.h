/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: g711wbe.h
 *  Function: Header of the G.711WBE encoder and decoder
 *------------------------------------------------------------------------
 */

#ifndef G711WBE_H
#define G711WBE_H

#define  MODE_R1             0
#define  MODE_R2a            1
#define  MODE_R2b            2
#define  MODE_R3             3
#ifdef APPENDIX_I_POSTFILTER
#define  MODE_R1_POST        10
#endif

#define  MODE_ULAW           1
#define  MODE_ALAW           2

#define  NSamplesPerFrame8k  40 /* Number of samples a frame in 8kHz  */
#define  NSamplesPerFrame16k 80 /* Number of samples a frame in 16kHz */

#define  NBytesPerFrame0     40 /* Sub codec 0 */
#define  NBytesPerFrame1     10 /* Sub codec 1 */
#define  NBytesPerFrame2     10 /* Sub codec 2 */

#define  NBitsPerFrame0      (NBytesPerFrame0*8)
#define  NBitsPerFrame1      (NBytesPerFrame1*8)
#define  NBitsPerFrame2      (NBytesPerFrame2*8)

#define  NBYTEPERFRAME_MAX   NBytesPerFrame0    /* Max value of NBytesPerFrameX */

#define  TotalBytesPerFrame  (NBytesPerFrame0+NBytesPerFrame1+NBytesPerFrame2)
#define  TotalBitsPerFrame   (TotalBytesPerFrame*8)

/* Function prototypes */

void *G711wbeEncode_const(unsigned short sampf, int mode, int law);
void  G711wbeEncode_dest(void *p_work);
int   G711wbeEncode_reset(void *p_work);
int   G711wbeEncode(const short *inwave, unsigned char *bitstream, void *p_work);

void *G711wbeDecode_const(int mode, int law);
void  G711wbeDecode_dest(void *p_work);
int   G711wbeDecode_reset(void *p_work);
int   G711wbeDecode(const unsigned char *bitstream, short *outwave, void *p_work, int ploss_status);

#endif /* G711WBE_H */
