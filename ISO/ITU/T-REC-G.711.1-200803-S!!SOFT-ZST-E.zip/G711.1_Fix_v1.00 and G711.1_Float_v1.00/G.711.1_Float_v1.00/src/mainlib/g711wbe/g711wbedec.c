/* 
 * ITU-T G.711.1 Floating-point implementation ANSI-C Source Code
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: g711wbedec.c
 *  Function: G.711WBE decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"
#include "lowband.h"
#include "highband.h"

#define OK  0
#define NG  1

typedef struct
{
  Short   Mode;                 /* Decoding mode */
  Short   OpFs;                 /* Sampling frequency */
  Short   law;                  /* Logarithmic law */
  Float   gain_ns;              /* Noise shaping gain */
  void   *SubDecoderL;          /* Work space for lower-band sub-decoder */
  void   *SubDecoderH;          /* Work space for higher-band sub-decoder */
  void   *pQMFBuf;              /* QMF filter buffer */
} G711wbeDecoder_WORK;

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder constructor
  Return value:
    Pointer to work space
  ----------------------------------------------------------------*/
void   *
G711wbeDecode_const(
  int mode,                     /* (i): Decoding mode      */
  int law                       /* (i): G.711 law for core layer */
  )
{
  G711wbeDecoder_WORK *w = NULL;

#ifdef APPENDIX_I_POSTFILTER
  Short   postfilter_option = 0;

  if (mode == MODE_R1_POST) {
    mode = MODE_R1;
    postfilter_option = 1;
  }
#endif

  /* Static memory allocation */
  w = (void *)malloc(sizeof(G711wbeDecoder_WORK));
  if (w == NULL)
    return NULL;

  w->Mode = mode;

  if (w->Mode == MODE_R1) {
    w->OpFs = 8000;
  }
  else if (w->Mode == MODE_R2a) {
    w->OpFs = 8000;
  }
  else if (w->Mode == MODE_R2b) {
    w->OpFs = 16000;
  }
  else if (w->Mode == MODE_R3) {
    w->OpFs = 16000;
  }
  else {
    error_exit("Decoding mode error.");
  }

  w->law = law;

#ifdef APPENDIX_I_POSTFILTER
  w->SubDecoderL = lowband_decode_const(law, postfilter_option);
#else
  w->SubDecoderL = lowband_decode_const(law);
#endif
  if (w->SubDecoderL == NULL)
    error_exit("Lower band init error.");

  w->SubDecoderH = highband_decode_const();
  if (w->SubDecoderH == NULL)
    error_exit("Higher band init error.");

  w->pQMFBuf = QMFilt_const();
  if (w->pQMFBuf == NULL)
    error_exit("QMF init error.");

  G711wbeDecode_reset((void *)w);

  return (void *)w;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void
G711wbeDecode_dest(
  void *p_work                  /* (i): Work space */
  )
{
  G711wbeDecoder_WORK *w = (G711wbeDecoder_WORK *) p_work;

  if (w != NULL) {
    lowband_decode_dest(w->SubDecoderL);        /* Lower band */
    highband_decode_dest(w->SubDecoderH);       /* Higher band */
    QMFilt_dest(w->pQMFBuf);    /* QMF */

    free(w);
  }
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder reset
  Return value:
    OK
  ----------------------------------------------------------------*/
int
G711wbeDecode_reset(
  void *p_work                  /* (i/o): Work space */
  )
{
  G711wbeDecoder_WORK *w = (G711wbeDecoder_WORK *) p_work;

  if (w != NULL) {
    lowband_decode_reset(w->SubDecoderL);       /* Lower band */
    highband_decode_reset(w->SubDecoderH);      /* Higher band */
    QMFilt_reset(w->pQMFBuf);   /* QMF */
    w->gain_ns = 1.0f;          /* start with full gain */
  }
  return OK;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder
  Return value:
    OK/NG
  ----------------------------------------------------------------*/
int
G711wbeDecode(
  const unsigned char *bitstream,       /* (i):   Input bitstream  */
  short *outwave,               /* (o):   Output signal    */
  void *p_work,                 /* (i/o): Work space       */
  int ploss_status              /* (i):   Packet-loss flag */
  )
{
  const unsigned char *bpt = bitstream;

  Float   gain = 1.0f;
  Float   powerL, powerH;

  Short   i, n;

  Float   fSubSigLow[L_FRAME_NB];
  Float   fSubSigHigh[L_FRAME_NB];
  Float   fOutwave[L_FRAME_WB];

  G711wbeDecoder_WORK *w = (G711wbeDecoder_WORK *) p_work;

  if (p_work == NULL)
    return NG;

  /* ------------------------------------------------------------- */
  /* Lower-band decoder including both core and enhancement layers */
  /* Frame erasure concealment is integrated in the decoder.       */
  /* ------------------------------------------------------------- */
  if ((w->Mode == MODE_R2a) || (w->Mode == MODE_R3)) {
    /* Core layer + Lower band enhancement layer */
    lowband_decode(bpt, bpt + NBytesPerFrame0, ploss_status, fSubSigLow,
                   &gain, w->SubDecoderL);
    bpt += (NBytesPerFrame0 + NBytesPerFrame1);
  }
  else {
    /* Core layer only */
    /* When the second parameter is NULL, this decoder works as G.711 decoder. */
    lowband_decode(bpt, NULL, ploss_status, fSubSigLow, &gain,
                   w->SubDecoderL);
    bpt += NBytesPerFrame0;
  }

  /* ------------------------------------- */
  /* Higher-band enhancement layer decoder */
  /* ------------------------------------- */
  if ((w->Mode == MODE_R2b) || (w->Mode == MODE_R3)) {
    if (ploss_status != 0) {
      /* Get the LB pitch for HB FERC */
      copy_lb_pitch(w->SubDecoderL, w->SubDecoderH);
    }
    highband_decode(bpt, ploss_status, fSubSigHigh, w->SubDecoderH);
  }

  /* --------------------- */
  /* Band reconstructing   */
  /* --------------------- */
  if (w->OpFs == 8000) {
    movF(L_FRAME_NB, fSubSigLow, fOutwave);
  }
  else {                        /* w->OpFs == 16000 */
    /* Band reconstructing with QMF */
    QMFilt_syn(fSubSigLow, fSubSigHigh, fOutwave, w->pQMFBuf);
  }

  /* ---------------- */
  /* Apply Noise Gate */
  /* ---------------- */
  if (w->OpFs == 16000) {
    powerL = 0;
    powerH = 0;
    for (i = 0; i < L_FRAME_NB; i++) {
      Float tmp;
      tmp = (Float)roundFto16(fSubSigLow[i]);
      powerL += abs_f(tmp);
      tmp = (Float)roundFto16(fSubSigHigh[i]);
      powerH += abs_f(tmp);
    }
    if ((gain < 1.0f) && (powerH > 800) && (0.0625f * powerH > powerL)) {
      gain = 1.0f;
    }
  }

  n = (w->OpFs == 8000) ? L_FRAME_NB : L_FRAME_WB;
  for (i = 0; i < n; ++i) {
    w->gain_ns =
      0.989319f * w->gain_ns + 0.010681f * (gain + 1.52587890625e-05f);

    if (w->gain_ns < 1.0f) {
      outwave[i] = roundFto16(fOutwave[i] * w->gain_ns);
    }
    else {
      outwave[i] = roundFto16(fOutwave[i]);
    }
  }

  return OK;
}
