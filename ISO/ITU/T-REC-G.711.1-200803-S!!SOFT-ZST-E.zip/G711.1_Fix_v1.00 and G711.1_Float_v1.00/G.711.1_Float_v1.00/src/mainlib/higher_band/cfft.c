/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: cfft.c
 *  Function: 20-point complex FFT
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "defines_mdct.h"
#include "cfft.h"

/*--------------------------------------------------------------------------*
 *  Function  cfft()                                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Complex Good-Thomas fast Fourier transform                              *
 *--------------------------------------------------------------------------*/

void cfft (
  Float * x1,  /* (i/o) pointer on the real part of data       */
  Float * x2,  /* (i/o) pointer on the imaginary part of data  */
  Short sign   /* (i) flag to select FFT (1) or IFFT (-1)      */
) {                               
  Float        tab_x1[MDCT_NP * MDCT_NPP];
  Float        tab_x2[MDCT_NP * MDCT_NPP];
  Float        rx1[MDCT_NP];
  Float        rx2[MDCT_NP];
  Float        *ptr_x1;   /* Pointer on tab_x1 */
  Float        *ptr_x2;   /* Pointer on tab_x2 */
  Float        *ptr0_x1;  /* Pointer on tab_x1 for DFT step */
  Float        *ptr0_x2;  /* Pointer on tab_x2 for DFT step */
  const Float  *ptr_cos;  /* Pointer on cos table */
  const Float  *ptr_sin;  /* Pointer on sin table */
  const Short  *ptr_map;  /* Pointer on mapping indice (input and output) */

  Short        ip, ipp, i, j;
  Float        x1_tmp;
  Float        x2_tmp;
  Short        exp_n2;
  Short        n1;
  Short        n2;        /* size of sub array */
  Short        n3;
  Short        p;         /* size of the butterfly */
  Short        inkw;
  Float        rix;
  Float        cix;
  Float        rjx;
  Float        cjx;

  /********************************************************************************
   * Mapping for the input indices (Good Thomas FTT)                              *
   ********************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_map;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (ipp = 0; ipp < MDCT_NPP; ipp++) {
      i = (Short) * ptr_map++;
      *ptr_x1++ = x1[i];
      *ptr_x2++ = x2[i];
    }
  }

  /***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (j = 0; j < MDCT_NB_REV; j++) {
      i = MDCT_tab_rev_i[j];
      ipp = MDCT_tab_rev_ipp[j];
      x1_tmp = ptr_x1[ipp];     /* swap value ptr_x1[i] and ptr_x1[ipp] */
      x2_tmp = ptr_x2[ipp];     /* swap value ptr_x2[i] and ptr_x2[ipp] */
      ptr_x1[ipp] = ptr_x1[i];
      ptr_x2[ipp] = ptr_x2[i];
      ptr_x1[i] = x1_tmp;
      ptr_x2[i] = x2_tmp;
    }
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }

  /*******************************************************************************
   * n1 size of butterfly                                                        *
   *******************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (exp_n2 = 0; exp_n2 <= MDCT_EXP_NPP; exp_n2++) {
      /*  n2 : size of sub arrays */
      n2 = 1 << exp_n2;
      n1 = n2 >> 1;
      n3 = MDCT_EXP_NPP - exp_n2;

      /* p equal the size of the butterfly */
      for (p = 0; p < n1; p++) {
        /*  get twiddle factor in arrays rw1 and rw2 */
        inkw = (p * MDCT_NP) << n3;
        x1_tmp = MDCT_rw1[inkw];
        x2_tmp = -(Float) sign *MDCT_rw2[inkw];

        for (i = p; i < MDCT_NPP; i += n2) {
          /*  selecet item p in array p */
          j = i + n1;

          /*   butterfly on x[i] and x[j] */
          rix = ptr_x1[i];
          cix = ptr_x2[i];

          /*  twiddle factor */
          rjx = (x1_tmp * ptr_x1[j]) - (x2_tmp * ptr_x2[j]);
          cjx = (x2_tmp * ptr_x1[j]) + (x1_tmp * ptr_x2[j]);
          ptr_x1[i] = rix + rjx;
          ptr_x2[i] = cix + cjx;
          ptr_x1[j] = rix - rjx;
          ptr_x2[j] = cix - cjx;
        }
      }
    }                           /* end while */
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }                             /* end for ip */

  /**************************************************************************/

  ptr0_x1 = tab_x1;
  ptr0_x2 = tab_x2;
  for (ipp = 0; ipp < MDCT_NPP; ipp++) {
    ptr_x1 = ptr0_x1;
    ptr_x2 = ptr0_x2;
    for (ip = 0; ip < MDCT_NP; ip++) {
      rx1[ip] = *ptr_x1;
      rx2[ip] = *ptr_x2;
      ptr_x1 += MDCT_NPP;
      ptr_x2 += MDCT_NPP;
    }

    ptr_x1 = ptr0_x1++;
    ptr_x2 = ptr0_x2++;
    ptr_cos = MDCT_xcos;
    ptr_sin = MDCT_xsin;

    if (sign > 0) {             /* FFT */
      for (ip = 0; ip < MDCT_NP; ip++) {
        x1_tmp = (Float) 0.0;
        x2_tmp = (Float) 0.0;
        for (i = 0; i < MDCT_NP; i++) {
          x1_tmp += rx1[i] * (*ptr_cos) - rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) + rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }                         /*end for ip */
    }
    else {                      /* IFFT */
      for (ip = 0; ip < MDCT_NP; ip++) {
        x1_tmp = (Float) 0.0;
        x2_tmp = (Float) 0.0;
        for (i = 0; i < MDCT_NP; i++) {
          x1_tmp += rx1[i] * (*ptr_cos) + rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) - rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }                         /*end for ip */
    }
  }                             /*end for ipp */

  /***************************************************************************
  * mapping for the output indices                                          *
  ***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_map2;
  for (ip = 0; ip < MDCT_NP; ip++) {
    for (ipp = 0; ipp < MDCT_NPP; ipp++) {
      i = (Short) * ptr_map++;
      x1[i] = *ptr_x1++;
      x2[i] = *ptr_x2++;
    }
  }

  return;
}
