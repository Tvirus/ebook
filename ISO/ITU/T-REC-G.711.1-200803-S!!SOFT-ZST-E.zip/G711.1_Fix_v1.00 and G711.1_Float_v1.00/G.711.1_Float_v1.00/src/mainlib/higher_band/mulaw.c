/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: mulaw.c
 *  Function: Mu-law compression
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Mu-law compression of gain, 8bit, u=255
  Return value
    Quantized value in log scale
  ----------------------------------------------------------------*/
Short mulaw (
  Short linbuf
) {
  Short  absno;
  Short  exponent;
  Short  mantissa;
  Short  logbuf;

  if (linbuf < 4) {
    logbuf = linbuf & 0x3;
  }
  else {
    if (linbuf > 32636) {
      absno = MAX_16;
    }
    else {
      absno = linbuf + 130;
    }

    exponent = 7 - (Short) Fnorme16((Float) absno);

    mantissa = ((absno >> exponent) - 128) >> 2;
    logbuf = (exponent << 5) + mantissa;

    logbuf = logbuf + 3;

    if (logbuf > 255) {
      logbuf = 255;
    }
  }

  return logbuf;
}
