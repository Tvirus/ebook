/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: vqenc_spectrum.c
 *  Function: MDCT coefficient encoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

static void  acc_opt_gain_param(Float *, Float *, Float *, Float *);
static Float get_opt_gain(Float, Float, Float);

/*----------------------------------------------------------------
  Function:
    Quantizes normalized MDCT coefficients.
  Return value
    0
  ----------------------------------------------------------------*/
int VQencode_spectrum(
  Float  normSpec[],   /* (i): Normalized coefficients */
  Short  index_wvq[],  /* (o): VQ indices              */
  Float  gain,         /* (i): Normalization RMS,      */
  Short  *index_pow    /* (o): Gain index              */
) {
  int    i, j;
  int    nDiv;
  Float  nume;
  Float  denom;
  Float  targetv[N_DIV][VECLEN]; /* Target subvectors               */
  Float  canMeas0[N_CAN];
  Float  canMeas1[N_CAN];
  Float  canSign0[N_CAN];
  Float  canSign1[N_CAN];
  Short  sCanIndx0[N_CAN];       /* Candidate indices for channel 0 */
  Short  sCanIndx1[N_CAN];       /* Candidate indices for channel 1 */
  Float  localv[VECLEN];         /* Locally decoded subvector       */
  Float  gopt;                   /* Optimal gain                    */

  /* Parameters for gain quantization */
  nume = 0.0f;
  denom = 1.0f / 8388608.0f;

  /* Interleaving */
  i = N_FR_FREQ - 1;
  for (j = 0; j < VECLEN; j++)
  {
    targetv[0][j] = normSpec[i--];
    targetv[1][j] = normSpec[i--];
    targetv[2][j] = normSpec[i--];
    targetv[3][j] = normSpec[i--];
    targetv[4][j] = normSpec[i--];
    targetv[5][j] = normSpec[i--];
  }

  /* Quantize subvectors */
  for (nDiv = 0; nDiv < N_DIV; nDiv++)
  {
    /* Pre-selection of channel 0 */
    vq_preselect(targetv[nDiv], gfCodebook_0ch, gfCodebook_0ch_pow, canMeas0, canSign0, sCanIndx0);

    /* Pre-selection of channel 1 */
    vq_preselect(targetv[nDiv], gfCodebook_1ch, gfCodebook_1ch_pow, canMeas1, canSign1, sCanIndx1);

    /* Main selection */
    vq_mainselect(sCanIndx0, sCanIndx1, &index_wvq[nDiv], canMeas0, canMeas1, canSign0, canSign1, localv);

    /* Parameter calculation for gain quantization */
    acc_opt_gain_param(targetv[nDiv], localv, &nume, &denom);
  }

  /* Obtain adjusted gain */
  gopt = get_opt_gain(nume, denom, gain);

  /* Mu-law quantization of the adjusted gain */
  *index_pow = mulaw(roundFto16(gopt));

  return 0;
}

/* Parameter calculation for gain quantization */
static void acc_opt_gain_param(
  Float  targetv[],  /* (i): Target subvector          */
  Float  localv[],   /* (i): Locally decoded subvector */
  Float  *pNume,     /* (i/o):                         */
  Float  *pDenom     /* (i/o):                         */
) {
  int    i_smp;
  Float  nume0;
  Float  denom0;

  nume0 = 0;
  denom0 = 0;

  for (i_smp = 0; i_smp < VECLEN; i_smp++)
  {
    nume0 += targetv[i_smp] * localv[i_smp];
    denom0 += localv[i_smp] * localv[i_smp];
  }
  *pNume += nume0;
  *pDenom += denom0;
}

/* Get adjusted (optimal) gain */
static Float get_opt_gain (
  Float  nume,   /* (i) */
  Float  denom,  /* (i) */
  Float  gain    /* (i) */
) {
  Float  gopt;
  Float  num;
  Float  invDen;
  Float  acc;

  invDen = 1.0f / denom;

  num = gain * nume;
  num *= (Float) GSCALE_FACT / 2048.0f;  /* GSCALE_FACT: Q11 */

  acc = num * invDen;

  if (acc >= 32767.0f)
  {
    gopt = 32767.0f;
  }
  else if (acc <= 0.0f)
  {
    gopt = 0.0f;
  }
  else
  {
    gopt = acc;
  }

  return gopt;
}
