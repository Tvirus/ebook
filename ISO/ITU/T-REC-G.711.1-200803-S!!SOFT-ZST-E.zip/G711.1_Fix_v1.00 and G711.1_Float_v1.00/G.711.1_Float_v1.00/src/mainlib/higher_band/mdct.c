/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: 80-point MDCT
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "defines_mdct.h"
#include "cfft.h"
#include "mdct.h"

#include "fec_highband.h"

/*---------------------------------------------------------------------------*
 * mdct()                                                                    *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~                                                *
 * Compute MDCT                                                              *
 *                                                                           *
 * Details of the MDCT computation algorithm implemented here:               *
 *                                                                           *
 * - The signal x(n) is divided into blocks of N successive samples          *
 *   with N=80 (with 50% overlap between blocks)                             * 
 *                                                                           *
 * - The samples x(n) are windowed to obtain                                 *
 *                                                                           *
 *                            yn = x(n).h(N-1-n)                             *
 *                                                                           *
 *   where h(N-1-n) is the following weighting law:                          *
 *                                                                           *
 *        h(N-1-n) = sqrt(2)/80 * sin( pi/N * (n+0.5) ), n=0...N-1           *
 *                                                                           *
 *   The window h(n) is symmetric,                                           *
 *   i.e. h(N-1-n) = h(n), n=0...N-1                                         *
 *                                                                           *
 * - The discrete modified discrete cosine transform (MDCT) of blocks of     *
 *   x(n) is calculated using the even order transform                       *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( 2n/(4N).(2n+1).(4k+1)+(4k+1).pi/4)               *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 *  In the equation above, the cosine operand can be written:                *
 *                                                                           *
 *    2pi/(4N).(2n+1).(2(2k)+1)+(2(2k)+1).pi/4                               *
 *     = (pi/(N/2).(n+0.5) + pi/4) . ((2k)+0.5)                              *
 *     = pi/(N/2).(n+0.5+N/4).((2k)+0.5)                                     *
 *                                                                           *
 *  Therefore, the MDCT can be also written as:                              *
 *                                                                           *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( pi/(N/2).(n+0.5+N/4).((2k)+0.5) )                *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 * IMPORTANT NOTE (to obtain odd order coefficients YN-1-2k through Y2k):    *
 * YN-k = -Yk-1 for k=0...N-1                                                *
 *                                                                           *
 * - The even order coefficients Y2k are calculated in the form of an        *
 *   invertible complex transform as follows:                                *
 *                                                                           *
 *    Y2k+N/4 + jY2k =                                                       *
 *                  N/4-1                                                    *
 *                 ------                                                    *
 *     k+1    -1   \                                          (4k+1)(4n+1)   *
 * (-1)   . W8  .   |     ((y'n-y''n+N/4)+j(y''n+y'n+N/4)).W4N           ,   *
 *                 /                                                         *
 *                 ------                                                    *
 *                  n=0                                                      *
 *   for k=0...N/4-1                                                         *
 *                                                                           *
 * with                                                                      *
 *                                                                           *
 *    y'n  = x2n.h2n                                                         *
 *    y''n = xN-2n-1.hN-2n-1                                                 *
 *    W4N  = cos(2pi/4N)+j.sin(2pi/4N)                                       *
 *                                                                           *
 * - The invertible complex transform is calculated on the basis on the      *
 *   the following auxiliary calculation equation:                           *
 *                                                                           *
 *                                N/4-1                                      *
 *                                -----                                      *
 *            k+1    -1     4k+1  \            n      nk                     *
 *   zk = (-1)   . W8  . W4N    .  |     (zn.WN ).WN/4                       *
 *                                /                                          *
 *                                -----                                      *
 *                                 n=0                                       *
 * where                                                                     *
 *                                                                           *
 *    zn = (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n), for n=0...N/4-1             *
 *                                                                           *
 * This fast MDCT algorithm is also described in:                            *
 * "A fast algorithm for the implementation of Filter Banks based on Time    *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212  *
 *                                                                           *
 * Remark about main notations (mapping of notations):                       *
 *                                                                           *
 *   Details above          |   C code           |    Text of G.711WB        *
 *  ------------------------+--------------------+------------------------   *
 *     x(n)                 |     xin[n]         |     sHB(n)                *
 *     Y2k                  |     ykr[k]         |     SHB(k)                *
 *     s(n)                 | xin[n]<<norm_shift |  sHB(n) * 2^etaTDAC1HB    *
 *     h(N-1-n)* 80         |     hTDAC[n]       |       wTDAC(n)            *
 *                                                                           * 
 *---------------------------------------------------------------------------*/
void mdct (
  Float  *mem,    /* (i): old input samples */
  Float  *input,  /* (i): input samples     */
  Float  *ykr     /* (o): MDCT coefficients */
) {
  Float  temp0, temp1;
  Float  xin[MDCT_L_WIN];
  Float  ycr[MDCT_L_WIN2];
  Float  yci[MDCT_L_WIN2];
  Float  *ptr_x1, *ptr_x2;        /* pointers on input samples */
  Float  *ptr_ycr;                /* pointer on ycr */
  Float  *ptr_yci;                /* pointer on yci */
  const Float  *ptr_h1, *ptr_h2;  /* pointers on window */

  Short  i, k;
  Short  sign;                    /* sign for FFT/IFFT */

  /*******************************************************************************/
  /* MDCT Computation                                                            */
  /*******************************************************************************/

  /* form block of length N */
  for (i = 0; i < MDCT_L_WIN2; i++) {
    xin[i] = mem[i];
  }
  for (i = 0; i < MDCT_L_WIN2; i++) {
    xin[i + MDCT_L_WIN2] = input[i];
  }

  /* Step 1 --> Calculate zn =  (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n) (complex terms), 
     for n=0...N/4-1                                         */
  ptr_h1 = MDCT_h + MDCT_L_WIN2;        /* Middle of the window */
  ptr_x1 = xin + MDCT_L_WIN2;
  ptr_h2 = MDCT_h + MDCT_L_WIN; /* End of the window */
  ptr_x2 = xin + MDCT_L_WIN;
  k = 0;
  ptr_yci = yci;
  ptr_ycr = ycr;
  for (i = 0; i < MDCT_L_WIN4; i++) {
    ycr[i] = MDCT_h[k] * xin[k] - ptr_h1[-k - 1] * ptr_x1[-k - 1];
    yci[i] = ptr_h2[-k - 1] * ptr_x2[-k - 1] + ptr_h1[k] * ptr_x1[k];
    k += 2;
  }

  /* Step 2 --> Calculate z'n = zn.WN^n, for n=0...N/4-1 */
  ptr_yci = yci;
  ptr_ycr = ycr;
  for (k = 0; k < MDCT_L_WIN4; k++) {
    temp1 = *ptr_ycr;
    temp0 = temp1 * MDCT_wcos[k];
    temp0 -= yci[k] * MDCT_wsin[k];
    *ptr_ycr++ = temp0;

    temp0 = temp1 * MDCT_wsin[k];
    temp0 += yci[k] * MDCT_wcos[k];
    *ptr_yci++ = temp0;
  }

  /* Step 3 --> Inverse FFT of size N/4: Z'k = FFT-1 z'n, for k=0...N/4-1 */
  sign = (Short) - 1;
  cfft(ycr, yci, sign);

  /* Step 4 --> Calculate Zk = 1/80 . ((-1)^k+1.W8^-1.W4N^(4k+1)) . Z'k

     Step 5 --> Rearranging results:
     Y2k       = Im[Zk]
     Y2(k+N/4) = Re[Zk]

     Since Y2(k+N/4) =-Y(N/2-1-2k), results are actually presented as follows:
     Y2k       = Im[Zk]
     YN/2-1-2k = -Re[Zk]                                             

     Steps 4 & 5 are integrated below in a single step */
  ptr_x1 = ykr;
  ptr_x2 = ykr + MDCT_L_WIN2 - 1;
  for (k = 0; k < MDCT_L_WIN4; k++) {
    temp1 = ycr[k];

    /* symmetry of the coeff k-1 and N-k */
    temp0 = yci[k] * MDCT_weti[k];
    temp0 -= temp1 * MDCT_wetr[k];
    *ptr_x2-- = temp0;
    ptr_x2--;

    temp0 = temp1 * MDCT_weti[k];
    temp0 += yci[k] * MDCT_wetr[k];
    *ptr_x1++ = temp0;
    ptr_x1++;
  }

  /* update memory */
  for (i = 0; i < MDCT_L_WIN2; i++) {
    mem[i] = input[i];
  }

  return;
}  /* END MDCT */

/*--------------------------------------------------------------------------*
 *  inv_mdct()                                                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute inverse MDCT and overlap-add                                    *
 * The underlying algorithm is described in                                 *
 * - "A fast algorithm for the implementation of Filter Banks based on Time *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212 *
 *                                                                          *
 * The inverse MDCT consists of:                                            *
 * - Permuting real and imaginary parts YN/4+2k, Y2k                        *
 *   of the transmitted MDCT spectrum                                       *
 * - Calculating the complex part of the forward MDCT, i.e. Re[Zk], Im[Zk]  *
 * - Permuting real and imaginary parts of this complex part                *
 * - Performing an overlap calculation to reconstruct samples               *
 *--------------------------------------------------------------------------*/

void inv_mdct (
  Float  *xr,        /* (o):   output samples                     */
  Float  *ykq,       /* (i):   MDCT coefficients                  */
  Float  *ycim1,     /* (i):   previous MDCT memory               */
  Short  loss_flag,  /* (i):   packet-loss flag                   */
  Float  *cur_save,  /* (i/o): signal saving buffer               */
  HBFEC_State  *st   /* (i/o): work space for HB FERC             */
) {
  Float  temp, temp1;

  Float  ACC0;

  Float  ycr[MDCT_L_WIN4];
  Float  yci[MDCT_L_WIN4];
  Float  sig_cur[MDCT_L_WIN2];
  Float  sig_next[MDCT_L_WIN2];

  Float  *ptr_yci;
  Float  *ptr_ycr;
  Float  *ptr1;
  Float  *ptr2;
  Float  *ptr1_next;
  Float  *ptr2_next;
  const Float  *ptr_h;  /* Pointer on window */

  Short  k;
  Short  sign;          /* sign for FFT / IFFT */
  Float  *hb_buf = st->hb_buf;
  Float  *ptr_imdct;

  /* Higher-band frame erasure concealment (FERC) in time domain */
  if (loss_flag != 0) {
    st->pre_bfi = 1;
    if (st->first_loss_frame) {
      st->hb_t0 = st->lb_t0;

      if (cor_hb_fec(hb_buf, &st->hb_t0) >= 0.7f) {
        st->high_cor = 1;
      }
      else {
        st->high_cor = 0;
      }
    }

    if (st->high_cor) {         /* HBFEC based on pitch repetition and attenuation */
      /* copy pitch for 2 HB frame */
      if (st->first_loss_frame) {
        for (k = 0; k < MDCT_L_WIN; k++) {
          hb_buf[MAXPIT + MDCT_L_WIN2 + k] =
            hb_buf[MAXPIT + MDCT_L_WIN2 + k - st->hb_t0];
        }
      }
      else {
        for (k = 0; k < MAXPIT + MDCT_L_WIN2; k++) {
          hb_buf[k] = hb_buf[k + MDCT_L_WIN2];
        }

        for (k = 0; k < MDCT_L_WIN; k++) {
          hb_buf[MAXPIT + MDCT_L_WIN2 + k] =
            hb_buf[MAXPIT + MDCT_L_WIN2 + k - st->hb_t0];
        }
      }

      ptr_imdct = &hb_buf[MAXPIT + MDCT_L_WIN2];
      for (k = 0; k < MDCT_L_WIN2; k++) {
        cur_save[k] = ptr_imdct[k] * MDCT_h[k];
      }

      if (st->att_weight >= 0.2f) {
        ptr_h = MDCT_h + MDCT_L_WIN2;
        for (k = 0; k < MDCT_L_WIN2; k++) {
          ACC0 = cur_save[k] * MDCT_h[k];
          ACC0 += ycim1[k] * (*(--ptr_h));
          xr[k] = ACC0;

          st->att_weight -= ATT_WEIGHT_STEP;
          xr[k] = xr[k] * st->att_weight;
        }
      }
      else {
        for (k = 0; k < MDCT_L_WIN2; k++) {
          xr[k] = 0;
        }
      }
      ptr_imdct = &hb_buf[MAXPIT + MDCT_L_WIN];
      for (k = 0; k < MDCT_L_WIN2; k++) {
        ycim1[k] = ptr_imdct[k] * MDCT_h[k + MDCT_L_WIN2];
      }
    }
    else {
      ptr_h = MDCT_h + MDCT_L_WIN2;
      for (k = 0; k < MDCT_L_WIN2; k++) {
        cur_save[k] = 0.875f * cur_save[k];
        ACC0 = cur_save[k] * MDCT_h[k];
        ACC0 += ycim1[k] * (*(--ptr_h));
        xr[k] = ACC0;
        ycim1[k] = 0.875f * ycim1[k];
      }
    }
    st->first_loss_frame = 0;

    return;
  }

  if (st->pre_bfi) {
    for (k = MDCT_L_WIN2 - 1; k >= 0; k--) {
      ycim1[k] = ycim1[k] * st->att_weight;
    }
    st->first_loss_frame = 1;
    st->att_weight = 1.0f;
    st->pre_bfi = 0;
  }

  /*******************************************************************************/
  /* Inverse MDCT computation                                                    */
  /*******************************************************************************/

  /* 1 --> Input rotation = Product by wetrm1 */

  ptr1 = ykq;
  ptr2 = ykq + (MDCT_L_WIN2 - 1);
  ptr_yci = yci;
  ptr_ycr = ycr;

  for (k = 0; k < MDCT_L_WIN4; k++) {
    temp = -(*ptr2 * MDCT_wetrm1[k]);
    temp -= *ptr1 * MDCT_wetim1[k];
    *ptr_ycr++ = temp;

    temp = *ptr1++ * MDCT_wetrm1[k];
    temp -= *ptr2-- * MDCT_wetim1[k];
    *ptr_yci++ = temp;

    ptr1++;
    ptr2--;
  }

  /* 2 --> Forward FFT : size = 160 */
  sign = 1;
  cfft(ycr, yci, sign);

  /*  3) Output rotation = product by a complex exponent */
  ptr_yci = yci;
  ptr_ycr = ycr;
  for (k = 0; k < MDCT_L_WIN4; k++) {
    temp1 = *ptr_ycr;
    temp = temp1 * MDCT_wcos[k];
    temp += yci[k] * MDCT_wsin[k];
    *ptr_ycr++ = temp;

    temp = yci[k] * MDCT_wcos[k];
    temp -= temp1 * MDCT_wsin[k];
    *ptr_yci++ = temp;
  }

  /* 4 --> Overlap and windowing (in one step) - equivalent to complex product */
  ptr1 = sig_cur;
  ptr2 = sig_cur + MDCT_L_WIN2 - 1;
  ptr1_next = sig_next;
  ptr2_next = sig_next + MDCT_L_WIN2 - 1;
  for (k = 0; k < MDCT_L_WIN4; k++) {
    *ptr1++ = ycr[k];
    *ptr2-- = -ycr[k];
    *ptr1_next++ = yci[k];
    *ptr2_next-- = yci[k];
    *ptr1++;
    ptr1_next++;
    ptr2--;
    ptr2_next--;
  }

  ptr_h = MDCT_h + MDCT_L_WIN2;
  for (k = 0; k < MDCT_L_WIN2; k++) {
    temp = sig_cur[k] * MDCT_h[k];
    temp += ycim1[k] * *(--ptr_h);
    xr[k] = temp;
    ycim1[k] = sig_next[k];
  }

  /* Save sig_cur for FERC */
  for (k = 0; k < MDCT_L_WIN2; k++) {
    cur_save[k] = sig_cur[k];
  }

  return;
}
