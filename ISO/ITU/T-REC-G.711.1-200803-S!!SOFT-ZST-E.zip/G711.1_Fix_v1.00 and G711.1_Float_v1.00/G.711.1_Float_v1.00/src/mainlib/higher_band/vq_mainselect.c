/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: vq_mainselect.c
 *  Function: Main-selection of Interleave CSVQ
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Main-selection of Interleave CSVQ
  Return value:
    None
  ----------------------------------------------------------------*/
void vq_mainselect (
  Short  sCanIndx0[],       /* (i): Candidate indices for channel 0 */
  Short  sCanIndx1[],       /* (i): Candidate indices for channel 1 */
  Short  index_wvq[],       /* (o): Selected VQ indices             */
  Float  fCanMeas0[N_CAN],  /* (i): Candidate measuremant parameter */
  Float  fCanMeas1[N_CAN],  /* (i): Candidate measuremant parameter */
  Float  fCanSign0[N_CAN],  /* (i): Candidate sign                  */
  Float  fCanSign1[N_CAN],  /* (i): Candidate sign                  */
  Float  fLocalv[]          /* (o): Locally decodec subvector       */
) {
  int    i_can;
  int    i_can0;
  int    i_can1;
  int    j_can;
  int    i_smp;
  Float  pol0, pol1;
  Short  index0, index1;
  Float  fMeas0;
  Float  fDist;
  Float  fDistMin;

  const Float  *pfCross;
  const Float  *pfCodev0, *pfCodev1;

  fDistMin = (Float) MAX_32;

  i_can0 = 0;
  i_can1 = 0;

  for (i_can = 0; i_can < N_CAN; i_can++)
  {
    fMeas0 = fCanMeas0[i_can];

    pfCross = gfCodebook_cross[sCanIndx0[i_can]];

    for (j_can = 0; j_can < N_CAN; j_can++)
    {
      /* cross *= sign0[i_can] * sign1[j_can] */
      /* dist = cross - meas[i_can] - meas[j_can]; */

      fDist = pfCross[sCanIndx1[j_can]] * fCanSign0[i_can] * fCanSign1[j_can];
      fDist -= fMeas0;
      fDist -= fCanMeas1[j_can];
      if (fDist < fDistMin)
      {
        i_can0 = i_can;
        i_can1 = j_can;
        fDistMin = fDist;
      }
    }
  }

  /* Local re-constructing */
  index0 = sCanIndx0[i_can0];
  index_wvq[0] = index0 + CB_SIZE;
  index1 = sCanIndx1[i_can1];
  index_wvq[N_DIV] = index1 + CB_SIZE;

  pol0 = fCanSign0[i_can0];  /* 1 or -1 */
  pol1 = fCanSign1[i_can1];  /* 1 or -1 */

  if (pol0 > 0.0f)
  {
    index_wvq[0] = index0;
  }
  if (pol1 > 0.0f)
  {
    index_wvq[N_DIV] = index1;
  }

  pfCodev0 = gfCodebook_0ch[index0];
  pfCodev1 = gfCodebook_1ch[index1];

  for (i_smp = 0; i_smp < VECLEN; i_smp++)
  {
    fLocalv[i_smp] = (pol0 * pfCodev0[i_smp] + pol1 * pfCodev1[i_smp]) / 2.0f;
  }
}
