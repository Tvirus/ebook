/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: vqdec_spectrum.c
 *  Function: MDCT coefficient decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Reconstructs MDCT coefficients.
  Return value
    0
  ----------------------------------------------------------------*/
int VQdecode_spectrum (
  Short  index_wvq[],  /* (i): VQ indices                                 */
  Short  index_pow,    /* (i): Gain index                                 */
  Float  pSpectrum[]   /* (o): Reconstruced coefficients, Q(*psSpectrumQ) */
) {
  int    i_div, i_smp;
  int    index0, index1;
  Short  sGain;
  Float  pol0, pol1;
  Float  dec0, dec1, dec2, dec3, dec4, dec5;
  Float  fGain;

  const Float  *pfCodev0, *pfCodev1;

  /* Decode gain */
  sGain = mulawinv(index_pow);  /* Q0 */

  fGain = (Float) sGain * (Float) (DE_SCALE_FACT) / 262144.0f;

  i_smp = N_DIV - 1;
  for (i_div = 0; i_div < N_DIV; i_div++)
  {
    /* VQ shape indices */
    index0 = index_wvq[i_div] & BITMASK_SHAPE;
    index1 = index_wvq[i_div + N_DIV] & BITMASK_SHAPE;

    /* Sign */
    pol0 = 1.0f - 2.0f * (Float) ((index_wvq[i_div] >> MAXBIT_SHAPE) & 0x1);
    pol1 = 1.0f - 2.0f * (Float) ((index_wvq[i_div + N_DIV] >> MAXBIT_SHAPE) & 0x1);

    /* Extract code-vectors from codebooks */
    pfCodev0 = gfCodebook_0ch[index0];
    pfCodev1 = gfCodebook_1ch[index1];

    /* Reconst CS-subvectors                      */
    /* Gain mulitiplication and inverse weighting */
    dec0 = (pol0 * pfCodev0[0] + pol1 * pfCodev1[0]) * fGain / 2.0f;
    dec1 = (pol0 * pfCodev0[1] + pol1 * pfCodev1[1]) * fGain / 2.0f;
    dec2 = (pol0 * pfCodev0[2] + pol1 * pfCodev1[2]) * fGain * 0.75f / 2.0f;
    dec3 = (pol0 * pfCodev0[3] + pol1 * pfCodev1[3]) * fGain * 0.60f / 2.0f;
    dec4 = (pol0 * pfCodev0[4] + pol1 * pfCodev1[4]) * fGain * 0.50f / 2.0f;
    dec5 = (pol0 * pfCodev0[5] + pol1 * pfCodev1[5]) * fGain / 2.0f;

    /* Reverse interleaving */
    pSpectrum[i_smp + 30] = dec0;
    pSpectrum[i_smp + 24] = dec1;
    pSpectrum[i_smp + 18] = dec2;
    pSpectrum[i_smp + 12] = dec3;
    pSpectrum[i_smp + 6] = dec4;
    pSpectrum[i_smp] = dec5;

    i_smp--;
  }

  return 0;
}
