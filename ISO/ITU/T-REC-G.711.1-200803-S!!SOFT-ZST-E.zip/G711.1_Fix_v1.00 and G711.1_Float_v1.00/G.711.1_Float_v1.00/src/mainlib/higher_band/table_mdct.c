/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: table_mdct.c
 *  Function: tables for MDCT computation
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "defines_mdct.h"

/***************************************************************
 *                                                             *
 *             MDCT COMPUTATION TABLES                         *
 *                                                             *
 ***************************************************************/

/* Cosine table for FFT */
const Float   MDCT_xcos[MDCT_NP * MDCT_NP] = {
  (Float) 1.000000000e+000, (Float) 1.000000000e+000,
  (Float) 1.000000000e+000, (Float) 1.000000000e+000,
  (Float) 1.000000000e+000,
  (Float) 1.000000000e+000, (Float) 3.090169944e-001,
  (Float)-8.090169944e-001, (Float)-8.090169944e-001,
  (Float) 3.090169944e-001,
  (Float) 1.000000000e+000, (Float)-8.090169944e-001,
  (Float) 3.090169944e-001, (Float) 3.090169944e-001,
  (Float)-8.090169944e-001,
  (Float) 1.000000000e+000, (Float)-8.090169944e-001,
  (Float) 3.090169944e-001, (Float) 3.090169944e-001,
  (Float)-8.090169944e-001,
  (Float) 1.000000000e+000, (Float) 3.090169944e-001,
  (Float)-8.090169944e-001, (Float)-8.090169944e-001,
  (Float) 3.090169944e-001
};

/* Sine table for FFT */
const Float   MDCT_xsin[MDCT_NP * MDCT_NP] = {
  (Float) 0.000000000e+000, (Float) 0.000000000e+000,
  (Float) 0.000000000e+000, (Float) 0.000000000e+000,
  (Float) 0.000000000e+000,
  (Float) 0.000000000e+000, (Float)-9.510565163e-001,
  (Float)-5.877852523e-001, (Float) 5.877852523e-001,
  (Float) 9.510565163e-001,
  (Float) 0.000000000e+000, (Float)-5.877852523e-001,
  (Float) 9.510565163e-001, (Float)-9.510565163e-001,
  (Float) 5.877852523e-001,
  (Float) 0.000000000e+000, (Float) 5.877852523e-001,
  (Float)-9.510565163e-001, (Float) 9.510565163e-001,
  (Float)-5.877852523e-001,
  (Float) 0.000000000e+000, (Float) 9.510565163e-001,
  (Float) 5.877852523e-001, (Float)-5.877852523e-001,
  (Float)-9.510565163e-001
};

/* Index mapping table for Good-Thomas FFT */
const Short   MDCT_tab_map[MDCT_NP * MDCT_NPP] = {
  (Short) 0, (Short) 5, (Short)10, (Short)15, (Short)16, (Short) 1,
  (Short) 6, (Short)11, (Short)12, (Short)17,
  (Short) 2, (Short) 7, (Short) 8, (Short)13, (Short)18, (Short) 3,
  (Short) 4, (Short) 9, (Short)14, (Short)19
};

/* Index mapping table for Good-Thomas FFT */
const Short   MDCT_tab_map2[MDCT_NP * MDCT_NPP] = {
  (Short) 0, (Short) 5, (Short)10, (Short)15, (Short) 4, (Short) 9,
  (Short)14, (Short)19, (Short) 8, (Short)13,
  (Short)18, (Short) 3, (Short)12, (Short)17, (Short) 2, (Short) 7,
  (Short)16, (Short) 1, (Short) 6, (Short)11
};

/* Table for Good-Thomas FFT */
const Short   MDCT_tab_rev_ipp[MDCT_NB_REV] = {
  (Short) 1
};

/* Table for Good-Thomas FFT */
const Short   MDCT_tab_rev_i[MDCT_NB_REV] = {
  (Short) 2
};

/* FFT twiddle factors (cosine part) */
const Float   MDCT_rw1[MDCT_L_WIN4] = {
  (Float) 1.000000000e+000, (Float) 9.510565163e-001,
  (Float) 8.090169944e-001, (Float) 5.877852523e-001,
  (Float) 3.090169944e-001,
  (Float) 6.123031769e-017, (Float)-3.090169944e-001,
  (Float)-5.877852523e-001, (Float)-8.090169944e-001,
  (Float)-9.510565163e-001,
  (Float)-1.000000000e+000, (Float)-9.510565163e-001,
  (Float)-8.090169944e-001, (Float)-5.877852523e-001,
  (Float)-3.090169944e-001,
  (Float)-1.836909531e-016, (Float) 3.090169944e-001,
  (Float) 5.877852523e-001, (Float) 8.090169944e-001,
  (Float) 9.510565163e-001
};

/* FFT twiddle factors (sine part) */
const Float   MDCT_rw2[MDCT_L_WIN4] = {
  (Float) 0.000000000e+000, (Float) 3.090169944e-001,
  (Float) 5.877852523e-001, (Float) 8.090169944e-001,
  (Float) 9.510565163e-001,
  (Float) 1.000000000e+000, (Float) 9.510565163e-001,
  (Float) 8.090169944e-001, (Float) 5.877852523e-001,
  (Float) 3.090169944e-001,
  (Float) 1.224606354e-016, (Float)-3.090169944e-001,
  (Float)-5.877852523e-001, (Float)-8.090169944e-001,
  (Float)-9.510565163e-001,
  (Float)-1.000000000e+000, (Float)-9.510565163e-001,
  (Float)-8.090169944e-001, (Float)-5.877852523e-001,
  (Float)-3.090169944e-001
};

/* Cosine table for MDCT and iMDCT */
const Float   MDCT_wcos[MDCT_L_WIN4] = {
  (Float) 1.000000000e+000, (Float) 9.969173337e-001,
  (Float) 9.876883406e-001, (Float) 9.723699204e-001,
  (Float) 9.510565163e-001,
  (Float) 9.238795325e-001, (Float) 8.910065242e-001,
  (Float) 8.526401644e-001, (Float) 8.090169944e-001,
  (Float) 7.604059656e-001,
  (Float) 7.071067812e-001, (Float) 6.494480483e-001,
  (Float) 5.877852523e-001, (Float) 5.224985647e-001,
  (Float) 4.539904997e-001,
  (Float) 3.826834324e-001, (Float) 3.090169944e-001,
  (Float) 2.334453639e-001, (Float) 1.564344650e-001,
  (Float) 7.845909573e-002
};

/* Sine table for MDCT and iMDCT */
const Float   MDCT_wsin[MDCT_L_WIN4] = {
  (Float) 0.000000000e+000, (Float) 7.845909573e-002,
  (Float) 1.564344650e-001, (Float) 2.334453639e-001,
  (Float) 3.090169944e-001,
  (Float) 3.826834324e-001, (Float) 4.539904997e-001,
  (Float) 5.224985647e-001, (Float) 5.877852523e-001,
  (Float) 6.494480483e-001,
  (Float) 7.071067812e-001, (Float) 7.604059656e-001,
  (Float) 8.090169944e-001, (Float) 8.526401644e-001,
  (Float) 8.910065242e-001,
  (Float) 9.238795325e-001, (Float) 9.510565163e-001,
  (Float) 9.723699204e-001, (Float) 9.876883406e-001,
  (Float) 9.969173337e-001
};

/* Table for complex post-multiplication in MDCT (Float part) */
const Float   MDCT_wetr[MDCT_L_WIN4] = {
  (Float)-9.010669959e-003, (Float) 9.662630667e-003,
  (Float)-1.025501804e-002, (Float) 1.078417982e-002,
  (Float)-1.124685355e-002,
  (Float) 1.164018668e-002, (Float)-1.196175420e-002,
  (Float) 1.220957352e-002, (Float)-1.238211676e-002,
  (Float) 1.247832013e-002,
  (Float)-1.249759051e-002, (Float) 1.243980908e-002,
  (Float)-1.230533210e-002, (Float) 1.209498865e-002,
  (Float)-1.181007558e-002,
  (Float) 1.145234946e-002, (Float)-1.102401580e-002,
  (Float) 1.052771542e-002, (Float)-9.966508172e-003,
  (Float) 9.343854086e-003
};

/* Table for complex post-multiplication in MDCT (imaginary part) */
const Float   MDCT_weti[MDCT_L_WIN4] = {
  (Float) 8.663592032e-003, (Float)-7.929916052e-003,
  (Float) 7.147349503e-003, (Float)-6.320717167e-003,
  (Float) 5.455115508e-003,
  (Float)-4.555881248e-003, (Float) 3.628558466e-003,
  (Float)-2.678864413e-003, (Float) 1.712654271e-003,
  (Float)-7.358850456e-004,
  (Float)-2.454211558e-004, (Float) 1.225214254e-003,
  (Float)-2.197453499e-003, (Float) 3.156144713e-003,
  (Float)-4.095377245e-003,
  (Float) 5.009360414e-003, (Float)-5.892459210e-003,
  (Float) 6.739229036e-003, (Float)-7.544449274e-003,
  (Float) 8.303155474e-003
};

/* Table for complex pre-multiplication in iMDCT (Float part) */
const Float   MDCT_wetrm1[MDCT_L_WIN4] = {
  (Float)-1.441707193e+000, (Float) 1.546020907e+000,
  (Float)-1.640802887e+000, (Float) 1.725468772e+000,
  (Float)-1.799496568e+000,
  (Float) 1.862429870e+000, (Float)-1.913880671e+000,
  (Float) 1.953531763e+000, (Float)-1.981138681e+000,
  (Float) 1.996531220e+000,
  (Float)-1.999614481e+000, (Float) 1.990369453e+000,
  (Float)-1.968853136e+000, (Float) 1.935198185e+000,
  (Float)-1.889612093e+000,
  (Float) 1.832375914e+000, (Float)-1.763842529e+000,
  (Float) 1.684434467e+000, (Float)-1.594641308e+000,
  (Float) 1.495016654e+000
};

/* Table for complex pre-multiplication in iMDCT (imaginary part) */
const Float   MDCT_wetim1[MDCT_L_WIN4] = {
  (Float)-1.386174725e+000, (Float) 1.268786568e+000,
  (Float)-1.143575920e+000, (Float) 1.011314747e+000,
  (Float)-8.728184813e-001,
  (Float) 7.289409998e-001, (Float)-5.805693545e-001,
  (Float) 4.286183061e-001, (Float)-2.740246834e-001,
  (Float) 1.177416073e-001,
  (Float) 3.926738492e-002, (Float)-1.960342807e-001,
  (Float) 3.515925599e-001, (Float)-5.049831540e-001,
  (Float) 6.552603591e-001,
  (Float)-8.014976662e-001, (Float) 9.427934737e-001,
  (Float)-1.078276646e+000, (Float) 1.207111884e+000,
  (Float)-1.328504876e+000
};

/* MDCT window */
const Float   MDCT_h[MDCT_L_WIN] = {
  (Float) 2.776623416e-002, (Float) 8.325588895e-002,
  (Float) 1.386171692e-001, (Float) 1.937647118e-001,
  (Float) 2.486134833e-001,
  (Float) 3.030789108e-001, (Float) 3.570770126e-001,
  (Float) 4.105245275e-001, (Float) 4.633390434e-001,
  (Float) 5.154391240e-001,
  (Float) 5.667444349e-001, (Float) 6.171758669e-001,
  (Float) 6.666556585e-001, (Float) 7.151075153e-001,
  (Float) 7.624567283e-001,
  (Float) 8.086302882e-001, (Float) 8.535569988e-001,
  (Float) 8.971675863e-001, (Float) 9.393948065e-001,
  (Float) 9.801735480e-001,
  (Float) 1.019440933e+000, (Float) 1.057136414e+000,
  (Float) 1.093201867e+000, (Float) 1.127581682e+000,
  (Float) 1.160222848e+000,
  (Float) 1.191075034e+000, (Float) 1.220090669e+000,
  (Float) 1.247225013e+000, (Float) 1.272436226e+000,
  (Float) 1.295685435e+000,
  (Float) 1.316936790e+000, (Float) 1.336157525e+000,
  (Float) 1.353318001e+000, (Float) 1.368391759e+000,
  (Float) 1.381355557e+000,
  (Float) 1.392189404e+000, (Float) 1.400876596e+000,
  (Float) 1.407403738e+000, (Float) 1.411760765e+000,
  (Float) 1.413940959e+000,
  (Float) 1.413940959e+000, (Float) 1.411760765e+000,
  (Float) 1.407403738e+000, (Float) 1.400876596e+000,
  (Float) 1.392189404e+000,
  (Float) 1.381355557e+000, (Float) 1.368391759e+000,
  (Float) 1.353318001e+000, (Float) 1.336157525e+000,
  (Float) 1.316936790e+000,
  (Float) 1.295685435e+000, (Float) 1.272436226e+000,
  (Float) 1.247225013e+000, (Float) 1.220090669e+000,
  (Float) 1.191075034e+000,
  (Float) 1.160222848e+000, (Float) 1.127581682e+000,
  (Float) 1.093201867e+000, (Float) 1.057136414e+000,
  (Float) 1.019440933e+000,
  (Float) 9.801735480e-001, (Float) 9.393948065e-001,
  (Float) 8.971675863e-001, (Float) 8.535569988e-001,
  (Float) 8.086302882e-001,
  (Float) 7.624567283e-001, (Float) 7.151075153e-001,
  (Float) 6.666556585e-001, (Float) 6.171758669e-001,
  (Float) 5.667444349e-001,
  (Float) 5.154391240e-001, (Float) 4.633390434e-001,
  (Float) 4.105245275e-001, (Float) 3.570770126e-001,
  (Float) 3.030789108e-001,
  (Float) 2.486134833e-001, (Float) 1.937647118e-001,
  (Float) 1.386171692e-001, (Float) 8.325588895e-002,
  (Float) 2.776623416e-002
};
