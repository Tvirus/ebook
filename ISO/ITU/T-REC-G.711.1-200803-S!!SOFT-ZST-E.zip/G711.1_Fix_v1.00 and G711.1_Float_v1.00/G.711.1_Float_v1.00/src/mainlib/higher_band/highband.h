/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: highband.h
 *  Function: Higher-band VQ constants
 *------------------------------------------------------------------------
 */

#ifndef HIGHBAND_H
#define HIGHBAND_H

#include "fec_highband.h"

#define N_FR_FREQ      36          /* Number of quantized coefficients */
#define MAXBIT_SHAPE   5           /* Number of bits allocated for shape */
#define CB_SIZE        32          /* Shape codebook size */
#define BITMASK_SHAPE  0x1F        /* Bit mask for shape index */
#define N_DIV          6           /* Number of subvectors */
#define VECLEN         6           /* Subvector length */
#define N_CAN          8           /* Number of preselected candidates */
#define GSCALE_FACT    25905       /* Gain scaling factor, 4*sqrt(10) in Q11 */
#define DE_SCALE_FACT  20724       /* Gain de-scaling factor 1/(4*sqrt(10)), Q18 */

typedef struct {
  Short wvq[N_DIV*2];
  Short pow;
} INDEX;

typedef struct {    /* used in encoder only */
  Float in[L_FRAME_NB];
} VQE_State;

typedef struct {    /* used in decoder only */
  Float prev[L_FRAME_NB];
  Float curSave[L_FRAME_NB];
  Short sSpectrumQ_pre;
  int    reset;
  HBFEC_State hbfec_st;
} VQD_State;

/* Global tables */

extern const Float gfCodebook_0ch[CB_SIZE][VECLEN];
extern const Float gfCodebook_1ch[CB_SIZE][VECLEN];
extern const Float gfCodebook_0ch_pow[CB_SIZE];
extern const Float gfCodebook_1ch_pow[CB_SIZE];
extern const Float gfCodebook_cross[CB_SIZE][CB_SIZE];

/* Function prototypes */

void* highband_encode_const(void);
void  highband_encode_dest(void *work);
int   highband_encode_reset(void *work);
int   highband_encode( const Float *, unsigned char *, void * );
void* highband_decode_const(void);
void  highband_decode_dest(void *work);
int   highband_decode_reset(void *work);
int   highband_decode( const unsigned char *, int, Float *, void * );

int   VQencode_spectrum( Float*, Short*, Float, Short* );
int   norm_spectrum( Float*, Short, Float*, Float* );
void  vq_preselect( Float*, const Float(*)[VECLEN], const Float*, Float*, Float*, Short* );
void  vq_mainselect( Short*, Short*, Short*, Float*, Float*, Float*, Float*, Float* );
int   VQdecode_spectrum( Short*, Short, Float* );

Short mulaw( Short );
int   mux_bitstream( INDEX *, unsigned char * );
Short mulawinv( Short index );
int   demux_bitstream( INDEX *, unsigned char * );

#endif  /* HIGHBAND_H */
