/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: norm_sprctrum.c
 *  Function: MDCT coefficient normalization
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

#define INV_N_FR_FREQ    29127  /* 1/36 in Q20 */

/*----------------------------------------------------------------
  Function:
    Normalizes MDCT coefficients by RMS.
  Return value:
    0
  ----------------------------------------------------------------*/
int norm_spectrum (
  Float  spectrum[],  /* (i): MDCT coefficients       */
  Short  expSpec,     /* (i): Q of sSpectrum[]        */
  Float  normSpec[],  /* (o): Normalized coefficients */
  Float  *pGain       /* (o): Normalizing gain        */
) {
  int    i;
  Float  norm;
  Float  acc;

  /* acc = sum (spectrum[] * spectrum[]) */
  acc = 0;
  for (i = 0; i < N_FR_FREQ; i++) {
    acc += spectrum[i] * spectrum[i];
  }

  /* acc / N_FR_FREQ */
  acc *= INV_N_FR_FREQ / 1048576.0f;     /* INV_N_FR_FREQ: Q20 */

  /* rms = sqrt( acc ) */
  acc = Sqrt (acc);

  /* gain = rms + EPS */
  acc += 1.0f / (Float) Pow (2.0f, (Float)expSpec);

  *pGain = acc;

  /* norm = 1.0 / gain */
  norm = 1.0f / acc;

  /* Normalization of spectrum       */
  /* normspec[] = spectrum[] * norm  */
  for (i = 0; i < N_FR_FREQ; i++) {
    normSpec[i] = spectrum[i] * norm;
  }

  return 0;
}
