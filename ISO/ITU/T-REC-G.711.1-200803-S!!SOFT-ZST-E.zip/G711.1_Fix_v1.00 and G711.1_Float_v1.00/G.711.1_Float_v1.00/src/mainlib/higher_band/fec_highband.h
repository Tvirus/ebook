/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: fec_highband.h
 *  Function: Header of high-band frame erasure concealment (FERC)
 *------------------------------------------------------------------------
 */

#ifndef FEC_HIGHBAND_H
#define FEC_HIGHBAND_H

/* Constants for higher-band FERC */

#define MAXPIT                144 /* maximal pitch lag (20ms @8kHz) => 50 Hz */
#define HB_PITCH_SEARCH_RANGE 3
#define ATT_WEIGHT_STEP       0.005f
#define HB_FEC_BUF_LEN        (L_FRAME_NB*3 + 144)

typedef struct {
  Float hb_buf[HB_FEC_BUF_LEN]; /* HB signal buffer for FERC */
  Short lb_t0;                  /* pitch delay of lowerband  */
  Short first_loss_frame;
  Short hb_t0;                  /* pitch delay of higherband */
  Float att_weight;
  Short high_cor;
  Short pre_bfi;
} HBFEC_State;

/* Function prototypes */

void  update_hb_buf(Float *hb_buf, Float *output_hi);
Float cor_hb_fec(Float * hb_buf, Short *hb_pitch_best);
void  copy_lb_pitch(void *SubDecoderL, void *SubDecoderH);

#endif
