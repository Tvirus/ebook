/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: lpctool.c
 *  Function: Linear prediction tools
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "lpctool.h"

/*-------------------------------------------------------------------------*
* Function Levinson                                                        *
*--------------------------------------------------------------------------*/

#define MAXORD  6

void
Levinson(
  Float R[],           /* (i)     : R[M+1] Vector of autocorrelations */
  Float  rc[],         /* (o) Q15 : rc[M]  Reflection coefficients.   */
  Short *stable,       /* (o)     : Stability flag                    */
  Short  ord,          /* (i)     : LPC order                         */
  Float *a             /* (o) Q12 : LPC coefficients                  */
  )
{
  Float   s, at, err;
  int     i, j, l;

  *stable = 0;

  rc[0] = (-R[1]) / R[0];
  a[0] = (Float) 1.0;
  a[1] = rc[0];
  err = R[0] + R[1] * rc[0];
  for (i = 2; i <= ord; i++) {
    s = (Float) 0.0;
    for (j = 0; j < i; j++) {
      s += R[i - j] * a[j];
    }
    rc[i - 1] = (-s) / (err);
    for (j = 1; j <= (i / 2); j++) {
      l = i - j;
      at = a[j] + rc[i - 1] * a[l];
      a[l] += rc[i - 1] * a[j];
      a[j] = at;
    }
    a[i] = rc[i - 1];
    err += rc[i - 1] * s;
    if (err <= (Float) 0.0) {
      err = (Float) 0.001;
    }
  }

  return;
}

/*----------------------------------------------------------*
 * Function Lag_window()                                    *
 *                                                          *
 * r[i] *= lag_wind[i]                                      *
 *                                                          *
 *    r[i] and lag_wind[i] are in special double precision. *
 *    See "oper_32b.c" for the format                       *
 *                                                          *
 *----------------------------------------------------------*/
void
Lag_window(
  Float       *R,
  const Float *W,
  Short        ord)
{
  int     i;

  for (i = 1; i <= ord; i++) {
    R[i] *= W[i - 1];
  }

  return;
}

/*-------------------------------------------------------------------------*
* Function Autocorr                                                        *
*--------------------------------------------------------------------------*/

#define MAX_LEN    80

void
Autocorr(
  Float       x[],     /* (i)    : Input signal                      */
  const Float win[],   /* (i)    : Analysis window                   */
  Float       R[],     /* (o)    : Autocorrelations                  */
  Short       ord,     /* (i)    : LPC order                         */
  Short       len      /* (i)    : length of analysis                */
  )
{

  Float   y[MAX_LEN];
  Float   sum;
  int     i, j;

  for (i = 0; i < len; i++)
    y[i] = x[i] * win[i];

  for (i = 0; i <= ord; i++) {
    sum = (Float) 0.0f;
    for (j = 0; j < len - i; j++) {
      sum += y[j] * y[j + i];
    }
    R[i] = sum;
  }
  if (R[0] < (Float) 1.0) {
    R[0] = (Float) 1.0;
  }

  return;
}

/*------------------------------------------------------------------------*
 *                         WEIGHT_A.C                                     *
 *------------------------------------------------------------------------*
 *   Weighting of LPC coefficients                                        *
 *   ap[i]  =  a[i] * (gamma ** i)                                        *
 *                                                                        *
 *------------------------------------------------------------------------*/
void
Weight_a(
  Float a[],           /* (i) Q*  : a[m+1]  LPC coefficients             */
  Float ap[],          /* (o) Q*  : Spectral expanded LPC coefficients   */
  Float gamma,         /* (i) Q15 : Spectral expansion factor.           */
  Short m              /* (i)     : LPC order.                           */
  )
{
  Float   fac;
  int     i;

  ap[0] = a[0];
  fac = gamma;
  for (i = 1; i < m; i++) {
    ap[i] = fac * a[i];
    fac *= gamma;
  }
  ap[m] = fac * a[m];

  return;
}
