/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: lowband.h
 *  Function: Header of lower-band encoder and decoder
 *------------------------------------------------------------------------
 */

#ifndef LOWBAND_H
#define LOWBAND_H

#define  ALAW_DEADZONE   11  /* Quantizer dead zone around zero (to minimize crackling) */
#define  MULAW_DEADZONE  7   /* Quantizer dead zone around zero (to minimize crackling) */
#define  ALAW_OFFSET     8   /* A-law offset to enable a zero output (0 = disable) */

#define  G711ULAW        1
#define  G711ALAW        2

/* Noise shaping parameters */

#define L_WINDOW         80     /* length of the LP analysis */
#define ORD_M            4      /* LP order (and # of "lags" in autocorr.c)  */
#define GAMMA1           30147  /* 0.92f in Q15 */
#define GAMMA1f          0.92f  /* 0.92f in Q15 */

#define MAX_NORM         16     /* when to begin noise shaping deactivation  */
                                /* use MAX_NORM = 32 to disable this feature */

void    *lowband_encode_const (int);
void    lowband_encode_dest (void*);
void    lowband_encode_reset (void*);
void    lowband_encode (const Float*, unsigned char*, unsigned char*, void*);

#ifdef APPENDIX_I_POSTFILTER
void    *lowband_decode_const (int, Short);
#else
void    *lowband_decode_const (int);
#endif
void    lowband_decode_dest (void*);
void    lowband_decode_reset (void*);

void    lowband_decode (const unsigned char*, const unsigned char*, int, Float*, Float*, void*);

void    lbe_bitalloc( Short* expi, Short* bit_alloc );

Short  AutocorrNS( Float  x[], Float  r_f[] );

/* Tables used in AutocorrNS() */
extern const Float NS_windowf[L_WINDOW];
extern const Float NS_lag_f[ORD_M];

#endif
