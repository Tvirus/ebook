/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: lpctool.h
 *  Function: Header of linear prediction tools
 *------------------------------------------------------------------------
 */

#ifndef LPCTOOL_H
#define LPCTOOL_H

void  Levinson(Float Rf[], Float rc[], Short * stable, Short ord, Float * a);
void  Lag_window(Float Rf[], const Float * Wf, Short ord);
void  Autocorr(Float x_f[], const Float win[], Float Rf[], Short ord, Short len);
void  Weight_a(Float a[], Float ap[], Float gamma, Short m);

#endif
