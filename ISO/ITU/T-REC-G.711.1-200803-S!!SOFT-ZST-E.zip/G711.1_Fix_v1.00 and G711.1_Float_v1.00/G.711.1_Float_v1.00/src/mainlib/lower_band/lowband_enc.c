/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: lowband_enc.c
 *  Function: Lower-band encoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "g711.h"
#include "lowband.h"
#include "lpctool.h"

typedef struct
{
  Short   law;                   /* G.711 law */
  Float   sigdec_past[L_WINDOW]; /* buffer for past G.711 decoded signal */
  Float   mem_A[ORD_M + 1];      /* A(z) of previous frame */
  Float   mem_rc[ORD_M];         /* Reflection coefficients of previous frame */
  Float   mem_wfilter[ORD_M];    /* buffer for the weighting filter */
} lowband_encode_work;

/* bitstream multiplexing for LBE layer */
static void lowband_lbe_mux(
  Short *excode,
  Short *expi,
  unsigned char code1[]);

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder constructor
  Return value:
    Pointer to work space
   -------------------------------------------------------------------*/
void   *
lowband_encode_const(
  int law                       /* (i): G.711 encoding law [G711ALAW/G711ULAW] */
  )
{
  lowband_encode_work *work = NULL;

  if (law == G711ULAW || law == G711ALAW) {
    work = (lowband_encode_work *) malloc(sizeof(lowband_encode_work));
    if (work != NULL) {
      work->law = law;
      lowband_encode_reset((void *)work);
    }
  }
  return (void *)work;
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder destructor
  Return value:
    None
   -------------------------------------------------------------------*/
void
lowband_encode_dest(
  void *ptr                     /* (i): Pointer to work space */
  )
{
  lowband_encode_work *work = (lowband_encode_work *) ptr;

  if (work != NULL)
    free(work);
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder reset
  Return value:
    None
   -------------------------------------------------------------------*/
void
lowband_encode_reset(
  void *ptr                     /* (i/o): Pointer to work space */
  )
{
  lowband_encode_work *work = (lowband_encode_work *) ptr;

  if (work != NULL) {
    work->mem_A[0] = 1.0f;
    zeroF(ORD_M, &work->mem_A[1]);
    zeroF(ORD_M, work->mem_rc);
    zeroF(ORD_M, work->mem_wfilter);
    zeroF(L_WINDOW, work->sigdec_past);
  }
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder
  Return value:
    None
   -------------------------------------------------------------------*/
void
lowband_encode(
  const Float sigin[],          /* (i): Input 5-ms signal                     */
  unsigned char code0[],        /* (o): Core-layer bitstream (multiplexed)    */
  unsigned char code1[],        /* (o): LB enh. layer bitstream (multiplexed) */
  void *ptr                     /* (i/o): Pointer to work space               */
  )
{

  Float   r[ORD_M + 1];

  lowband_encode_work *work = (lowband_encode_work *) ptr;

  Short   i, j, norm, stable, offset, sigtmp, codtmp, *sigdec;
  Float   alpha, tmp;

  /* G.711 decoding function */
  Short   (*convertLin_Log)(Short, Short *, Short *, Short *);
  Short   exp[L_FRAME_NB], excode[L_FRAME_NB];

  Float  *rc = work->mem_rc;  /* Reflection coefficients              */
  Float  *A = work->mem_A;    /* A0(z) with bandwidth-expansion       */

  Short   sigdec_past_i[L_WINDOW];

  movFS(L_WINDOW, work->sigdec_past, sigdec_past_i);

  /* Pointer initialization */
  sigdec = sigdec_past_i + L_FRAME_NB;

  /* LP analysis and filter weighting */
  norm = AutocorrNS(work->sigdec_past, r);

  Levinson(r, rc, &stable, ORD_M, A);

  if (norm >= MAX_NORM) {
    for (i = 1; i <= ORD_M; ++i) {
      A[i] /= Pow(2.0f, (Float) (i + norm - MAX_NORM));
    }
  }
  else {
    if (rc[0] > 0.9844f) {
      alpha = 0.92f * 16.0f * (1.047f - rc[0]);
      Weight_a(A, A, alpha, ORD_M);
    }
    else {
      Weight_a(A, A, GAMMA1f, ORD_M);
    }
  }

  /* Update of the past signal */
  movF(L_FRAME_NB, work->sigdec_past + L_FRAME_NB, work->sigdec_past);

  if (work->law == G711ALAW) {
    convertLin_Log = convertLin_ALaw;
    offset = ALAW_OFFSET;
  }
  else {                        /* work->law == G711ULAW */
    convertLin_Log = convertLin_MuLaw;
    offset = 0;
  }

  for (i = 0; i < L_FRAME_NB; i++) {
    /* Calculation of the shaped sample */
    tmp = A[0] * (sigin[i] + (Float) offset);
    for (j = 0; j < ORD_M; j++) {
      tmp += A[j + 1] * work->mem_wfilter[j];
    }
    tmp = (tmp > (Float) MAX_16) ? (Float) MAX_16 : tmp;
    tmp = (tmp < (Float) MIN_16) ? (Float) MIN_16 : tmp;
    sigtmp = (Short) Floor(tmp);

    if ((work->law == G711ALAW) &&
        (norm >= MAX_NORM) &&
        (sigtmp >= ALAW_OFFSET - ALAW_DEADZONE) &&
        (sigtmp <= ALAW_OFFSET + ALAW_DEADZONE)) {
      codtmp = 0xD5;
      sigdec[i] = 8;            /* reduce G711 cracles */
      exp[i] = 0;

      excode[i] = 7;
      if (sigtmp < 2) {
        excode[i] = 0;
      }
      else if (sigtmp < 16) {
        excode[i] = sigtmp >> 1;
      }
    }
    else {
      if ((work->law == G711ULAW) &&
          (norm >= MAX_NORM) &&
          (sigtmp >= -MULAW_DEADZONE) && (sigtmp <= MULAW_DEADZONE)) {
        codtmp = 0xFF;
        sigdec[i] = 0;
        exp[i] = 0;

        excode[i] = 3 << 1;
        if (sigtmp < -1) {
          excode[i] = 0;
        }                       /* 0xFF (R1=0) with R2a ext. 0 and 1 will replace 0x7F with ext. 3 and 2 */
        else if (sigtmp < 0) {
          excode[i] = 1 << 1;
        }
        else if (sigtmp < 2) {
          excode[i] = 2 << 1;
        }
      }
      else {
        codtmp = (*convertLin_Log) (sigtmp, &excode[i], &sigdec[i], &exp[i]);
      }
    }

    code0[i] = (unsigned char)(codtmp & 0x00FF);
    sigdec[i] -= offset;

    /* Update the noise-shaping filter memory */
    for (j = ORD_M - 1; j > 0; j--) {
      work->mem_wfilter[j] = work->mem_wfilter[j - 1];
    }
    work->mem_wfilter[0] = sigin[i] - sigdec[i];
  }

  movSF(L_FRAME_NB, sigdec, work->sigdec_past + L_FRAME_NB);

  if (code1 != NULL) {          /* Layer 1 encoding */
    lowband_lbe_mux(excode, exp, code1);
  }
}

/* Lower-band enhancement layer encoding */
#define LBE_NUM_BITS    80      /* no. of bits allocated to LBE */
#define MAX_EXP_VALUE   7       /* max. exponent value */
#define MAX_ENH_BITS    3       /* max. allowable bits per sample for LBE */
#define MAX_EXP_POS     (MAX_EXP_VALUE + MAX_ENH_BITS)

static void
lowband_lbe_mux(
  Short * excode,
  Short * expi,
  unsigned char code1[])
{
  unsigned char *pcode1 = code1;
  Short   bit_pos;
  Short   i;
  Short   tmp1;
  Short   bit_alloc[L_FRAME_NB];

  /* Bit allocation */
  lbe_bitalloc(expi, bit_alloc);

  /* bits arrangement */
  bit_pos = 0;
  tmp1 = 0;
  for (i = 0; i < L_FRAME_NB; i++) {
    excode[i] >>= (MAX_ENH_BITS - bit_alloc[i]);

    tmp1 = (tmp1 << bit_alloc[i]) | excode[i];
    bit_pos += bit_alloc[i];

    if (bit_pos >= 8) {
      bit_pos -= 8;
      *pcode1 = (unsigned char)(tmp1 >> bit_pos);
      tmp1 -= (Short) (*pcode1 << bit_pos);
      pcode1++;
    }
  }

  return;
}

void
lbe_bitalloc(
  Short * expi,
  Short * bit_alloc)
{
  Short   bit_cnt;
  Short   bit_reservoir;
  Short   i, j, iexp;

  Short   arr_exp[MAX_EXP_POS][L_FRAME_NB];
  Short   cnt_exp[MAX_EXP_POS];

  Short   icnt;

  bit_reservoir = LBE_NUM_BITS;
  zeroS(MAX_EXP_POS, cnt_exp);
  zeroS(L_FRAME_NB, bit_alloc);

  /* count no. of samples corresponding to each exponent and store its index */
  for (i = 0; i < L_FRAME_NB; i++) {
    for (j = 0; j < MAX_ENH_BITS; j++) {
      iexp = expi[i] + j;
      icnt = cnt_exp[iexp];

      arr_exp[iexp][icnt] = i;  /* store index */
      cnt_exp[iexp]++;          /* count no. of exponents */
    }
  }

  /* compute bit allocation table for enhancement layer */
  for (iexp = MAX_EXP_POS - 1; iexp >= 0; iexp--) {
    if (cnt_exp[iexp] > bit_reservoir) {
      bit_cnt = bit_reservoir;
    }
    else {
      bit_cnt = cnt_exp[iexp];
    }

    for (j = 0; j < bit_cnt; j++) {
      bit_alloc[arr_exp[iexp][j]]++;
    }

    bit_reservoir -= bit_cnt;

    if (bit_reservoir == 0) {
      break;
    }
  }

  return;
}
