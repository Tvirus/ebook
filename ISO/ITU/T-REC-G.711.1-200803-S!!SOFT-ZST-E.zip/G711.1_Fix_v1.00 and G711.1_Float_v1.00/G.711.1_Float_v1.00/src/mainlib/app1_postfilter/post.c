/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post.c
 *  Function: Main routine that calls all post-processing subroutines
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "post_const.h"
#include "post.h"
#include "post_anasyn.h"
#include "post_gainfct.h"


/**
* Process of post processing (done per frame)
* Call sequently the different functions :
* 1. Analysis of the signal : postProc_Analysis()
* 2. Compute the Impulse Response of the post process filter : postProc_GainProcess() 
* 3. Synthesis of the output signal with a time OLS : postProc_Synthesis()
*/

void
postProc_Processing(
  Float   *bloc_in,       /* IN:  Table of the new samples */
  Float   *bloc_out,      /* OUT: Table of the filtered samples */
  VAR_MEM *var_mem,       /* I/O: State structure including state variables */
  Short    postfilter_sw, /* IN:  Post processing ON/OFF switch */
  Short    anaflag,       /* IN:  Analysis flag */
  Float   *xl_nq          /* IN:  Speech buffer */
  )
{
  int           max_eq;

  int           i;

  if (postfilter_sw != 0) {     /* Postfilter option is ON */
    if (anaflag != 0) {
      postProc_Analysis(bloc_in, &(var_mem->var_anaSynth));

      postProc_GainProcess(var_mem->var_anaSynth.X,
                           &(var_mem->var_gain), &(var_mem->var_anaSynth));
    }
    else {
      movF(FRAME_LGTH_POSTPROC,
           bloc_in, &(var_mem->var_anaSynth.x[L_WIN - FRAME_LGTH_POSTPROC]));
    }
    postProc_Synthesis(bloc_out, var_mem->var_gain.h, &(var_mem->var_anaSynth));

    for (i = 0; i < FRAME_LGTH_POSTPROC; i++) {
      if (abs_f(bloc_out[i]) > 24) {
        max_eq = max_err_quant[Fnorme16(xl_nq[i])];
        bloc_out[i] = f_max(bloc_out[i], xl_nq[i] - max_eq);
        bloc_out[i] = f_min(bloc_out[i], xl_nq[i] + max_eq);
      }
    }
  }
}
