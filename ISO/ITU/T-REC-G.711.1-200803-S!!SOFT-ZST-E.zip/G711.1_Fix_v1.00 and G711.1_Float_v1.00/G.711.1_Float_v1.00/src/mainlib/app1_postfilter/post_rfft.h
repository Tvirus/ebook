/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_rfft.h
 *  header: real fft and ifft prototypes
 *------------------------------------------------------------------------
 */

#ifndef POST_RFFT_H
#define POST_RFFT_H

#include "floatutil.h"

extern const Short r[64];
extern const Float w_flt[16];

void rfft_64(Float *xw, Float *X);
void rsifft_64(Float *data);

#endif /* POST_RFFT_H */
