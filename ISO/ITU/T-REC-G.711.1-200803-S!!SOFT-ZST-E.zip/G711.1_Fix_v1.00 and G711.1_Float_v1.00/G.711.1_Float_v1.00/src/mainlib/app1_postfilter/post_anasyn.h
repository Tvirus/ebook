/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_anasyn.h
 *  header: Header of analysis/synthesis for post-processing
 *------------------------------------------------------------------------
 */

#ifndef POST_ANASYN_H
#define POST_ANASYN_H

#include "post_const.h"
#include "floatutil.h"

extern const Float  Hann_flt[L_WIN];
extern const Float  Hann_p6_flt[7];
extern const Float  Hann_p6m1_flt[7];

void   postProc_Init_anaSynth(VAR_ANASYNTH *var_anaSynth);

void   postProc_Analysis(const Float *bloc_in, VAR_ANASYNTH *var_anaSynth);
void   postProc_Synthesis(Float *bloc_out, const Float *filtre,
                          VAR_ANASYNTH *var_anaSynth);


Float postProc_Filter(const Float *filter, const Float *dataIn,
                         Short filt_length);

#endif /* POST_ANASYN_H */

