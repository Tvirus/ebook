/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_gainfct.h
 *  Header: Header of post-processing filter estimation
 *------------------------------------------------------------------------
 */

#ifndef POST_GAINFCT_H
#define POST_GAINFCT_H

extern const Float WinFilt_flt[L_FLT_DIV2+1];

void postProc_GainProcess(Float *X, VAR_GAIN *var_gain,
                          VAR_ANASYNTH *var_anasynth);

void postProc_InitGainProcess(VAR_GAIN *var_gain);

#endif /* POST_GAINFCT_H */
