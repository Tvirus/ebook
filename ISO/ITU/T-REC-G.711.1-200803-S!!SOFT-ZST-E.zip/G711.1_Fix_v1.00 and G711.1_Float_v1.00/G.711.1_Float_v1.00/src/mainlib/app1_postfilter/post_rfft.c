/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 * All rights reserved
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_rfft.c
 *  Function: 64-point real fft and ifft
 *------------------------------------------------------------------------
 */
#include "post_rfft.h"

#include "floatutil.h"

/**
 * FFT of a real signal (Split-radix - time decimation).
 * Output spectrum is saved among the following sequency :
 * [ Re(0) Re(1) ... Re(N/2) Re(N/2+1) Im(N/2) ... Im(1) ]
 */
void
rfft_64(
  Float * xw,               /* I/O: Signal to analyse with FFT */
  Float * X                 /* OUT: Coefficients of the FFT */
  )
{
  Short         i, k;
  Short         i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12;

  Float         xwi[64], Xi[64];
  Float         tmpr, tmpi;

  for (i = 0; i < 64; i++) {
    X[i] = xw[r[i]];
  }

  for (i = 0; i < 64; i += 2) {
    i1 = i + 1;

    xw[i] = X[i] + X[i1];
    xw[i1] = X[i] - X[i1];
  }

  for (i = 0; i < 64; i += 4) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;

    X[i] = xw[i] + xw[i2];
    X[i2] = xw[i] - xw[i2];
    X[i1] = xw[i1];
    Xi[i1] = -xw[i3];
  }

  for (i = 0; i < 64; i += 8) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;
    i4 = i + 4;
    i5 = i + 5;
    i6 = i + 6;

    xw[i] = X[i] + X[i4];
    xw[i4] = X[i] - X[i4];
    xw[i2] = X[i2];
    xwi[i2] = -X[i6];

    tmpr = w_flt[8] * (X[i5] + Xi[i5]);
    tmpi = w_flt[8] * (Xi[i5] - X[i5]);
    xw[i1] = X[i1] + tmpr;
    xwi[i1] = Xi[i1] + tmpi;
    xw[i3] = X[i1] - tmpr;
    xwi[i3] = tmpi - Xi[i1];
  }

  for (i = 0; i < 64; i += 16) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;
    i4 = i + 4;
    i5 = i + 5;
    i6 = i + 6;
    i7 = i + 7;
    i8 = i + 8;
    i9 = i + 9;
    i10 = i + 10;
    i11 = i + 11;
    i12 = i + 12;

    X[i] = xw[i] + xw[i8];
    X[i8] = xw[i] - xw[i8];
    X[i4] = xw[i4];
    Xi[i4] = -xw[i12];

    tmpr = w_flt[8] * (xw[i10] + xwi[i10]);
    tmpi = w_flt[8] * (xwi[i10] - xw[i10]);
    X[i2] = xw[i2] + tmpr;
    Xi[i2] = xwi[i2] + tmpi;
    X[i6] = xw[i2] - tmpr;
    Xi[i6] = tmpi - xwi[i2];

    tmpr = w_flt[12] * xw[i9] + w_flt[4] * xwi[i9];
    tmpi = w_flt[12] * xwi[i9] - w_flt[4] * xw[i9];
    X[i1] = xw[i1] + tmpr;
    Xi[i1] = xwi[i1] + tmpi;
    X[i7] = xw[i1] - tmpr;
    Xi[i7] = tmpi - xwi[i1];

    tmpr = w_flt[4] * xw[i11] + w_flt[12] * xwi[i11];
    tmpi = w_flt[4] * xwi[i11] - w_flt[12] * xw[i11];
    X[i3] = xw[i3] + tmpr;
    Xi[i3] = xwi[i3] + tmpi;
    X[i5] = xw[i3] - tmpr;
    Xi[i5] = tmpi - xwi[i3];
  }

  for (i = 0; i < 64; i += 32) {
    i4 = i + 16;
    i2 = i + 8;
    i3 = i + 24;

    xw[i] = X[i] + X[i4];
    xw[i4] = X[i] - X[i4];
    xw[i2] = X[i2];
    xwi[i2] = -X[i3];

    for (k = 1; k < 8; k++) {
      i1 = i + k;
      i2 = i1 + 16;
      i3 = i4 - k;
      i5 = k + k;
      i6 = 16 - i5;

      tmpr = w_flt[i6] * X[i2] + w_flt[i5] * Xi[i2];
      tmpi = w_flt[i6] * Xi[i2] - w_flt[i5] * X[i2];
      xw[i1] = X[i1] + tmpr;
      xwi[i1] = Xi[i1] + tmpi;
      xw[i3] = X[i1] - tmpr;
      xwi[i3] = tmpi - Xi[i1];
    }
  }

  X[0] = xw[0] + xw[32];
  X[32] = xw[0] - xw[32];
  X[16] = xw[16];
  Xi[16] = -xw[48];

  for (k = 1; k < 16; k++) {
    i2 = k + 32;
    i3 = 32 - k;
    i6 = 16 - k;

    tmpr = w_flt[i6] * xw[i2] + w_flt[k] * xwi[i2];
    tmpi = w_flt[i6] * xwi[i2] - w_flt[k] * xw[i2];
    X[k] = xw[k] + tmpr;
    Xi[k] = xwi[k] + tmpi;
    X[i3] = xw[k] - tmpr;
    Xi[i3] = tmpi - xwi[k];
  }

  for (i = 33; i < 64; i++) {
    X[i] = Xi[64 - i];
  }

  return;
}


/**
 * IFFT of an hermitia, spectrum (Split-radix - time decimation).
 * The input spectrum should be given among the following sequency :
 * [ Re(0) Re(1) ... Re(N/2) Re(N/2+1) Im(N/2) ... Im(1) ] 
 */
/*spectrum real and symmetrical*/
void
rsifft_64(
  Float * W)
{
/**< I/O: FFT [0..32] only real -> sig[0..31] */
  Short         i, k;
  Short         i1, i2, i3, i4, i5, i6, i7, i8, i9, i10, i11, i12;

  Float         X[64], xw[64], Xi[64], xwi[64];
  Float         tmpr, tmpi;

  for (i = 0; i < 33; i++) {
    xw[i] = W[i];
  }
  for (i = 33; i < 64; i++) {
    xw[i] = W[64 - i];
  }

  for (i = 0; i < 64; i++) {
    X[i] = xw[r[i]];
  }

  for (i = 0; i < 64; i += 2) {
    i1 = i + 1;

    xw[i] = (X[i] + X[i1]);
    xw[i1] = (X[i] - X[i1]);
  }

  for (i = 0; i < 64; i += 4) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;

    X[i] = (xw[i] + xw[i2]);
    X[i2] = (xw[i] - xw[i2]);
    X[i1] = xw[i1];
    Xi[i1] = xw[i3];
  }

  for (i = 0; i < 64; i += 8) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;
    i4 = i + 4;
    i5 = i + 5;
    i6 = i + 6;

    xw[i] = (X[i] + X[i4]);
    xw[i4] = (X[i] - X[i4]);
    xw[i2] = X[i2];
    xwi[i2] = X[i6];

    tmpr = w_flt[8] * (X[i5] - Xi[i5]);
    tmpi = w_flt[8] * (Xi[i5] + X[i5]);
    xw[i1] = (X[i1] + tmpr);
    xwi[i1] = (Xi[i1] + tmpi);
    xw[i3] = (X[i1] - tmpr);
    xwi[i3] = (tmpi - Xi[i1]);
  }

  for (i = 0; i < 64; i += 16) {
    i1 = i + 1;
    i2 = i + 2;
    i3 = i + 3;
    i4 = i + 4;
    i5 = i + 5;
    i6 = i + 6;
    i7 = i + 7;
    i8 = i + 8;
    i9 = i + 9;
    i10 = i + 10;
    i11 = i + 11;
    i12 = i + 12;

    X[i] = (xw[i] + xw[i8]);
    X[i8] = (xw[i] - xw[i8]);
    X[i4] = xw[i4];
    Xi[i4] = xw[i12];

    tmpr = w_flt[8] * (xw[i10] - xwi[i10]);
    tmpi = w_flt[8] * (xwi[i10] + xw[i10]);
    X[i2] = (xw[i2] + tmpr);
    Xi[i2] = (xwi[i2] + tmpi);
    X[i6] = (xw[i2] - tmpr);
    Xi[i6] = (tmpi - xwi[i2]);

    tmpr = w_flt[12] * xw[i9] - w_flt[4] * xwi[i9];
    tmpi = w_flt[12] * xwi[i9] + w_flt[4] * xw[i9];
    X[i1] = (xw[i1] + tmpr);
    Xi[i1] = (xwi[i1] + tmpi);
    X[i7] = (xw[i1] - tmpr);
    Xi[i7] = (tmpi - xwi[i1]);

    tmpr = w_flt[4] * xw[i11] - w_flt[12] * xwi[i11];
    tmpi = w_flt[4] * xwi[i11] + w_flt[12] * xw[i11];
    X[i3] = (xw[i3] + tmpr);
    Xi[i3] = (xwi[i3] + tmpi);
    X[i5] = (xw[i3] - tmpr);
    Xi[i5] = (tmpi - xwi[i3]);

  }

  xw[0] = (X[0] + X[16]);
  xw[16] = (X[0] - X[16]);
  xw[8] = X[8];

  for (k = 1; k < 8; k++) {
    i2 = k + 16;
    i3 = 16 - k;
    i5 = k + k;
    i6 = 16 - i5;

    tmpr = w_flt[i6] * X[i2] - w_flt[i5] * Xi[i2];
    xw[k] = (X[k] + tmpr);
    xw[i3] = (X[k] - tmpr);
  }

  xw[32] = (X[32] + X[48]);
  xw[48] = (X[32] - X[48]);
  xw[40] = X[40];
  xwi[40] = X[56];

  for (k = 1; k < 8; k++) {
    i1 = 32 + k;
    i2 = i1 + 16;
    i3 = 48 - k;
    i5 = k + k;
    i6 = 16 - i5;

    tmpr = w_flt[i6] * X[i2] - w_flt[i5] * Xi[i2];
    tmpi = w_flt[i6] * Xi[i2] + w_flt[i5] * X[i2];
    xw[i1] = (X[i1] + tmpr);
    xwi[i1] = (Xi[i1] + tmpi);
    xw[i3] = (X[i1] - tmpr);
    xwi[i3] = (tmpi - Xi[i1]);
  }

  W[0] = xw[0] + xw[32];
  W[32] = xw[0] - xw[32];
  W[16] = xw[16];

  for (k = 1; k < 16; k++) {
    i2 = k + 32;
    i3 = 32 - k;
    i6 = 16 - k;

    tmpr = w_flt[i6] * xw[i2] - w_flt[k] * xwi[i2];
    W[k] = xw[k] + tmpr;
    W[i3] = xw[k] - tmpr;
  }

  for (i = 0; i < 64; i++) {
    W[i] = W[i] / 64;
  }

  return;
}
