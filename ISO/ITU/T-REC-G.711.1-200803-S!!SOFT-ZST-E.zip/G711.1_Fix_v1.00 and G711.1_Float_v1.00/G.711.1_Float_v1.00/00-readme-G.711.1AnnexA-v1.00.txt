===============================================================================
   ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
   Copyright (c) 2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
   All rights reserved
  
   Version: 1.00
   Revision Date: 10 October 2008
===============================================================================

These files represent the ITU-T G.711.1 Annex A, floating-point implementation.
All code is written in ANSI-C.  The coder is implemented as two separate programs:

        encoder [-options] <law> <infile> <codefile>
        decoder [-options] <law> -mode <modenum> <codefile> <outfile> 
	
The folder "test_vector.flt" contains a set of test vectors to verify the proper
compilation of the reference software.

                            FILE FORMATS:
                            =============

The file format of the supplied binary data is 16-bit binary data which is
read and written in 16 bit little-endian words.
The data is therefore platform DEPENDENT.

The bitstream follows the ITU-T G.192 format. For every 5-ms input speech frame,
the bitstream contains the following data:

	Word16 SyncWord
	Word16 DataLen
	Word16 1st Databit
	Word16 2nd DataBit
	.
	.
	.
	Word16 Nth DataBit

Each bit is presented as follows: Bit 0 = 0x007f, Bit 1 = 0x0081.

The SyncWord from the encoder is always 0x6b21. The SyncWord 0x6b20, on decoder side, 
indicates that the current frame was received in error (frame erasure).

The DataLen parameter gives the number of speech data bits in the frame. 


			INSTALLING THE SOFTWARE
			=======================

Installing the software on the PC:

The package includes Makefile for gcc and makefile.cl for Visual C++. 
The makefiles can be used as follows:

Linux/Cygwin: make
Visual C++  : nmake -f makefile.cl

The codec has been successfully compiled on Linux/Cygwin using gcc
and Windows using Visual C++.

NOTE: Visual C++ command prompt should be used to compile with Visual C++ on Windows.


                       RUNNING THE SOFTWARE
                       ====================

The usage of the "encoder" program is as follows:

  encoder [-options] <law> <infile> <codefile>

  where:
    law        is the desired G.711 law (A or u).
    infile     is the name of the input file to be encoded.
    codefile   is the name of the bitstream file.

  Options:
    -mode #    is the desired encode mode (1, 2, 3, 4).
    -nb        indicates that input signal is sampled at 8 kHz.
    -quiet     quiet processing.
    -hardbit   outputs hardbit instead of G.192 softbit.

Encoding modes 1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.
By default, the encoder input is sampled at 16 kHz, and the encoding mode is 4 (R3).


The usage of the "decoder" program is as follows:

  decoder [-options] <law> -mode <modenum> <codefile> <outfile>

  where:
    law        is the desired G.711 law (A or u)
    modenum    is the mode of the bitstream file(1, 2, 3, 4).
    codefile   is the name of the bitstream file.
    outfile    is the name of the decoded output file.

  Options:
    -quiet     quiet processing.
    -r1pf      enables R1 postfilter. (valid for R1 only)
    -hardbit   specifies hardbit instead of G.192 softbit.

Decoding modes 1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.
The decoder output is sampled at 8 kHz for modes 1 (R1) and 2 (R2a),
and at 16 kHz for modes 3 (R2b) and 4 (R3).


If you run the software on Windows, you can make a set of test vectors using:

Cygwin    : make proc
Visual C++: nmake -f makefile.cl proc

or

test proc

easily. The test vectors are stored in folder "out".

NOTE: This batch file is not available on non-Windows platforms, because the tools
in folder "tools" are Windows executable files.

NOTE: The test vectors were obtained by using the executable compiled with Visual
C++. Since this simulation software is decribed in floating-point, processed files
might not be identical to the test vectors depending on the compiler or the platform.

--end - 2008-10-10