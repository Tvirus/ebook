/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "dsputil.h"
#include "mathtool.h"

/* Table for square-root operation, SqrtI31() */
const Word16 table_sqrt_w[49] = {
  16384, 16888, 17378, 17854,
  18318, 18770, 19212, 19644,
  20066, 20480, 20886, 21283,
  21674, 22058, 22435, 22806,
  23170, 23530, 23884, 24232,
  24576, 24915, 25249, 25580,
  25905, 26227, 26545, 26859,
  27170, 27477, 27780, 28081,
  28378, 28672, 28963, 29251,
  29537, 29819, 30099, 30377,
  30652, 30924, 31194, 31462,
  31727, 31991, 32252, 32511,
  32767
};

/* Table for inverse square-root operation, Isqrt_n() */
Word16 table_isqrt[49] =
{ /* Table is negated to correctly represent 1.0 i.e. -32768 first element */
   -32768,-31790,-30894,-30070,-29309,-28602,-27945,-27330,-26755,-26214,
   -25705,-25225,-24770,-24339,-23930,-23541,-23170,-22817,-22479,-22155,
   -21845,-21548,-21263,-20988,-20724,-20470,-20225,-19988,-19760,-19539,
   -19326,-19119,-18919,-18725,-18536,-18354,-18176,-18004,-17837,-17674,
   -17515,-17361,-17211,-17064,-16921,-16782,-16646,-16514,-16384
};
