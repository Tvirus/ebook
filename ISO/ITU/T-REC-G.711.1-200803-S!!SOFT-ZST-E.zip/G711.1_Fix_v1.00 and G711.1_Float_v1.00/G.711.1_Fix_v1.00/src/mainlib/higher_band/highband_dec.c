/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: highband_dec.h
 *  Function: Layer 2 (Higher-band) decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"

#include "fec_highband.h"

#define DECODER_OK  2
#define DECODER_NG  3

/*----------------------------------------------------------------
  Function:
    Higher-band decoder constructor
  Return value
    Pointer to work space
  ----------------------------------------------------------------*/
void* highband_decode_const(void)
{
  VQD_State  *dec_st=NULL;

  dec_st = (VQD_State *)malloc( sizeof(VQD_State) );
  if (dec_st == NULL) return NULL;

  highband_decode_reset( (void *)dec_st );

  return (void *)dec_st;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void  highband_decode_dest(
  void *work        /* (i): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;

  if (dec_st != NULL)  free( dec_st );
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder reset
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int   highband_decode_reset(
  void *work        /* (i/o): Pointer to work space */
) {
  VQD_State  *dec_st=(VQD_State *)work;
  int  i;

  if (dec_st != NULL) {
    FOR ( i=0; i<L_FRAME_NB; i++ ) {
      dec_st->sPrev[i] = 0;    move16();
    }
    FOR ( i=0; i<L_FRAME_NB; i++ ) {
      dec_st->sCurSave[i] = 0; move16();
    }
    dec_st->sSpectrumQ_pre = 0; move16();
    dec_st->reset = 1;

    FOR ( i=0; i<HB_FEC_BUF_LEN; i++) {
      dec_st->hbfec_st.hb_buf[i] = 0; move16();
    }
    dec_st->hbfec_st.lb_t0 = 0;            move16();
    dec_st->hbfec_st.first_loss_frame = 1; move16();
    dec_st->hbfec_st.hb_t0 = 0;            move16();
    dec_st->hbfec_st.att_weight = 32767;   move16();
    dec_st->hbfec_st.high_cor = 0;         move16();
    dec_st->hbfec_st.pre_bfi = 0;          move16();
  }
  return DECODER_OK;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int   highband_decode(
  const unsigned char *bitstream, /* (i): Input bitstream                */
  int                 erasure,    /* (i): FER flag, 0:No FER/1:FER       */
  Word16              sBufout[],  /* (o): Output higher-band signal (Q0) */
  void                *work       /* (i/o): Pointer to work space        */
) {
  VQD_State *dec_st=(VQD_State *)work;
  int      i;
  INDEX    index;                 /* Gain and VQ indices              */
  Word16   sSpectrum[L_FRAME_NB]; /* MDCT coefficients, Q(sQspectrum) */
  Word16   sSpectrumQ;            /* Q of sSpectrum[]                 */
  Word16   sOut[L_FRAME_NB];      /* Decoded signal, Q0               */

  IF (erasure == 0)    /* No FER */
  {
    /* deMUX of indices */
    demux_bitstream(&index, (unsigned char *)bitstream);

    /* De-quantize MDCT coefficients */
    VQdecode_spectrum(
        index.wvq,      /* (i) */
        index.pow,      /* (i) */
        &sSpectrum[4],  /* (o) Q(sQspectrum) */
        &sSpectrumQ     /* (o) */
    );

    /* Windowing */
    sSpectrum[0] = 0; move16();
    sSpectrum[1] = 0; move16();
    sSpectrum[2] = 0; move16();
    sSpectrum[3] = 0; move16();
    sSpectrum[4] = mult_r( sSpectrum[4],  4277 ); /* *= sin(   PI/24) */
    sSpectrum[5] = mult_r( sSpectrum[5], 12540 ); /* *= sin( 3*PI/24) */
    sSpectrum[6] = mult_r( sSpectrum[6], 19948 ); /* *= sin( 5*PI/24) */
    sSpectrum[7] = mult_r( sSpectrum[7], 25997 ); /* *= sin( 7*PI/24) */
    sSpectrum[8] = mult_r( sSpectrum[8], 30274 ); /* *= sin( 9*PI/24) */
    sSpectrum[9] = mult_r( sSpectrum[9], 32488 ); /* *= sin(11*PI/24) */
    move16(); move16(); move16(); move16(); move16(); move16();

    FOR ( i=0; i<L_FRAME_NB; i++ ) {
      sSpectrum[i] = shr (sSpectrum[i], 1); move16();
    }
    sSpectrumQ = sub (sSpectrumQ, 1);
  }

  /* iMDCT */
  inv_mdct( sOut, sSpectrum, dec_st->sPrev, sSpectrumQ,
            &dec_st->sSpectrumQ_pre,
            (Word16)erasure, dec_st->sCurSave,
            &dec_st->hbfec_st  /* higher-band buffer for FERC */
          );

  /* Mute at first frame after reset */
  IF (dec_st->reset != 0)
  {
    zero16(L_FRAME_NB, sOut);
    dec_st->reset = 0; move16();
  }

  /* Update higher-band FERC buffer */
  IF (erasure == 0) {
    update_hb_buf(dec_st->hbfec_st.hb_buf, sOut);
  }

  /* Copy decoded signal to output buffer */
  mov16(L_FRAME_NB, sOut, sBufout);

  return DECODER_OK;
}
