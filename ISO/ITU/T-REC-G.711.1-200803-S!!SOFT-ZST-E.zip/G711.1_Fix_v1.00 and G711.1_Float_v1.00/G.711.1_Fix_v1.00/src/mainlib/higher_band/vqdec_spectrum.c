/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "g711wbe_common.h"
#include "highband.h"

static Word16 reconstruct_cs(Word16, Word16, Word16, Word16, Word16);

/*----------------------------------------------------------------
  Function:
    Reconstructs MDCT coefficients.
  Return value
    0
  ----------------------------------------------------------------*/
int VQdecode_spectrum(
  Word16  index_wvq[],  /* (i): VQ indices                                 */
  Word16  index_pow,    /* (i): Gain index                                 */
  Word16  psSpectrum[], /* (o): Reconstruced coefficients, Q(*psSpectrumQ) */
  Word16  *psSpectrumQ  /* (o): Q of sSpectrum[]                           */
)
{
  int     i_div, i_smp;
  int     index0, index1;
  Word16  pol0, pol1;
  Word16  sDec0, sDec1, sDec2, sDec3, sDec4, sDec5;
  Word16  sGain;
  Word16  sExpGain;
  Word16  stmp;

  const Word16  *psCodev0, *psCodev1;

  /* Decode gain */
  sGain = mulawinv( index_pow );  /* Q0 */

  sExpGain = norm_s( sGain );
  sGain = shl( sGain, sExpGain );         /*Q(sExpGain)*/
  sGain = mult_r( sGain, DE_SCALE_FACT ); /*Q(3+sExpGain)=Q(sExpGain+18-15)*/

  i_smp = N_DIV-1;
  FOR (i_div = 0; i_div < N_DIV; i_div++)
  {
    /* VQ shape indices */
    index0 = s_and (index_wvq[i_div], BITMASK_SHAPE);
    index1 = s_and (index_wvq[i_div+N_DIV], BITMASK_SHAPE);

    /* Sign */
    /* pol0 = 1 - 2 * ((index_wvq[i_div]>>MAXBIT_SHAPE) & 0x1) */
    stmp = sub( 1, s_and( shr( index_wvq[i_div], MAXBIT_SHAPE-1 ), 0x2 ) );
    pol0 = shl( stmp, 14 );

    /* pol1 = 1 - 2 * ((index_wvq[i_div + N_DIV]>>MAXBIT_SHAPE) & 0x1) */
    stmp = sub( 1, s_and( shr( index_wvq[i_div+N_DIV], MAXBIT_SHAPE-1 ), 0x2 ) );
    pol1 = shl( stmp, 14 );

    /* Extract code-vectors from codebooks */
    psCodev0 = gsCodebook_0ch[index0]; a_mac(); move16();  /* for addressing */
    psCodev1 = gsCodebook_1ch[index1]; a_mac(); move16();  /* for addressing */

    /* Reconst CS-subvectors                      */
    /* Gain mulitiplication and inverse weighting */
    sDec0 = reconstruct_cs( pol0, pol1, psCodev0[0], psCodev1[0], sGain );

    sDec1 = reconstruct_cs( pol0, pol1, psCodev0[1], psCodev1[1], sGain );

    sDec2 = reconstruct_cs( pol0, pol1, psCodev0[2], psCodev1[2], sGain );
    sDec2 = mult_r( 24576, sDec2 ); /* inverse weighting */

    sDec3 = reconstruct_cs( pol0, pol1, psCodev0[3], psCodev1[3], sGain );
    sDec3 = mult_r( 19661, sDec3 ); /* inverse weighting */

    sDec4 = reconstruct_cs( pol0, pol1, psCodev0[4], psCodev1[4], sGain );
    sDec4 = shr( sDec4, 1 );        /* inverse weighting */

    sDec5 = reconstruct_cs( pol0, pol1, psCodev0[5], psCodev1[5], sGain );

    /* Reverse interleaving */
    psSpectrum[i_smp+30] = sDec0; move16();
    psSpectrum[i_smp+24] = sDec1; move16();
    psSpectrum[i_smp+18] = sDec2; move16();
    psSpectrum[i_smp+12] = sDec3; move16();
    psSpectrum[i_smp+6]  = sDec4; move16();
    psSpectrum[i_smp]    = sDec5; move16();

    i_smp --;
  }

  *psSpectrumQ = sExpGain;  move16();

  return 0;
}

static Word16 reconstruct_cs(
  Word16  p0,   /* (i): Sign (polarity) for channel 0, Q14   */
  Word16  p1,   /* (i): Sign (polarity) for channel 1, Q14   */
  Word16  cv0,  /* (i): Code-vector value for channel 0, Q12 */
  Word16  cv1,  /* (i): Code-vector value for channel 1, Q12 */
  Word16  gain  /* (i): Gain, Q(3+sExpGain)                  */
) {
  Word32  lAcc;

  /* ( pol0 * c0 + pol1 * cv1[] ) * 0.5 */
  lAcc = L_mult( p0, cv0 );       /* Q27 = Q(14+12+1) */
  lAcc = L_mac( lAcc, p1, cv1 );  /* Q27 */

  return  mult( gain, extract_h( lAcc ) );
                                  /* Q(sExpGain) = Q(3+sExpGain+27-16-15)*0.5 */
}
