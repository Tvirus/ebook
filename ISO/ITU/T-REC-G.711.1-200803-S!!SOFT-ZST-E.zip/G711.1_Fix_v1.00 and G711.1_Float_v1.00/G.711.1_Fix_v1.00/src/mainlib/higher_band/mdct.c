/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: 80-point MDCT
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "defines_mdct.h"
#include "cfft.h"
#include "mdct.h"

#include "fec_highband.h"

/*---------------------------------------------------------------------------*
 * mdct()                                                                    *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~                                                *
 * Compute MDCT                                                              *
 *                                                                           *
 * Details of the MDCT computation algorithm implemented here:               *
 *                                                                           *
 * - The signal x(n) is divided into blocks of N successive samples          *
 *   with N=80 (with 50% overlap between blocks)                             * 
 *                                                                           *
 * - The samples x(n) are windowed to obtain                                 *
 *                                                                           *
 *                            yn = x(n).h(N-1-n)                             *
 *                                                                           *
 *   where h(N-1-n) is the following weighting law:                          *
 *                                                                           *
 *        h(N-1-n) = sqrt(2)/80 * sin( pi/N * (n+0.5) ), n=0...N-1           *
 *                                                                           *
 *   The window h(n) is symmetric,                                           *
 *   i.e. h(N-1-n) = h(n), n=0...N-1                                         *
 *                                                                           *
 * - The discrete modified discrete cosine transform (MDCT) of blocks of     *
 *   x(n) is calculated using the even order transform                       *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( 2n/(4N).(2n+1).(4k+1)+(4k+1).pi/4)               *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 *  In the equation above, the cosine operand can be written:                *
 *                                                                           *
 *    2pi/(4N).(2n+1).(2(2k)+1)+(2(2k)+1).pi/4                               *
 *     = (pi/(N/2).(n+0.5) + pi/4) . ((2k)+0.5)                              *
 *     = pi/(N/2).(n+0.5+N/4).((2k)+0.5)                                     *
 *                                                                           *
 *  Therefore, the MDCT can be also written as:                              *
 *                                                                           *
 *                                                                           *
 *           N-1                                                             *
 *          -----                                                            *
 *          \                                                                *
 *   Y2k =   |      yn.cos( pi/(N/2).(n+0.5+N/4).((2k)+0.5) )                *
 *          /                                                                *
 *          -----                                                            *
 *          n=0                                                              *
 *                                                                           *
 *     for k=0...N/2-1                                                       *
 *                                                                           *
 * IMPORTANT NOTE (to obtain odd order coefficients YN-1-2k through Y2k):    *
 * YN-k = -Yk-1 for k=0...N-1                                                *
 *                                                                           *
 * - The even order coefficients Y2k are calculated in the form of an        *
 *   invertible complex transform as follows:                                *
 *                                                                           *
 *    Y2k+N/4 + jY2k =                                                       *
 *                  N/4-1                                                    *
 *                 ------                                                    *
 *     k+1    -1   \                                          (4k+1)(4n+1)   *
 * (-1)   . W8  .   |     ((y'n-y''n+N/4)+j(y''n+y'n+N/4)).W4N           ,   *
 *                 /                                                         *
 *                 ------                                                    *
 *                  n=0                                                      *
 *   for k=0...N/4-1                                                         *
 *                                                                           *
 * with                                                                      *
 *                                                                           *
 *    y'n  = x2n.h2n                                                         *
 *    y''n = xN-2n-1.hN-2n-1                                                 *
 *    W4N  = cos(2pi/4N)+j.sin(2pi/4N)                                       *
 *                                                                           *
 * - The invertible complex transform is calculated on the basis on the      *
 *   the following auxiliary calculation equation:                           *
 *                                                                           *
 *                                N/4-1                                      *
 *                                -----                                      *
 *            k+1    -1     4k+1  \            n      nk                     *
 *   zk = (-1)   . W8  . W4N    .  |     (zn.WN ).WN/4                       *
 *                                /                                          *
 *                                -----                                      *
 *                                 n=0                                       *
 * where                                                                     *
 *                                                                           *
 *    zn = (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n), for n=0...N/4-1             *
 *                                                                           *
 * This fast MDCT algorithm is also described in:                            *
 * "A fast algorithm for the implementation of Filter Banks based on Time    *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212  *
 *                                                                           *
 * Remark about main notations (mapping of notations):                       *
 *                                                                           *
 *   Details above          |   C code           |    Text of G.711WB        *
 *  ------------------------+--------------------+------------------------   *
 *     x(n)                 |     xin[n]         |     sHB(n)                *
 *     Y2k                  |     ykr[k]         |     SHB(k)                *
 *     s(n)                 | xin[n]<<norm_shift |  sHB(n) * 2^etaTDAC1HB    *
 *     h(N-1-n)* 80         |     hTDAC[n]       |       wTDAC(n)            *
 *                                                                           * 
 *---------------------------------------------------------------------------*/
void mdct(
  Word16 * mem,        /* (i): old input samples    */
  Word16 * input,      /* (i): input samples        */
  Word16 * ykr,        /* (o): MDCT coefficients    */
  Word16 * norm_shift  /* (i): normalization factor */
)
{
  Word32   ACC0;               /* ACC */

  Word16   xin[MDCT_L_WIN];
  Word16   ycr[MDCT_L_WIN4];
  Word16   yci[MDCT_L_WIN4];

  const Word16 *ptr_h1;        /* pointer on window */
  const Word16 *ptr_h2;        /* pointer on window */
  Word16   *ptr_x1;            /* pointer on input samples */
  Word16   *ptr_x2;            /* pointer on input samples */
  Word16   *ptr_ycr;           /* pointer on ycr */
  Word16   *ptr_yci;           /* pointer on yci */

  Word16   k;
  Word16   i;
  Word16   tmp16_ycr;
  Word16   sign;               /* sign for FFT/IFFT */
  Word16   tmp16_norm_shift;

  /********************************************************************************/
  /* MDCT Computation                                                             */
  /********************************************************************************/

  /* form block of length N */
  FOR (i = 0; i < MDCT_L_WIN2; i++)
  {
    xin[i] = mem[i];
    move16();
  }
  
  FOR (i = 0; i < MDCT_L_WIN2; i++)
  {
    xin[i + MDCT_L_WIN2] = input[i];
    move16();
  }

  /* Step 1 --> Pre-scaling of input signal
                compute norm_shift               */
  *norm_shift = Exp16Array(MDCT_L_WIN , xin);
  FOR (i = 0; i < MDCT_L_WIN; i++)
  {
    xin[i] = shl(xin[i], *norm_shift);
  }

  /* Step 2 --> Calculate zn =  (y2n-yN/2-1-2n) + j(yN-1-2n+yN+2+2n) (complex terms), 
                          for n=0...N/4-1                                         */

  ptr_h1 = MDCT_h + MDCT_L_WIN2;  /* Middle of the window */
  ptr_x1 = xin + MDCT_L_WIN2;

  ptr_h2 = MDCT_h + MDCT_L_WIN; /* End of the window */
  ptr_x2 = xin + MDCT_L_WIN;

  k = (Word16) 0;
  move16();

  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (i = 0; i < MDCT_L_WIN4; i++)
  {
    ACC0 = L_mult(MDCT_h[k], xin[k]);
    ACC0 = L_msu(ACC0, ptr_h1[sub(-1, k)], ptr_x1[sub(-1, k)]);
    *ptr_ycr++ = round(ACC0);
    move16();

    ACC0 = L_mult(ptr_h2[sub(-1, k)], ptr_x2[sub(-1, k)]);
    ACC0 = L_mac(ACC0, ptr_h1[k], ptr_x1[k]);
    *ptr_yci++ = round(ACC0);
    move16();

    k = add(k, 2);
  }

  /* Step 3 --> Calculate z'n = zn.WN^n, for n=0...N/4-1 */

  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (k = 0; k < MDCT_L_WIN4; k++)
  {
    tmp16_ycr = *ptr_ycr; move16();

    ACC0 = L_mult0(tmp16_ycr, MDCT_wcos[k]);
    ACC0 = L_msu0(ACC0, yci[k], MDCT_wsin[k]);
    *ptr_ycr++ = round(ACC0);
    move16();

    ACC0 = L_mult0(tmp16_ycr, MDCT_wsin[k]);
    ACC0 = L_mac0(ACC0, yci[k], MDCT_wcos[k]);
    *ptr_yci++ = round(ACC0);
    move16();
  }

  /* Step 3 --> Inverse FFT of size N/4: Z'k = FFT-1 z'n, for k=0...N/4-1 */

  sign = (Word16) - 1; move16();

  cfft(ycr, yci, sign);

  /* Step 4 --> Calculate Zk = 1/80 . ((-1)^k+1.W8^-1.W4N^(4k+1)) . Z'k
  
     Step 5 --> Rearranging results:
                     Y2k       = Im[Zk]
                     Y2(k+N/4) = Re[Zk]

     Since Y2(k+N/4) =-Y(N/2-1-2k), results are actually presented as follows:
                     Y2k       = Im[Zk]
                     YN/2-1-2k = -Re[Zk]                                             
       
     Steps 4 & 5 are integrated below in a single step */

  ptr_x1 = ykr;
  ptr_x2 = ykr + MDCT_L_WIN2 - 1;

  FOR (k = 0; k < MDCT_L_WIN4; k++)
  {
    tmp16_ycr = ycr[k]; move16();

    /* symetry of coeff k-1 and N-k */

    ACC0 = L_mult0(yci[k], MDCT_weti[k]);         /* weti in Q21 */
    ACC0 = L_msu0(ACC0, tmp16_ycr, MDCT_wetr[k]); /* wetr in Q21 */
    *ptr_x2-- = round(ACC0);
    move16();
    ptr_x2--;

    ACC0 = L_mult0(tmp16_ycr, MDCT_weti[k]);       /* weti in Q21 */
    ACC0 = L_mac0(ACC0, yci[k], MDCT_wetr[k]);     /* wetr in Q21 */
    *ptr_x1++ = round(ACC0);
    move16();
    ptr_x1++;
  }

  /* Step 6 --> Post-scaling of MDCT coefficient
                compute norm_shift               */
  tmp16_norm_shift = Exp16Array(MDCT_L_WIN2, ykr);
  FOR (i = 0; i < MDCT_L_WIN2; i++)
  {
    ykr[i] = shl(ykr[i], tmp16_norm_shift);
    move16();
  }
  
  /* compute overall normalization factor */
  *norm_shift = add(*norm_shift, tmp16_norm_shift);

  /* update memory */
  FOR (i = 0; i < MDCT_L_WIN2; i++)
  {
    mem[i] = input[i];
    move16();
  }

  return;
}                               /* END MDCT */


/*--------------------------------------------------------------------------*
 *  inv_mdct()                                                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute inverse MDCT and overlap-add                                    *
 * The underlying algorithm is described in                                 *
 * - "A fast algorithm for the implementation of Filter Banks based on Time *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212 *
 *                                                                          *
 * The inverse MDCT consists of:                                            *
 * - Permuting real and imaginary parts YN/4+2k, Y2k                        *
 *   of the transmitted MDCT spectrum                                       *
 * - Calculating the complex part of the forward MDCT, i.e. Re[Zk], Im[Zk]  *
 * - Permuting real and imaginary parts of this complex part                *
 * - Performing an overlap calculation to reconstruct samples               *
 *--------------------------------------------------------------------------*/
void inv_mdct(
  Word16 * xr,         /* (o):   output samples                     */
  Word16 * ykq,        /* (i):   MDCT coefficients                  */
  Word16 * ycim1,      /* (i):   previous MDCT memory               */
  Word16   norm_shift, /* (i):   norm_shift value defined by coder  */
  Word16 * norm_pre,   /* (i/o): norm_shift value of previous frame */
  Word16   loss_flag,  /* (i):   packet-loss flag                   */
  Word16 * cur_save,   /* (i/o): signal saving buffer               */
  HBFEC_State * st     /* (i/o): work space for HB FERC             */
)
{
  Word32   ACC0;

  Word16   ycr[MDCT_L_WIN4];
  Word16   yci[MDCT_L_WIN4];
  Word16   sig_cur[MDCT_L_WIN2];
  Word16   sig_next[MDCT_L_WIN2];

  Word16   *ptr_yci;
  Word16   *ptr_ycr;
  Word16   *ptr1;
  Word16   *ptr2;
  Word16   *ptr1_next;
  Word16   *ptr2_next;
  const Word16 *ptr_h;         /* Pointer on window */

  Word16   k,n;
  Word16   sign;               /* sign for FFT / IFFT */
  Word16   tmp16;

  Word32   ACC1;
  Word16   n1;

  Word16   *hb_buf=st->hb_buf;
  Word16   *ptr_imdct;
  Word16   n2;

  /* Higher-band frame erasure concealment (FERC) in time domain */
  IF (loss_flag != 0)
  {
    st->pre_bfi = 1; move16();
    IF (st->first_loss_frame)
    {
      st->hb_t0 = st->lb_t0; move16();
      IF (sub(cor_hb_fec(hb_buf, &st->hb_t0), 16056) >= 0)
      {
        st->high_cor = 1; move16();
      }
      ELSE
      {
        st->high_cor = 0; move16();
      }
    }
    IF (st->high_cor)
    {   /* HBFEC based on pitch repetition and attenuation */

      /* copy pitch for 2 HB frame */
      IF (st->first_loss_frame)
      {               
        FOR (k = 0; k < MDCT_L_WIN; k++)
        {
          hb_buf[MAXPIT + MDCT_L_WIN2 + k] = hb_buf[MAXPIT + MDCT_L_WIN2 + k - st->hb_t0]; move16();
        }              
      }
      ELSE
      {
        FOR (k = 0; k < MAXPIT + MDCT_L_WIN2; k++)
        {
          hb_buf[k] = hb_buf[k + MDCT_L_WIN2]; move16();
        }

        FOR (k = 0; k < MDCT_L_WIN; k++)
        {
          hb_buf[MAXPIT + MDCT_L_WIN2  + k] = hb_buf[MAXPIT + MDCT_L_WIN2 + k - st->hb_t0]; move16();
        }
      }
      
      n1 = sub(*norm_pre, 6);
      ptr_imdct = & hb_buf[MAXPIT + MDCT_L_WIN2];
      n2 = add(n1, 2);
      FOR (k = 0; k < MDCT_L_WIN2; k++)
      {
        /* look MDCT_h as Q15, then sqrt(2)*sin can be used as sin/sqrt(2) */
        cur_save[k] = mult_r(ptr_imdct[k], MDCT_h[k]); 
        cur_save[k] = shl(cur_save[k], n2); move16();
        move16();
      }
      
      IF (st->att_weight >= 6560)
      {
        ptr_h = MDCT_h + MDCT_L_WIN2;
        FOR (k = 0; k < MDCT_L_WIN2; k++)
        {
          ACC0 = L_mult0(cur_save[k], MDCT_h[k]);
          ACC0 = L_mac0(ACC0, ycim1[k], *(--ptr_h));
          ACC0 = L_shr(ACC0, n1);
          xr[k] = round(ACC0);
          st->att_weight = sub(st->att_weight, ATT_WEIGHT_STEP);
          xr[k] = mult_r(xr[k], st->att_weight); move16();
          move16();  
        }
      }
      ELSE
      {
        FOR (k = 0; k < MDCT_L_WIN2; k++)
        {
          xr[k] = 0; move16();
        }
      }
      ptr_imdct = & hb_buf[MAXPIT + MDCT_L_WIN];
      FOR (k = 0; k < MDCT_L_WIN2; k++)
      {
        /* look MDCT_h as Q15, then sqrt(2)*sin can be used as sin/sqrt(2) */
        ycim1[k] = mult_r(ptr_imdct[k], MDCT_h[k + MDCT_L_WIN2]); 
        ycim1[k] = shl(ycim1[k], n2); move16(); 
        move16();
      }
    }
    ELSE
    {
      n1 = sub(*norm_pre, 6);
      ptr_h = MDCT_h + MDCT_L_WIN2;
      FOR (k = 0; k < MDCT_L_WIN2; k++)
      {
        cur_save[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, cur_save[k]); move16();

        ACC0 = L_mult0(cur_save[k], MDCT_h[k]);
        ACC0 = L_mac0(ACC0, ycim1[k], *(--ptr_h));
        ACC0  = L_shr(ACC0, n1);
        xr[k] = round(ACC0); move16();

        ycim1[k] = mult_r ((Word16)28672/*ATT_FEC_COEF*/, ycim1[k]); move16();
      }
    }
    st->first_loss_frame = 0; move16();

    return;
  }

  IF (st->pre_bfi)
  {
    FOR (k = MDCT_L_WIN2 -1 ; k >= 0 ; k--)
    {
      ycim1[k] = mult_r(ycim1[k], st->att_weight); move16();
    }
    st->first_loss_frame = 1; move16();
    st->att_weight = 32767; move16();
    st->pre_bfi = 0; move16();
  }
  
  /*******************************************************************************/
  /* Inverse MDCT computation                                                    */
  /*******************************************************************************/

  /* 1 --> Input rotation = Product by wetrm1 */

  ptr1 = ykq;
  ptr2 = ykq + (MDCT_L_WIN2 - 1);
  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (k = 0; k < MDCT_L_WIN4; k++)
  {
    ACC0 = L_mult0(*ptr2, MDCT_wetrm1[k]);
    ACC0 = L_negate(ACC0);
    ACC0 = L_msu0(ACC0, *ptr1, MDCT_wetim1[k]);
    *ptr_ycr++ = round(ACC0);
    move16();

    ACC0 = L_mult0(*ptr1++, MDCT_wetrm1[k]);
    ACC0 = L_msu0(ACC0, *ptr2--, MDCT_wetim1[k]);
    *ptr_yci++ = round(ACC0);
    move16();

    ptr1++;
    ptr2--;
  }

  /* 2 --> Forward FFT : size = 20 */

  sign = (Word16) 1; move16();
  cfft(ycr, yci, sign);

  /* 3 --> Output rotation : product by a complex exponent */

  ptr_yci = yci;
  ptr_ycr = ycr;

  FOR (k = 0; k < MDCT_L_WIN4; k++)
  {
    tmp16 = *ptr_ycr; move16();

    ACC0 = L_mult0(tmp16, MDCT_wcos[k]);
    ACC0 = L_mac0(ACC0, yci[k], MDCT_wsin[k]);
    *ptr_ycr++ = round(ACC0);
    move16();

    ACC0 = L_mult0(yci[k], MDCT_wcos[k]);
    ACC0 = L_msu0(ACC0, tmp16, MDCT_wsin[k]);
    *ptr_yci++ = round(ACC0);
    move16();
  }

  /* 4 --> Overlap and windowing (in one step) - equivalent to complex product */

  ptr1 = sig_cur;
  ptr2 = sig_cur + MDCT_L_WIN2 - 1;
  ptr1_next = sig_next;
  ptr2_next = sig_next + MDCT_L_WIN2 - 1;

  FOR (k = 0; k < MDCT_L_WIN4; k++)
  {
    *ptr1++ = ycr[k];              move16();
    *ptr2--      = negate(ycr[k]); move16();
    *ptr1_next++ = yci[k];         move16();
    *ptr2_next-- = yci[k];         move16();

    ptr1++;
    ptr1_next++;
    ptr2--;
    ptr2_next--;
  }

  n = sub(norm_shift, 6);
  n1 = sub(*norm_pre, 6);
  ptr_h = MDCT_h + MDCT_L_WIN2;
  FOR (k = 0; k < MDCT_L_WIN2; k++)
  {
    ACC0  = L_mult0(sig_cur[k], MDCT_h[k]);
    ACC0  = L_shr(ACC0, n);
    ACC1  = L_mult0(ycim1[k], *(--ptr_h));
    ACC1  = L_shr(ACC1, n1);
    ACC0  = L_add(ACC0, ACC1);
    xr[k] = round(ACC0);
    ycim1[k] = sig_next[k];        move16();
  }

  /* Save sig_cur for FERC */
  FOR (k = 0; k < MDCT_L_WIN2; k++)
  {
    cur_save[k] = sig_cur[k];      move16();
  }

  *norm_pre = norm_shift;  move16();

  return;
}
