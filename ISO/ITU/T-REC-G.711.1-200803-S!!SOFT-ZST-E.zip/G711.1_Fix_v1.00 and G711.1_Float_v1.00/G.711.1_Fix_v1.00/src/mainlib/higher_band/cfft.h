/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: cfft.h
 *  Function: complex FFT headers
 *------------------------------------------------------------------------
 */

#ifndef CFFT_H
#define CFFT_H

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      cfft(Word16 * x1, Word16 * x2, Word16 sign);

/* Tables : */

extern const Word16 MDCT_tab_map[MDCT_NP * MDCT_NPP];
extern const Word16 MDCT_tab_map2[MDCT_NP * MDCT_NPP];
extern const Word16 MDCT_tab_rev_i[MDCT_NB_REV];
extern const Word16 MDCT_tab_rev_ipp[MDCT_NB_REV];
extern const Word16 MDCT_rw1[MDCT_L_WIN4];
extern const Word16 MDCT_rw2[MDCT_L_WIN4];
extern const Word16 MDCT_xcos[25];
extern const Word16 MDCT_xsin[25];

#endif /* CFFT_H */
