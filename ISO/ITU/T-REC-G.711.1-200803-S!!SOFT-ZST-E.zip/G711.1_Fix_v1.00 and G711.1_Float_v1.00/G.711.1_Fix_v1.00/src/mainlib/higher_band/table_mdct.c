/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: table_mdct.c
 *  Function: tables for MDCT computation
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "defines_mdct.h"


/***************************************************************
 *                                                             *
 *             MDCT COMPUTATION TABLES                         *
 *                                                             *
 ***************************************************************/

/* Cosine table for FFT, Q15 */
const Word16 MDCT_xcos[MDCT_NP*MDCT_NP] = {
(Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767, (Word16) 32767, 
(Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126, 
(Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510, 
(Word16) 32767, (Word16)-26510, (Word16) 10126, (Word16) 10126, (Word16)-26510, 
(Word16) 32767, (Word16) 10126, (Word16)-26510, (Word16)-26510, (Word16) 10126 };

/* Sine table for FFT, Q15 */
const Word16 MDCT_xsin[MDCT_NP*MDCT_NP] = {
(Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0, (Word16)     0, 
(Word16)     0, (Word16)-31164, (Word16)-19261, (Word16) 19261, (Word16) 31164, 
(Word16)     0, (Word16)-19261, (Word16) 31164, (Word16)-31164, (Word16) 19261, 
(Word16)     0, (Word16) 19261, (Word16)-31164, (Word16) 31164, (Word16)-19261, 
(Word16)     0, (Word16) 31164, (Word16) 19261, (Word16)-19261, (Word16)-31164 };

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map[MDCT_NP*MDCT_NPP] = {
(Word16)     0, (Word16)     5, (Word16)    10, (Word16)    15, (Word16)    16, (Word16)     1, (Word16)     6, (Word16)    11, (Word16)    12, (Word16)    17, 
(Word16)     2, (Word16)     7, (Word16)     8, (Word16)    13, (Word16)    18, (Word16)     3, (Word16)     4, (Word16)     9, (Word16)    14, (Word16)    19 };

/* Index mapping table for Good-Thomas FFT */
const Word16 MDCT_tab_map2[MDCT_NP*MDCT_NPP] = {
(Word16)     0, (Word16)     5, (Word16)    10, (Word16)    15, (Word16)     4, (Word16)     9, (Word16)    14, (Word16)    19, (Word16)     8, (Word16)    13, 
(Word16)    18, (Word16)     3, (Word16)    12, (Word16)    17, (Word16)     2, (Word16)     7, (Word16)    16, (Word16)     1, (Word16)     6, (Word16)    11 };

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_ipp[MDCT_NB_REV] = {
(Word16)     1 };

/* Table for Good-Thomas FFT */
const Word16 MDCT_tab_rev_i[MDCT_NB_REV] = {
(Word16)     2 };

/* FFT twiddle factors (cosine part), Q15 */
const Word16 MDCT_rw1[MDCT_L_WIN4] = {
(Word16) 32767, (Word16) 31164, (Word16) 26510, (Word16) 19261, (Word16) 10126, 
(Word16)     0, (Word16)-10126, (Word16)-19261, (Word16)-26510, (Word16)-31164, 
(Word16)-32767, (Word16)-31164, (Word16)-26510, (Word16)-19261, (Word16)-10126, 
(Word16)     0, (Word16) 10126, (Word16) 19261, (Word16) 26510, (Word16) 31164 };

/* FFT twiddle factors (sine part), Q15 */
const Word16 MDCT_rw2[MDCT_L_WIN4] = {
(Word16)     0, (Word16) 10126, (Word16) 19261, (Word16) 26510, (Word16) 31164, 
(Word16) 32767, (Word16) 31164, (Word16) 26510, (Word16) 19261, (Word16) 10126, 
(Word16)     0, (Word16)-10126, (Word16)-19261, (Word16)-26510, (Word16)-31164, 
(Word16)-32767, (Word16)-31164, (Word16)-26510, (Word16)-19261, (Word16)-10126 };

/* Cosine table for MDCT and iMDCT, Q15 */
const Word16 MDCT_wcos[MDCT_L_WIN4] = {
(Word16) 32767, (Word16) 32667, (Word16) 32365, (Word16) 31863, (Word16) 31164, 
(Word16) 30274, (Word16) 29197, (Word16) 27939, (Word16) 26510, (Word16) 24917, 
(Word16) 23170, (Word16) 21281, (Word16) 19261, (Word16) 17121, (Word16) 14876, 
(Word16) 12540, (Word16) 10126, (Word16)  7650, (Word16)  5126, (Word16)  2571 };

/* Sine table for MDCT and iMDCT, Q15 */
const Word16 MDCT_wsin[MDCT_L_WIN4] = {
(Word16)     0, (Word16)  2571, (Word16)  5126, (Word16)  7650, (Word16) 10126, 
(Word16) 12540, (Word16) 14876, (Word16) 17121, (Word16) 19261, (Word16) 21281, 
(Word16) 23170, (Word16) 24917, (Word16) 26510, (Word16) 27939, (Word16) 29197, 
(Word16) 30274, (Word16) 31164, (Word16) 31863, (Word16) 32365, (Word16) 32667 };

/* Table for complex post-multiplication in MDCT (real part), Q21 */
const Word16 MDCT_wetr[MDCT_L_WIN4] = {
(Word16)-18897, (Word16) 20264, (Word16)-21506, (Word16) 22616, (Word16)-23586, 
(Word16) 24411, (Word16)-25086, (Word16) 25605, (Word16)-25967, (Word16) 26169, 
(Word16)-26209, (Word16) 26088, (Word16)-25806, (Word16) 25365, (Word16)-24768, 
(Word16) 24017, (Word16)-23119, (Word16) 22078, (Word16)-20901, (Word16) 19595 };

/* Table for complex post-multiplication in MDCT (imaginary part), Q21 */
const Word16 MDCT_weti[MDCT_L_WIN4] = {
(Word16) 18169, (Word16)-16630, (Word16) 14989, (Word16)-13256, (Word16) 11440, 
(Word16) -9554, (Word16)  7610, (Word16) -5618, (Word16)  3592, (Word16) -1543, 
(Word16)  -515, (Word16)  2569, (Word16) -4608, (Word16)  6619, (Word16) -8589, 
(Word16) 10505, (Word16)-12357, (Word16) 14133, (Word16)-15822, (Word16) 17413 };

/* Table for complex pre-multiplication in iMDCT (real part), Q14 */
const Word16 MDCT_wetrm1[MDCT_L_WIN4] = {
(Word16)-23621, (Word16) 25330, (Word16)-26883, (Word16) 28270, (Word16)-29483, 
(Word16) 30514, (Word16)-31357, (Word16) 32007, (Word16)-32459, (Word16) 32711, 
(Word16)-32762, (Word16) 32610, (Word16)-32258, (Word16) 31706, (Word16)-30959, 
(Word16) 30022, (Word16)-28899, (Word16) 27598, (Word16)-26127, (Word16) 24494 };

/* Table for complex pre-multiplication in iMDCT (imaginary part), Q14 */
const Word16 MDCT_wetim1[MDCT_L_WIN4] = {
(Word16)-22711, (Word16) 20788, (Word16)-18736, (Word16) 16569, (Word16)-14300, 
(Word16) 11943, (Word16) -9512, (Word16)  7022, (Word16) -4490, (Word16)  1929, 
(Word16)   643, (Word16) -3212, (Word16)  5760, (Word16) -8274, (Word16) 10736, 
(Word16)-13132, (Word16) 15447, (Word16)-17666, (Word16) 19777, (Word16)-21766 };

/* MDCT window, Q14 */
const Word16 MDCT_h[MDCT_L_WIN] = {
(Word16)   455, (Word16)  1364, (Word16)  2271, (Word16)  3175, (Word16)  4073, 
(Word16)  4966, (Word16)  5850, (Word16)  6726, (Word16)  7591, (Word16)  8445, 
(Word16)  9286, (Word16) 10112, (Word16) 10922, (Word16) 11716, (Word16) 12492, 
(Word16) 13249, (Word16) 13985, (Word16) 14699, (Word16) 15391, (Word16) 16059, 
(Word16) 16703, (Word16) 17320, (Word16) 17911, (Word16) 18474, (Word16) 19009, 
(Word16) 19515, (Word16) 19990, (Word16) 20435, (Word16) 20848, (Word16) 21229, 
(Word16) 21577, (Word16) 21892, (Word16) 22173, (Word16) 22420, (Word16) 22632, 
(Word16) 22810, (Word16) 22952, (Word16) 23059, (Word16) 23130, (Word16) 23166, 
(Word16) 23166, (Word16) 23130, (Word16) 23059, (Word16) 22952, (Word16) 22810, 
(Word16) 22632, (Word16) 22420, (Word16) 22173, (Word16) 21892, (Word16) 21577, 
(Word16) 21229, (Word16) 20848, (Word16) 20435, (Word16) 19990, (Word16) 19515, 
(Word16) 19009, (Word16) 18474, (Word16) 17911, (Word16) 17320, (Word16) 16703, 
(Word16) 16059, (Word16) 15391, (Word16) 14699, (Word16) 13985, (Word16) 13249, 
(Word16) 12492, (Word16) 11716, (Word16) 10922, (Word16) 10112, (Word16)  9286, 
(Word16)  8445, (Word16)  7591, (Word16)  6726, (Word16)  5850, (Word16)  4966, 
(Word16)  4073, (Word16)  3175, (Word16)  2271, (Word16)  1364, (Word16)   455 };
