/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "g711wbe_common.h"
#include "fec_highband.h"

#include "fec_lowband.h"
#include "highband.h"

/*--------------------------------------------------------------------------*
 *  Function  update_hb_buf()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  update the higherband buffer for HB FERC                                *
 *--------------------------------------------------------------------------*/
void update_hb_buf(
  Word16  *hb_buf,    /* (i/o): HB signal buffer */
  Word16  *output_hi  /* (i):   HB output signal */
)
{
  Word16  i;

  /* shift HB buffer for FERC */
  FOR (i = 0; i < MAXPIT; i++)
  {
    hb_buf[i] = hb_buf[i + L_FRAME_NB];  move16();
  }

  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    hb_buf[i + MAXPIT] = output_hi[i];   move16();
  }
}

/*--------------------------------------------------------------------------*
 *  Function  copy_lb_pitch()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  copy the lowerband pitch for HB FERC                                    *
 *--------------------------------------------------------------------------*/
void copy_lb_pitch(
  void * SubDecoderL,  /* (i): Work space for lower-band decoder  */
  void * SubDecoderH   /* (o): Work space for higher-band decoder */
)
{
  VQD_State * vqd = (VQD_State *) SubDecoderH;
  vqd->hbfec_st.lb_t0 = get_lb_pitch(SubDecoderL);
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  cor_hb_fec()                                                  *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  search best pitch, computer the correlation for HB FERC,                *
 *--------------------------------------------------------------------------*/
Word16  cor_hb_fec(       /* returns correlation     */
  Word16 * hb_buf,        /* (i): HB signal buffer   */
  Word16 * hb_pitch_best  /* (o): Pitch delay for HB */
)
{
  Word32  hb_cor, hb_scale1, hb_scale2;
  Word16  hb_nor_cor, hb_nor_cor2, hb_nor_cor_max = 0;

  Word16  hb_cor_16, hb_scale1_16, hb_scale2_16;
  Word16  norm_cor, norm_scale1, norm_scale2, norm_tot;

  Word16  i;

  Word16  hb_pitch_min = sub(*hb_pitch_best, HB_PITCH_SEARCH_RANGE);
  Word16  hb_pitch_max = add(*hb_pitch_best, HB_PITCH_SEARCH_RANGE);
  Word16  hb_pitch;

  /* adjust the pitch search range according to the min and max pitch */
  IF (hb_pitch_min < MINPIT)
    hb_pitch_min = MINPIT;
  IF (hb_pitch_max > MAXPIT)
    hb_pitch_max = MAXPIT;

  /* calculate the self correlation of the frame*/
  hb_scale1 = 1;  move16();
  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    hb_scale1 = L_mac(hb_scale1, hb_buf[i + MAXPIT], hb_buf[i + MAXPIT]);
  }

  norm_scale1 = norm_l(hb_scale1);
  hb_scale1 = L_shl(hb_scale1, norm_scale1);
  hb_scale1_16 = round( hb_scale1);

  /* search the best pitch */
  FOR (hb_pitch = hb_pitch_min; hb_pitch <= hb_pitch_max; hb_pitch++)
  {
    hb_cor = 0; move16();
    FOR (i = 0; i < L_FRAME_NB; i++)
    {
      hb_cor = L_mac(hb_cor, hb_buf[i + MAXPIT], hb_buf[i + MAXPIT - hb_pitch]);
    }

    norm_cor = sub(norm_l(hb_cor), 1);
    hb_cor = L_shl(hb_cor, norm_cor);
    hb_cor_16 = round( hb_cor);

    IF (hb_cor > 0)
    {
      hb_scale2 = 1;  move16();
      FOR (i = 0; i < L_FRAME_NB; i++)
      {
        hb_scale2 = L_mac(hb_scale2, hb_buf[i + MAXPIT - hb_pitch], hb_buf[i + MAXPIT - hb_pitch]);
      }

      norm_scale2 = norm_l(hb_scale2);
      hb_scale2 = L_shl(hb_scale2, norm_scale2);
      hb_scale2_16 = round(hb_scale2);

      hb_nor_cor = div_s(hb_cor_16, hb_scale1_16);
      hb_nor_cor2 = div_s(hb_cor_16, hb_scale2_16);

      hb_nor_cor = mult_r(hb_nor_cor, hb_nor_cor2);
      norm_tot = sub( sub( shl(norm_cor, 1), norm_scale1), norm_scale2);
      hb_nor_cor = shr(hb_nor_cor, norm_tot);

      IF (hb_nor_cor > hb_nor_cor_max)
      {
        *hb_pitch_best = hb_pitch;   move16();
        hb_nor_cor_max = hb_nor_cor; move16();
      }
    }
  }

  return hb_nor_cor_max;
}
