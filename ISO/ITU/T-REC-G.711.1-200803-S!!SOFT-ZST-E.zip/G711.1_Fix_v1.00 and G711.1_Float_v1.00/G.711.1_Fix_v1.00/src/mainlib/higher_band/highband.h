/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: highband.h
 *  Function: Higher-band VQ constants
 *------------------------------------------------------------------------
 */

#ifndef HIGHBAND_H
#define HIGHBAND_H

#include "fec_highband.h"

#define N_FR_FREQ      36          /* Number of quantized coefficients */
#define MAXBIT_SHAPE   5           /* Number of bits allocated for shape */
#define CB_SIZE        32          /* Shape codebook size */
#define BITMASK_SHAPE  0x1F        /* Bit mask for shape index */
#define N_DIV          6           /* Number of subvectors */
#define VECLEN         6           /* Subvector length */
#define N_CAN          8           /* Number of preselected candidates */
#define GSCALE_FACT    25905       /* Gain scaling factor, 4*sqrt(10) in Q11 */
#define DE_SCALE_FACT  20724       /* Gain de-scaling factor 1/(4*sqrt(10)), Q18 */

typedef struct {
  Word16 wvq[N_DIV*2];
  Word16 pow;
} INDEX;

typedef struct {    /* used in encoder only */
  Word16 sIn[L_FRAME_NB];
} VQE_State;

typedef struct {    /* used in decoder only */
  Word16 sPrev[L_FRAME_NB];
  Word16 sCurSave[L_FRAME_NB];
  Word16 sSpectrumQ_pre;
  int    reset;
  HBFEC_State hbfec_st;
} VQD_State;

/* Global tables */

extern const Word16 gsCodebook_0ch[CB_SIZE][VECLEN];
extern const Word16 gsCodebook_1ch[CB_SIZE][VECLEN];
extern const Word32 glCodebook_0ch_pow[CB_SIZE];
extern const Word32 glCodebook_1ch_pow[CB_SIZE];
extern const Word16 gsCodebook_cross[CB_SIZE][CB_SIZE];

/* Function prototypes */

void*  highband_encode_const(void);
void   highband_encode_dest(void *work);
int    highband_encode_reset(void *work);
int    highband_encode( const Word16 *, unsigned char *, void * );
void*  highband_decode_const(void);
void   highband_decode_dest(void *work);
int    highband_decode_reset(void *work);
int    highband_decode( const unsigned char *, int, Word16 *, void * );

int    VQencode_spectrum( Word16*, Word16*, Word16, Word16, Word16* );
int    norm_spectrum( Word16*, Word16, Word16*, Word16*, Word16* );
void   vq_preselect( Word16*, const Word16(*)[VECLEN], const Word32*, Word32*,
           Word16*, Word16* );
void   vq_mainselect( Word16*, Word16*, Word16*, Word32*, Word32*, Word16*,
           Word16*, Word16* );
Word16 mulaw( Word16 );
int    mux_bitstream( INDEX *, unsigned char * );

int    VQdecode_spectrum( Word16*, Word16, Word16*, Word16* );
Word16 mulawinv( Word16 index );
int    demux_bitstream( INDEX *, unsigned char * );

#endif  /* HIGHBAND_H */
