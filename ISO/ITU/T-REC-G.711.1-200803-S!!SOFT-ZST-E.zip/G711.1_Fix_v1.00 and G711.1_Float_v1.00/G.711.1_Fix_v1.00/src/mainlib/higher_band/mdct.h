/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: mdct.c
 *  Function: MDCT headers
 *------------------------------------------------------------------------
 */

#ifndef MDCT_H
#define MDCT_H

#include <stdio.h>
#include "stl.h"
#include "fec_highband.h"

/* Functions : */
void      mdct(Word16 * mem, Word16 * input, Word16 * ykr, Word16 *norm_shift);
void      inv_mdct(Word16 * xr, Word16 * ykq, Word16 * ycim1, Word16 norm_shift, Word16 * norm_pre, Word16, Word16 *, HBFEC_State *);

/* Tables : */

extern const Word16 MDCT_h[MDCT_L_WIN];
extern const Word16 MDCT_wcos[MDCT_L_WIN4];
extern const Word16 MDCT_wsin[MDCT_L_WIN4];
extern const Word16 MDCT_wetr[MDCT_L_WIN4];
extern const Word16 MDCT_weti[MDCT_L_WIN4];
extern const Word16 MDCT_wetrm1[MDCT_L_WIN4];
extern const Word16 MDCT_wetim1[MDCT_L_WIN4];
extern const Word16 MDCT_win[MDCT_L_WIN2];

#endif /* MDCT_H */
