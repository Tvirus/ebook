/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: g711.h
 *  Function: Header of embedded lower-band PCM coders
 *------------------------------------------------------------------------
 */

#ifndef G711_H
#define G711_H


short convertLin_ALaw(short x, short *ind2, short *xq, short* expo);
short convertALaw_Lin(short ind, short *expo, short* signo);
short convertALaw_Lin_enh(short code2, short exp, short sign, short numbits);

short convertLin_MuLaw(short x, short *ind2, short *xq, short* expo);
short convertMuLaw_Lin(short ind, short *expo, short* signo);
short convertMuLaw_Lin_enh(short code2, short exp, short sign, short numbits);

#endif
