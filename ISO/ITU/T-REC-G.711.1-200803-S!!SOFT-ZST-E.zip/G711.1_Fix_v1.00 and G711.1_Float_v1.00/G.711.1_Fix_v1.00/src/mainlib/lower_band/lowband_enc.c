/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: lowband_enc.c
 *  Function: Lower-band encoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "g711.h"
#include "lowband.h"
#include "lpctool.h"

typedef struct {
  Word16 law;                    /* G.711 law */
  Word16 sigdec_past[L_WINDOW];  /* buffer for past G.711 decoded signal */
  Word16 mem_A[ORD_M+1];         /* A(z) of previous frame */
  Word16 mem_rc[ORD_M];          /* Reflection coefficients of previous frame */
  Word16 mem_wfilter[ORD_M];     /* buffer for the weighting filter */
} lowband_encode_work;

/* bitstream multiplexing for LBE layer */
static void lowband_lbe_mux(Word16* excode, Word16* expi, unsigned char code1[]);

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder constructor
  Return value:
    Pointer to work space
   -------------------------------------------------------------------*/
void    *lowband_encode_const(
  int law    /* (i): G.711 encoding law [G711ALAW/G711ULAW] */
) {
  lowband_encode_work *work=NULL;

  if ( law == G711ULAW || law == G711ALAW ) {
    work = (lowband_encode_work *)malloc( sizeof(lowband_encode_work) );
    if ( work != NULL ) {
      work->law = law;
      lowband_encode_reset( (void *)work );
    }
  }
  return (void *)work;
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder destructor
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_encode_dest(
  void *ptr  /* (i): Pointer to work space */
) {
  lowband_encode_work *work = (lowband_encode_work *)ptr;
  if (work != NULL ) free( work );
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder reset
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_encode_reset(
  void *ptr  /* (i/o): Pointer to work space */
) {
  lowband_encode_work *work = (lowband_encode_work *)ptr;

  if (work != NULL) {
    work->mem_A[0] = 4096; move16();
    zero16(ORD_M, &work->mem_A[1]);
    zero16(ORD_M, work->mem_rc);
    zero16(ORD_M, work->mem_wfilter);
    zero16(L_WINDOW, work->sigdec_past);
  }
}

/* -------------------------------------------------------------------
  Function:
    Lower-band encoder
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_encode(
  const Word16  sigin[],  /* (i): Input 5-ms signal                     */
  unsigned char code0[],  /* (o): Core-layer bitstream (multiplexed)    */
  unsigned char code1[],  /* (o): LB enh. layer bitstream (multiplexed) */
  void          *ptr      /* (i/o): Pointer to work space               */
) {
  Word16  i, j;
  Word16  offset;
  Word16  sigtmp;
  Word16  codtmp;
  Word16  sAlpha;
  Word16  *sigdec;
  Word16  norm;
  Word16  stable;
  Word16  excode[L_FRAME_NB];
  Word16  rh[ORD_M+1];             /* Autocorrelations of windowed signal  */
  Word16  rl[ORD_M+1];
  Word32  lval;

  lowband_encode_work *work = (lowband_encode_work *)ptr;

  Word16  *rc=work->mem_rc;        /* Reflection coefficients              */
  Word16  *A =work->mem_A;         /* A0(z) with bandwidth-expansion       */

  /* G.711 decoding function */
  short   (*convertLin_Log)(short, short*, short*, short*);
  short   exp[L_FRAME_NB];


  /* Pointer initialization */
  sigdec = work->sigdec_past + L_FRAME_NB;

  /* LP analysis and filter weighting */
  norm = AutocorrNS(work->sigdec_past, rh, rl);
  Levinson(rh, rl, rc, &stable, ORD_M, A);

  IF (sub(norm, MAX_NORM) >= 0) {
    FOR (i=1; i<=ORD_M; ++i) {
      A[i] = shr(A[i],add(i,sub(norm,MAX_NORM)));
      move16();
    }
  }
  ELSE {
    sAlpha = negate(rc[0]); ;       /* rc[0] == -r[1]/r[0]   */
    IF (sub (sAlpha, -32256) < 0)   /* r[1]/r[0] < -0.984375 */
    {
      sAlpha = add (sAlpha, 32767);
      sAlpha = add (sAlpha, 1536);
      sAlpha = shl (sAlpha, 4);     /* alpha=16*(r[1]/r[0]+1+0.75/16) */
      Weight_a(A, A, mult_r(GAMMA1, sAlpha), ORD_M);
    }
    ELSE {
      Weight_a(A, A, GAMMA1, ORD_M);
    }
  }

  /* Update of the past signal */
  mov16(L_FRAME_NB, work->sigdec_past + L_FRAME_NB, work->sigdec_past);

  IF (work->law == G711ALAW)
  {
    convertLin_Log = convertLin_ALaw;
    offset = ALAW_OFFSET;
    move16();
  }
  ELSE  /* work->law == G711ULAW */
  {
    convertLin_Log = convertLin_MuLaw;
    offset = 0;
    move16();
  }

  FOR (i=0; i<L_FRAME_NB; i++)
  {
    /* Calculation of the shaped sample */
    lval = L_mult(A[0], sigin[i]);    /* put sigin in 32-bits in Q12 (A[0]=1.0) */
    lval = L_mac(lval, A[0], offset); /* put offset in Q12 and add to sigin */
    FOR (j=0; j<ORD_M; j++) {
      lval = L_mac(lval, A[j+1], work->mem_wfilter[j]);
    }
    sigtmp = extract_h(L_shl(lval, 3));

    test();test();test();
    IF (sub(work->law, G711ALAW) == 0               &&
        sub(norm, MAX_NORM) >= 0                    &&
        sub(sigtmp, ALAW_OFFSET-ALAW_DEADZONE) >= 0 &&
        sub(sigtmp, ALAW_OFFSET+ALAW_DEADZONE) <= 0)
    {
      codtmp = 0xD5; move16(); sigdec[i] = 8; move16(); /* reduce G711 cracles */
      exp[i] = 0; move16();

      excode[i] = 7; move16();
      IF (sub(sigtmp, 2) < 0)       { excode[i] = 0;   move16(); }
      ELSE IF (sub(sigtmp, 16) < 0) { excode[i] = shr(sigtmp, 1); move16(); }
    }
    ELSE
    {
      test();test();test();
      IF (sub(work->law, G711ULAW) == 0     &&
          sub(norm, MAX_NORM) >= 0          &&
          sub(sigtmp, -MULAW_DEADZONE) >= 0 &&
          sub(sigtmp, MULAW_DEADZONE) <= 0)
      {
        codtmp = 0xFF; move16(); sigdec[i] = 0; move16();
        exp[i] = 0; move16();

        excode[i] = 3 << 1; move16();
        IF (sub(sigtmp, -1) < 0)      { excode[i] = 0; move16(); } /* 0xFF (R1=0) with R2a ext. 0 and 1 will replace 0x7F with ext. 3 and 2 */
        ELSE IF (sigtmp < 0)          { excode[i] = 1 << 1; move16(); }
        ELSE IF (sub(sigtmp, 2) < 0 ) { excode[i] = 2 << 1; move16(); }
      }
      ELSE
      {
        codtmp = (*convertLin_Log) (sigtmp, &excode[i], &sigdec[i], &exp[i]);
      }
    }

    code0[i] = (unsigned char)s_and (codtmp, 0x00FF);  move16();
    sigdec[i] = sub(sigdec[i], offset); move16();

    /* Update the noise-shaping filter memory */
    FOR (j=ORD_M-1; j>0; j--) {
      work->mem_wfilter[j] = work->mem_wfilter[j-1];   move16();
    }
    work->mem_wfilter[0] = sub(sigin[i], sigdec[i]);
    move16();
  }

  IF (code1 != NULL)    /* Layer 1 encoding */
  {
    lowband_lbe_mux(excode, exp, code1);
  }
}

/* Lower-band enhancement layer encoding */

#define LBE_NUM_BITS    80       /* no. of bits allocated to LBE */
#define MAX_EXP_VALUE   7        /* max. exponent value */
#define MAX_ENH_BITS    3        /* max. allowable bits per sample for LBE */
#define MAX_EXP_POS     (MAX_EXP_VALUE + MAX_ENH_BITS)

static void lowband_lbe_mux(Word16* excode, Word16* expi, unsigned char code1[])
{
  unsigned char* pcode1 = code1;
  Word16  bit_pos;
  Word16  i;
  Word16  tmp1;
  Word16  bit_alloc[L_FRAME_NB];

  /* Bit allocation */
  lbe_bitalloc( expi, bit_alloc );

  /* bits arrangement */
  bit_pos = 0; move16();
  tmp1 = 0;    move16();
  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    excode[i] = shr(excode[i], sub(MAX_ENH_BITS, bit_alloc[i]));
    move16();

    tmp1 = shl(tmp1, bit_alloc[i]);
    tmp1 = s_or(tmp1, excode[i]);
    bit_pos = add(bit_pos, bit_alloc[i]);

    IF (sub(bit_pos, 8) >= 0)
    {
      bit_pos = sub(bit_pos, 8);
      *pcode1 = (unsigned char)shr(tmp1, bit_pos);
      move16();
      tmp1 = sub(tmp1, shl((Word16)*pcode1, bit_pos));
      pcode1++;
    }
  }

  return;
}

void lbe_bitalloc( Word16* expi, Word16* bit_alloc )
{
  Word16  bit_cnt;
  Word16  bit_reservoir;
  Word16  i, j, iexp;

  Word16  arr_exp[MAX_EXP_POS][L_FRAME_NB];
  Word16  cnt_exp[MAX_EXP_POS];
  Word16  (*parr_exp)[L_FRAME_NB];
  Word16  *pcnt_exp;
  Word16  *pbit_alloc;

  bit_reservoir = LBE_NUM_BITS;  move16();
  zero16( MAX_EXP_POS, cnt_exp );
  zero16( L_FRAME_NB, bit_alloc );

  /* count no. of samples corresponding to each exponent and store its index */
  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    parr_exp = (Word16 (*)[L_FRAME_NB])arr_exp[expi[i]];
                                         a_mac(); move16(); /* for addressing */
    pcnt_exp = &cnt_exp[expi[i]];        add(0,0);          /* for addressing */

    FOR (j = 0; j < MAX_ENH_BITS; j++)
    {
      parr_exp[j][*pcnt_exp] = i;        move16();  /* store index */
                                         add(0,0);  /* for addressing */
      *pcnt_exp = add(*pcnt_exp, 1);     move16();  /* count no. of exponents */
      pcnt_exp ++;
    }
  }

  /* compute bit allocation table for enhancement layer */
  FOR (iexp = MAX_EXP_POS-1; iexp >= 0; iexp--)
  {
    IF (sub(cnt_exp[iexp], bit_reservoir) > 0)
    {
      bit_cnt = bit_reservoir;    move16();
    }
    ELSE
    {
      bit_cnt = cnt_exp[iexp];    move16();
    }

    FOR (j = 0; j < bit_cnt; j++)
    {
      pbit_alloc = &bit_alloc[ arr_exp[iexp][j] ]; add(0,0);  /* addressing */
      *pbit_alloc = add(*pbit_alloc, 1);           move16();
    }

    bit_reservoir = sub(bit_reservoir, bit_cnt);

    IF (bit_reservoir == 0) {
        BREAK;
    }
  }

  return;
}
