/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: prehpf.h
 *  Function: Header of pre-processing 1-tap high-pass filtering
 *------------------------------------------------------------------------
 */

#ifndef FPREHPF_H
#define FPREHPF_H

void  *highpass_1tap_iir_const (void);
void  highpass_1tap_iir_dest (void*);
void  highpass_1tap_iir_reset (void*);
void  highpass_1tap_iir (Word16, Word16, Word16*, Word16*, void*);

#endif  /* FPREHPF_H */
