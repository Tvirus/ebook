/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: qmfilt.c
 *  Function: Quadrature mirror filter (QMF)
 *            for band splitting and band reconstructing
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"

#define LFRAME_HALF    (L_FRAME_WB/2)
#define NTAP_QMF_HALF  (NTAP_QMF/2)
#define QMFBUFSIZE     (NTAP_QMF-2)

typedef struct {
  Word16  bufmem[QMFBUFSIZE];
  Word16  ovflag_pre;
} QMFilt_WORK;

/* Constructor */
void* QMFilt_const(void)  /* returns pointer to work space */
{
  QMFilt_WORK *work=NULL;

  work = (QMFilt_WORK *)malloc( sizeof(QMFilt_WORK) );
  if ( work != NULL ) QMFilt_reset( (void *)work );

  return (void *)work;
}

/* Destructor */
void  QMFilt_dest(void *ptr)
{
  QMFilt_WORK *work=(QMFilt_WORK *)ptr;
  if ( work != NULL ) free( work );
}

/* Reset */
void  QMFilt_reset(void *ptr)
{
  int    i;
  QMFilt_WORK *work=(QMFilt_WORK *)ptr;

  if ( work != NULL ) {
      FOR ( i=0; i<QMFBUFSIZE; i++ )
          work->bufmem[i] = 0;
      work->ovflag_pre = 0;
  }
}

/* Band splitting */
void  QMFilt_ana(
  Word16  *insig,  /* (i): Input 16-kHz-sampled signal */
  Word16  *lsig,   /* (o): Output lower-band signal    */
  Word16  *hsig,   /* (o): Output higher-band signal   */
  void    *ptr     /* (i/o): Work space                */
) {
  QMFilt_WORK *work=(QMFilt_WORK *)ptr;
  int     i, j;
  Word16  *insigpt;
  Word16  insigbf[L_FRAME_WB+QMFBUFSIZE];
  Word32  lAcc0;
  Word32  lAcc1;

  insigpt = insigbf;  move16();

  FOR (i = 0; i < QMFBUFSIZE; i++) {
    *insigpt++ = work->bufmem[i];
    move16();
  }
  FOR (i = 0; i < L_FRAME_WB; i++) {
    *insigpt++ = insig[i];
    move16();
  }

  FOR (i = 0; i < L_FRAME_WB; i+=2)
  {
    insigpt = insigbf + i;  add(0,0);
    lAcc0 = 0;  move32();
    lAcc1 = 0;  move32();

    FOR (j = 0; j < NTAP_QMF_HALF; j++) {
      lAcc0 = L_mac0( lAcc0, sQmf0[j], *(insigpt++) );
      lAcc1 = L_mac0( lAcc1, sQmf1[j], *(insigpt++) );
    }

    *(lsig++) = round( L_shl( L_add(lAcc0, lAcc1), 1 ) );
    *(hsig++) = round( L_shl( L_sub(lAcc1, lAcc0), 1 ) );
  }

  insigpt = insigbf + L_FRAME_WB;  add(0,0);

  FOR (i = 0; i < QMFBUFSIZE; i++) {
    work->bufmem[i] = *insigpt++;
    move16();
  }

  return;
}

/* Band reconstructing */
void QMFilt_syn(
  Word16  *lsig,   /* (i): Input lower-band signal      */
  Word16  *hsig,   /* (i): Input higher-band signal     */
  Word16  *outsig, /* (o): Output 16-kHz-sampled signal */
  void    *ptr     /* (i/o): Pointer to work space      */
) {
  QMFilt_WORK *work=(QMFilt_WORK *)ptr;
  int     i, j;
  Word16  buf_sum[LFRAME_HALF+NTAP_QMF_HALF-1];
  Word16  buf_dif[LFRAME_HALF+NTAP_QMF_HALF-1];
  Word16  *pbuf;
  Word16  *ps_sum;
  Word16  *ps_dif;
  Word32  lAcc0;
  Word32  lAcc1;
  Word16  sAcc;
  Word16  ovflag;
  Word16  fmt, sshift;

  /* Overflow check */
  ovflag = 0; move16();
  FOR (i = 0; i < LFRAME_HALF; i++) {
    sAcc = sub (add(abs_s(lsig[i]), abs_s(hsig[i])), MAX_16);
    if (sAcc >= 0) {
      ovflag = 1; move16();
    }
  }

  pbuf = work->bufmem;  move16();
  ps_sum = buf_sum;  move16();
  ps_dif = buf_dif;  move16();

  /* copy from filter buffer */
  IF (work->ovflag_pre != 0)
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *ps_sum++ = *pbuf++; move16();
      *ps_dif++ = *pbuf++; move16();
    }
  }
  ELSE IF (ovflag == 0)  /*ovflag==0 && ovflag_pre==0*/
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *ps_sum++ = *pbuf++; move16();
      *ps_dif++ = *pbuf++; move16();
    }
  }
  ELSE                   /*ovflag!=0 && ovflag_pre==0*/
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *ps_sum++ = shr (*pbuf++, 1); move16();
      *ps_dif++ = shr (*pbuf++, 1); move16();
    }
  }

  fmt = s_max (ovflag, work->ovflag_pre);
  sshift = add (2, fmt);

  /* calculate sum/diff values */
  IF (fmt != 0)
  {
    FOR (i = 0; i < LFRAME_HALF; i++) {
      lAcc0 = L_mult (0x4000, lsig[i]);
      *(ps_sum++) = mac_r (lAcc0, 0x4000, hsig[i]);  /*Q(-1)*/
      *(ps_dif++) = msu_r (lAcc0, 0x4000, hsig[i]);  /*Q(-1)*/
    }
  }
  ELSE
  {
    FOR (i = 0; i < LFRAME_HALF; i++) {
      *(ps_sum++) = add(lsig[i], hsig[i]);
      *(ps_dif++) = sub(lsig[i], hsig[i]);
    }
  }

  ps_sum = buf_sum;
  ps_dif = buf_dif;

  FOR (i = 0; i < LFRAME_HALF; i++)
  {
    lAcc0 = 0;  move32();
    lAcc1 = 0;  move32();

    FOR (j = 0; j < NTAP_QMF_HALF; j++) {
      lAcc0 = L_mac0( lAcc0, sQmf0[j], ps_sum[j] );
      lAcc1 = L_mac0( lAcc1, sQmf1[j], ps_dif[j] );
    }

    *(outsig++) = round( L_shl(lAcc1, sshift) );
    *(outsig++) = round( L_shl(lAcc0, sshift) );

    ps_sum++;  move16();
    ps_dif++;  move16();
  }

  /* copy to filter buffer */
  pbuf = work->bufmem;  move16();
  IF (ovflag != 0)
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *pbuf++ = *ps_sum++; move16();
      *pbuf++ = *ps_dif++; move16();
    }
  }
  ELSE IF (work->ovflag_pre == 0)  /*ovflag==0 && ovflag_pre==0*/
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *pbuf++ = *ps_sum++; move16();
      *pbuf++ = *ps_dif++; move16();
    }
  }
  ELSE                             /*ovflag==0 && ovflag_pre!=0*/
  {
    FOR (i = 0; i < NTAP_QMF_HALF-1; i++) {
      *pbuf++ = shl (*ps_sum++, 1); move16();
      *pbuf++ = shl (*ps_dif++, 1); move16();
    }
  }

  work->ovflag_pre = ovflag;

  return;
}
