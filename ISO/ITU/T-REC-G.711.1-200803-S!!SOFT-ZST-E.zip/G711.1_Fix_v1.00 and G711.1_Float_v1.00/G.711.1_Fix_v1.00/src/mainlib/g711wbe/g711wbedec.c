/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei
   All rights reserved

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: g711wbedec.c
 *  Function: G.711WBE decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"
#include "lowband.h"
#include "highband.h"

#define OK  0
#define NG  1

typedef struct {
  Word16  Mode;        /* Decoding mode */
  Word16  OpFs;        /* Sampling frequency */
  Word16  law;         /* Logarithmic law */
  Word16  gain_ns;     /* Noise shaping gain */
  void*   SubDecoderL; /* Work space for lower-band sub-decoder */
  void*   SubDecoderH; /* Work space for higher-band sub-decoder */
  void*   pQMFBuf;     /* QMF filter buffer */
} G711wbeDecoder_WORK;

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder constructor
  Return value:
    Pointer to work space
  ----------------------------------------------------------------*/
void *G711wbeDecode_const(
  int  mode,  /* (i): Decoding mode      */
  int  law    /* (i): G.711 law for core layer */
)
{
  G711wbeDecoder_WORK *w=NULL;
#ifdef APPENDIX_I_POSTFILTER
  Word16  postfilter_option=0;

  if ( mode == MODE_R1_POST ) {
    mode = MODE_R1;
    postfilter_option = 1;
  }
#endif

  /* Static memory allocation */
  w = (void *)malloc( sizeof(G711wbeDecoder_WORK) );
  if ( w == NULL )  return NULL;

  w->Mode = mode;

  if ( w->Mode == MODE_R1 ) {
    w->OpFs = 8000;
  } else if ( w->Mode == MODE_R2a ) {
    w->OpFs = 8000;
  } else if ( w->Mode == MODE_R2b ) {
    w->OpFs = 16000;
  } else if ( w->Mode == MODE_R3 ) {
    w->OpFs = 16000;
  } else {
    error_exit( "Decoding mode error." );
  }

  w->law = law;

#ifdef APPENDIX_I_POSTFILTER
  w->SubDecoderL = lowband_decode_const(law, postfilter_option);
#else
  w->SubDecoderL = lowband_decode_const(law);
#endif
  if ( w->SubDecoderL == NULL )  error_exit( "Lower band init error." );

  w->SubDecoderH = highband_decode_const();
  if ( w->SubDecoderH == NULL )  error_exit( "Higher band init error." );

  w->pQMFBuf = QMFilt_const();
  if ( w->pQMFBuf == NULL )  error_exit( "QMF init error." );

  G711wbeDecode_reset( (void *)w );

  return (void *)w;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void G711wbeDecode_dest(
  void*  p_work  /* (i): Work space */
)
{
  G711wbeDecoder_WORK *w=(G711wbeDecoder_WORK *)p_work;

  if ( w != NULL )
  {
    lowband_decode_dest( w->SubDecoderL );   /* Lower band */
    highband_decode_dest( w->SubDecoderH );  /* Higher band */
    QMFilt_dest( w->pQMFBuf );               /* QMF */

    free( w );
  }
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder reset
  Return value:
    OK
  ----------------------------------------------------------------*/
int  G711wbeDecode_reset(
  void*  p_work  /* (i/o): Work space */
)
{
  G711wbeDecoder_WORK *w=(G711wbeDecoder_WORK *)p_work;

  if ( w != NULL )
  {
    lowband_decode_reset( w->SubDecoderL );  /* Lower band */
    highband_decode_reset( w->SubDecoderH ); /* Higher band */
    QMFilt_reset( w->pQMFBuf );              /* QMF */
    w->gain_ns = 32767;                      /* start with full gain */
  }
  return OK;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE decoder
  Return value:
    OK/NG
  ----------------------------------------------------------------*/
int  G711wbeDecode(
  const unsigned char*  bitstream,   /* (i):   Input bitstream  */
  short*                outwave,     /* (o):   Output signal    */
  void*                 p_work,      /* (i/o): Work space       */
  int                   ploss_status /* (i):   Packet-loss flag */
) {
  const unsigned char  *bpt = bitstream;
  Word16  SubSigLow[L_FRAME_NB];
  Word16  SubSigHigh[L_FRAME_NB];
  Word16  gain = 32767;
  Word32  gain32;
  Word16  i, n;
  Word32  powerL, powerH;

  G711wbeDecoder_WORK *w=(G711wbeDecoder_WORK *)p_work;

  if (p_work == NULL) return NG;

  /* ------------------------------------------------------------- */
  /* Lower-band decoder including both core and enhancement layers */
  /* Frame erasure concealment is integrated in the decoder.       */
  /* ------------------------------------------------------------- */
  IF ( w->Mode == MODE_R2a || w->Mode == MODE_R3 )
  {
    /* Core layer + Lower band enhancement layer */
    lowband_decode( bpt, bpt+NBytesPerFrame0, ploss_status, SubSigLow, &gain, w->SubDecoderL );
    bpt += (NBytesPerFrame0+NBytesPerFrame1);
  }
  ELSE
  {
    /* Core layer only */
    /* When the second parameter is NULL, this decoder works as G.711 decoder. */
    lowband_decode( bpt, NULL, ploss_status, SubSigLow, &gain, w->SubDecoderL );
    bpt += NBytesPerFrame0;
  }

  /* ------------------------------------- */
  /* Higher-band enhancement layer decoder */
  /* ------------------------------------- */
  IF ( w->Mode == MODE_R2b || w->Mode == MODE_R3 )
  {
    IF ( ploss_status != 0 ) {
      /* Get the LB pitch for HB FERC */
      copy_lb_pitch(w->SubDecoderL, w->SubDecoderH);
    }
    highband_decode( bpt, ploss_status, SubSigHigh, w->SubDecoderH );
  }

  /* --------------------- */
  /* Band reconstructing   */
  /* --------------------- */
  IF (w->OpFs == 8000)
  {
    mov16( L_FRAME_NB, SubSigLow, outwave );
  }
  ELSE  /* w->OpFs == 16000 */
  {
    /* Band reconstructing with QMF */
    QMFilt_syn( SubSigLow, SubSigHigh, outwave, w->pQMFBuf );
  }

  /* ---------------- */
  /* Apply Noise Gate */
  /* ---------------- */
  sub(0,0);
  IF (w->OpFs == 16000)
  {
    powerL = 0;  move32();
    powerH = 0;  move32();
    FOR (i=0; i<L_FRAME_NB; i++)
    {
      powerL = L_mac0( powerL, 1, abs_s(SubSigLow[i]) );
      powerH = L_mac0( powerH, 1, abs_s(SubSigHigh[i]) );
    }
    sub(0,0); L_sub(0L,0L); L_sub(0L,0L);
    test(); test();
    IF ( gain < 32767 && powerH > 800 && L_shr(powerH,4) > powerL ) {
      gain = 32767;
      move16();
    }
  }

  n = (w->OpFs==8000) ? L_FRAME_NB : L_FRAME_WB;
  gain32 = L_add(L_mult(gain,350),32768); /* inc gain to be able to converge to 1.0 */

  FOR (i=0; i<n; ++i)
  {
    w->gain_ns = mac_r(gain32,w->gain_ns,32418); /* 32418 = 32768 - 350 */

    IF (sub(w->gain_ns, 32767) < 0)
    {
      outwave[i] = mult_r(w->gain_ns,outwave[i]); move16();
    }
  }

  return OK;
}
