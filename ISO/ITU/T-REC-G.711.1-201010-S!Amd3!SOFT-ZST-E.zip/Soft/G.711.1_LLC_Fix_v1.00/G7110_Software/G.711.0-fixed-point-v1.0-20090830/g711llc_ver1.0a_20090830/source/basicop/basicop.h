/***************************************************************************
 ITU-T G.711.0 ANSI-C Source Code Release 1.0

 (C) Cisco Systems Inc., Huawei, NTT and Texas Instruments Incorporated.

 Filename: basicop.h
 Contents: Umbrella header file for STL.
 Version: 1.0
 Revision Date: July 24, 2009
**************************************************************************/

#ifndef _BASICOP_H
#define _BASICOP_H

#include "stl.h"
#include "oper_32b.h"

#endif /* !_BASICOP_H */

