                       RUNNING THE SOFTWARE
                       ====================

The usage of the "encoder" program is as follows:

  encoder [-options] <law> <infile> <codefile>

  where:
    law        is the desired G.711 law (A or u).
    infile     is the name of the input file to be encoded.
    codefile   is the name of the bitstream file.

  Options:
    -mode #    is the desired encode mode (1, 2, 3, 4).
    -nb        indicates that input signal is sampled at 8 kHz.
    -quiet     quiet processing.
    -hardbit   outputs hardbit instead of G.192 softbit.
    -Fn #      Number of G.711.1 frames in one G.711.1-LLC frame��default: 1; maximum: 128.
    -g711llc   Combined with G711.0 codec mode.

Encoding modes 1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.
By default, the encoder input is sampled at 16 kHz, and the encoding mode is 4 (R3).


The usage of the "decoder" program is as follows:

  decoder [-options] <law> -mode <modenum> <codefile> <outfile>

  where:
    law        is the desired G.711 law (A or u)
    modenum    is the mode of the bitstream file(1, 2, 3, 4).
    codefile   is the name of the bitstream file.
    outfile    is the name of the decoded output file.

  Options:
    -quiet     quiet processing.
    -r1pf      enables R1 postfilter. (valid for R1 only)
    -hardbit   specifies hardbit instead of G.192 softbit.
    -g711llc   Combined with G711.0 codec mode.

Decoding modes 1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.
The decoder output is sampled at 8 kHz for modes 1 (R1) and 2 (R2a),
and at 16 kHz for modes 3 (R2b) and 4 (R3).

NOTE - G.711.1 Annex C source code is found in the "codec". G7110_Software 
reproduces, for the convenience of the user, applicable code from G.711.0 
that is needed by G.711.1 Annex C.

--ML/H,SCN/TSB, 2010-09-15
