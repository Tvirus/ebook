/* 
   ITU-T G.711.1-LLC ANSI-C Source Code
   Version: 1.0, 2010
*/
/*
 *------------------------------------------------------------------------
 *  File: decoder.c
 *  Function: G.711WBE decoder test program
 *------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stl.h"
#include "g711wbe.h"
#include "softbit.h"

/* G.711.0 */
#define G711_LLC
#ifdef G711_LLC
#include "g711llc_decoder.h"
#endif


/***************************************************************************
 * usage()
 ***************************************************************************/
static void usage(char progname[])
{
  fprintf(stderr, "\n");
  fprintf(stderr, " Usage: %s [-options] <law> -mode <modenum> <codefile> <outfile>\n", progname);
  fprintf(stderr, "\n");
  fprintf(stderr, " where:\n");
  fprintf(stderr, "   law         is the desired G.711 law (A or u).\n");
  fprintf(stderr, "   modenum     is the mode of the bitstream file (1, 2, 3, 4).\n");
  fprintf(stderr, "               1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.\n");
  fprintf(stderr, "   codefile    is the name of the input bitstream file.\n");
  fprintf(stderr, "   outfile     is the name of the decoded output file.\n");
  fprintf(stderr, "\n");
  fprintf(stderr, " Options:\n");
  fprintf(stderr, "   -decmode #  is the decoder mode (1, 2, 3, 4).\n");
  fprintf(stderr, "               Default mode is the same as modenum.\n");
#ifdef APPENDIX_I_POSTFILTER
  fprintf(stderr, "   -r1pf       R1 postfilter enabled.\n");
#endif
  fprintf(stderr, "   -hardbit    Input bitstream file is in multiplexed hardbit format.\n");
#ifdef G711_LLC
  fprintf(stderr, "   -g711llc    Combined with G711.0 codec mode.\n");  
#endif
  fprintf(stderr, "   -quiet      quiet processing.\n");
  fprintf(stderr, "\n");
}

typedef struct {
#ifdef G711_LLC
  int  g711llc;
#endif
  int  quiet;
  int  law;
  int  mode_bst;
  int  mode_dec;
  char *code_fname;
  char *output_fname;
#ifdef APPENDIX_I_POSTFILTER
  int  postfilter_option;
#endif
  int  format;
} DECODER_PARAMS;

static void  get_commandlile_params(
  int            argc,
  char           *argv[],
  DECODER_PARAMS *params
) {
  char  *progname=argv[0];

  if (argc < 6) {
      usage(progname);
      exit(1);
  }

  /* Default mode */
  params->quiet = 0;
  params->format = 0;    /* Default is G.192 softbit format */
  params->mode_dec = -1;
#ifdef APPENDIX_I_POSTFILTER
  params->postfilter_option = 0;
#endif
#ifdef G711_LLC
  params->g711llc = 0;
#endif

  while (argc > 1 && argv[1][0] == '-')
  {
      
	  if (strcmp(argv[1], "-quiet") == 0) {
          /* Set the quiet mode flag */
          params->quiet=1;

          /* Move arg{c,v} over the option to the next argument */
          argc --;
          argv ++;
      }
#ifdef APPENDIX_I_POSTFILTER
      else if (strcmp(argv[1], "-r1pf") == 0 ) {
          /* Set R1 postfilter option flag */
          params->postfilter_option = 1;
          argc --; argv ++;
      }
#endif
      else if (strcmp(argv[1], "-hardbit") == 0) {
          params->format = 1;    /* Hardbit output format */
          /* Move arg{c,v} over the option to the next argument */
          argc --;
          argv ++;
      }
#ifdef G711_LLC
      else if (strcmp(argv[1], "-g711llc") == 0) {
          params->g711llc = 1;    /* g711llc output format */
		  argc -=1;
		  argv +=1;
      }
#endif
      else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-?") == 0) {
          /* Display help message */
          usage(progname);
          exit(1);
      }
      else if (strcmp(argv[1], "-decmode") == 0) {
          if (strcmp(argv[2], "1") == 0) {
              params->mode_dec = MODE_R1;
          }
          else if (strcmp(argv[2], "2") == 0) {
              params->mode_dec = MODE_R2a;
          }
          else if (strcmp(argv[2], "3") == 0) {
              params->mode_dec = MODE_R2b;
          }
          else if (strcmp(argv[2], "4") == 0) {
              params->mode_dec = MODE_R3;
          }
          else {
              fprintf(stderr, "Error in decoding mode %s\n", argv[2]);
              fprintf(stderr, "Mode character must be 1, 2, 3 or 4!!\n\n");
              usage(progname);
              exit(-1);
          }
          argc -=2; argv +=2;
      }
      else {
          fprintf(stderr, "ERROR! Invalid option \"%s\" in command line\n\n",argv[1]);
          usage(progname);
          exit(1);
      }
  }
  
  /* check law character */
  if (strcmp(argv[1], "u") == 0) {
      params->law = MODE_ULAW;
  }
  else if (strcmp(argv[1], "A") == 0) {
      params->law = MODE_ALAW;
  }
  else {
      fprintf(stderr, "Error in law character %s, ", argv[1]);
      fprintf(stderr, "law character must be A or u!!\n\n");
      usage(progname);
      exit(-1);
  }

  if (strcmp(argv[2], "-mode") == 0) {

      if (strcmp(argv[3], "1") == 0) {
          params->mode_bst = MODE_R1;
      }
      else if (strcmp(argv[3], "2") == 0) {
          params->mode_bst = MODE_R2a;
      }
      else if (strcmp(argv[3], "3") == 0) {
          params->mode_bst = MODE_R2b;
      }
      else if (strcmp(argv[3], "4") == 0) {
          params->mode_bst = MODE_R3;
      }
      else {
          fprintf(stderr, "Error in bitstream mode %s\n", argv[2]);
          fprintf(stderr, "Mode character must be 1, 2, 3 or 4!!\n\n");
          usage(progname);
          exit(-1);
      }
  }
  else {
      /* Display help message */
      fprintf(stderr, "Error in bitstream mode: '-mode' is needed.\n");
      usage(progname);
      exit(1);
  };      

  if (params->mode_dec == -1)
      params->mode_dec = params->mode_bst;

  /* Open input code, output signal files. */
  params->code_fname   = argv[4];
  params->output_fname = argv[5];

#ifdef APPENDIX_I_POSTFILTER
  if (params->postfilter_option != 0)
  {
      if (params->mode_dec == MODE_R1) {
          params->mode_dec = MODE_R1_POST;
      } else {
          fprintf(stderr, "ERROR: Option -r1pf is available for R1 only.\n");
          exit(1);
      }
  }
#endif
}

static void  trans_mode( int, int, unsigned char * );

/***************************************************************************
 * main()
 ***************************************************************************/
int
main(int argc, char *argv[])
{
  DECODER_PARAMS  params;
  int             nbitsIn;
  int             nbytesIn;
  int             nsamplesOut;
  FILE            *fpcode, *fpout;

  void            *theDecoder=0;

  int             status;
  short           sbufOut[NSamplesPerFrame16k];
#ifndef G711_LLC
  unsigned short  sbufIn[G192_HeaderSize+TotalBitsPerFrame];
#endif
  unsigned char   cbufIn[TotalBytesPerFrame];
  int             payloadsize;
  int             ploss_status=0;

#ifdef G711_LLC
  short           output_buffer_basicops[320], input_buffer_basicops[321+3], output_size;
  unsigned short  bytes_processed;
  unsigned int    input_size;
  unsigned char   packet_num, input_buffer[321], input_bit_buf[(TotalBytesPerFrame+1+1)*128], *input_ptr;
  int             i, j, law_mod, llc_bitlen, cur_packetlen, cur_framelen, framelen;
  unsigned char   cbufIn_buf[TotalBytesPerFrame*128], *buf_ptr, *ext_ptr;
  unsigned short  sbufIn[G192_HeaderSize+(TotalBitsPerFrame+8+8)*128];
#endif

#ifdef WMOPS
  short           Id = -1;
#endif

  /* Set parameters from argv[]. */
  get_commandlile_params( argc, argv, &params );

  if( params.mode_bst == MODE_R1 ) {
      nbitsIn  = NBitsPerFrame0;
      nbytesIn = NBytesPerFrame0;
  } else if( params.mode_bst == MODE_R2a ) {
      nbitsIn  = NBitsPerFrame0+NBitsPerFrame1;
      nbytesIn = NBytesPerFrame0+NBytesPerFrame1;
  } else if( params.mode_bst == MODE_R2b ) {
      nbitsIn  = NBitsPerFrame0+NBitsPerFrame2;
      nbytesIn = NBytesPerFrame0+NBytesPerFrame2;
  } else if( params.mode_bst == MODE_R3 ) {
      nbitsIn  = NBitsPerFrame0+NBitsPerFrame1+NBitsPerFrame2;
      nbytesIn = NBytesPerFrame0+NBytesPerFrame1+NBytesPerFrame2;
  } else {
      fprintf(stderr, "Mode error. Exiting.\n");
      exit(1);
  }

  if( params.mode_dec == MODE_R1 ) {
      nsamplesOut = NSamplesPerFrame8k;
#ifdef APPENDIX_I_POSTFILTER
  } else if( params.mode_dec == MODE_R1_POST ) {
      nsamplesOut = NSamplesPerFrame8k;
#endif
  } else if( params.mode_dec == MODE_R2a ) {
      nsamplesOut = NSamplesPerFrame8k;
  } else if( params.mode_dec == MODE_R2b ) {
      nsamplesOut = NSamplesPerFrame16k;
  } else if( params.mode_dec == MODE_R3 ) {
      nsamplesOut = NSamplesPerFrame16k;
  } else {
      fprintf(stderr, "Mode error. Exiting.\n");
      exit(1);
  }

  /* Open input bitstream */
  fpcode   = fopen(params.code_fname, "rb");
  if (fpcode == (FILE *)NULL) {
      fprintf(stderr, "file open error.\n");
      exit(1);
  }

  /* Open output speech file. */
  fpout  = fopen(params.output_fname, "wb");
  if (fpout == (FILE *)NULL) {
      fprintf(stderr, "file open error.\n");
      exit(1);
  }

  /* Instanciate an decoder. */
  theDecoder = G711wbeDecode_const(params.mode_dec, params.law);
  if (theDecoder == 0) {
      fprintf(stderr, "Decoder init error.\n");
      exit(1);
  }


  /* Reset (unnecessary if right after instantiation!). */
  G711wbeDecode_reset( theDecoder );


#ifdef G711_LLC

#ifdef WMOPS
  setFrameRate(16000, NSamplesPerFrame16k);
  Id = getCounterId("Decoder");
  setCounter(Id);
  Init_WMOPS_counter();
#endif

  while (1)
  {
#ifdef WMOPS
      setCounter(Id);
      fwc();
      Reset_WMOPS_counter();
#endif

	  if( params.format == 0 )    /* G.192 softbit output format */
      {
		  
		  /* Read G.192 header. */
          if (fread(sbufIn, sizeof(short), G192_HeaderSize, fpcode) ==  0)
              break;
          /* Check FER and payload size */
		  if ( sbufIn[idxG192_SyncHeader] == G192_SYNCHEADER )
		  {
			  payloadsize = sbufIn[idxG192_BitstreamLength];
		  }
		  else if ( sbufIn[idxG192_SyncHeader] != G192_SYNCHEADER_FER )
		  {
			  fprintf( stderr, "G192 format (header) error.\n");			  
		  }
          ploss_status = 0; /* False: No FER */
          IF( payloadsize <= 0 )  /* Frame erasure */
          {
              ploss_status = 1; /* True: FER */
          }
		  /* Read bitstream. */
		  if ( (input_size = fread(&sbufIn[G192_HeaderSize], sizeof(short), payloadsize, fpcode) ) ==  0)
			  break;
		  /* Check bit error */
		  for (i = G192_HeaderSize; i < (int)(G192_HeaderSize+payloadsize); i++)
		  {
			  if ( sbufIn[i] != G192_BITONE && sbufIn[i] != G192_BITZERO )
			  {
				  fprintf( stderr, "G192 format (bit) error. %d \n", i );
				  exit(1);
			  }
		  }
		  
		  if ( params.g711llc == 1 )
		  {
			  /* Convert from softbit to hardbit */
			  softbit2hardbit( payloadsize/8, &sbufIn[G192_HeaderSize], input_bit_buf); 
			  packet_num = input_bit_buf[0];
#ifdef WMOPS
			  setFrameRate(16000, NSamplesPerFrame16k*packet_num);
#endif		  
			  cur_packetlen = packet_num*5;
			  if ( cur_packetlen >= 40){
				  cur_framelen = 40;
			  }else if ( cur_packetlen >= 30){
				  cur_framelen = 30;
			  }else if ( cur_packetlen >= 20){
				  cur_framelen = 20;
			  }else if ( cur_packetlen >= 10){
				  cur_framelen = 10;
			  }else{
				  cur_framelen = 5;
			  }
			  buf_ptr = cbufIn_buf;
			  /* set mode(A/mu) for g.711.0 */
			  if (params.law == MODE_ALAW)
			  {
				  law_mod = 0;
			  }else{
				  law_mod = 1;
			  }		  
			  
			  llc_bitlen = (payloadsize-1)/8-(nbytesIn-NBytesPerFrame0)*packet_num;
			  
			  input_ptr = &input_bit_buf[1];
			  /* decode G.711.0 bitstream */
			  do {
				  
				  /*set max encoded bytes for special G711.0 frame length*/
				  framelen=cur_framelen*8+1;
				  for ( i=0; i < framelen; i++)
				  {
					  input_buffer_basicops[i] = input_ptr[i];
				  }			  
				  /* Decode the frame (memory -> memory) */
				  bytes_processed = (unsigned short) framelen;
				  output_size = g711llc_decode_frame(input_buffer_basicops, &bytes_processed, output_buffer_basicops, sizeof(output_buffer_basicops)/sizeof(output_buffer_basicops[0]), law_mod);
				  if (output_size <= 0) {
					  printf(" g711llc error!");
				  }
				  
				  /* Convert the output buffer from Word16 to unsigned char for fwrite() */		  
				  for (i=0; i<output_size; ++i)
				  {
					  buf_ptr[i] = (unsigned char)output_buffer_basicops[i];
					  
				  }
				  buf_ptr += output_size;
				  input_ptr += bytes_processed;
				  
				  /* check decode status */
				  if ( bytes_processed > (framelen))
				  {
					  printf(" decode error!");
				  }
				  
				  cur_packetlen -= cur_framelen;
				  while (cur_packetlen < cur_framelen){				  
					  if (cur_framelen > 10 ){
						  cur_framelen -= 10;
					  }else{
						  cur_framelen -= 5;
					  }
				  }
			  }while( cur_packetlen > 0);
			  
			  for (i=0; i< (nbytesIn-NBytesPerFrame0)*packet_num; i++)
			  {
				  buf_ptr[i] = input_bit_buf[i + llc_bitlen + 1];
			  }
			  
		  }else{
			  /* Convert from softbit to hardbit */
			  softbit2hardbit( payloadsize/8, &sbufIn[G192_HeaderSize], cbufIn_buf);
			  packet_num = payloadsize/(8*nbytesIn);
#ifdef WMOPS
			  setFrameRate(16000, NSamplesPerFrame16k*packet_num);
#endif		  

		  }
		  
	 }else{
		  if ( params.g711llc == 1 )
		  {
			  /* decode G.711.0 bitstream */
			  input_size = fread(&packet_num, sizeof(char), 1, fpcode);
#ifdef WMOPS
			  setFrameRate(16000, NSamplesPerFrame16k*packet_num);
#endif
			  if( input_size == 0 || (packet_num <= 0 || packet_num > 128) )
			  {
				  goto end_loop_de;
			  } else {	  
				  cur_packetlen = packet_num*5;
				  if ( cur_packetlen >= 40){
					  cur_framelen = 40;
				  }else if ( cur_packetlen >= 30){
					  cur_framelen = 30;
				  }else if ( cur_packetlen >= 20){
					  cur_framelen = 20;
				  }else if ( cur_packetlen >= 10){
					  cur_framelen = 10;
				  }else{
					  cur_framelen = 5;
				  }
				  buf_ptr = cbufIn_buf;
				  /* set mode(A/mu) for g.711.0 */
				  if (params.law == MODE_ALAW)
				  {
					  law_mod = 0;
				  }else{
					  law_mod = 1;
				  }				  
			  }
			  do {
				  
				  /*set max G711.0 encoded bytes for special frame length*/
				  framelen=cur_framelen*8+1;
				  if( ( input_size = fread(input_buffer, sizeof(char), framelen, fpcode) ) == 0)
				  {
					  goto end_loop_de;
				  }
				  
				  for ( i=0; i < framelen; i++)
				  {
					  input_buffer_basicops[i] = input_buffer[i];
				  }
				  
				  /* Decode the frame (memory -> memory) */
				  bytes_processed = (unsigned short)input_size;
				  output_size = g711llc_decode_frame(input_buffer_basicops, &bytes_processed, output_buffer_basicops, sizeof(output_buffer_basicops)/sizeof(output_buffer_basicops[0]), law_mod);
				  
				  if (output_size <= 0) {
					  printf(" g711llc error!");
				  }
				  
				  /* Convert the output buffer from Word16 to unsigned char for fwrite() */		  
				  for (i=0; i<output_size; ++i)
				  {
					  buf_ptr[i] = (unsigned char)output_buffer_basicops[i];

				  }
				  buf_ptr += output_size;
				  
				  /* check decode status */
				  if ( bytes_processed > input_size)
				  {
					  printf(" decode error!");
				  }
				  /* Adjust the file pointer in the input stream if needed */
				  if (input_size != bytes_processed) {
					  /* Seek backwards */
					  fseek(fpcode, (int)bytes_processed - (int)input_size, SEEK_CUR);
				  }
				  
				  cur_packetlen -= cur_framelen;
				  while (cur_packetlen < cur_framelen){				  
					  if (cur_framelen > 10 ){
						  cur_framelen -= 10;
					  }else{
						  cur_framelen -= 5;
					  }
				  }
			  }while( cur_packetlen > 0);

			  /*read the G.711.1 extension bitstream*/
			  fread(buf_ptr, sizeof(char), (nbytesIn - 40)*packet_num, fpcode);			  
		  }else{
			  /* Read bitstream. */
			  if (fread(cbufIn_buf, sizeof(char), nbytesIn, fpcode) ==  0)
				  break;
			  packet_num = 1;
		  }
       	  ploss_status = 0; /* False: No FER */
   		  /* When FER is detected, set ploss_status=1 */
	 }
	 
	 if ( params.g711llc == 1 ){
		 buf_ptr = cbufIn_buf;
		 ext_ptr = cbufIn_buf + packet_num*40 - 40;
		 for(i=0; i<packet_num; i++){
			 for (j=0; j<40; j++){
				 cbufIn[j] = buf_ptr[j];
			 }
			 buf_ptr += 40;
			 for (j; j<nbytesIn; j++){
				 cbufIn[j] = ext_ptr[j];
			 }

			 ext_ptr += (nbytesIn-40);
			 /* Mode translation from mode_bst to mode_dec */
			 if( (params.mode_bst != params.mode_dec) && ploss_status == 0 )
				 trans_mode( params.mode_bst, params.mode_dec, cbufIn );
			 
			 /* Decode. */
			 status = G711wbeDecode( cbufIn, sbufOut, theDecoder, ploss_status );
			 
			 if ( status ) {
				 fprintf(stderr, "Decoder NG. Exiting.\n");
				 exit(1);
			 }
			 /* Write output signal to fout. */
			 fwrite(sbufOut, sizeof(short), nsamplesOut, fpout);			  
		 }
	 }else{
		 buf_ptr = cbufIn_buf;
		 for ( i=0; i<packet_num; i++){			 
			 /* Mode translation from mode_bst to mode_dec */
			 if( (params.mode_bst != params.mode_dec) && ploss_status == 0 )
				 trans_mode( params.mode_bst, params.mode_dec, buf_ptr);
			 
			 /* Decode. */
			 status = G711wbeDecode( buf_ptr, sbufOut, theDecoder, ploss_status );
			 
			 if ( status ) {
				 fprintf(stderr, "Decoder NG. Exiting.\n");
				 exit(1);
			 }
			 /* Write output signal to fout. */
			 fwrite(sbufOut, sizeof(short), nsamplesOut, fpout);
			 buf_ptr += nbytesIn;
		 }
	 }
 }
end_loop_de:
#else

#ifdef WMOPS
  setFrameRate(16000, NSamplesPerFrame16k);
  Id = getCounterId("Decoder");
  setCounter(Id);
  Init_WMOPS_counter();
#endif
  
  while (1)
  {
#ifdef WMOPS
      setCounter(Id);
      fwc();
      Reset_WMOPS_counter();
#endif	 
     if( params.format == 0 )    /* G.192 softbit output format */
      {		
          /* Read bitstream. */
          if (fread(sbufIn, sizeof(short), G192_HeaderSize+nbitsIn, fpcode) ==  0)
              break;

          /* Check FER and payload size */
          payloadsize = checksoftbit( sbufIn );

          ploss_status = 0; /* False: No FER */
          IF( payloadsize <= 0 )  /* Frame erasure */
          {
              ploss_status = 1; /* True: FER */
          }

          /* Convert from softbit to hardbit */
          softbit2hardbit( nbytesIn, &sbufIn[G192_HeaderSize], cbufIn );
	 }else{
		 /* Read bitstream. */
		 if (fread(cbufIn, sizeof(char), nbytesIn, fpcode) ==  0)
			 break;
		 ploss_status = 0; /* False: No FER */
		 /* When FER is detected, set ploss_status=1 */
	 }
	 /* Mode translation from mode_bst to mode_dec */
	 if( (params.mode_bst != params.mode_dec) && ploss_status == 0 )
		 trans_mode( params.mode_bst, params.mode_dec, cbufIn );
	 
	 /* Decode. */
	 status = G711wbeDecode( cbufIn, sbufOut, theDecoder, ploss_status );
	 
	 if ( status ) {
		 fprintf(stderr, "Decoder NG. Exiting.\n");
		 exit(1);
	 }
	 /* Write output signal to fout. */
	 fwrite(sbufOut, sizeof(short), nsamplesOut, fpout);
 }
#endif

#ifdef WMOPS
  setCounter(Id);
  fwc();
  WMOPS_output(0);
#endif

  /* Close files. */
  fclose(fpcode);
  fclose(fpout);
  
  /* Delete the decoder. */
  G711wbeDecode_dest( theDecoder );

  return 0;
}

static void
copy_uchar( int n, unsigned char src[], unsigned char dst[] )
{
  int   i;
  for( i=0; i<n; i++ )  dst[i] = src[i];
}

static void
set_uchar( int n, int val, unsigned char buf[] )
{
  int   i;
  for( i=0; i<n; i++ )  buf[i] = (unsigned char)val;
}

static void
trans_mode(
  int           mode_src, 
  int           mode_dst, 
  unsigned char cbuf[]
) {
  unsigned char  cbuftmp[NBytesPerFrame1+NBytesPerFrame2];
  int            src, dst;

  src = NBytesPerFrame0;
  dst = 0;

  /* Copy lower-band enhancement layer data */
  if( mode_src == MODE_R3 || mode_src == MODE_R2a )
  {
      if( mode_dst == MODE_R3 || mode_dst == MODE_R2a ) {
          copy_uchar( NBytesPerFrame1, &cbuf[src], &cbuftmp[dst] );
          dst += NBytesPerFrame1;
      }
      src += NBytesPerFrame1;
  }
  else
  {
      if( mode_dst == MODE_R3 || mode_dst == MODE_R2a ) {
          set_uchar( NBytesPerFrame1, 0, &cbuftmp[dst] );
          dst += NBytesPerFrame1;
      }
  }

  /* Copy higher-band enhancement layer data */
  if( mode_src == MODE_R3 || mode_src == MODE_R2b )
  {
      if( mode_dst == MODE_R3 || mode_dst == MODE_R2b ) {
          copy_uchar( NBytesPerFrame2, &cbuf[src], &cbuftmp[dst] );
          dst += NBytesPerFrame2;
      }
  }
  else
  {
      if( mode_dst == MODE_R3 || mode_dst == MODE_R2b ) {
          set_uchar( NBytesPerFrame2, 0, &cbuftmp[dst] );
          dst += NBytesPerFrame2;
      }
  }

  copy_uchar( dst, cbuftmp, &cbuf[NBytesPerFrame0] );
}
