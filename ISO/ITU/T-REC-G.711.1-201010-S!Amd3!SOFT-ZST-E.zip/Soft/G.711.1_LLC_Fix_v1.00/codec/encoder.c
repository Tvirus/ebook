/* 
   ITU-T G.711.1-LLC ANSI-C Source Code
   Version: 1.0, 2010
*/
/*
 *------------------------------------------------------------------------
 *  File: encoder.c
 *  Function: G.711WBE encoder test program
 *------------------------------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stl.h"
#include "g711wbe.h"
#include "softbit.h"

/* G.711.0 */
#define G711_LLC
#ifdef G711_LLC
#include "g711llc_encoder.h"
#endif

/***************************************************************************
 * usage()
 ***************************************************************************/
static void usage(char progname[])
{
  fprintf(stderr, "\n");
  fprintf(stderr, " Usage: %s [-options] <law> <infile> <codefile>\n", progname);
  fprintf(stderr, "\n");
  fprintf(stderr, " where:\n" );
  fprintf(stderr, "   law         is the desired G.711 law (A or u).\n");
  fprintf(stderr, "   infile      is the name of the input file to be encoded.\n");
  fprintf(stderr, "   codefile    is the name of the output bitstream file.\n");
  fprintf(stderr, "\n");
  fprintf(stderr, " Options:\n");
  fprintf(stderr, "   -mode #     is the desired encoder mode (1, 2, 3, 4).\n");
  fprintf(stderr, "               1, 2, 3, 4 correspond to R1, R2a, R2b, R3 respectively.\n");
  fprintf(stderr, "               Default mode is R3.\n");
  fprintf(stderr, "   -nb         indicates that input signal is narrow band.\n");
  fprintf(stderr, "   -hardbit    Output bitstream file is in multiplexed hardbit format.\n");
#ifdef G711_LLC
  fprintf(stderr, "   -Fn #       Number of G.711.1 frames in one G.711.1-LLC frame��default: 1; maximum: 128.\n");
  fprintf(stderr, "   -g711llc    Combined with G711.0 codec mode.\n");  
#endif
  fprintf(stderr, "   -quiet      quiet processing.\n");
  fprintf(stderr, "\n");
}

typedef struct { 
#ifdef G711_LLC
  int  g711llc;
  int  packet;
#endif
  int  mode;
  int  quiet;
  int  format;
  unsigned short  inputSF;
  int  law;
  char *input_fname;
  char *code_fname;
} ENCODER_PARAMS;

static void  get_commandlile_params(
  int            argc,
  char           *argv[],
  ENCODER_PARAMS *params
) {
  char  *progname=argv[0];

  if (argc < 4) {
      usage(progname);
      exit(1);
  }

  /* Default mode */
  params->mode = MODE_R3;
  params->quiet = 0;
  params->format = 0;    /* Default is G.192 softbit format */
  params->inputSF = 16000;   /* Default is wideband input */
#ifdef G711_LLC
  params->g711llc = 0;
  params->packet = 1;
#endif

  /* Search options */
  while (argc > 1 && argv[1][0] == '-')
  {
      if (strcmp(argv[1], "-mode") == 0)
      {
          /* set the mode */
          if (strcmp(argv[2], "1") == 0) {
              params->mode = MODE_R1;
          }
          else if (strcmp(argv[2], "2") == 0) {
              params->mode = MODE_R2a;
          }
          else if (strcmp(argv[2], "3") == 0) {
              params->mode = MODE_R2b;
          }
          else if (strcmp(argv[2], "4") == 0) {
              params->mode = MODE_R3;
          }
          else
          {
              fprintf(stderr, "Error in mode character %s\n", argv[2]);
              fprintf(stderr, "Mode character must be R1, R2a, R2b or R3!!\n");
              exit(-1);
          }

          /* Move arg{c,v} over the option to the next argument */
          argc -=2;
          argv +=2;
      }
      else if (strcmp(argv[1],"-quiet") == 0) {
          /* Set the quiet mode flag */
          params->quiet=1;

          /* Move arg{c,v} over the option to the next argument */
          argc --;
          argv ++;
      }
      else if (strcmp(argv[1], "-hardbit") == 0) {
          params->format = 1;    /* Hardbit output format */
          /* Move arg{c,v} over the option to the next argument */
          argc --;
          argv ++;
      }
#ifdef G711_LLC
      else if (strcmp(argv[1], "-Fn") == 0) {
		  if( sscanf( argv[2], "%d", &(params->packet) )){
			  if (params->packet < 1 || params->packet > 128){
				  printf("G.711.1 frame number error in one G.711.1-LLC frame ! please input number between 1 and 128!\n");
				  usage(progname);
				  exit(1);
			  }
			  /* Move arg{c,v} over the option to the next argument */
			  argc -=2;
			  argv +=2;
		  }else{
			  /* Move arg{c,v} over the option to the next argument */
			  argc -=1;
			  argv +=1;
		  }
      }
      else if (strcmp(argv[1], "-g711llc") == 0) {
          params->g711llc = 1;    /* g711llc output format */
		  argc -=1;
		  argv +=1;
      }
#endif

      else if (strcmp(argv[1], "-nb") == 0) {
          params->inputSF = 8000;    /* Input signal is narrow band. */
          argc --;
          argv ++;
      }
      else if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "-?") == 0) {
          /* Display help message */
          usage(progname);
          exit(1);
      }
      else {
          fprintf(stderr, "ERROR! Invalid option \"%s\"\n\n",argv[1]);
          usage(progname);
          exit(1);
      }
  }
  
  /* check law character */
  if (strcmp(argv[1], "u") == 0) {
      params->law = MODE_ULAW;
  }
  else if (strcmp(argv[1], "A") == 0) {
      params->law = MODE_ALAW;
  }
  else {
      fprintf(stderr, "Error in law character %s\n", argv[1]);
      fprintf(stderr, "Law character must be A or u!!\n");
      exit(-1);
  }

  /* Open input signal and output code files. */
  params->input_fname  = argv[2/*++iargv*/];
  params->code_fname   = argv[3/*++iargv*/];
}

/***************************************************************************
 * main()
 ***************************************************************************/
int
main(int argc, char *argv[])
{
  int             i;
  ENCODER_PARAMS  params;
  int             nsamplesIn;
  int             nbitsOut;
  int             nbytesOut;
  FILE            *fpin, *fpcode;

  void            *theEncoder=0;

  int             status;
  short           sbufIn[NSamplesPerFrame16k];

#ifdef G711_LLC
  short           g711llc_input[320], output_buffer_basicop[321+3], output_size, output_size_sum, framelen;
  int             end_flag, law_mod, p, cur_packet, cur_framelen;
  unsigned char   packet_num, output_buf[321+3], cbufOut_buf[TotalBytesPerFrame*128], *buf_ptr, reorder_buf[TotalBytesPerFrame*128], *reorder_ptr;
  struct          g711llc_encoder encoder;
  unsigned short  sbufOut[G192_HeaderSize+(TotalBitsPerFrame+8)*128], *sbuf_ptr;
#else
  unsigned short  sbufOut[G192_HeaderSize+TotalBitsPerFrame];
#endif
  unsigned char   cbufOut[TotalBytesPerFrame];

#ifdef WMOPS
  short           Id = -1;
#endif

  /* Set parameters from argv[]. */
  get_commandlile_params( argc, argv, &params );

  if( params.inputSF == 8000 )
      nsamplesIn = NSamplesPerFrame8k;  /* Input sampling rate is 8 kHz */
  else
      nsamplesIn = NSamplesPerFrame16k; /* Input sampling rate is always 16 kHz */

  if( params.mode == MODE_R1 ) {
      nbitsOut  = NBitsPerFrame0;
      nbytesOut = NBytesPerFrame0;
  } else if( params.mode == MODE_R2a ) {
      nbitsOut  = NBitsPerFrame0+NBitsPerFrame1;
      nbytesOut = NBytesPerFrame0+NBytesPerFrame1;
  } else if( params.mode == MODE_R2b ) {
      nbitsOut  = NBitsPerFrame0+NBitsPerFrame2;
      nbytesOut = NBytesPerFrame0+NBytesPerFrame2;
  } else if( params.mode == MODE_R3 ) {
      nbitsOut  = NBitsPerFrame0+NBitsPerFrame1+NBitsPerFrame2;
      nbytesOut = NBytesPerFrame0+NBytesPerFrame1+NBytesPerFrame2;
  } else {
      fprintf(stderr, "Mode error. Exiting.\n");
      exit(1);
  }

  /* Open input speech file. */
  fpin = fopen(params.input_fname, "rb");
  if (fpin == (FILE *)NULL) {
      fprintf(stderr, "file open error.\n");
      exit(1);
  }

  /* Open output bitstream. */
  fpcode = fopen(params.code_fname, "wb");
  if (fpcode == (FILE *)NULL) {
      fprintf(stderr, "file open error.\n");
      exit(1);
  }

  /* Instanciate an encoder. */
  theEncoder = G711wbeEncode_const(params.inputSF, params.mode, params.law);
  if (theEncoder == 0) {
      fprintf(stderr, "Encoder init error.\n");
      exit(1);
  }



  /* Reset (unnecessary if right after instantiation!). */
  G711wbeEncode_reset( theEncoder );
#ifdef G711_LLC
  /* Initialize G.711.0 */
  g711llc_encoder_init(&encoder);

#ifdef WMOPS
  setFrameRate(16000, NSamplesPerFrame16k*params.packet);
  Id = getCounterId("Encoder");
  setCounter(Id);
  Init_WMOPS_counter();
#endif

  end_flag = 1;
  while (end_flag)
  {
#ifdef WMOPS
      setCounter(Id);
      fwc();
      Reset_WMOPS_counter();
#endif
	  packet_num=(unsigned char)params.packet;
	  buf_ptr = cbufOut_buf;

      for (p=0; p< packet_num; p++){
		  
		  /* Initialize sbuf[]. */
		  for (i=0; i<nsamplesIn; i++) sbufIn[i] = 0;
		  
		  /* Read input singal from fin */
		  if ( fread( sbufIn, sizeof(short), nsamplesIn, fpin ) == 0 ){
			  if (p == 0){
			     goto end_loop_en;
			  }else {
				 end_flag = 0;
    			 /* Encode. */
			     status = G711wbeEncode( sbufIn, cbufOut, theEncoder );
	 			 if ( status ) {
				    fprintf(stderr, "Encoder NG. Exiting.\n");
				    exit(1);
				 }
				 for (; p < packet_num; p++){					 
					 for ( i = 0 ; i < nbytesOut; i++){
					     buf_ptr[i] = cbufOut[i];
					 }
					 buf_ptr += nbytesOut;
				 }
				 break;
			  }
		  }else{
			  /* Encode. */
			  status = G711wbeEncode( sbufIn, cbufOut, theEncoder );
			  if ( status ) {
				  fprintf(stderr, "Encoder NG. Exiting.\n");
				  exit(1);
			  }else{
				  for (i=0; i< nbytesOut; i++)
				  {
					  buf_ptr[i] = cbufOut[i];
				  }
				  buf_ptr += nbytesOut;
			  }
		  }
	  }
	  if ( params.g711llc == 1 )
	  {
          /* reorder the G.711.1 bitstream */
          buf_ptr = cbufOut_buf;
		  reorder_ptr = reorder_buf;
          for (p=0; p<packet_num; p++){
			  for (i=0; i< 40; i++)
			  {
				  reorder_ptr[i] = buf_ptr[i];
				  
			  }
              buf_ptr += nbytesOut;
              reorder_ptr += 40;
		  }
		  
		  if (params.law == MODE_ALAW)
		  {
			  law_mod = 0;
		  }else{
			  law_mod = 1;
		  }
		  /*G.711.0 encode G.711 bits in G.711.1 core*/
		  cur_packet = params.packet*5;
		  if ( cur_packet >= 40){
			  cur_framelen = 40;
		  }else if ( cur_packet >= 30){
			  cur_framelen = 30;
		  }else if ( cur_packet >= 20){
			  cur_framelen = 20;
		  }else if ( cur_packet >= 10){
			  cur_framelen = 10;
		  }else{
			  cur_framelen = 5;
		  }
		  reorder_ptr = reorder_buf;
		  output_size_sum = 0;
		  
		  if( params.format == 0 )    /* G.192 softbit output format */
		  {
			  sbuf_ptr = &sbufOut[G192_HeaderSize];
			  /*Convert from hardbit to softbit for the number of G.711.1 frames*/
              hardbit2softbit( 1, &packet_num, sbuf_ptr);
			  sbuf_ptr += 8;
			  do {
				  framelen=cur_framelen*8;		 
				  for ( i=0; i<framelen; i++){
					  g711llc_input[i] = reorder_ptr[i];
				  }
				  reorder_ptr += framelen;
				  /* Encode the frame (memory -> memory) */
				  output_size = (short)g711llc_encode_frame(g711llc_input, framelen, output_buffer_basicop, sizeof(output_buffer_basicop)/sizeof(output_buffer_basicop[0]), law_mod, &encoder);
				  /* if replace it with assert function? */
				  if (output_size <= 0) {
					  printf(" g711llc error!");
				  }
				  
				  /* Convert the output buffer from Word16 to unsigned char for fwrite() */		  
				  for (i=0; i<output_size; ++i){
					  output_buf[i] = (unsigned char)output_buffer_basicop[i];
				  }
				  
				  /* G711.0 sum length */
				  output_size_sum += output_size;
				  
                  /* Convert from hardbit to softbit for G.711.0 bitstream. */
			      hardbit2softbit( output_size, output_buf, sbuf_ptr);
			      sbuf_ptr += output_size*8;
				  
				  cur_packet -= cur_framelen;
				  while (cur_packet < cur_framelen){				  
					  if (cur_framelen > 10 ){
						  cur_framelen -= 10;
					  }else{
						  cur_framelen -= 5;
					  }
				  }
			  }while( cur_packet > 0);			  
			  /* Write main header */
			  sbufOut[0] = G192_SYNCHEADER;
			  nbitsOut = (output_size_sum + (nbytesOut-40)*packet_num +1)*8;
			  sbufOut[idxG192_BitstreamLength] = nbitsOut; 
			  
			  /*Convert from hardbit to softbit for G.711.1 extension bits in G.711.1*/
			  buf_ptr = cbufOut_buf+40;
			  sbuf_ptr = &sbufOut[G192_HeaderSize + (output_size_sum+1)*8];
			  for (p=0; p<packet_num; p++){
	  			  hardbit2softbit( (nbytesOut-40), buf_ptr, sbuf_ptr);	
				  buf_ptr += nbytesOut;
				  sbuf_ptr += (nbytesOut-40)*8;
			  }
			  /* Write bitstream. */
			  fwrite( sbufOut, sizeof(short), G192_HeaderSize+nbitsOut, fpcode );
			  
		  }else{
			  /* output the number of G.711.1 frames in one G.711.1-LLC frame */			  
			  fwrite(&packet_num, sizeof(char), 1, fpcode);
			  do {
				  framelen=cur_framelen*8;		 
				  for ( i=0; i<framelen; i++){
					  g711llc_input[i] = reorder_ptr[i];
				  }
				  reorder_ptr += framelen;
				  /* Encode the frame (memory -> memory) */
				  output_size = (short)g711llc_encode_frame(g711llc_input, framelen, output_buffer_basicop, sizeof(output_buffer_basicop)/sizeof(output_buffer_basicop[0]), law_mod, &encoder);
				  /* if replace it with assert function? */
				  if (output_size <= 0) {
					  printf(" g711llc error!");
				  }
				  
				  /* Convert the output buffer from Word16 to unsigned char for fwrite() */		  
				  for (i=0; i<output_size; ++i){
					  output_buf[i] = (unsigned char)output_buffer_basicop[i];
				  }				  
				  
				  /* output G.711.0 bitstream */			  
				  fwrite( output_buf, sizeof(char), output_size, fpcode);
				  
				  cur_packet -= cur_framelen;
				  while (cur_packet < cur_framelen){				  
					  if (cur_framelen > 10 ){
						  cur_framelen -= 10;
					  }else{
						  cur_framelen -= 5;
					  }
				  }
			  }while( cur_packet > 0);		  
			  
			  /*output G.711.1 extension bits in G.711.1*/
			  buf_ptr = cbufOut_buf+40;
			  for (p=0; p<packet_num; p++){
				  fwrite( buf_ptr, sizeof(char), (nbytesOut- 40), fpcode);	
				  buf_ptr += nbytesOut;
			  }
		  }  
	  }else{
		  if( params.format == 0 )    /* G.192 softbit output format */
		  {
			  /* Write main header */
			  sbufOut[0] = G192_SYNCHEADER;
			  sbufOut[idxG192_BitstreamLength] = nbitsOut*packet_num;
			  /* Convert from hardbit to softbit. */
			  hardbit2softbit( nbytesOut*packet_num, cbufOut_buf, &sbufOut[G192_HeaderSize] );
			  /* Write bitstream. */
			  fwrite( sbufOut, sizeof(short), G192_HeaderSize+nbitsOut*packet_num, fpcode );
			  
		  }else{
			  fwrite( cbufOut_buf, sizeof(char), nbytesOut*packet_num, fpcode);
		  }
	  }
  }
end_loop_en: 

#else

#ifdef WMOPS
  setFrameRate(16000, NSamplesPerFrame16k);
  Id = getCounterId("Encoder");
  setCounter(Id);
  Init_WMOPS_counter();
#endif
  
  while (1)
  {
#ifdef WMOPS
      setCounter(Id);
      fwc();
      Reset_WMOPS_counter();
#endif
      /* Initialize sbuf[]. */
      for (i=0; i<nsamplesIn; i++) sbufIn[i] = 0;

      /* Read input singal from fin. */
      if ( fread( sbufIn, sizeof(short), nsamplesIn, fpin ) == 0 )
          break;

      /* Encode. */
      status = G711wbeEncode( sbufIn, cbufOut, theEncoder );
      if ( status ) {
          fprintf(stderr, "Encoder NG. Exiting.\n");
          exit(1);
      }

      if( params.format == 0 )    /* G.192 softbit output format */
      {
          /* Write main header */
          sbufOut[0] = G192_SYNCHEADER;
          sbufOut[idxG192_BitstreamLength] = nbitsOut;
          /* Convert from hardbit to softbit. */
          hardbit2softbit( nbytesOut, cbufOut, &sbufOut[G192_HeaderSize] );
          /* Write bitstream. */
          fwrite( sbufOut, sizeof(short), G192_HeaderSize+nbitsOut, fpcode );
      }
      else    /* Hardbit output format */
      {
          /* Write bitstream. */
          fwrite( cbufOut, sizeof(char), nbytesOut, fpcode );
      }
  }
#endif

#ifdef WMOPS
  setCounter(Id);
  fwc();
  WMOPS_output(0);
#endif

  /* Close files. */
  fclose(fpin);
  fclose(fpcode);
  
  /* Delete the encoder. */
  G711wbeEncode_dest( theEncoder );

  return 0;
}
