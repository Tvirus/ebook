/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: softbit.h
 *  Function: Header of conversion between hardbit and softbit
 *------------------------------------------------------------------------
 */

#ifndef SOFTBIT_H
#define SOFTBIT_H

#define G192_SYNCHEADER      (const unsigned short)0x6B21
#define G192_SYNCHEADER_FER  (const unsigned short)0x6B20
#define G192_BITONE          (const unsigned short)0x0081
#define G192_BITZERO         (const unsigned short)0x007F

#define idxG192_SyncHeader       0      /* Synchronization Header */
#define idxG192_BitstreamLength  1      /* Bitstream Length in soft bit */

#define G192_HeaderSize  (const unsigned int)(idxG192_BitstreamLength+1)

void hardbit2softbit(int, const unsigned char *, unsigned short *);
void softbit2hardbit(int, const unsigned short *, unsigned char *);
int  checksoftbit(const unsigned short *bitstream);
#endif
