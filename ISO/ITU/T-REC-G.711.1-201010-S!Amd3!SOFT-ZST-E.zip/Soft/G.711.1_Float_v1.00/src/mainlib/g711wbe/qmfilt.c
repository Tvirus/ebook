/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: qmfilt.c
 *  Function: Quadrature mirror filter (QMF)
 *            for band splitting and band reconstructing
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"

#define LFRAME_HALF    (L_FRAME_WB/2)
#define NTAP_QMF_HALF  (NTAP_QMF/2)
#define QMFBUFSIZE     (NTAP_QMF-2)

typedef struct
{
  Float   bufmem[QMFBUFSIZE];
} QMFilt_WORK;

/* Constructor */
void *QMFilt_const(void)
{                               /* returns pointer to work space */
  QMFilt_WORK *work = NULL;

  work = (QMFilt_WORK *) malloc(sizeof(QMFilt_WORK));
  if (work != NULL) {
    QMFilt_reset((void *)work);
  }

  return (void *)work;
}

/* Destructor */
void QMFilt_dest(void *ptr)
{
  QMFilt_WORK *work = (QMFilt_WORK *) ptr;

  if (work != NULL) {
    free(work);
  }
}

/* Reset */
void QMFilt_reset(void *ptr)
{
  int     i;
  QMFilt_WORK *work = (QMFilt_WORK *) ptr;

  if (work != NULL) {
    for (i = 0; i < QMFBUFSIZE; i++)
      work->bufmem[i] = 0;
  }
}

/* Band splitting */
void
QMFilt_ana(
  Float *insig,                /* (i): Input 16-kHz-sampled signal */
  Float *lsig,                 /* (o): Output lower-band signal    */
  Float *hsig,                 /* (o): Output higher-band signal   */
  void  *ptr                   /* (i/o): Work space                */
  )
{
  QMFilt_WORK *work = (QMFilt_WORK *) ptr;
  int     i, j;
  Float  *insigpt;
  Float   insigbf[L_FRAME_WB + QMFBUFSIZE];
  Float   acc0;
  Float   acc1;

  insigpt = insigbf;

  for (i = 0; i < QMFBUFSIZE; i++) {
    *insigpt++ = work->bufmem[i];
  }
  for (i = 0; i < L_FRAME_WB; i++) {
    *insigpt++ = insig[i];
  }

  for (i = 0; i < L_FRAME_WB; i += 2) {
    insigpt = insigbf + i;
    acc0 = 0;
    acc1 = 0;

    for (j = 0; j < NTAP_QMF_HALF; j++) {
      acc0 += fQmf0[j] * *(insigpt++);
      acc1 += fQmf1[j] * *(insigpt++);
    }

    *(lsig++) = (Float) roundFto16(acc0 + acc1);
    *(hsig++) = (Float) roundFto16(acc1 - acc0);
  }

  insigpt = insigbf + L_FRAME_WB;

  for (i = 0; i < QMFBUFSIZE; i++) {
    work->bufmem[i] = *insigpt++;
  }

  return;
}

/* Band reconstructing */
void
QMFilt_syn(
  Float *lsig,                 /* (i): Input lower-band signal      */
  Float *hsig,                 /* (i): Input higher-band signal     */
  Float *outsig,               /* (o): Output 16-kHz-sampled signal */
  void  *ptr                   /* (i/o): Pointer to work space      */
  )
{
  QMFilt_WORK *work = (QMFilt_WORK *) ptr;
  int     i, j;
  Float   buf_sum[LFRAME_HALF + NTAP_QMF_HALF - 1];
  Float   buf_dif[LFRAME_HALF + NTAP_QMF_HALF - 1];
  Float  *pbuf;
  Float  *pf_sum;
  Float  *pf_dif;
  Float   acc0;
  Float   acc1;

  pbuf = work->bufmem;
  pf_sum = buf_sum;
  pf_dif = buf_dif;

  /* copy from filter buffer */
  for (i = 0; i < NTAP_QMF_HALF - 1; i++) {
    *pf_sum++ = *pbuf++;
    *pf_dif++ = *pbuf++;
  }

  /* calculate sum/diff values */
  for (i = 0; i < LFRAME_HALF; i++) {
    *(pf_sum++) = lsig[i] + hsig[i];
    *(pf_dif++) = lsig[i] - hsig[i];
  }

  pf_sum = buf_sum;
  pf_dif = buf_dif;

  for (i = 0; i < LFRAME_HALF; i++) {
    acc0 = 0;
    acc1 = 0;

    for (j = 0; j < NTAP_QMF_HALF; j++) {
      acc0 += fQmf0[j] * pf_sum[j];
      acc1 += fQmf1[j] * pf_dif[j];
    }
    *(outsig++) = (Float) roundFto16(2.0f * acc1);
    *(outsig++) = (Float) roundFto16(2.0f * acc0);

    pf_sum++;
    pf_dif++;
  }

  /* copy to filter buffer */
  pbuf = work->bufmem;
  for (i = 0; i < NTAP_QMF_HALF - 1; i++) {
    *pbuf++ = *pf_sum++;
    *pbuf++ = *pf_dif++;
  }

  return;
}
