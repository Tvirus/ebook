/* 
 * ITU-T G.711.1 Floating-point implementation ANSI-C Source Code
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: g711wbeenc.c
 *  Function: G.711WBE encoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "prehpf.h"
#include "qmfilt.h"
#include "lowband.h"
#include "highband.h"

#define OK  0
#define NG  1

/* High-pass filter cutoff definition */
#define FILT_NO_8KHZ_INPUT   5
#define FILT_NO_16KHZ_INPUT  6

typedef struct
{
  Short   Mode;                 /* Encoding mode */
  Short   OpFs;                 /* Sampling frequency */
  void   *pHpassFiltBuf;        /* High-pass filter buffer */
  void   *QmfFiltBuf;           /* QMF buffer */
  void   *SubEncoderL;          /* Work space for lower-band sub-encoder */
  void   *SubEncoderH;          /* Work space for higher-band sub-encoder */
} G711wbeEncoder_WORK;

/*----------------------------------------------------------------
  Function:
    G.711WBE encoder constructor
  Return value:
    Pointer to work space
  ----------------------------------------------------------------*/
void   *
G711wbeEncode_const(
  unsigned short sampf,         /* (i): Input sampling rate (Hz) */
  int mode,                     /* (i): Encoding mode            */
  int law                       /* (i): G.711 law for core layer */
  )
{
  G711wbeEncoder_WORK *w = NULL;

  /* Static memory allocation */
  w = (void *)malloc(sizeof(G711wbeEncoder_WORK));
  if (w == NULL)
    return NULL;

  w->Mode = mode;
  w->OpFs = 16000;              /* Input sampling rate is always 16kHz */
  if (sampf == 8000) {
    w->OpFs = 8000;             /* Input sampling rate is 8 kHz */
  }
  if (w->Mode != MODE_R1 && w->Mode != MODE_R2a &&
      w->Mode != MODE_R2b && w->Mode != MODE_R3) {
    error_exit("Encoding mode error.");
  }

  w->pHpassFiltBuf = highpass_1tap_iir_const();
  if (w->pHpassFiltBuf == NULL)
    error_exit("HPF init error.");

  w->QmfFiltBuf = QMFilt_const();
  if (w->QmfFiltBuf == NULL)
    error_exit("QMF init error.");

  w->SubEncoderL = lowband_encode_const(law);
  if (w->SubEncoderL == NULL)
    error_exit("Lower band init error.");

  w->SubEncoderH = highband_encode_const();
  if (w->SubEncoderH == NULL)
    error_exit("Higher band init error.");

  G711wbeEncode_reset((void *)w);

  return (void *)w;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE encoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void
G711wbeEncode_dest(
  void *p_work                  /* (i): Work space */
  )
{
  G711wbeEncoder_WORK *w = (G711wbeEncoder_WORK *) p_work;

  if (w != NULL) {
    highpass_1tap_iir_dest(w->pHpassFiltBuf);
    QMFilt_dest(w->QmfFiltBuf);             /* QMF */
    lowband_encode_dest(w->SubEncoderL);    /* Lower band */
    highband_encode_dest(w->SubEncoderH);   /* Higher band */

    free(w);
  }
}

/*----------------------------------------------------------------
  Function:
    G.711WBE encoder reset
  Return value:
    OK
  ----------------------------------------------------------------*/
int
G711wbeEncode_reset(
  void *p_work                  /* (i/o): Work space */
  )
{
  G711wbeEncoder_WORK *w = (G711wbeEncoder_WORK *) p_work;

  if (w != NULL) {
    highpass_1tap_iir_reset(w->pHpassFiltBuf);
    QMFilt_reset(w->QmfFiltBuf);            /* QMF */
    lowband_encode_reset(w->SubEncoderL);   /* Lower band */
    highband_encode_reset(w->SubEncoderH);  /* Higher band */
  }
  return OK;
}

/*----------------------------------------------------------------
  Function:
    G.711WBE encoder
  Return value:
    OK/NG
  ----------------------------------------------------------------*/
int
G711wbeEncode(
  const short *inwave,
  unsigned char *bitstream,
  void *p_work)
{

  unsigned char *bpt = bitstream;

  Float   fSigInQMF[L_FRAME_WB];
  Float   fSubSigLow[L_FRAME_NB];
  Float   fSubSigHigh[L_FRAME_NB];

  G711wbeEncoder_WORK *w = (G711wbeEncoder_WORK *) p_work;

  if (p_work == NULL)
    return NG;

  /* ------------------------------- */
  /* Pre-processing & band splitting */
  /* ------------------------------- */
  if (w->OpFs == 8000) {        /* Narrow band input */
    /* High-pass filtering */
    highpass_1tap_iir(FILT_NO_8KHZ_INPUT,
                      L_FRAME_NB, (Short *) inwave,
                      fSubSigLow, w->pHpassFiltBuf);
  }
  else {                        /* w->OpFs == 16000 *//* Wideband input */
    /* High-pass filtering */
    highpass_1tap_iir(FILT_NO_16KHZ_INPUT,
                      L_FRAME_WB, (Short *) inwave,
                      fSigInQMF, w->pHpassFiltBuf);

    /* Band splitting with QMF */
    QMFilt_ana(fSigInQMF, fSubSigLow, fSubSigHigh, w->QmfFiltBuf);
  }

  /* ------------------------------------------------------------- */
  /* Lower-band encoder including both core and enhancement layers */
  /* ------------------------------------------------------------- */
  if ((w->Mode == MODE_R2a) || (w->Mode == MODE_R3)) {
    /* Core layer + Lower band enhancement layer */
    lowband_encode(fSubSigLow, bpt, bpt + NBytesPerFrame0, w->SubEncoderL);
    bpt += (NBytesPerFrame0 + NBytesPerFrame1);
  }
  else {                        /* w->Mode == MODE_R1 || w->Mode == MODE_R2b */
    /* Core layer only */
    lowband_encode(fSubSigLow, bpt, NULL, w->SubEncoderL);
    bpt += NBytesPerFrame0;
  }

  /* ------------------------------------- */
  /* Higher-band enhancement layer encoder */
  /* ------------------------------------- */
  if ((w->Mode == MODE_R2b) || (w->Mode == MODE_R3)) {
    if (w->OpFs == 8000) {
      zeroS(NBytesPerFrame2 / 2, (Short *) bpt);
    }
    else {
      highband_encode(fSubSigHigh, bpt, w->SubEncoderH);
    }
  }

  return OK;
}
