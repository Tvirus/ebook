/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: qmfilt.h
 *  Function: Header of quadrature mirror filter (QMF)
 *------------------------------------------------------------------------
 */

#ifndef QMFILT_H
#define QMFILT_H

#define NTAP_QMF  32

void *QMFilt_const(void);
void  QMFilt_dest(void *ptr);
void  QMFilt_reset(void *ptr);

void  QMFilt_ana(Float *insig, Float *lsig, Float *hsig, void *ptr);
void  QMFilt_syn(Float *lsig, Float *hsig, Float *outsig, void *ptr);

/* Floating point */
extern const Float fQmf0[NTAP_QMF / 2];
extern const Float fQmf1[NTAP_QMF / 2];

#endif
