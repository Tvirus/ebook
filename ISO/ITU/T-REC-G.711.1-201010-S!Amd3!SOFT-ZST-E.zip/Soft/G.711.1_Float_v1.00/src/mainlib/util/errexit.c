/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */

#include <stdio.h>
#include <stdlib.h>
#include "errexit.h"

void  error_exit( char *str )
{
  if ( str != NULL )
    fprintf( stderr, "%s\n", str );
  exit(1);
}
