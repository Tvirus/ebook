/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post.h
 *  Header: Header of main routine of the post-processing
 *------------------------------------------------------------------------
 */

#ifndef POST_H
#define POST_H
 
extern const  Short max_err_quant[16];

void postProc_Processing(Float  *bloc_in,
                         Float  *bloc_out,
                         VAR_MEM *var_mem,
                         Short  postfilter_sw,
                         Short  anaflag,
                         Float  *xl_nq);

#endif /* POST_H */
