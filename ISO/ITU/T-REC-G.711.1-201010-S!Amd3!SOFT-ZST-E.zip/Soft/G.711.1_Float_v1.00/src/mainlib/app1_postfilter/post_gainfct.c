/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_gainfct.c
 *  Function: Subroutines for estimating of the post-processing filter
 *------------------------------------------------------------------------
 */
#include "post_const.h"
#include "post_rfft.h"
#include "post_gainfct.h"

#include "floatutil.h"

static void   postProc_FFTtoPSD_F32(Float *fftIn, Float *specOut);
static void   postProc_SpecFilter32(Float *specIn, Float *W, Float *specOut);

/**
 * Initialisation of variables in the structure 
 */
void
postProc_InitGainProcess(
  VAR_GAIN *var_gain           /* I/O: VAR_GAIN state structure */
  )
{
  zeroF(NB_BINS, var_gain->S2_32);
}


/**
* Computation of a post-processing time filter (casual) that reduces the 
* quantization noise. The time filter is store in var_gain->h
*/
void
postProc_GainProcess(
  Float *X,                    /* IN:  FFT of "noised" signal */
  VAR_GAIN *var_gain,          /* I/O: VAR_GAIN state structure */
  VAR_ANASYNTH *var_anasynth   /* I/O: VAR_ANASYNTH state structure */
  )
{
  /* float interface variables */
  Float         W[L_FFT], PSD_N[NB_BINS], X2[NB_BINS];
  Float         energyFrame, SNRpost, SNRprio;

  /* end of float interface variables */
  Short         p, q, r;

  /* Variables loaded in the structure */
  Float        *h;
  Float        *x, *S2;

  h = var_gain->h;
  x = var_anasynth->x;
  S2 = var_gain->S2_32;

  /*-- Power Spectral Density of quantized ("noised") signal --*/
  /* X2 : Q[30+2*(X_shift-4)]
     -> X_shift = global shift done per frame before FFT computation
     -> 4 = 3+1 (3 = shift of the FFT, 1 = adding shift) */
  postProc_FFTtoPSD_F32(X, X2);


  /*-- Energy of the current frame --*/
  energyFrame = (Float) 0;
  /* The earliest samples are at the end of the window */
  for (p = L_WIN - FRAME_LGTH_POSTPROC; p < L_WIN; p++) {
    energyFrame += x[p] * x[p];
  }

  /* Load factor = sqrt(x_sat/sigma_x) = sqrt(1/sigma_x^2)
     an estimation of sigma_x = energyFrame/FRAME_LGTH_POSTPROC */

  /* Load factor = sqrt(FRAME_LGTH_POSTPROC/energyFrame)
     <=> loadFactor^2 = FRAME_LGTH_POSTPROC/energyFrame */

  /*-- Evaluation of the power of the quantization noise --*/
  if (energyFrame > UNIF_LOG_THRESH_FLT) {
    /* Logarithmic part of the curve: SQNR = contant */
    PSD_N[0] = energyFrame * NOISE_A_LAW_64K_FLT;
  }
  else {
    /* Uniform part of the curve --> PSD_N32[] constant 
       (SQNR decreases with the level of the signal) */
    /* Load factor threshold = 50 dB */
    if (energyFrame < DEC_ON_50DB_FLT) {
      /* 0.03162277660168 = -15 dB [Q31] */
      PSD_N[0] = energyFrame * (Float)0.03162277660168;
    }
    else {
      /* PSD_N32 = [ 1/((A/1+ln(A))*3*(2^(2*8))) ]
         --> (1/3145728) */
      PSD_N[0] = 341;       /*1/(Float)3145728; !!! */
    }
  }
  /*-- End of Evaluation of the power of the quantization noise --*/


  /*-- Evaluation of a priori SNR --*/

  /*---------------------------------------------------*/
  /* Filter computation in frequency domain : 1st step */
  /*---------------------------------------------------*/

  /* Loop over frequency channels */
  for (p = 0; p < NB_BINS; p++) {
    Float         denom;

    /*---------------------------------*/
    /* Computation of a posteriori SNR */
    /* SNRpost = X2[p] - PSD_N[0];   */
    /*---------------------------------*/
    SNRpost = X2[p] - PSD_N[0];

    /* Half wave rectification */
    if (SNRpost < (Float)0) {
      SNRpost = (Float)0;
    }

    /*---------------------------------------------*/
    /* A priori SNR computation          */
    /* SNRprio = beta*P_s_est[p] + betam1*SNRpost; */
    /*---------------------------------------------*/
    SNRprio = S2[p] - BETAM1_FLT * (S2[p] - SNRpost);

    /*--------------------------------------------*/
    /* Computation of filterW in frequency domain */
    /* W[p] = SNRprio/(SNRprio + PSD_N[0]);     */
    /*--------------------------------------------*/
    denom = SNRprio + PSD_N[0] + (Float)1e-16;
    W[p] = (Float)1;
    if (denom > (Float)0) {
      W[p] = SNRprio / denom;
    }
  }

  /*------------------------------------------------------*/
  /* Computation of filter in frequency domain : 2nd step */
  /*------------------------------------------------------*/

  /* Loop over frequency channels */
  for (p = 0; p < NB_BINS; p++) {
    Float         denom;

    SNRprio = W[p] * W[p] * X2[p];

    /*-----------------------------------------------------*/
    /* W[p] = Max( SNRprio/(SNRprio + PSD_N[0]) , W_MIN ); */
    /*-----------------------------------------------------*/
    denom = SNRprio + PSD_N[0] + (Float) 1e-16;
    if (denom > (Float) 0) {
      W[p] = SNRprio / denom;
    }
    W[p] = f_max(W[p], W16_MIN_FLT);
  }

  /*- If silent frame, a 20 dB attenuation is applied -*/
  if (energyFrame <= SILENCE_THRESH_FLT) {
    for (p = 0; p < NB_BINS; p++) {
      W[p] = (Float)0.25 * W[p];
    }
  }
  /*------------------------------------------------------------------------*/

  /*******************************************************************/
  /* Computation of an estimation of the PSD of the "cleaned" signal */
  /*******************************************************************/

  postProc_SpecFilter32(X2, W, S2);

  /************************************************/
  /* Computation of the filter in the time domain */
  /************************************************/

  /* iFFT */
  rsifft_64(W);

  /* Windowing + constraint on the symmetry of the filter */
  q = 0;
  r = L_FLT_DIV2;

  for (p = L_FLT_DIV2; p >= 0; p--) {
    h[p] = W[q] * WinFilt_flt[p];
    h[r] = h[p];
    q++;
    r++;
  }

  return;
}


/**
 * Squared module of a complex frequency table
 * [Re(0) Re(1) ... Re(N/2) Re(N/2+1) Im(N/2) ... Im(1)]
 */
static void
postProc_FFTtoPSD_F32(
  Float *FftIn,            /* IN:  Complex FFT of length L_FFT */
  Float *SpecOut           /* OUT: Power spectrum (length NB_BINS=L_FFT/2+1) */
  )
{
  Short         i, j;

  /* bin 0 and Fe/2 (index 0 and L_FFT_2) are real */
  SpecOut[0] = FftIn[0] * FftIn[0];
  SpecOut[L_FFT_DIV_2] = FftIn[L_FFT_DIV_2] * FftIn[L_FFT_DIV_2];

  /* other bins */
  j = L_FFT_M1;
  for (i = 1; i < L_FFT_DIV_2; i++) {
    /* specOut[i] = Re^2 + Im^2 = fftIn[i]*fftIn[i] + fftIn[j]*fftIn[j] */
    SpecOut[i] = FftIn[i] * FftIn[i] + FftIn[j] * FftIn[j];

    j--;
  }

  return;
}


/**
 * Filtering of the power spectrum by the transfert function W
 */
static void
postProc_SpecFilter32(
  Float *SpecIn,           /* IN:  Power spectrum to filter */
  Float *W,                /* IN:  Transfert function (real) of the filter */
  Float *SpecOut           /* OUT: Power spectrum fitered */
  )
{
  Short         i;

  /* bin 0 and Fe/2 (index 0 and L_FFT_2) are real */

  /* specOut = |W|^2 * specIn (specIn is already a power spectrum */
  for (i = 0; i < NB_BINS; i++) {
    /* specOut[i] = W*W*specIn[i] */
    SpecOut[i] = W[i] * W[i] * SpecIn[i];
  }

  return;
}
