/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: post_anasyn.c
 *  Function: Analysis/synthesis subroutines for post-processing
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "post_const.h"
#include "post_anasyn.h"
#include "post_rfft.h"


/**
 * Windowing of a signal of length L_WIN with the analysis window
 */
static void
postProc_WindowingAna(
  Float *DataIn_flt,           /* IN:  Input signal */
  Float *DataOut_flt           /* OUT: Output windowed signal */
  )
{
  Short         i;

  for (i = 0; i < L_WIN; i++) {
    DataOut_flt[i] = DataIn_flt[i] * Hann_flt[i];
  }

  return;
}


/**
* Initialization of the state structure VAR_ANASYNTH
*/
void
postProc_Init_anaSynth(
  VAR_ANASYNTH *var_anaSynth   /* OUT: VAR_ANASYNTH state structure */
  )
{
  zeroF(L_FFT, var_anaSynth->X);
  zeroF(L_WIN, var_anaSynth->x);
  zeroF(L_BUF_CIRC, var_anaSynth->buf_circ);
  zeroF(L_FLT, var_anaSynth->hOld);

  var_anaSynth->bottom = 0;
}


/**
 * Analysis of the current frame :
 *  1. Store new samples bloc_in in var_anaSynth->x
 *  2. Window the frame
 *  3. Compute the FFT (of the windowed frame), saved in var_anaSynth->X
 */
void
postProc_Analysis(
  const Float *bloc_in,      /* IN:  Block of new samples */
  VAR_ANASYNTH *var_anaSynth /* I/O: State structure of analysis/synthesis */
  )
{
  Short         p, q;
  Float        *x, *X;

  Float         xw[L_WIN];

  /* Loading of the state structure */
  x = var_anaSynth->x;
  X = var_anaSynth->X;

  /* Beginning */
  p = L_WIN - FRAME_LGTH_POSTPROC;
  for (q = 0; q < FRAME_LGTH_POSTPROC; q++) {
    x[p++] = bloc_in[q];
  }

  /* Scaling of data of x -> scaling is kept at this step of the fix to float
     conversion because FFT data are still stored as Word16 values in the
     state structure */

  /* Scaling of data + windowing */
  postProc_WindowingAna(x, xw);

  /* FFT */

  rfft_64(xw, X);

  return;
}


/**
* Reconstruction of the useful ("denoised") signal :
* 1. Filtering of the FRAME_LGTH_POSTPROC new samples with the filter h
* 2. Reconstruction of the useful signal with a time OLS (with interpolation)
*/
void
postProc_Synthesis(
  Float *bloc_out, /* OUT: Block of filtered samples */
  const Float *h,  /* IN:  Impulse response of the filter of the current frame */
  VAR_ANASYNTH *var_anaSynth
  /* IN:  State structure including the samples to filter */
  )
{
  Float        *x, *hOld, *buf_circ;
  Float         temp;

  Short         top;
  Short         p, q;
  Short        *bottom;

  /* Loading of the state structure */
  x = var_anaSynth->x;
  hOld = var_anaSynth->hOld;
  buf_circ = var_anaSynth->buf_circ;

  bottom = &(var_anaSynth->bottom);


  /*******************************************************/
  /* Filtering of the new samples with a circular buffer */
  /*******************************************************/
  q = L_WIN - FRAME_LGTH_POSTPROC;

  /* Loop over the samples */
  for (p = 0; p < NSAMP_INTERP_M1; p++) {
    temp = x[q];
    if (*bottom == L_FLT) {
      *bottom = 0;
    }
    top = *bottom + L_FLT;

    buf_circ[*bottom] = temp;
    buf_circ[top] = temp;

    (*bottom)++;
    q++;

    bloc_out[p] = postProc_Filter((Float *)h, &(buf_circ[top]), L_FLT);

    /* Interpolation on the first samples */
    temp = postProc_Filter(hOld, &(buf_circ[top]), L_FLT);
    bloc_out[p] = temp * Hann_p6m1_flt[p] + bloc_out[p] * Hann_p6_flt[p];

  } /* end of loop over the samples */

  /* Loop over the samples */
  for (p = NSAMP_INTERP_M1; p < FRAME_LGTH_POSTPROC; p++) {
    temp = x[q];
    if (*bottom == L_FLT) {
      *bottom = 0;
    }
    top = (*bottom) + L_FLT;
    buf_circ[top] = temp;
    buf_circ[*bottom] = temp;

    (*bottom)++;
    q++;

    bloc_out[p] = postProc_Filter((Float *)h, &(buf_circ[top]), L_FLT);
  } /* end of loop over the samples */


  /* Shift the frame for the next block */
  for (p = 0; p < L_WIN - FRAME_LGTH_POSTPROC; p++) {
    x[p] = x[p + FRAME_LGTH_POSTPROC];
  }

  /* Refresh the coefficients of the filter */
  for (p = 0; p < L_FLT; p++) {
    hOld[p] = h[p];
  }

  return;
}


/**
* Convolve the signal dataIn with the impulse response filter
*  out = sum_k { filter(k) * dataIn(-k) }
*/
Float
postProc_Filter(
  const Float *filter, /* IN: Impulse Response of the filter */
  const Float *dataIn, /* IN: Data to filter : points on the most recent data */
  Short filt_length    /* IN: Length of the filter (i) */
  )
{
  Float         accu;
  Short         k;

  accu = (Float) 0;

  for (k = 0; k < filt_length; k++) {
    accu += dataIn[-k] * filter[k];
  }
  return accu;
}
