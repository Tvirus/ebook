/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: fec_lowband.h
 *  Function: Frame erasure concealment (FERC) for lower-band signal
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "lpctool.h"
#include "fec_lowband.h"

#ifdef APPENDIX_I_POSTFILTER
#include "post_const.h"
#include "post.h"
#include "post_anasyn.h"
#include "post_gainfct.h"
#endif

#define L_FRAME2      (2*L_FRAME_NB)
#define L_AHEAD       40        /* Output speech is 1-frame delay. */
#define L_BUFF        (L_AHEAD+L_FRAME_NB)
#define RSX_LEN       5


/* Static memory allocated dynamically */
typedef struct _LBFEC_STATE
{
  Short   prev_bfi;             /* bad frame indicator of previous frame */

  /* analysis results (signal class, LPC coefficients, pitch delay) */
  Short   clas;                 /* unvoiced, weakly voiced, voiced, transient */
  Short   t0;                   /* pitch delay */
  Float   maxco;              /* correlation at pitch delay */

  /* variables for crossfade */
  Short   count_crossfade;      /* counter for cross-fading (number of samples) */

  /* variables for synthesis attenuation */
  Short   count_att;            /* counter for lower-band attenuation (number of samples) */
  Short   inc_att;              /* increment for counter update */

  Float   fact1;               /* increment for attenuation factor, first part of the curve */
  Float   fact2p;              /* additional increment for attenuation factor, 2nd part of the curve (attenuiation increment is fact1+fact2p) */
  Float   fact3p;              /* additional increment for attenuation factor, 3rd part of the curve (attenuiation increment is fact1+fact2p+fact3p) */
  Float   weight_lb;           /* attenuation factor */
  Float   factrho;


  /* coefficient of AR predictive filter A(z) */
  Float  *a;                    /* LPC coefficients */
  Float  *mem_syn;              /* past synthesis */

  /* signal buffers */
  Float  *mem_speech;           /* lower-band speech buffer */
  Float  *mem_exc;              /* past LPC residual */

  Float   fecbuf[L_BUFF];       /* for low band delay */
  Float  *nooffsig;             /* no offset signal */

#ifdef APPENDIX_I_POSTFILTER
  Short   postfilter_option;
  VAR_MEM *var_mem;
#endif

} LBFEC_STATE;

/***********************************
 * declaration of FERC subroutines *
 ***********************************/

/* lower-band analysis (main subroutine: LBFEC_ana) */
static Short LBFEC_classif_modif(LBFEC_STATE *state);
static void LBFEC_residu(LBFEC_STATE *state);
static void LBFEC_DC_remove(LBFEC_STATE *state);
static Float LBFEC_ltp_pred_1s(Float *exc, int t0, int *jitter);
static void LBFEC_ltp_syn(LBFEC_STATE *state, Float *cur_exc, Float *cur_syn, int n, int *jitter);
static void LBFEC_syn_filt(int m, Float *a, Float *x, Float *y, int n);
static void LBFEC_update_mem_exc(LBFEC_STATE *state, Float *cur_sig, int NumSamples);
static void LBFEC_syn(LBFEC_STATE *state, Float *syn_f, Short NumSamples);
static void LBFEC_attenuate(LBFEC_STATE *state, Float *cur_sig, Float *tabout, Short NumSamples, Short *ind, Float *weight);
static void LBFEC_attenuate_lin(LBFEC_STATE *state, Float fact, Float *cur_sig, Float *tabout, Short NumSamples, Short *ind, Float *weight);
static void LBFEC_calc_weight(Short *ind_weight, Float fact1, Float fact2p, Float fact3p, Float *weight);
static void LBFEC_lpc(LBFEC_STATE *state, Float *mem_speech);
static Short LBFEC_pitch_ol(Float *signal, Float *maxco);

static void Plc_resynchro(Float *conceal, Float *sp, Short clas);
static Float Sum_vect_E(const Float *vec, const Short lvec);
static void Resample_vector(Float *vect, Short n);


/************************************
 * definition of main FERC routines *
 ************************************/
/* Calculate energy ratio */
Float
get_E_ratio(
  /* OUT: ratio */
  Float vec_E1,                 /* IN: energy 1 */
  Float vec_E2                  /* IN: energy 2 */
  )
{
  //Word16  ratio;
  Float   ratio;            /* float version of ratio */
  Float   L_tmp1, L_tmp2;

  /* Calculate Maximum Normalized Correlation */
  L_tmp1 = (vec_E1 + 1.0f);
  L_tmp2 = (vec_E2 + 1.0f);

  /* ----------- Calculate Energy Ratio Part ----------- */
  if (L_tmp1 > L_tmp2) {        /* Numer must be the smallest for div_s */
    ratio = L_tmp2 / L_tmp1;
  }
  else {
    ratio = L_tmp1 / L_tmp2;
  }

  return ratio;
}


/* Constructor */
#ifdef APPENDIX_I_POSTFILTER
void   *
FEC_lowerband_const(
  Short postfilter_option)
#else
void   *
FEC_lowerband_const(
  void)                         /* OUT: state variables of FERC */
#endif
{
  LBFEC_STATE *state;

  /* allocate memory for FERC state */
  state = (LBFEC_STATE *) malloc(sizeof(LBFEC_STATE));
  if (state != NULL) {
    state->a = (Float *) calloc(ORD_LPC + 1, sizeof(Float));
    state->mem_syn = (Float *) calloc(ORD_LPC, sizeof(Float));
    /* signal buffers */
    state->mem_speech = (Float *) calloc(MEMSPEECH_LEN, sizeof(Float));
    state->mem_exc = (Float *) calloc(MAXPIT2P1, sizeof(Float));

    state->nooffsig = (Float *) calloc(MEMSPEECH_LEN, sizeof(Float));

#ifdef APPENDIX_I_POSTFILTER
    state->postfilter_option = postfilter_option;
    state->var_mem = NULL;
    if (postfilter_option != 0) {
      state->var_mem = (VAR_MEM *) malloc(sizeof(VAR_MEM));
    }
#endif
    FEC_lowerband_reset((void *)state);
  }

  return (void *)state;
}

/* Destructor */
void
FEC_lowerband_dest(
  void *ptr_work)
{                               /* OUT: state variables of FERC */
  LBFEC_STATE *state = (LBFEC_STATE *) ptr_work;

  if (state != NULL) {
    free(state->mem_speech);
    free(state->mem_exc);
    free(state->a);
    free(state->mem_syn);
    free(state->nooffsig);

#ifdef APPENDIX_I_POSTFILTER
    if (state->var_mem != NULL)
      free(state->var_mem);
#endif
    free(state);
  }
}

/* Reset */
void
FEC_lowerband_reset(
  void *ptr_work)
{                               /* OUT: state variables of FERC */
  Short   i;
  LBFEC_STATE *state = (LBFEC_STATE *)ptr_work;

  /* bad frame indicator */
  state->prev_bfi = 0;

  /* LPC, pitch, signal classification parameters */
  for (i = 0; i < ORD_LPC; i++) {
    state->mem_syn[i] = 0.0f;
    state->a[i] = 0.0f;
  }
  state->a[ORD_LPC] = 0.0f;

  state->t0 = (Short) 0;
  state->clas = LBFEC_WEAKLY_VOICED;

  for (i = 0; i < MEMSPEECH_LEN; i++) {
    state->mem_speech[i] = 0.0f;
  }
  for (i = 0; i < MAXPIT2P1; i++) {
    state->mem_exc[i] = 0.0f;
  }

  /* cross-fading counter */
  state->count_crossfade = CROSSFADELEN;        /*init */

  /* adaptive muting */
  state->count_att = (Short) 0;
  state->inc_att = 1;

  state->weight_lb = 1.0f;
  state->fact1 = (Float) FACT1_Vf;
  state->fact2p = (Float) FACT2P_Vf;
  state->fact3p = (Float) FACT3P_Vf;
  state->factrho = 0.0f;

  zeroF(L_BUFF, state->fecbuf);

#ifdef APPENDIX_I_POSTFILTER
  if (state->postfilter_option != 0) {
    postProc_Init_anaSynth(&(state->var_mem->var_anaSynth));
    postProc_InitGainProcess(&(state->var_mem->var_gain));
  }
#endif
}

/*----------------------------------------------------------------------
 * LBFEC_conceal_p1(fec_state, xl, xh, output, decoder)
 * 1st part of extrapolation of 1st erased frame
 *
 * fec_state (i/o) : state variables of FERC
 *---------------------------------------------------------------------- */
void
LBFEC_conceal_p1(
  void *fec_state)
{                               /* I/O: state variables of FERC */
  LBFEC_STATE *state = (LBFEC_STATE *) fec_state;

 /***********************
  * reset counter       *
  ***********************/

  state->count_crossfade = 0;   /* reset counter for cross-fading */
  state->count_att = 0;         /* reset counter for attenuation in lower band */
  state->weight_lb = 1.0f;     /* reset attenuation weight to 1 (Q15) */

  LBFEC_DC_remove(state);       /*remove DC, 50Hz high pass */

 /**********************************
  * analyze buffer of past samples *
  * - LPC analysis
  * - pitch estimation
  **********************************/


  /* perform 6th order LPC analysis on past valid decoded signal */
  LBFEC_lpc(state, state->nooffsig);
  /* estimate (open-loop) pitch */
  /* attention, may shift noofsig, but only used after for zero crossing rate not 
     influenced by this shift (except for very small values) */
  state->t0 =
    LBFEC_pitch_ol(state->nooffsig + MEMSPEECH_LEN - MAXPIT2, &state->maxco);

  return;
}

/*----------------------------------------------------------------------
 * LBFEC_conceal_p2(fec_state, xl, xh, output, decoder)
 * 2nd part of extrapolation of 1st erased frame
 *
 * fec_state (i/o) : state variables of FERC
 * output (o) :      synthesized signal for erased frame
 *---------------------------------------------------------------------- */
void
LBFEC_conceal_p2(
  void  *fec_state,            /* I/O: state variables of FERC */
  Float *output                /* OUT: synthesized signal for erased frame */
  )
{
  LBFEC_STATE *state = (LBFEC_STATE *)fec_state;

  Float   L_tmp1, L_tmp2;

  /* compute LPC residual signal */
  LBFEC_residu(state);

  /* update memory for LPC
     during ereased period the state->mem_syn contains the non weighted
     synthetised speech memory. For the    first erased frame, it
     should contain the output speech.
     Saves the last ORD_LPC samples of the output signal in
     state->mem_syn    */

  movF(ORD_LPC, &state->mem_speech[MAXPIT2P1], state->mem_syn);

  /* determine signal classification and modify residual in case of transient */
  state->clas = LBFEC_classif_modif(state);

  L_tmp1 =
    Sum_vect_E(&state->mem_speech[MEMSPEECH_LEN - state->t0], state->t0) + 1;
  L_tmp2 =
    Sum_vect_E(&state->mem_speech[MEMSPEECH_LEN - state->t0 * 2], state->t0) + 1;

  if ((L_tmp1 < L_tmp2) && ((L_tmp2 / 1024) > (state->t0 * 720))) {
    state->factrho = 1.0f - Sqrt(get_E_ratio(L_tmp1, L_tmp2));
    state->factrho /= (Float) state->t0;
  }
  else {
    state->factrho = 0.0f;
  }

 /*****************************
  * synthesize erased samples *
  *****************************/

  /* set increment for attenuation */
  if (state->clas == LBFEC_TRANSIENT) {
    /* attenuation in 15 ms */
    state->inc_att = 4;         /* time increment */
    state->fact1  = (Float)FACT1_V_Rf;  /* basic increment */
    state->fact2p = (Float)FACT2P_V_Rf; /* additional increment for 2nd linear part of attenuation function */
    state->fact3p = (Float)FACT3P_V_Rf; /* additional increment for last linear part of attenuation function */
  }
  else {
    /* attenuation in 60 ms */
    state->inc_att = 1;         /* time increment */
    state->fact1  = (Float)FACT1_Vf;  /* basic increment */
    state->fact2p = (Float)FACT2P_Vf; /* additional increment for 2nd linear part of attenuation function */
    state->fact3p = (Float)FACT3P_Vf; /* additional increment for last linear part of attenuation function */
  }

  /* shift low band memory */
  movF(MEMSPEECH_LEN_MFRAME, &state->mem_speech[L_FRAME_NB], state->mem_speech);    /*shift low band */

  /* synthesize lost frame (low band) */
  LBFEC_syn(state, output, L_FRAME_NB); /* xl : mem_speech[len] */

  /* attenuate synthesis filter */
  state->a[1] *= (Float)GAMMA_AZ1f;
  state->a[2] *= (Float)GAMMA_AZ2f;
  state->a[3] *= (Float)GAMMA_AZ3f;
  state->a[4] *= (Float)GAMMA_AZ4f;
  state->a[5] *= (Float)GAMMA_AZ5f;
  state->a[6] *= (Float)GAMMA_AZ6f;

  /* attenuate outputs */
  /*first lost frame : low complexity linear attenuation */
  LBFEC_attenuate_lin(state, state->fact1, output, output, L_FRAME_NB,
                      &state->count_att, &state->weight_lb);

  return;
}


/*----------------------------------------------------------------------
 * LBFEC_conceal_p3(fec_state, xl, xh, output, decoder)
 * extrapolation of 2nd (and consecutively) erased frames
 *
 * fec_state (i/o) : state variables of FERC
 * output (o) :      synthesized signal for erased frame
 *---------------------------------------------------------------------- */
void
LBFEC_conceal_p3(
  void  *fec_state,            /* I/O: state variables of FERC */
  Float *output                /* OUT: synthesized signal for erased frame */
  )
{
  LBFEC_STATE *state = (LBFEC_STATE *) fec_state;

  /* synthesize lost frame (low band) */
  LBFEC_syn(state, output, L_FRAME_NB);
  if (state->prev_bfi <= 1) {   /* 2nd lost frame : low complexity linear attenuation */
    LBFEC_attenuate_lin(state, state->fact1, output, output, L_FRAME_NB,
                        &state->count_att, &state->weight_lb);
  }
  else {                        /* attenuation, complete version */
    LBFEC_attenuate(state, output, output, L_FRAME_NB, &state->count_att,
                    &state->weight_lb);
  }
  return;
}


/**********************************
 * definition of FERC subroutines *
 **********************************/

/*-------------------------------------------------------------------------*
 * LBFEC_attenuate(state, in, out, n, count, weight)
 * linear muting with adaptive slope
 *
 * state (i/o) : FERC state variables
 * in    (i)   : input signal
 * out   (o)   : output signal = attenuated input signal
 * n     (i)   : number of samples
 * count (i/o) : counter
 * weight (i/o): muting factor
 *--------------------------------------------------------------------------*/
static void
LBFEC_attenuate(
  LBFEC_STATE *state,        /* I/O: state variables of FERC */
  Float *in,                 /* IN: input signal */
  Float *out,                /* OUT: attenuated signal */
  Short  n,                  /* IN: number of samples */
  Short *count,              /* I/O: counter of attenuated samples */
  Float *weight              /* I/O: attenuation factor */
  )
{
  int     i;

  if (state->prev_bfi == 5) {
    if (*weight < (Float) 0.9277) {
      if ((state->clas == LBFEC_VOICED)
          || (state->clas == LBFEC_WEAKLY_VOICED)) {
        state->fact3p = (Float) (*weight / 320.0 - 6.1035e-4);
        if (state->fact3p < 0) {
          state->fact3p = 0;
        }
      }
    }
  }

  for (i = 0; i < n; i++) {
    /* calculate attenuation factor and multiply */
    LBFEC_calc_weight(count, state->fact1, state->fact2p, state->fact3p,
                      weight);

    out[i] = *weight * in[i];
    *count += state->inc_att;
  }

  return;
}


/*-------------------------------------------------------------------------*
 * LBFEC_attenuate_lin(state, fact, in, out, n, count, weight)
 * linear muting with fixed slope (low complexity)
 *
 * state (i/o) : FERC state variables
 * fact  (i/o) : muting parameter
 * in    (i)   : input signal
 * out   (o)   : output signal = attenuated input signal
 * n     (i)   : number of samples
 * count (i/o) : counter
 * weight (i/o): muting factor
 *--------------------------------------------------------------------------*/
static void
LBFEC_attenuate_lin(
  LBFEC_STATE *state,        /* I/O: state variables of FERC */
  Float  fact,               /* IN: attenuation increment */
  Float *in,                 /* IN: input signal */
  Float *out,                /* OUT: attenuated signal */
  Short  n,                  /* IN: number of samples */
  Short *count,              /* I/O: counter of attenuated samples */
  Float *weight              /* I/O: attenuation factor */
  )
{
  int     i;

  if (state->factrho > fact) {
    fact = state->factrho;
  }

  for (i = 0; i < n; i++) {
    /* calculate attenuation factor and multiply */
    *weight -= fact;
    if (*weight < 0)
      *weight = 0;

    out[i] = *weight * in[i];
  }

  state->factrho = state->factrho / 2;

  *count += state->inc_att * n;

  return;
}


/*-------------------------------------------------------------------------*
 * LBFEC_calc_weight(ind_weight,fact1, fact2, fact3, weight)
 *                     
 * calculate attenuation factor
 *--------------------------------------------------------------------------*/
static void
LBFEC_calc_weight(
  Short *ind_weight,           /* I/O: counter of attenuated samples */
  Float  fact1,                /* IN: increment for attenuation factor, first slope */
  Float  fact2p,               /* IN: additional increment for 2nd slope */
  Float  fact3p,               /* IN: additional increment for 3rd slope */
  Float *weight                /* OUT: computed attenuation factor */
  )
{

  /*in version totally float both weight and slope variables will be 'Float's */

  *weight -= fact1;             /* increment composant for all slopes */
  if (*ind_weight >= END_1ST_PART) {
    *weight -= fact2p;          /* additional increment for 2nd slope */
  }
  if (*ind_weight >= END_2ND_PART) {
    *weight -= fact3p;          /* additional increment for 3rd slope */
  }
  if (*ind_weight >= END_3RD_PART) {
    *weight = 0;                /* complete muting */
  }
  if (*weight < 0) {            /* for security */
    *weight = 0;                /* complete muting */
  }
  if (*weight == 0) {           /* when complete muting is achived */
    *ind_weight = END_3RD_PART; /*stop counter (to avoid overflow) */
  }
  return;
}


/*--------------------------------------------------------------------------*
 * Function LBFEC_update_mem_exc                                            *
 * Update of state->mem_exc and shifts the memory                           *
 * if state->t0 > L_FRAME_NB                                                *
 *--------------------------------------------------------------------------*/
static void
LBFEC_update_mem_exc(
  LBFEC_STATE *state,          /* I/O: state variables of FERC */
  Float *exc,                  /* I: excitation signal to memorise */
  int n                        /* length of excitaion signal (frame length) */
  )
{

  Float  *ptr;
  int     temp;
  int     lag;

  /* shift ResMem, if t0 > l_frame */
  lag = state->t0 + T0_SAVEPLUS;        /*update temp samples */
  temp = lag - n;

  ptr = state->mem_exc + MAXPIT2P1 - lag;
  if (temp > 0) {               /*shift needed */
    movF(temp, &ptr[n], ptr);
    movF(n, exc, &ptr[temp]);
  }
  else {
    /* copy last "pitch cycle" of residual */
    movF(lag, &exc[(n - lag)], ptr);
  }
  return;
}


/* 50 Hz higgh pass filter to remove DC component*/
static void
LBFEC_DC_remove(
  LBFEC_STATE *state          /* I/O: state variables of FEC */
)
{                               
  int     i;


  Float  *mem_speech;
  Float  *nooffsig;

  mem_speech = state->mem_speech;
  nooffsig = state->nooffsig;

  /*offset removing for pitch estimation input */
  nooffsig[0] = mem_speech[0];

  for (i = 1; i < MEMSPEECH_LEN; i++) {
    nooffsig[i] =
      mem_speech[i] - mem_speech[i - 1] + (Float)0.97 * nooffsig[i - 1];
  }
}


/*----------------------------------------------------------------------
 * LBFEC_pitch_ol(signal, maxco)
 * open-loop pitch estimation
 *
 * signal      (i) : pointer to signal buffer (including signal memory)
 * maxco       (o) : maximal correlation
 *
 *---------------------------------------------------------------------- */
static Short
LBFEC_pitch_ol(
  /* OUT: repetition period (pitch lag) */
  Float * signal,               /* IN: pointer to signal buffer (including signal memory) */
  Float * maxco)
{                               /* OUT: maximal correlation */

  int     i, j, k, il;
  int     ind, ind2;
  int     zcr;
  int     start_ind, end_ind, beg_last_per, end_last_per;
  int     valid = 0;
  Float  *nooffsigptr, *ptr1;
  Float   ds_sig[MAXPIT2_DS];
  Float   temp;
  Float   ai[3] = { 1, 0, 0 };
  Float   cor[3], rc[3];
  Short   stable;
  Float   w_ds_sig[MAXPIT2_DS];
  Float   corx, ener1, ener2, em;
  Float  *pt1, *pt2;

  Float   sigbuf[MEMSPEECH_LEN];      /* (hidden input)    : IN: pointer to signal buffer (including signal memory),  normally allocated already in state */

  movF(MEMSPEECH_LEN, signal + MAXPIT2 - MEMSPEECH_LEN, sigbuf);

  nooffsigptr = sigbuf + MEMSPEECH_LEN - MAXPIT2;

  /* downsample (filter and decimate) signal by factor 4 */
  ptr1 = ds_sig;
  for (i = FACT_M1; i < MAXPIT2; i += FACT) {
    temp = nooffsigptr[i] * LBFEC_fir_lp_f[0];
    for (k = 1; k < FEC_L_FIR_FILTER_LTP; k++) {
      temp += nooffsigptr[i - k] * LBFEC_fir_lp_f[k];
    }
    *ptr1++ = temp;
  }

  //movFSQ(MAXPIT2_DS, ds_sig, ds_sig, 0);

  /* compute the autocorrelation function */
  Autocorr(ds_sig, &LBFEC_lpc_win_80_f[HAMWINDLEN - MAXPIT2_DS], cor, 2,
           MAXPIT2_DS);
  /* length = 72 samples, uses the end of the window of 80 samples */
  /* 60 Hz bandwidth expansion + 40 dB noise floor */
  Lag_window(cor, LBFEC_lag, 2);
  /* Levinson to compute the 2nd ordre LPC filter */
  Levinson(cor, rc, &stable, 2, ai);

  /* weighting by 0.94 */
  ai[1] *= (Float) 0.94;
  ai[2] *= (Float) 0.8836;

  /* filtering to obtaine the weighted signal */
  w_ds_sig[0] = ds_sig[0];

  w_ds_sig[1] = ds_sig[1] + ai[1] * ds_sig[0];

  for (i = 2; i < MAXPIT2_DS; i++) {
    w_ds_sig[i] =
      ds_sig[i] + ai[1] * ds_sig[i - 1] + ai[2] * ds_sig[i - 2];
  }

  ind = MAXPIT_S2_DS;           /*default value */
  ind2 = 0;                     /* initialise counter for multiple pitch */

  /* compute energy of signal in range [len/fac-1,(len-MAX_PIT)/fac-1] */
  ener1 = 1;
  for (j = MAXPIT2_DSM1; j >= MAXPIT_DSP1; j--) {
    ener1 += w_ds_sig[j] * w_ds_sig[j];
  }

  /* compute maximal correlation (maxco) and pitch lag (ind) */
  *maxco = 0;
  ener2 = ener1 - w_ds_sig[MAXPIT2_DSM1] * w_ds_sig[MAXPIT2_DSM1];      /*update, part 1 */

  /* search first zero-crossing */
  pt1 = &w_ds_sig[MAXPIT2_DSM1];
  pt2 = pt1 - 1;
  zcr = 0;
  j = 2;

  while (zcr == 0 && j < MAXPIT2_DSM1) {
    if (((int)*pt1 ^ (int)*pt2) < 0) {
      zcr = j;
    }
    pt1--;
    pt2--;
    j++;
  }

  for (i = 1; i < MAXPIT_DS; i++) {     /* < to avoid out of range later */
    ind2++;                     /* update counter for multiple pitch */
    corx = 0;

    for (j = MAXPIT2_DSM1; j >= MAXPIT_DSP1; j--) {
      corx += w_ds_sig[j] * w_ds_sig[j - i];
    }
    ener2 += w_ds_sig[MAXPIT_DSP1 - i] * w_ds_sig[MAXPIT_DSP1 - i];       /*update, part 2 */
    if (ener1 > ener2) {
      em = ener1;
    }
    else {
      em = ener2;
    }
    ener2 -= w_ds_sig[MAXPIT2_DSM1 - i] * w_ds_sig[MAXPIT2_DSM1 - i];     /*update, part 1 *//* BK bug correction, was 9 lines higher */
    if (corx > 0) {
      corx /= em;
    }

    if (corx < 0) {
      valid = 1;
      /* maximum correlation is only searched after the first positive lobe of autocorrelation function */
    }
    if (i < zcr) {              /*pitch must be grater then zcr (at least one zero crossing in a pitch period) */
      valid = 0;
    }
    if (valid == 1) {
      if ((ind2 == ind) || (ind2 == 2 * ind)) { /* double or triple of actual pitch */
        if (*maxco > 0.85) {  /* 0.85 : high correlation, small chance that double pitch is OK */
          *maxco = 1;         /* the already found pitch value is kept */
        }

        /*increase the already found maxco to avoid choosing the double pitch */
        *maxco *= (Float) 1.125;      /* BK : bug correction 04th April 2008, was 1.25 */
      }

      if ((corx > *maxco) && (i >= MINPIT_DS)) {
        *maxco = corx;
        ind = i;                /*save the new candidate */
        ind2 = 1;               /* reset counter for multiple pitch */
      }
    }
  }

  /* convert pitch to non decimated domain */
  il = 4 * ind;
  ind = il;

  /* refine pitch in non-decimated (8 kHz) domain by step of 1
     -> maximize correlation around estimated pitch lag (ind) */
  start_ind = il - 2;
  if (start_ind < MINPIT) {
    start_ind = MINPIT;
  }
  end_ind = il + 2;
  beg_last_per = MAXPIT2 - il;
  end_last_per = MAXPIT2 - 1;
  j = end_last_per - start_ind;
  ener1 = 1 + nooffsigptr[end_last_per] * nooffsigptr[end_last_per];  /*to avoid division by 0 */
  ener2 = 1 + nooffsigptr[j] * nooffsigptr[j];        /*to avoid division by 0 */
  for (j = end_last_per - 1; j > beg_last_per; j--) {
    ener1 += nooffsigptr[j] * nooffsigptr[j];
    ener2 += nooffsigptr[j - start_ind] * nooffsigptr[j - start_ind];
  }
  ener1 += nooffsigptr[j] * nooffsigptr[j];   /*last point for ener1, for ener2 it is done in update 2 */
  /* compute maximal correlation (maxco) and pitch lag (ind) */
  *maxco = 0;

  for (i = start_ind; i <= end_ind; i++) {
    corx = 0;

    ener2 += nooffsigptr[beg_last_per - i] * nooffsigptr[beg_last_per - i];   /*update, part 2 */
    for (j = end_last_per; j >= beg_last_per; j--) {
      corx += nooffsigptr[j] * nooffsigptr[j - i];
    }
    if (ener1 > ener2) {
      em = ener1;
    }
    else {
      em = ener2;
    }
    if (corx > 0) {
      corx /= em;
    }
    if (corx > *maxco) {
      ind = i;
      *maxco = corx;
    }
    ener2 -= nooffsigptr[end_last_per - i] * nooffsigptr[end_last_per - i];   /*update, part 1 */
  }
  if (*maxco < 0.25) {        /*very weakly or unvoiced signal */
    if (ind < 32) {
      ind *= 2;                 /*repetition period = 2 times pitch for very small pitch, at least 2 times MINPIT */
    }
  }

  if (*maxco > 1) {
    *maxco = 1;
  }

  return ind;
}


/*----------------------------------------------------------------------
 * LBFEC_classif_modif(maxco)
 * signal classification and conditional residual modification
 *
 *---------------------------------------------------------------------- */
static Short
LBFEC_classif_modif(
  LBFEC_STATE * state           /* I/O: state variables of FERC */
  )
{
  Float  *pt1, *pt2;
  int     zcr;
  int     i;
  Short   clas;
  Float   abs_mem_exc[MAXPIT + 4];
  int     Temp, tmp1, tmp2, tmp3, tmp4;
  Float   maxres, absres, absval;
  Float   mean;

  Float   maxpulse, maxpulse2nd;
  Float   cumul, pulsecumul;
  int     pulseind = 0;
  int     mincheck;
  int     end2nd;
  int     pulseind2nd = 0;
  int     signbit, signbit2nd;

  Float  *nooffsig;
  Float  *mem_exc;
  Float  *maxco;

  nooffsig = state->nooffsig;
  mem_exc = state->mem_exc;
  maxco = &state->maxco;

 /************************************************************************
  * select preliminary class => clas = UNVOICED, WEAKLY_VOICED or VOICED *
  * by default clas=WEAKLY_VOICED                                        *
  * classification criterio:                                             *
  * -normalized correlation from open-loop pitch                         *
  * -zero crossing rate                                                  *
  ************************************************************************/

  /* compute zero-crossing (from + to -) rate in last 5 ms */
  pt1 = &nooffsig[MEMSPEECH_LEN - 80];
  pt2 = pt1 - 1;
  zcr = 0;

  for (i = 0; i < 80; i++) {
    if ((*pt1 <= 0) && (*pt2 > 0)) {    /* aligned with previous expression? (yh) */
      zcr++;
    }
    pt1++;
    pt2++;
  }

  /* set default clas to weakly voiced */
  clas = LBFEC_WEAKLY_VOICED;

  /* detect voiced clas (cmaximum correlation > 0.7) */
  if (*maxco > 0.7) {         /* 22936 in Q15 = 0.7 */
    clas = LBFEC_VOICED;
  }

  /* change class to unvoiced if zcr is high */
  if (zcr >= 20) {
    clas = LBFEC_UNVOICED;
    /* change repetition period if unvoiced class (to avoid too short pitch lags) */
    if (state->t0 < 32) {
      state->t0 *= 2;           /*2 times pitch for very small pitch, at least 2 times MINPIT */
    }
  }

 /**************************************************************************
  * detect transient => clas = TRANSIENT                                   *
  * + modify residual to limit amplitude for LTP                           *
  * (this is performed only if current class is WEAKLY VOICED to avoid     *
  *  perturbation of the residual for LTP in case of VOICED class)         *
  *  UNVOICED class is smoothed differently, see below                     *
  **************************************************************************/

  /* detect transient and limit amplitude of residual */
  Temp = 0;
  if (clas == LBFEC_WEAKLY_VOICED) {    /*LBFEC_WEAKLY_VOICED(5) */
    tmp1 = MAXPIT2P1 - state->t0;       /* tmp1 = start index of last "pitch cycle" */
    tmp2 = tmp1 - state->t0;    /* tmp2 = start index of last but one "pitch cycle" */
    tmp3 = tmp2 - 2;            /* neighbourhood in the previous period: +-2 */
    tmp4 = state->t0 + 4;
    /*pre_compute abs values */
    for (i = 0; i < tmp4; i++) {
      abs_mem_exc[i] = abs_f(mem_exc[tmp3]);
      tmp3++;                   /*address */
    }

    for (i = 0; i < state->t0; i++) {
      /*maxres : maximum residual amplitude around the same position (+-2) in the previous pitch period */
      maxres = f_max(f_max(abs_mem_exc[i], abs_mem_exc[i + 1]),
                     f_max(abs_mem_exc[i + 2], abs_mem_exc[i + 3]));
      maxres = f_max(abs_mem_exc[i + 4], maxres);
      absres = abs_f(mem_exc[tmp1 + i]);

      /* if magnitude in last cycle > magnitude in last but one cycle */
      if (absres > maxres) {
        /* detect  and count transient (ratio >= 1/8) */
        if (absres >= 8 * maxres) {
          Temp++;
        }

        /* limit the amplitude of the repetition period (even if a transient is not detected...) */
        if (mem_exc[tmp1 + i] < 0) {
          mem_exc[tmp1 + i] = -maxres;
        }
        else {
          mem_exc[tmp1 + i] = maxres;
        }
      }
    }
  }

  if (clas == LBFEC_UNVOICED) { /*in case of unvoiced class */
    mean = 0;

    tmp1 = MAXPIT2P1 - 80;      /* tmp1 = start index of last 10 ms, last period is smoothed */
    for (i = 0; i < 80; i++) {
      mean += abs_f(mem_exc[tmp1 + i]);
    }
    mean /= 32;                 /*80/32 = "mean" contains 2.5 * mean amplitude */

    tmp1 = MAXPIT2P1 - state->t0;       /* tmp1 = start index of last "pitch cycle" */
    for (i = 0; i < state->t0; i++) {
      if (abs_f(mem_exc[tmp1 + i]) > mean) {  /* if current amplitude > 2.5 mean amplitude */
        mem_exc[tmp1 + i] /= 4;       /* current amplitude is divided by 4 */
      }
    }
  }
  if (Temp > 0) {               /* if at least one transient is detected */
    clas = LBFEC_TRANSIENT;
    if (state->t0 > 40) {
      state->t0 = 40;           /* max 5 ms pitch */
    }
  }

 /*******************************************************************************
  * pitch tuning by searching last glotal pulses in case of VOICED class        *
  * checks if there is no 2 pulses in the last periode due to pitch decreasing  *
  *******************************************************************************/
  if (clas == LBFEC_VOICED) {
    mincheck = state->t0 - 5;   /* max pitch variation searched is +-5 */
    maxpulse = -1;
    maxpulse2nd = -1;
    cumul = 0;
    pulsecumul = 0;

    pt1 = &mem_exc[MAXPIT2];  /* check the last period */
    for (i = 0; i < state->t0; i++) {
      absval = abs_f(*pt1);
      if (absval > maxpulse) {
        pulseind = i;           /* index of the biggest pulse */
        maxpulse = absval;
      }
      cumul += absval;          /* to compute the mean amplitude */
      pt1--;
    }
    pulsecumul = maxpulse * state->t0;

    if (mem_exc[MAXPIT2 - pulseind] < 0) {
      signbit = 1;              /* sign of the biggest pulse */
    }
    else {
      signbit = 0;
    }

    if (pulsecumul > 4 * cumul) {       /* if max amplitude > 4*mean amplitude --> real pulse */
      end2nd = pulseind - mincheck;
      if (end2nd >= 0) {        /* biggest pulse at the beggining of the last period */
        pt1 = &mem_exc[MAXPIT2];      /* end of excitation */
        for (i = 0; i < end2nd; i++) {  /* search 2nd pulse at the end of the period */
          absval = abs_f(*pt1);
          if (absval > maxpulse2nd) {
            pulseind2nd = i;    /* index of the 2nd biggest pulse */
            maxpulse2nd = absval;       /* amplitude of the 2nd biggest pulse */
          }
          pt1--;
        }
      }
      if (pulseind < 5) {       /* biggest pulse at the end of the last period */
        end2nd = state->t0 - 5 + pulseind;
        pt1 = &mem_exc[MAXPIT2 - end2nd];     /* end of excitation */
        for (i = end2nd; i < state->t0; i++) {  /* search 2nd pulse at the beggining of the period */
          absval = abs_f(*pt1);
          if (absval > maxpulse2nd) {
            pulseind2nd = i;    /* index of the 2nd biggest pulse */
            maxpulse2nd = absval;       /* amplitude of the 2nd biggest pulse */
          }
          pt1--;
        }
      }
      /* if the amplitude of the 2nd biggest pulse is at least the half of the biggest pulse */
      if (maxpulse2nd > maxpulse / 2) {
        if (mem_exc[MAXPIT2 - pulseind2nd] < 0) {
          signbit2nd = 1;       /* sign of the biggest pulse */
        }
        else {
          signbit2nd = 0;
        }
        if (signbit == signbit2nd) {    /* if signes are  identical */
          /* the new pitch value is the distance betwwen the two pulses */
          if (pulseind > pulseind2nd) {
            state->t0 = pulseind - pulseind2nd;
          }
          else {
            state->t0 = pulseind2nd - pulseind;
          }
        }
      }
    }
  }

  return clas;
}

/*----------------------------------------------------------------------
 * LBFEC_syn_filt(m, a, x, y, n n)
 * LPC synthesis filter
 *
 * m (i) : LPC order
 * a (i) : LPC coefficients
 * x (i) : input buffer
 * y (o) : output buffer
 * n (i) : number of samples
 *---------------------------------------------------------------------- */
static void
LBFEC_syn_filt(
  int m,                        /* IN:  LPC order */
  Float * a,                    /* IN:  LPC coefficients (Q12) */
  Float * x,                    /* IN:  input buffer (Q15) */
  Float * y,                    /* OUT: output buffer (Q15) */
  int n                         /* IN:  number of samples */
  )
{
  Float   L_temp;
  int     j;

  L_temp = a[0] * x[0];
  for (j = 1; j <= m; j++) {
    L_temp -= a[j] * y[-j];
  }
  y[0] = L_temp;

  return;
}

/*----------------------------------------------------------------------
 * LBFEC_ltp_pred_1s(cur_exc, t0, jitter)
 * one-step LTP prediction and jitter update
 *
 * exc     (i)   : excitation buffer (exc[...-1] correspond to past)
 * t0      (i)   : pitch lag
 * jitter  (i/o) : pitch lag jitter
 *---------------------------------------------------------------------- */
static Float
LBFEC_ltp_pred_1s(
  Float * exc,                  /* IN:  excitation buffer */
  int t0,                       /* IN:  repetition period (pitch lag) */
  int *jitter                   /* I/O: pitch lag jitter (+-1 or 0) */
  )
{
  int     i;

  i = *jitter - t0;

  /* update jitter for next sample */
  *jitter = -*jitter;

  /* prediction =  exc[-t0+jitter] */
  return exc[i];
}


/*----------------------------------------------------------------------
 * LBFEC_ltp_syn(state, cur_exc, cur_syn, n, jitter)
 * LTP prediction followed by LPC synthesis filter
 *
 * state    (i/o) : FERC state variables
 * cur_exc  (i)   : pointer to current excitation sample (cur_exc[...-1] correspond to past)
 * cur_syn  (i/o) : pointer to current synthesis sample
 * n     (i)      : number of samples
 * jitter  (i/o)  : pitch lag jitter
 *---------------------------------------------------------------------- */

static void
LBFEC_ltp_syn(
  LBFEC_STATE * state,          /* I/O: state variables of FERC */
  Float * cur_exc,              /* IN:  excitation buffer */
  Float * cur_syn,              /* I/O: synthetised signal buffer */
  int n,                        /* IN:  number of samples to synthetise */
  int *jitter                   /* I/O: pitch lag jitter (+-1 or 0) */
  )
{

  int     i;
  Float  *a;                  /* (i)  : lpc coefficients, normally just a pointer */

  a = state->a;

  for (i = 0; i < n; i++) {
    /* LTP prediction using exc[...-1] */
    *cur_exc = LBFEC_ltp_pred_1s(cur_exc, state->t0, jitter);

    /* LPC synthesis filter (generate one sample) */
    LBFEC_syn_filt(ORD_LPC, a, cur_exc, cur_syn, 1);

    cur_exc++;
    cur_syn++;
  }

  return;
}


/*----------------------------------------------------------------------
 * LBFEC_syn(state, syn, n)
 * extrapolate erased lower-band signal (FERC)
 *
 * state (i/o) : FERC state variables
 * syn   (o)   : synthesis
 * n     (i)   : number of samples
 *---------------------------------------------------------------------- */
static void
LBFEC_syn(
  LBFEC_STATE * state,          /* I/O: state variables of FERC */
  Float * syn_f,                /* OUT: synthetised signal buffer */
  Short n)
{                               /* IN:  number of samples to synthetise */
  Float   buffer_syn[2 * ORD_LPC];      /* synthesis buffer */
  Float   buffer_exc[MAXPIT + T0_SAVEPLUS + L_FRAME_NB];        /* excitation buffer */
  Float  *cur_syn;              /* pointer to current sample of synthesis */
  Float  *cur_exc;              /* pointer to current sample of excition */
  Float  *exc;                  /* pointer to beginning of excitation in current frame */
  int     temp;
  int     jitter;

  Float  *mem_syn;            /* (i)  : speech mem in state, normally float in state */
  Float  *mem_exc;            /* (o) : offset removed past speech in state, normally float in state  */

  mem_syn = state->mem_syn;
  mem_exc = state->mem_exc;

  temp = state->t0 + T0_SAVEPLUS;
  cur_exc = &buffer_exc[temp];
  cur_syn = &buffer_syn[ORD_LPC];
  exc = cur_exc;

  /* copy memory
     - past samples of synthesis (LPC order)            -> buffer_syn[0]
     - last "pitch cycle" of excitation (t0+t0SavePlus) -> buffer_exc[0]
   */
  movF(ORD_LPC, mem_syn, buffer_syn); /* load memory part of synthetised signal  */
  movF(temp, mem_exc + MAXPIT2P1 - temp, buffer_exc); /* load memory part of exitation signal  */

 /***************************************************
  * set pitch jitter according to clas information  *
  ***************************************************/

  jitter = 1;
  if (state->clas == LBFEC_VOICED) {
    jitter = 0;                 /*0 (not activated) for VOICED class */
  }
  state->t0 = state->t0 | jitter;       /* change even delay as jitter is more efficient for odd delays */

 /*****************************************************
  * generate signal by LTP prediction + LPC synthesis *
  *****************************************************/

  temp = n - ORD_LPC;
  /* first samples [0...ORD_LPC-1] */
  LBFEC_ltp_syn(state, cur_exc, cur_syn, ORD_LPC, &jitter);
  movF(ORD_LPC, cur_syn, syn_f);

  /* remaining samples [ORD_LPC...n-1] */
  LBFEC_ltp_syn(state, &cur_exc[ORD_LPC], &syn_f[ORD_LPC], temp, &jitter);

  /* update memory:
     - synthesis for next frame (last LPC-order samples)
     - excitation */
  movF(ORD_LPC, &syn_f[temp], state->mem_syn);
  LBFEC_update_mem_exc(state, exc, n);

  return;
}


/*--------------------------------------------------------------------------*
 * Function LBFEC_lpc                                                       *
 * LPC analysis                                                             *
 *--------------------------------------------------------------------------*/
static void
LBFEC_lpc(
  LBFEC_STATE * state,          /* I/O: state variables of FERC */
  Float * mem_speech            /* IN: past decoded speech */
  )
{
  Short   tmp;
  Float   cor[ORD_LPC + 1];
  Float   rc[ORD_LPC + 1];

  /* compute the autocorrelation function */
  Autocorr(&mem_speech[MEMSPEECH_LEN - HAMWINDLEN], LBFEC_lpc_win_80_f, cor,
           ORD_LPC, HAMWINDLEN);

  /* Lag windowing    */
  /*60 Hz bandwidth expansion + 40 dB noise floor */
  Lag_window(cor, LBFEC_lag, ORD_LPC);

  /* Levinson to compute the LPC filter */
  Levinson(cor, rc, &tmp, ORD_LPC, state->a);

  return;
}


/*-------------------------------------------------------------------------*
 * Function LBFEC_residu                                                *
 * compute the past excitation signal by incers LPC filtering               *
 *--------------------------------------------------------------------------*/

static void
LBFEC_residu(
  LBFEC_STATE * state)
{                               /* I/O: state variables of FERC */
  int     i, j;
  Float  *ptr_sig, *ptr_res;
  Float   L_temp;

  Float  *mem_speech;
  Float  *mem_exc;
  Float  *a;

  /* fix_float conversion */
  mem_speech = state->mem_speech;
  mem_exc = state->mem_exc;
  a = state->a;
  /* end fix_float conversion */

  ptr_res = mem_exc;          /* residual to compute */
  ptr_sig = &mem_speech[MEMSPEECH_LEN - MAXPIT2P1];   /*past decoded signal */

  for (i = 0; i < MAXPIT2P1; i++) {
    L_temp = ptr_sig[i] * a[0];
    for (j = 1; j <= ORD_LPC; j++) {
      L_temp += a[j] * ptr_sig[i - j];
    }
    ptr_res[i] = L_temp;
  }

  return;
}


/* Frame-erasure concealment procedure + dealy line for lower band */
void
FEC_lowerband(
  int loss_flag,                /* IN: indicate lost frame */
  Short * sigin,                /* IN: input decoded signal (in case of valid frame) */
  Float * sigout,               /* OUT: final lower band output signal */
  void *ptr_work                /* I/O: state variables of FERC */
  )
{
  Float   weight;
  Short   i;

  Float   crossfade_buf[CROSSFADELEN];
  Float  *spch, *spchnew;

#ifdef APPENDIX_I_POSTFILTER
  Short   anaflag;
  Float  *spchnew_post;
#endif

  LBFEC_STATE *state = (LBFEC_STATE *) ptr_work;

  Float   sp[L_FRAME_NB], rsx_buff[2 * L_FRAME_NB];

  spch = &state->fecbuf[L_BUFF - L_FRAME_NB - L_AHEAD];       /* future output to realise L_AHEAD delay */
  spchnew = &state->fecbuf[L_BUFF - L_FRAME_NB];      /* for "current" frame */


#ifdef APPENDIX_I_POSTFILTER
  spchnew_post = spchnew - L_FLT_DIV2;
  anaflag = 1;
#endif

  if (state->prev_bfi == 1) {   /*finish 1st erased frame concealment */
    LBFEC_conceal_p2(ptr_work, spchnew);        /* 2nd part of the 1st erased frame concealment */
    movF(L_FRAME_NB, spchnew, &(state->mem_speech[MEMSPEECH_LEN_MFRAME]));    /*save 5 ms */

#ifdef APPENDIX_I_POSTFILTER
    anaflag = 0;
    /* call R1 post-processing, effective when R1 post-procesing is activated in command line */
    postProc_Processing(spchnew, spchnew_post, state->var_mem,
                        state->postfilter_option, anaflag,
                        &(state->
                          mem_speech[MEMSPEECH_LEN_MFRAME - L_FLT_DIV2]));
#endif

    movF(L_BUFF - L_FRAME_NB, &state->fecbuf[L_FRAME_NB], &state->fecbuf[0]);       /*shift memory */
  }
  if (loss_flag == NO_FRAME_LOSS) {     /* Current frame not lost */
    /* shift speech buffers */
    movF(MEMSPEECH_LEN_MFRAME, &state->mem_speech[L_FRAME_NB], state->mem_speech);  /*shift 5 ms */
    i = 0;

    if (state->count_crossfade == 0) {  /* first good frame, crossfade is needed */
      /*FERC synthesize a new frame in parallel with the valid one */
      LBFEC_conceal_p3(ptr_work, crossfade_buf);

      /* prepare the buffers */
      movF(L_FRAME_NB, spch, rsx_buff);
      movF(L_FRAME_NB, crossfade_buf, rsx_buff + L_FRAME_NB);
      movSF(L_FRAME_NB, sigin, sp);

      /* do the resynchro */
      Plc_resynchro(rsx_buff, sp, state->clas);

      /* copy back the resynchronized concealement */
      movF(L_FRAME_NB, rsx_buff, spch);
      movF(L_FRAME_NB, rsx_buff,
           &state->mem_speech[MEMSPEECH_LEN_MFRAME - L_FRAME_NB]);
      movF(L_FRAME_NB, rsx_buff + L_FRAME_NB, crossfade_buf);

      weight = (Float) 0.025;   /*32768/40 */

      for (i = 0; i < CROSSFADELEN; i++) {
        /* cross-fade samples with FERC synthesis (in lower band only) */
        spchnew[i] = (sigin[i] * weight + crossfade_buf[i] * (1 - weight));
        weight += (Float) 0.025;
      }
      state->count_crossfade = CROSSFADELEN;
    }

    for (; i < L_FRAME_NB; i++) {       /*no crossfade is needed */
      /* simple copy of valid input */
      spchnew[i] = (Float) sigin[i];
    }
    movF(L_FRAME_NB, spchnew, &(state->mem_speech[MEMSPEECH_LEN_MFRAME]));    /*save 5 ms */
    state->prev_bfi = 0;        /* set previous bfi to good frame */
  }
  else {                        /* Current frame lost */
    if (state->prev_bfi == 0) { /*previous frame was valid : first lost frame */
      /* call first part  of the 1st erased frame concealment (no output samples yet) */
      LBFEC_conceal_p1(ptr_work);
      state->prev_bfi = 1;      /* set previous bfi to first bad frame */
    }
    else {
      movF(MEMSPEECH_LEN_MFRAME, &state->mem_speech[L_FRAME_NB], state->mem_speech);        /*shift */
      /* FERC synthesize a new frame */
      LBFEC_conceal_p3(ptr_work, spchnew);

      state->prev_bfi += 1;     /* update bad frame counter */

      movF(L_FRAME_NB, spchnew, &(state->mem_speech[MEMSPEECH_LEN_MFRAME]));  /*save 5 ms */
    }
  }

#ifdef APPENDIX_I_POSTFILTER
  if (state->prev_bfi != 1) {   /*1st erased frame concealment to finish if == 1 */
    /* call R1 post-processing, effective when R1 post-procesing is activated in command line */
    postProc_Processing(spchnew, spchnew_post, state->var_mem,
                        state->postfilter_option, anaflag,
                        &(state->
                          mem_speech[MEMSPEECH_LEN_MFRAME - L_FLT_DIV2]));
  }
#endif

  /* Copy buffer data to output buffer */
  /* Output speech is L_AHEAD delayed. */
  /* final output is the last but one lower band frame to be synchronise with higher band */
  movF(L_FRAME_NB, spch, sigout);

  /* Update wave buffer. */
  if (state->prev_bfi != 1) {   /*1st erased frame concealment to finish if == 1 */
    movF(L_BUFF - L_FRAME_NB, &state->fecbuf[L_FRAME_NB],
         &state->fecbuf[0]);
  }
}


/*-----------------------------------------------------------------*
 *   Funtion  fec_resynchro                                        *
 *            ~~~~~~~~~~~~~~~~                                     *
 *   - Resynchronization after FERC                                *
 *-----------------------------------------------------------------*/
static void
Plc_resynchro(
  Float * conceal,              /* I/O: pointer to buffer with concealed speech (and extrapolated conc.) */
  Float * sp,                   /* IN:  pointer to buffer with newly decoded speech */
  Short clas                    /* IN:  last class */
  )
{
  Float   L_vec_E1, L_vec_E2;
  Float   incr;
  Float   coef;
  Short   len;
  Float   ratio;

  Short   i, j, j_win;
  Float  *pt_end, *pt1, *pt2, c, c_max, enr1, enr2, e_ratio;
  Float   Fconceal[2 * L_FRAME_NB], Fsp[L_FRAME_NB];

  movF(2 * L_FRAME_NB, conceal, Fconceal);
  movF(L_FRAME_NB, sp, Fsp);

  /* initialize pointer to the end of the buffer */
  pt_end = Fconceal + L_FRAME_NB;

  /* calculate correlation between the extra frame and the received frame */
  /* - only in a limited range */
  c_max = 1e-30f;
  j_win = 0;
  for (j = -RSX_LEN; j <= RSX_LEN; j++) {
    pt1 = pt_end + j;
    pt2 = Fsp;
    c = 0;
    for (i = 0; i < L_FRAME_NB - RSX_LEN; i++) {
      c += *pt1++ * *pt2++;
    }
    if (c > c_max) {
      j_win = j;
      c_max = c;
    }
  }

  /* calculate maximum normalized correlation */
  enr1 = Sum_vect_E(pt_end + j_win, L_FRAME_NB - RSX_LEN) + 1.0f;
  enr2 = Sum_vect_E(Fsp, L_FRAME_NB - RSX_LEN) + 1.0f;
  c_max *= 1.0f / Sqrt(enr1 * enr2);
  j_win = -j_win;
  if (enr2 > enr1) {
    e_ratio = enr2 / enr1;
  }
  else {
    e_ratio = enr1 / enr2;
  }

  /* do resynchronization, if required */
  if ((clas == LBFEC_VOICED) && (c_max > 0.7f) && (e_ratio < 2.0f)) {
    Resample_vector(conceal, j_win);
  }


  L_vec_E1 = enr1;
  L_vec_E2 = enr2;
  ratio = 1.0f / e_ratio;

  if (L_vec_E1 > L_vec_E2) {
    len = L_FRAME_NB + CROSSFADELEN;
    incr = Sqrt(1 - ratio);
    incr /= 80.0f;              /* 409 = 32767 / 40 * 2 */
    coef = 1.0f - incr;

    for (i = 0; i < len; i++) {
      conceal[i] *= coef;
      coef -= incr;
    }
  }
}


/*---------------------------------------------------------------------*
 * procedure   Sum_vect_E:                                     
 *             ~~~~~~~~~~                                    
 *  Find vector energy
 *---------------------------------------------------------------------*/
static Float
Sum_vect_E(
  /* OUT:   return calculated vector energy */
  const Float * vec,            /* IN:   input vector                     */
  const Short lvec              /* IN:   length of input vector           */
  )
{
  Short   j;
  Float   L_sum;

  L_sum = (*vec) * (*vec);
  for (j = 1; j < lvec; j++) {
    L_sum = L_sum + vec[j] * vec[j];
  }
  return L_sum;
}


/*---------------------------------------------------------------------*
 * routine Resample_vector()                                           *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 * adds/removes samples from a vector, thereby changing its size       *
 *---------------------------------------------------------------------*/
static void
Resample_vector(
  Float * vect,                 /* I/O: vector to be resampled */
  short n                       /* IN:   number of samples to be added/removed */
  )
{
  Float   f, delta, pos, new_sig[L_FRAME_NB2];
  Short   i, lim, i_pos;

  if (n == 0)
    return;

  new_sig[0] = vect[0];
  delta = (L_FRAME_NB2 - n - 1) / (Float) (L_FRAME_NB2 - 1);
  pos = delta;

  lim = n > 0 ? 0 : -n;

  for (i = 1; i < L_FRAME_NB2 - lim; i++) {
    i_pos = (Short) pos;
    f = pos - i_pos;

    new_sig[i] = (1 - f) * vect[i_pos] + f * vect[i_pos + 1];
    pos += delta;
  }

  movF(L_FRAME_NB2, new_sig, vect);
  zeroF(lim, vect + L_FRAME_NB2 - lim);
}

/* returns the low band pitch lag*/
Short
get_lb_pit(
  void *pFECWork)
{
  LBFEC_STATE *pFEC = (LBFEC_STATE *) pFECWork;

  return pFEC->t0;
}
