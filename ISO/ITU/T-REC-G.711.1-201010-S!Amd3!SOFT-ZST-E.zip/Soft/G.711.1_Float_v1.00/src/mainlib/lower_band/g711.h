/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: g711.h
 *  Function: Header of embedded lower-band PCM coders
 *------------------------------------------------------------------------
 */

#ifndef G711_H
#define G711_H


Short convertLin_ALaw(Short x, Short *ind2, Short *xq, Short* expo);
Short convertALaw_Lin(Short ind, Short *expo, Short* signo);
Short convertALaw_Lin_enh(Short code2, Short exp, Short sign, Short numbits);

Short convertLin_MuLaw(Short x, Short *ind2, Short *xq, Short* expo);
Short convertMuLaw_Lin(Short ind, Short *expo, Short* signo);
Short convertMuLaw_Lin_enh(Short code2, Short exp, Short sign, Short numbits);

#endif
