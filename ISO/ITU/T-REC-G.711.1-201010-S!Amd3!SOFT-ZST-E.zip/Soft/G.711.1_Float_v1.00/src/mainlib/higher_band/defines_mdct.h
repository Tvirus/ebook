/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: defines_mdct.h
 *  Function: MDCT constants
 *------------------------------------------------------------------------
 */

#ifndef DEFINES_MDCT_H
#define DEFINES_MDCT_H

/* constants for MDCT and inverse MDCT */
#define MDCT_L_WIN    80
#define MDCT_L_WIN2   40
#define MDCT_L_WIN4   20
#define MDCT_NP        5
#define MDCT_EXP_NPP   2
#define MDCT_NB_REV    1
#define MDCT_NPP      (1<<MDCT_EXP_NPP)

#endif /* DEFINES_MDCT_H */
