/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: cfft.h
 *  Function: complex FFT headers
 *------------------------------------------------------------------------
 */

#ifndef CFFT_H
#define CFFT_H

/* Functions : */
void cfft(Float * x1, Float * x2, Short sign);

/* Tables : */
extern const Short MDCT_tab_map[MDCT_NP * MDCT_NPP];
extern const Short MDCT_tab_map2[MDCT_NP * MDCT_NPP];
extern const Short MDCT_tab_rev_i[MDCT_NB_REV];
extern const Short MDCT_tab_rev_ipp[MDCT_NB_REV];
extern const Float MDCT_rw1[MDCT_L_WIN4];
extern const Float MDCT_rw2[MDCT_L_WIN4];
extern const Float MDCT_xcos[25];
extern const Float MDCT_xsin[25];

#endif /* CFFT_H */
