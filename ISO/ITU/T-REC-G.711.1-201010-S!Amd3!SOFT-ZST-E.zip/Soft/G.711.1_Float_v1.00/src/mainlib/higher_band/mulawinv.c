/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: mulawinv.c
 *  Function: Mu-law expansion
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Mu-law expansion of gain, 8bit, u=255
  Return value
    Reconstructed value in linear scale
  ----------------------------------------------------------------*/
Short mulawinv (
  Short  index
) {
  Short  mantissa;
  Short  exponent;
  Short  logbuf;
  Short  linbuf;

  logbuf = index & 0x00ff;

  if (logbuf < 4) {
    linbuf = logbuf & 0x0003;
  }
  else {
    logbuf -= 3;
    exponent = (logbuf >> 5) & 0x0007;
    mantissa = logbuf & 0x001f;
    linbuf = (((mantissa << 2) + 130) << exponent) - 130;
  }

  return linbuf;
}
