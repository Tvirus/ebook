/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: vq_preselect.c
 *  Function: Pre-selection of Interleave CSVQ
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

#define BLOCKSIZE  (CB_SIZE/N_CAN)  /* = 4 */

/*----------------------------------------------------------------
  Function:
    Pre-selection of Interleave CSVQ
  Return value:
    None
  ----------------------------------------------------------------*/
void vq_preselect (
  Float  targetv[],                   /* (i): Target subvector                */
  const  Float (*pCodebook)[VECLEN],  /* (i): Codebook table                  */
  const  Float *pCodebook_pow,        /* (i): Codebook table                  */
  Float  canMeas[N_CAN],              /* (o): Candidate measuremant parameter */
  Float  canSign[N_CAN],              /* (o): Candidate sign                  */
  Short  canIndx[N_CAN]               /* (o): Candidate indices               */
) {
  int    i_cb, i_can, ismp, t_ind;
  Short  cbTop;
  Float  sc;
  Float  measMax;
  Float  sctmp;
  Float  meas;

  sc = 0;
  t_ind = 0;
  cbTop = 0;

  for (i_can = 0; i_can < N_CAN; i_can++)
  {
    measMax = - (Float) MAX_32;
    for (i_cb = 0; i_cb < BLOCKSIZE; i_cb++)
    {
      /* Sc = sum (targetv[] * codebook[]) */
      sctmp = 0;
      for (ismp = 0; ismp < VECLEN; ismp++)
      {
        sctmp += targetv[ismp] * pCodebook[i_cb][ismp];
      }

      /* meas = 4.0 * abs(Sc) - cc; */
      meas = 4.0f * abs_f(sctmp) - pCodebook_pow[i_cb];

      if (meas > measMax) {
        measMax = meas;
        t_ind = i_cb;
        sc = sctmp;
      }
    }

    canSign[i_can] = 1.0f;

    if (sc < 0.0f) {
      canSign[i_can] = -1.0f;
    }

    canIndx[i_can] = (Short) t_ind + cbTop;

    canMeas[i_can] = measMax;

    cbTop += BLOCKSIZE;
    pCodebook += BLOCKSIZE;
    pCodebook_pow += BLOCKSIZE;
  }
}
