/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: mux_bits.c
 *  Function: MUX and deMUX for Layer 2 (Higher-band)
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    MUX (bit-packing) of Layer 2 indices
  Return value:
    0
  ----------------------------------------------------------------*/
int mux_bitstream (
  INDEX * index,
  unsigned char *bitstream
) {
  int    i;
  Short  stmp1, stmp2;
  Short  *idx = index->wvq;

  for (i = 0; i < 3; i++) {
    stmp1 = (idx[0] & 0x003F) << 2;     /* 6 bits */
    stmp2 = (idx[6] & 0x0030) >> 4;     /* 2 bits */
    bitstream[0] = (unsigned char)(stmp1 | stmp2);

    stmp1 = (idx[6] & 0x000F) << 4;     /* 4 bits */
    stmp2 = (idx[1] & 0x003C) >> 2;     /* 4 bits */
    bitstream[1] = (unsigned char)(stmp1 | stmp2);

    stmp1 = (idx[1] & 0x0003) << 6;     /* 2 bits */
    stmp2 = (idx[7] & 0x003F);          /* 6 bits */
    bitstream[2] = (unsigned char)(stmp1 | stmp2);

    idx += 2;
    bitstream += 3;
  }
  bitstream[0] = (unsigned char)index->pow;  /* 8 bits */

  return 0;
}

/*----------------------------------------------------------------
  Function:
    deMUX (bit-unpacking) of Layer 2 indices
  Return value:
    0
  ----------------------------------------------------------------*/
int demux_bitstream (
  INDEX * index,
  unsigned char *bitstream
) {
  int    i;
  Short  stmp1, stmp2;
  Short  *idx = index->wvq;

  for (i = 0; i < 3; i++) {
    stmp1 = ((Short) bitstream[0] & 0x00FC) >> 2;       /* 6 bits */
    idx[0] = stmp1;

    stmp1 = ((Short) bitstream[0] & 0x0003) << 4;       /* 2 bits */
    stmp2 = ((Short) bitstream[1] & 0x00F0) >> 4;       /* 4 bits */
    idx[6] = stmp1 | stmp2;

    stmp1 = ((Short) bitstream[1] & 0x000F) << 2;       /* 4 bits */
    stmp2 = ((Short) bitstream[2] & 0x00C0) >> 6;       /* 2 bits */
    idx[1] = stmp1 | stmp2;

    stmp1 = bitstream[2] & 0x003F;      /* 6 bits */
    idx[7] = stmp1;

    idx += 2;
    bitstream += 3;
  }
  index->pow = bitstream[0];    /* 8 bits */

  return 0;
}
