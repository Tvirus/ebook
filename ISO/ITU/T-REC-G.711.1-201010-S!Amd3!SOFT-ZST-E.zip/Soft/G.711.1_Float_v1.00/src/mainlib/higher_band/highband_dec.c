/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: highband_dec.c
 *  Function: Layer 2 (Higher-band) decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"

#include "fec_highband.h"

#define DECODER_OK  2
#define DECODER_NG  3

/*----------------------------------------------------------------
  Function:
    Higher-band decoder constructor
  Return value
    Pointer to work space
  ----------------------------------------------------------------*/
void *highband_decode_const (void)
{
  VQD_State    *dec_st = NULL;

  dec_st = (VQD_State *) malloc(sizeof(VQD_State));
  if (dec_st == NULL)
    return NULL;

  highband_decode_reset((void *)dec_st);

  return (void *)dec_st;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void highband_decode_dest (
  void *work                    /* (i): Pointer to work space */
) {
  VQD_State  *dec_st = (VQD_State *) work;

  if (dec_st != NULL)
    free(dec_st);
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder reset
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int highband_decode_reset (
  void *work                    /* (i/o): Pointer to work space */
) {
  VQD_State  *dec_st = (VQD_State *) work;

  if (dec_st != NULL) {
    zeroF(L_FRAME_NB, dec_st->prev);
    zeroF(L_FRAME_NB, dec_st->curSave);
    dec_st->sSpectrumQ_pre = 0;
    dec_st->reset = 1;
    zeroF(HB_FEC_BUF_LEN, dec_st->hbfec_st.hb_buf);
    dec_st->hbfec_st.lb_t0 = 0;
    dec_st->hbfec_st.first_loss_frame = 1;
    dec_st->hbfec_st.hb_t0 = 0;
    dec_st->hbfec_st.att_weight = 1.0f;
    dec_st->hbfec_st.high_cor = 0;
    dec_st->hbfec_st.pre_bfi = 0;
  }
  return DECODER_OK;
}

/*----------------------------------------------------------------
  Function:
    Higher-band decoder
  Return value:
    DECODER_OK
  ----------------------------------------------------------------*/
int highband_decode (
  const unsigned char *bitstream,  /* (i): Input bitstream                */
  int    erasure,                  /* (i): FER flag, 0:No FER/1:FER       */
  Float  fBufout[],                /* (o): Output higher-band signal      */
  void   *work                     /* (i/o): Pointer to work space        */
) {
  VQD_State  *dec_st = (VQD_State *) work;
  INDEX  index;                  /* Gain and VQ indices              */
  Float  fOut[L_FRAME_NB];
  Float  fSpectrum[L_FRAME_NB];  /* MDCT coefficients, floating      */

  if (erasure == 0) {  /* No FER */
    /* deMUX of indices */
    demux_bitstream(&index, (unsigned char *)bitstream);

    /* De-quantize MDCT coefficients */
    VQdecode_spectrum(index.wvq,     /* (i) */
                      index.pow,     /* (i) */
                      &fSpectrum[4]  /* (o) */
      );

    /* Windowing */
    fSpectrum[0] = 0.0f;
    fSpectrum[1] = 0.0f;
    fSpectrum[2] = 0.0f;
    fSpectrum[3] = 0.0f;
    fSpectrum[4] *= (Float) 0.130526192220052e+00;  /* *= sin(   PI/24) */
    fSpectrum[5] *= (Float) 0.382683432365090e+00;  /* *= sin( 3*PI/24) */
    fSpectrum[6] *= (Float) 0.608761429008721e+00;  /* *= sin( 5*PI/24) */
    fSpectrum[7] *= (Float) 0.793353340291235e+00;  /* *= sin( 7*PI/24) */
    fSpectrum[8] *= (Float) 0.923879532511287e+00;  /* *= sin( 9*PI/24) */
    fSpectrum[9] *= (Float) 0.991444861373810e+00;  /* *= sin(11*PI/24) */
  }

  /* iMDCT */
  inv_mdct(fOut, fSpectrum, dec_st->prev, (Short) erasure, dec_st->curSave, &dec_st->hbfec_st);

  /* Mute at first frame after reset */
  if (dec_st->reset != 0) {
    zeroF(L_FRAME_NB, fOut);
    dec_st->reset = 0;
  }

  /* Update higher-band FERC buffer */
  if (erasure == 0) {
    update_hb_buf(dec_st->hbfec_st.hb_buf, fOut);
  }

  /* Copy decoded signal to output buffer */
  movF(L_FRAME_NB, fOut, fBufout);

  return DECODER_OK;
}
