/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: fec_highband.c
 *  Function: Higher-band frame erasure concealment (FERC)
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "fec_highband.h"

#include "fec_lowband.h"
#include "highband.h"

/*--------------------------------------------------------------------------*
 *  Function  update_hb_buf()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  update higher-band buffer for HB FERC                                   *
 *--------------------------------------------------------------------------*/
void update_hb_buf (
  Float *hb_buf,    /* (i/o): HB signal buffer */
  Float *output_hi  /* (i):   HB output signal */
) {
  int  i;

  /* shift HB buffer for FERC */
  for (i = 0; i < MAXPIT; i++) {
    hb_buf[i] = hb_buf[i + L_FRAME_NB];
  }

  for (i = 0; i < L_FRAME_NB; i++) {
    hb_buf[i + MAXPIT] = output_hi[i];
  }
}

/*--------------------------------------------------------------------------*
 *  Function  copy_lb_pitch()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  copy lower-band pitch for HB FERC                                       *
 *--------------------------------------------------------------------------*/
void copy_lb_pitch (
  void *SubDecoderL,            /* (i): Work space for lower-band decoder  */
  void *SubDecoderH             /* (o): Work space for higher-band decoder */
) {
  VQD_State  *vqd = (VQD_State *)SubDecoderH;

  vqd->hbfec_st.lb_t0 = get_lb_pitch(SubDecoderL);
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  cor_hb_fec()                                                  *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  search best pitch, computer the correlation for HB FERC,                *
 *--------------------------------------------------------------------------*/
Float cor_hb_fec (       /* returns correlation     */
  Float * hb_buf,        /* (i): HB signal buffer   */
  Short * hb_pitch_best  /* (o): Pitch delay for HB */
) {
  Float  hb_cor = 0;
  Float  hb_scale1 = 0, hb_scale2 = 0;
  Float  hb_nor_cor = 0;
  Float  hb_nor_cor_max = 0;  /*float version of hb_nor_cor_max */
  Short  i;
  Short  hb_pitch_min = *hb_pitch_best - HB_PITCH_SEARCH_RANGE;
  Short  hb_pitch_max = *hb_pitch_best + HB_PITCH_SEARCH_RANGE;
  Short  hb_pitch;

  /* adjust the pitch search range according to the min and max pitch */
  if (hb_pitch_min < MINPIT) {
    hb_pitch_min = MINPIT;
  }
  if (hb_pitch_max > MAXPIT) {
    hb_pitch_max = MAXPIT;
  }

  /* calculate the self correlation of the frame */
  hb_scale1 = 1;
  for (i = 0; i < L_FRAME_NB; i++) {
    hb_scale1 += hb_buf[i + MAXPIT] * hb_buf[i + MAXPIT];
  }

  /* search the best pitch */
  for (hb_pitch = hb_pitch_min; hb_pitch <= hb_pitch_max; hb_pitch++) {
    hb_cor = 0;
    for (i = 0; i < L_FRAME_NB; i++) {
      hb_cor += hb_buf[i + MAXPIT] * hb_buf[i + MAXPIT - hb_pitch];
    }

    if (hb_cor > 0) {
      hb_scale2 = 1;
      for (i = 0; i < L_FRAME_NB; i++) {
        hb_scale2 +=
          hb_buf[i + MAXPIT - hb_pitch] * hb_buf[i + MAXPIT - hb_pitch];
      }
      hb_nor_cor = (Float)(hb_cor / Sqrt(hb_scale1) / Sqrt(hb_scale2));
      if (hb_nor_cor > hb_nor_cor_max) {
        *hb_pitch_best = hb_pitch;
        hb_nor_cor_max = hb_nor_cor;
      }
    }
  }

  hb_nor_cor_max = (hb_nor_cor_max < 0.0f) ? -hb_nor_cor_max : hb_nor_cor_max;

  return hb_nor_cor_max;
}
