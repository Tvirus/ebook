/* 
 * ITU-T G.711.1 Annex A - Floating-point implementation (ANSI-C Source Code)
 * Copyright (c) 2008
 * NTT, France Telecom, VoiceAge Corp., ETRI, Huawei Technologies
 *
 * Software Release: 1.00
 * Revision Date: 10 October 2008
 */
/*
 *------------------------------------------------------------------------
 *  File: mdct.h
 *  Function: MDCT headers
 *------------------------------------------------------------------------
 */

#ifndef MDCT_H
#define MDCT_H

#include "fec_highband.h"

/* Functions : */
void mdct(Float * mem, Float * input, Float * ykr);
void inv_mdct(Float * xr, Float * ykq, Float * ycim1, Short loss_flag, Float *, HBFEC_State *);

/* Tables : */
extern const Float MDCT_h[MDCT_L_WIN];
extern const Float MDCT_wcos[MDCT_L_WIN4];
extern const Float MDCT_wsin[MDCT_L_WIN4];
extern const Float MDCT_wetr[MDCT_L_WIN4];
extern const Float MDCT_weti[MDCT_L_WIN4];
extern const Float MDCT_wetrm1[MDCT_L_WIN4];
extern const Float MDCT_wetim1[MDCT_L_WIN4];

#endif /* MDCT_H */
