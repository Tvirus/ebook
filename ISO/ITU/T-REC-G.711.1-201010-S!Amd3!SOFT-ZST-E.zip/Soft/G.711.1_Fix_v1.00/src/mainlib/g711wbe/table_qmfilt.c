/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: table_qmfilt.c
 *  Function: Tables for Quadrature mirror filter (QMF)
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "qmfilt.h"

/* QMF filter coefficients (polyphase representation) */
const Word16 sQmf0[NTAP_QMF/2] = {    /* Q15 */
     21,   -41,    47,    -6,  -135,   474, -1286,  4210,
  15285, -3270,  1734, -1021,   586,  -307,   136,   -44
};

/* QMF filter coefficients (polyphase representation) */
const Word16 sQmf1[NTAP_QMF/2] = {    /* Q15 */
    -44,   136,  -307,   586, -1021,  1734, -3270, 15285,
   4210, -1286,   474,  -135,    -6,    47,   -41,    21
};
