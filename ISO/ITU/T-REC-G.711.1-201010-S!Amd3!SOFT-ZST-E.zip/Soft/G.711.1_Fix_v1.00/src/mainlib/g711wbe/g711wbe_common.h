/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: g711wbe_common.h
 *  Function: Common definitions for all module files
 *------------------------------------------------------------------------
 */

#ifndef COMMON_DEFS_H
#define COMMON_DEFS_H

#include "stl.h"
#include "errexit.h"
#include "dsputil.h"
#include "g711wbe.h"

#define L_FRAME_NB  NSamplesPerFrame8k   /* Number of samples in  8 kHz */
#define L_FRAME_WB  NSamplesPerFrame16k  /* Number of samples in 16 kHz */

#endif
