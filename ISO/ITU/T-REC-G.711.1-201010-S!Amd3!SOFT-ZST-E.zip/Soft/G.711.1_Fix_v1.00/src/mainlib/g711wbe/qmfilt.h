/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: qmfilt.h
 *  Function: Header of quadrature mirror filter (QMF)
 *------------------------------------------------------------------------
 */

#ifndef QMFILT_H
#define QMFILT_H

#define NTAP_QMF  32

void* QMFilt_const(void);
void  QMFilt_dest(void *ptr);
void  QMFilt_reset(void *ptr);
void  QMFilt_ana( Word16 *insig, Word16 *lsig, Word16 *hsig, void *prt );
void  QMFilt_syn( Word16 *lsig, Word16 *hsig, Word16 *outsig, void *ptr);

/* Tables */
extern const Word16 sQmf0[NTAP_QMF/2]; /* Q15 */
extern const Word16 sQmf1[NTAP_QMF/2]; /* Q15 */

#endif
