/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: post_gainfct.h
 *  Header: Header of post-processing filter estimation
 *------------------------------------------------------------------------
 */

#ifndef POST_GAINFCT_H
#define POST_GAINFCT_H

extern const Word16 WinFilt[L_FLT_DIV2+1];
 
void postProc_GainProcess(Word16 *X, Word16 X_shift, VAR_GAIN *var_gain,
                          VAR_ANASYNTH *var_anasynth);

void postProc_InitGainProcess(VAR_GAIN *var_gain);

#endif /* POST_GAINFCT_H */
