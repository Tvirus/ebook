/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: lowband_dec.c
 *  Function: Lower-band decoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "g711.h"
#include "fec_lowband.h"
#include "lowband.h"
#include "lpctool.h"

typedef struct {
  Word16 law;                    /* G.711 law */
  void*  pFECWork;               /* Lower band FEC work area */
  Word16 sigdec_past[L_WINDOW];  /* buffer for past G.711 decoded signal */
  Word16 mem_A[ORD_M+1];         /* A(z) of previous frame */
  Word16 mem_rc[ORD_M];          /* Reflection coefficients of previous frame */
  Word16 mem_wfilter[ORD_M];     /* buffer for the weighting filter */
  Word16 loss_cnt;               /* indicator of past lost frames (up to 2) */
  Word32 energy;                 /* Signal energy of previous frame */
} lowband_decode_work;

static void lowband_lbe_demux(const unsigned char* code1, Word16* expi, Word16* excode, Word16* bit_alloc);

/* -------------------------------------------------------------------
  Function:
    Lower-band decoder constructor
  Return value:
    Pointer of work space
   -------------------------------------------------------------------*/
void    *lowband_decode_const(
  int    law                /* (i): G.711 decoding law [G711ALAW/G711ULAW] */
#ifdef APPENDIX_I_POSTFILTER
 ,Word16 postfilter_option  /* (i): R1 postfilter option SW */
#endif
) {
  lowband_decode_work *work=NULL;

  if ( law == G711ULAW || law == G711ALAW ) {
    work = (lowband_decode_work *)malloc( sizeof(lowband_decode_work) );
    if ( work != NULL )
    {
      work->law = law;

      /* FEC routines for 5ms frame */
#ifdef APPENDIX_I_POSTFILTER
      work->pFECWork = FEC_lowerband_const( postfilter_option );
#else
      work->pFECWork = FEC_lowerband_const();
#endif
      if ( work->pFECWork == NULL ) {
        lowband_decode_dest((void *)work);
        return NULL;
      }

      lowband_decode_reset( (void *)work );
    }
  }
  return (void *)work;
}

/* -------------------------------------------------------------------
  Function:
    Lower-band decoder destructor
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_decode_dest(
  void *ptr   /* (i): Pointer to work space */
) {
  lowband_decode_work *work = (lowband_decode_work *)ptr;
  if (work != NULL)
  {
    FEC_lowerband_dest(work->pFECWork);
    free( work );
  }
}

/* -------------------------------------------------------------------
  Function:
    Lower-band decoder reset
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_decode_reset(
  void *ptr   /* (i/o): Pointer to work space */
) {
  lowband_decode_work *work = (lowband_decode_work *)ptr;

  if (work != NULL) {
    work->mem_A[0] = 4096;  move16();
    zero16(ORD_M, &work->mem_A[1]);
    zero16(ORD_M, work->mem_rc);
    zero16(ORD_M, work->mem_wfilter);
    zero16(L_WINDOW, work->sigdec_past);
    work->loss_cnt = 0;  move16();
    work->energy = 0;    move16(); /* could be set to some high value */
    FEC_lowerband_reset(work->pFECWork);
  }
}


/* -------------------------------------------------------------------
  Function:
    Lower band decoder
  Return value:
    None
   -------------------------------------------------------------------*/
void    lowband_decode(
  const unsigned char code0[],   /* (i): Layer 0 bitstream (multiplexed)    */
  const unsigned char code1[],   /* (i): Layer 1 bitstream (multiplexed)    */
  int                 loss_flag, /* (i): Frame erasure status flag          */
  Word16              sigout[],  /* (o): Output 5-ms signal                 */
  Word16              *gain,     /* (o): Target gain for noise gate         */
  void                *ptr       /* (i/o): Pointer to work space            */
) {
  Word16  i, j;
  Word16  tmp;
  Word16  offset;
  Word16  sigtmp;
  Word16  sAlpha;
  Word16  norm;
  Word16  stable;
  Word16  sigdec[L_FRAME_NB];
  Word16  exp[L_FRAME_NB];
  Word16  sign[L_FRAME_NB];
  Word16  bit_alloc[L_FRAME_NB];
  Word16  excode_buf[ORD_M+L_FRAME_NB], *excode;
  Word16  rh[ORD_M+1];             /* Autocorrelations of windowed speech  */
  Word16  rl[ORD_M+1];
  Word32  lval;
  Word32  tmp32;

  lowband_decode_work *work = (lowband_decode_work *)ptr;

  Word16  *rc=work->mem_rc;        /* Reflection coefficients              */
  Word16  *A =work->mem_A;         /* A0(z) with spectral expansion        */

  /* G.711 decoding function */
  short   (*convertLog_Lin)(short, short*, short*);
  short   (*convertLog_Lin_enh)(short, short, short, short);


  IF (work->loss_cnt == 0)
  {
    /* LP analysis and filter weighting */
    norm = AutocorrNS(work->sigdec_past, rh, rl);
    Levinson(rh, rl, rc, &stable, ORD_M, A);

    IF (sub(norm, MAX_NORM) >= 0) {
      FOR (i=1; i<=ORD_M; ++i) {
        A[i] = shr(A[i],add(i,sub(norm,MAX_NORM)));
        move16();
      }
    }
    ELSE {
      sAlpha = negate(rc[0]); ;       /* rc[0] == -r[1]/r[0]   */
      IF (sub (sAlpha, -32256) < 0)   /* r[1]/r[0] < -0.984375 */
      {
        sAlpha = add (sAlpha, 32767);
        sAlpha = add (sAlpha, 1536);
        sAlpha = shl (sAlpha, 4);     /* alpha=16*(r[1]/r[0]+1+0.75/16) */
        Weight_a(A, A, mult_r(GAMMA1, sAlpha), ORD_M);
      }
      ELSE {
        Weight_a(A, A, GAMMA1, ORD_M);
      }
    }
  }

  IF (loss_flag == 0)
  {
    excode = excode_buf+ORD_M;

    IF (sub(work->law, G711ALAW) == 0)
    {
      convertLog_Lin = convertALaw_Lin;            move16();
      convertLog_Lin_enh = convertALaw_Lin_enh;    move16();
      offset = ALAW_OFFSET;                  move16();
    }
    ELSE    /* work->law == G711ULAW */
    {
      convertLog_Lin = convertMuLaw_Lin;             move16();
      convertLog_Lin_enh = convertMuLaw_Lin_enh;    move16();
      offset = 0;                            move16();
    }

    /* Zero code detection */
    IF (code1 != NULL)    /* Layer 1 exists */
    {
      tmp = 0;  move16();
      FOR (i=0; i<L_FRAME_NB/4; i++)
      {
        tmp = add(tmp, (Word16)code1[i]);
      }
      if (tmp == 0)
      {
        code1 = NULL;  move16();
      }
    }

    FOR (i=0; i<L_FRAME_NB; i++)
    {
      /* Decoding of the shaped sample */
      sigtmp = (*convertLog_Lin) (code0[i], &exp[i], &sign[i]);
      sigdec[i] = sub(sigtmp, offset);
      move16();
    }

    /* Updating of the past synthesized buffer */
    mov16(L_FRAME_NB, work->sigdec_past + L_FRAME_NB, work->sigdec_past);
    mov16(L_FRAME_NB, sigdec, work->sigdec_past + L_FRAME_NB);

    IF (code1 != NULL)    /* Layer 1 exists */
    {
      lowband_lbe_demux(code1, exp, excode, bit_alloc);

      FOR (i = 0; i < L_FRAME_NB; i++)
      {
        excode[i] = (*convertLog_Lin_enh)(excode[i], exp[i], sign[i], bit_alloc[i]);
      }
      IF (work->loss_cnt == 0)
      {
        mov16(ORD_M, work->mem_wfilter, excode_buf);

        FOR (i=0; i<L_FRAME_NB; i++)
        {
          /* Noise shaping of the enhancement layer signal */
          lval = L_mult(A[0], excode[i]);
          FOR (j = 1; j <= ORD_M; j++) {
            lval = L_msu(lval, A[j], excode[i-j]);  /* lval -= A[j]*excode[i-j] */
          }
          excode[i] = round(L_shl(lval, 3));
          move16();

          /* Add the enhancement layer signal */
          sigdec[i] = add(sigdec[i], excode[i]);
          move16();
        }
      }

      /* Update the shaping filter memory */
      mov16(ORD_M, excode_buf+L_FRAME_NB, work->mem_wfilter);
    }
  }

  /* ---------------------------------------------------------- */
  /* Lower-band frame-erasure concealment (FERC)                */
  /* Sigout is 5-ms delayed from sigtmp.                        */
  /* ---------------------------------------------------------- */
  FEC_lowerband( loss_flag, sigdec, sigout, work->pFECWork );

  /* Updating of the lost frames counter */
  loss_flag = s_min((Word16)loss_flag, 1);      /* 1 or zero */
  tmp = add(work->loss_cnt, (Word16)loss_flag); /* Add 1 if Loss */
  tmp = s_min(tmp, 2);                          /* Do not Count above 2 */
  tmp = sub(tmp, 1);                            /* Decrement if no Loss */
  tmp = add(tmp, (Word16)loss_flag);            /* But Re-Increment Since there is Loss */
  work->loss_cnt = s_max(tmp, 0); move16();     /* Do not Decrement below 0 */

  /* ----------------------------- */
  /* Calculate Gain for Noise Gate */
  /* ----------------------------- */
  lval = 300; /* offset energy measure */
  move32();

  FOR (i=L_WINDOW/2; i<L_WINDOW; ++i) {
    tmp = sub(work->sigdec_past[i], mult_r(work->sigdec_past[i-1],24576));
    lval = L_mac(lval,tmp,tmp);
  }
  tmp32 = lval; move32();
  lval = L_add(work->energy,lval);
  work->energy = tmp32; move32();

  SqrtI31(lval,&lval);
  *gain = extract_h(L_shl(lval,9));
  *gain = s_max(*gain, 8192);

  return;
}

Word16 get_lb_pitch(void * lb_dec)
{
  lowband_decode_work * lb_dec_pt = (lowband_decode_work *) lb_dec;
  return get_lb_pit(lb_dec_pt->pFECWork);
}

/* Bitstream demultiplexing for Layer 1 */
static void lowband_lbe_demux(
  const unsigned char* code1,  /* (i): Layer 1 bitstream    */
  Word16* expi,                /* (o): exponent signal      */
  Word16* excode,              /* (o): enhancement signal   */
  Word16* bit_alloc            /* (o): bit allocation table */
)
{
  unsigned char* pcode1 = (unsigned char*)code1;
  Word16  bit_pos;
  Word16  i;
  Word16  tmp1;

  /* Bit allocation */
  lbe_bitalloc( expi, bit_alloc );

  /* Retrieve excode */
  bit_pos = 8;  move16();
  tmp1 = (Word16)(*pcode1); move16();
  FOR (i = 0; i < L_FRAME_NB; i++)
  {
    IF (sub(bit_pos, bit_alloc[i]) < 0)
    {
      pcode1++;
      tmp1 = shl(tmp1, 8);
      tmp1 = s_or(tmp1, (Word16)(*pcode1));
      bit_pos = add(bit_pos, 8);
    }

    bit_pos = sub(bit_pos, bit_alloc[i]);
    excode[i] = shr(tmp1, bit_pos);
    move16();
    tmp1 = sub(tmp1, shl(excode[i], bit_pos));
  }

  return;
}
