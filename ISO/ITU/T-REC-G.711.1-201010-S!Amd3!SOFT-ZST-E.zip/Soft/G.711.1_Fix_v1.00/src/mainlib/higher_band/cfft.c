/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: cfft.c
 *  Function: 20-point complex FFT
 *------------------------------------------------------------------------
 */
 
#include "g711wbe_common.h"
#include "defines_mdct.h"
#include "cfft.h"


/*--------------------------------------------------------------------------*
 *  Function  cfft()                                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Complex Good-Thomas fast Fourier transform                              *
 *--------------------------------------------------------------------------*/

void cfft(
  Word16 * x1,   /* (i/o) real part of data                 */
  Word16 * x2,   /* (i/o) imaginary part of data            */
  Word16   sign  /* (i) flag to select FFT (1) or IFFT (-1) */
)
{
  Word32    ACC0;                 /* first ACC */
  Word32    ACC1;                 /* second ACC */
  Word32    tmp32;                /* Tempory 32 bits variable */

  Word16    tab_x1[MDCT_NP * MDCT_NPP];
  Word16    tab_x2[MDCT_NP * MDCT_NPP];
  Word16    rx1[MDCT_NP];
  Word16    rx2[MDCT_NP];

  Word16   *ptr_x1;               /* Pointer on tab_x1 */
  Word16   *ptr_x2;               /* Pointer on tab_x2 */
  Word16   *ptr0_x1;              /* Pointer on tab_x1 for DFT step */
  Word16   *ptr0_x2;              /* Pointer on tab_x2 for DFT step */
  const Word16 *ptr_cos;          /* Pointer on cos table */
  const Word16 *ptr_sin;          /* Pointer on sin table */
  const Word16 *ptr_cos_Overflow; /* Pointer on cos table (case of Overflow) */
  const Word16 *ptr_sin_Overflow; /* Pointer on sin table (case of Overflow) */
  const Word16 *ptr_map;          /* Pointer on mapping indice (input and output) */

  Word16    ip, ipp, i, j;
  Word16    x1_tmp;
  Word16    x2_tmp;
  Word16    exp_n2;
  Word16    n1;
  Word16    n2;                 /* size of sub array */
  Word16    n3;
  Word16    p;                  /* size of the butterfly */
  Word16    inkw;
  Word16    w1;
  Word16    w2;
  Word16    rix;
  Word16    cix;
  Word16    rjx;
  Word16    cjx;

  /********************************************************************************
   * Re-indexing (mapping of input indices)                                       *
   ********************************************************************************/

  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_map;

  FOR (ip = 0; ip < MDCT_NP; ip++)
  {
    FOR (ipp = 0; ipp < MDCT_NPP; ipp++)
    {
      i = (Word16) * ptr_map++;  move16();
      *ptr_x1++ = x1[i];         move16();
      *ptr_x2++ = x2[i];         move16();
    }
  }

  /*******************************************************************************/

  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;

  FOR (ip = 0; ip < MDCT_NP; ip++)
  {
    FOR (j = 0; j < MDCT_NB_REV; j++)
    {
      i = MDCT_tab_rev_i[j];     move16();
      ipp = MDCT_tab_rev_ipp[j]; move16();
      x1_tmp = ptr_x1[ipp];      move16(); /* swap value ptr_x1[i] and ptr_x1[ipp] */
      x2_tmp = ptr_x2[ipp];      move16(); /* swap value ptr_x2[i] and ptr_x2[ipp] */
      ptr_x1[ipp] = ptr_x1[i];   move16();
      ptr_x2[ipp] = ptr_x2[i];   move16();
      ptr_x1[i] = x1_tmp;        move16();
      ptr_x2[i] = x2_tmp;        move16();
    }
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }

  /*******************************************************************************
   * n1 size of butterfly                                                        *
   *******************************************************************************/

  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;

  FOR (ip = 0; ip < MDCT_NP; ip++)
  {
    FOR (exp_n2 = 0; exp_n2 <= MDCT_EXP_NPP; exp_n2++)
    {
      n2 = shl(1, exp_n2);
      n1 = shr(n2, 1);
      n3 = sub(MDCT_EXP_NPP, exp_n2);

      FOR (p = 0; p < n1; p++)
      {
        /* get twiddle factor in arrays rw1 and rw2 */

        tmp32 = L_shl(L_mult(p, MDCT_NP), sub(n3, 1));
        inkw = extract_l(tmp32);
        w1 = MDCT_rw1[inkw]; move16();
        w2 = MDCT_rw2[inkw]; move16();

        if (sign > 0)
        {
          w2 = negate(w2);
        }

        IF (sign > 0)            /* FFT */
        {
          FOR (i = p; i < MDCT_NPP; i = add(i, n2))
          {
            /* select item p in array p */
            j = add(i, n1);

            /* butterfly on x[i] and x[j] */
            rix = ptr_x1[i]; move16();
            cix = ptr_x2[i]; move16();

            /* twiddle factor */
            ACC0 = L_mult(w1, ptr_x1[j]);
            ACC0 = L_msu(ACC0, w2, ptr_x2[j]);
            rjx = round(ACC0);

            ACC0 = L_mult(w2, ptr_x1[j]);
            ACC0 = L_mac(ACC0, w1, ptr_x2[j]);
            cjx = round(ACC0);

            ptr_x1[i] = add(rix, rjx); move16();
            ptr_x2[i] = add(cix, cjx); move16();
            ptr_x1[j] = sub(rix, rjx); move16();
            ptr_x2[j] = sub(cix, cjx); move16();
          }
        }
        ELSE                    /* IFFT */
        {
          FOR (i = p; i < MDCT_NPP; i = add(i, n2))
          {
            /* select item p in array p */
            j = add(i, n1);

            /* butterfly on x[i] and x[j] */
            rix = shr(ptr_x1[i], 1); move16();
            cix = shr(ptr_x2[i], 1); move16();

            /* twiddle factor */

            ACC0 = L_mult(w1, ptr_x1[j]);
            ACC0 = L_msu(ACC0, w2, ptr_x2[j]);
            ACC0 = L_shr(ACC0, 1);
            rjx = round(ACC0);

            ACC0 = L_mult(w2, ptr_x1[j]);
            ACC0 = L_mac(ACC0, w1, ptr_x2[j]);
            ACC0 = L_shr(ACC0, 1);
            cjx = round(ACC0);

            ptr_x1[i] = add(rix, rjx); move16();
            ptr_x2[i] = add(cix, cjx); move16();
            ptr_x1[j] = sub(rix, rjx); move16();
            ptr_x2[j] = sub(cix, cjx); move16();
          }
        }
      }
    }                           /* end while */
    ptr_x1 += MDCT_NPP;
    ptr_x2 += MDCT_NPP;
  }                             /* end for ip */

  /**************************************************************************/

  ptr0_x1 = tab_x1;
  ptr0_x2 = tab_x2;

  FOR (ipp = 0; ipp < MDCT_NPP; ipp++)
  {
    ptr_x1 = ptr0_x1;
    ptr_x2 = ptr0_x2;

    FOR (ip = 0; ip < MDCT_NP; ip++)
    {
      rx1[ip] = *ptr_x1; move16();
      rx2[ip] = *ptr_x2; move16();

      ptr_x1 += MDCT_NPP;
      ptr_x2 += MDCT_NPP;
    }

    ptr_x1 = ptr0_x1++;
    ptr_x2 = ptr0_x2++;

    ptr_cos = MDCT_xcos;
    ptr_sin = MDCT_xsin;

    IF (sign > 0)                /* FFT */
    {
      FOR (ip = 0; ip < MDCT_NP; ip++)
      {

        /* Set Overflow to 0 to test it after radix 5 with Q15 sin & cos coef */
        /* keep pointer's position on cos & sin tables */

        Overflow = 0; move16();
        ptr_cos_Overflow = ptr_cos;
        ptr_sin_Overflow = ptr_sin;

        ACC0 = (Word32) 0; move32();
        ACC1 = (Word32) 0; move32();

        FOR (i = 0; i < MDCT_NP; i++)
        {
          ACC0 = L_mac(ACC0, rx1[i], (*ptr_cos));
          ACC0 = L_msu(ACC0, rx2[i], (*ptr_sin));

          ACC1 = L_mac(ACC1, rx2[i], (*ptr_cos++));
          ACC1 = L_mac(ACC1, rx1[i], (*ptr_sin++));
        }

        ACC0 = L_shr(ACC0, 1);
        ACC1 = L_shr(ACC1, 1);

        /* Overflow in Radix 5 --> use cos and sin coef in Q14 */
        IF (sub((Word16) Overflow, 1) == 0)
        {
          ptr_cos = ptr_cos_Overflow;
          ptr_sin = ptr_sin_Overflow;

          ACC0 = (Word32) 0; move32();
          ACC1 = (Word32) 0; move32();

          FOR (i = 0; i < MDCT_NP; i++)
          {
            ACC0 = L_mac(ACC0, rx1[i], shr((*ptr_cos), 1));
            ACC0 = L_msu(ACC0, rx2[i], shr((*ptr_sin), 1));

            ACC1 = L_mac(ACC1, rx2[i], shr((*ptr_cos++), 1));
            ACC1 = L_mac(ACC1, rx1[i], shr((*ptr_sin++), 1));
          }
        }


        *ptr_x1 = round(ACC0);
        *ptr_x2 = round(ACC1);

        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }
    }

    ELSE                        /* IFFT */
    {
      FOR (ip = 0; ip < MDCT_NP; ip++)
      {

        /* Set Overflow to 0 to test it after radix 5 with Q15 sin & cos coef */
        /* keep pointer's position on cos & sin tables */

        Overflow = (Word16) 0; move16();
        ptr_cos_Overflow = ptr_cos;
        ptr_sin_Overflow = ptr_sin;

        ACC0 = (Word32) 0; move32();
        ACC1 = (Word32) 0; move32();

        FOR (i = 0; i < MDCT_NP; i++)
        {
          ACC0 = L_mac(ACC0, rx1[i], (*ptr_cos));
          ACC0 = L_mac(ACC0, rx2[i], (*ptr_sin));

          ACC1 = L_mac(ACC1, rx2[i], (*ptr_cos++));
          ACC1 = L_msu(ACC1, rx1[i], (*ptr_sin++));
        }

        ACC0 = L_shr(ACC0, 1);
        ACC1 = L_shr(ACC1, 1);

        /* 0verflow in Radix 5 --> use cos and sin coef in Q14 */
        IF (sub((Word16) Overflow, 1) == 0)
        {
          ptr_cos = ptr_cos_Overflow;
          ptr_sin = ptr_sin_Overflow;

          ACC0 = (Word32) 0; move32();
          ACC1 = (Word32) 0; move32();

          FOR (i = 0; i < MDCT_NP; i++)
          {
            ACC0 = L_mac(ACC0, rx1[i], shr((*ptr_cos), 1));
            ACC0 = L_mac(ACC0, rx2[i], shr((*ptr_sin), 1));

            ACC1 = L_mac(ACC1, rx2[i], shr((*ptr_cos++), 1));
            ACC1 = L_msu(ACC1, rx1[i], shr((*ptr_sin++), 1));
          }
        }

        *ptr_x1 = round(ACC0);
        *ptr_x2 = round(ACC1);

        ptr_x1 += MDCT_NPP;
        ptr_x2 += MDCT_NPP;
      }                         /* end for ip */
    }
  }                             /* end for ipp */


  /***************************************************************************
   * mapping for the output indices                                          *
   ***************************************************************************/

  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = MDCT_tab_map2;

  FOR (ip = 0; ip < MDCT_NP; ip++)
  {
    FOR (ipp = 0; ipp < MDCT_NPP; ipp++)
    {
      i = (Word16) * ptr_map++; move16();
      x1[i] = *ptr_x1++;        move16();
      x2[i] = *ptr_x2++;        move16();
    }
  }

  return;
}
