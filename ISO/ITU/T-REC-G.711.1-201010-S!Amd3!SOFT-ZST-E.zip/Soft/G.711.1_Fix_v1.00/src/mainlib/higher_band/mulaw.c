/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Mu-law compression of gain, 8bit, u=255
  Return value
    Quantized value in log scale
  ----------------------------------------------------------------*/
Word16 mulaw(Word16 linbuf) /* in: Q0, out: Q0 */
{
  Word16  absno;
  Word16  exponent;
  Word16  mantissa;
  Word16  logbuf;

  IF ( sub(linbuf,4) < 0 )
  {
    logbuf = s_and (linbuf, 0x3);
  }
  ELSE
  {
    absno = add(linbuf, 130);

    exponent = sub(7, norm_s(absno));

    mantissa = shr(sub(shr(absno, exponent), 128), 2);
    logbuf = add(shl(exponent, 5), mantissa);

    logbuf = add( logbuf, 3 );

    if ( sub(logbuf,255) > 0 ) {
      logbuf = 255; move16();
    }
  }

  return logbuf;  /* Q0 */
}
