/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "g711wbe_common.h"
#include "highband.h"

/*----------------------------------------------------------------
  Function:
    Main-selection of Interleave CSVQ
  Return value:
    None
  ----------------------------------------------------------------*/
void vq_mainselect(
  Word16  sCanIndx0[],        /* (i): Candidate indices for channel 0      */
  Word16  sCanIndx1[],        /* (i): Candidate indices for channel 1      */
  Word16  index_wvq[],        /* (o): Selected VQ indices                  */
  Word32  lCanMeas0[N_CAN],   /* (i): Candidate measuremant parameter, Q22 */
  Word32  lCanMeas1[N_CAN],   /* (i): Candidate measuremant parameter, Q22 */
  Word16  sCanSign0[N_CAN],   /* (i): Candidate sign, Q14                  */
  Word16  sCanSign1[N_CAN],   /* (i): Candidate sign, Q14                  */
  Word16  sLocalv[]           /* (o): Locally decodec subvector, Q12       */
)
{
  int     i_can;
  int     i_can0;
  int     i_can1;
  int     j_can;
  int     i_smp;
  Word16  signtmp;
  Word16  pol0, pol1;
  Word16  index0, index1;
  Word32  lMeas0;
  Word32  lDist;
  Word32  lDistMin;
  Word32  lAcc;

  const Word16 *pcross;
  const Word16 *psCodev0, *psCodev1;

  lDistMin = MAX_32;  move32();

  i_can0 = 0; move16();
  i_can1 = 0; move16();

  FOR (i_can = 0; i_can < N_CAN; i_can++)
  {
    lMeas0 = lCanMeas0[i_can]; move32(); /* Q22 */

    pcross = gsCodebook_cross[sCanIndx0[i_can]];
    a_mac(); move16(); /* for addressing */

    FOR (j_can = 0; j_can < N_CAN; j_can++)
    {
      /* cross *= sign0[i_can] * sign1[j_can] */
      /* dist = cross - meas[i_can] - meas[j_can]; */

      signtmp = mult (sCanSign0[i_can], sCanSign1[j_can]);  /*Q13=Q(14+14+1-16)*/
      lDist = L_mult0( pcross[sCanIndx1[j_can]], signtmp ); /*Q22=Q(9+13)*/
      add(0,0); /* for addressing */

      lDist = L_sub( lDist, lMeas0 );           /* Q22 */
      lDist = L_sub( lDist, lCanMeas1[j_can] ); /* Q22 */

      IF ( L_sub( lDist, lDistMin ) < 0 )
      {
        i_can0 = i_can;   move16();
        i_can1 = j_can;   move16();
        lDistMin = lDist; move32();
      }
    }
  }

  /* Local re-constructing */

  index0 = sCanIndx0[i_can0];                move16();
                                             add(0,0); /* addressing */
  index_wvq[0] = add( index0, CB_SIZE );     move16();
  index1 = sCanIndx1[i_can1];                move16();
                                             add(0,0); /* addressing */
  index_wvq[N_DIV] = add( index1, CB_SIZE ); move16();

  pol0 = sCanSign0[i_can0]; move16(); /* Q14: 1 or -1 -> Q15: 0.5 or -0.5 */
                            add(0,0); /* addressing */
  pol1 = sCanSign1[i_can1]; move16(); /* Q14: 1 or -1 -> Q15: 0.5 or -0.5 */
                            add(0,0); /* addressing */

  if ( pol0 > 0 ) {
    index_wvq[0] = index0;     move16();
  }
  if ( pol1 > 0 ) {
    index_wvq[N_DIV] = index1; move16();
  }

  psCodev0 = gsCodebook_0ch[index0]; a_mac(); move16(); /* for addressing */
  psCodev1 = gsCodebook_1ch[index1]; a_mac(); move16(); /* for addressing */

  FOR (i_smp = 0; i_smp < VECLEN; i_smp++)
  {
    lAcc= L_mult( pol0, psCodev0[i_smp] );  /* Q28 = Q(15+12+1) */
    sLocalv[i_smp] = extract_h( L_mac( lAcc, pol1, psCodev1[i_smp]) );
                                            /* Q12 = Q(15+12+1-16) */
    move16();
  }
}
