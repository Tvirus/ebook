/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/
/*
 *------------------------------------------------------------------------
 *  File: highband_dec.h
 *  Function: Layer 2 (Higher-band) encoder
 *------------------------------------------------------------------------
 */

#include "g711wbe_common.h"
#include "highband.h"

#include "defines_mdct.h"
#include "mdct.h"
#include "cfft.h"

#define ENCODER_OK  0
#define ENCODER_NG  1

/*----------------------------------------------------------------
  Function:
    Higher-band encoder constructor
  Return value:
    Pointer to work space
  ----------------------------------------------------------------*/
void* highband_encode_const(void)
{
  VQE_State  *enc_st=NULL;

  enc_st = (VQE_State *)malloc( sizeof(VQE_State) );
  if (enc_st == NULL) return NULL;

  highband_encode_reset( (void *)enc_st );

  return (void *)enc_st;
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder destructor
  Return value:
    None
  ----------------------------------------------------------------*/
void  highband_encode_dest(
  void *work        /* (i): Pointer to work space  */
) {
  VQE_State  *enc_st=(VQE_State *)work;

  if (enc_st != NULL) free( enc_st );
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder reset
  Return value:
    ENCODER_OK
  ----------------------------------------------------------------*/
int   highband_encode_reset(
  void *work        /* (i/o): Pointer to work space  */
) {
  VQE_State  *enc_st=(VQE_State *)work;
  int  i;

  if (enc_st != NULL) {
    FOR ( i=0; i<L_FRAME_NB; i++ )
    {
      enc_st->sIn[i] = 0; move16();
    }
  }
  return ENCODER_OK;
}

/*----------------------------------------------------------------
  Function:
    Higher-band encoder
  Return value:
    ENCODER_OK
  ----------------------------------------------------------------*/
int   highband_encode(
  const Word16  sBufin[],    /* (i): Input higher-band signal */
  unsigned char *bitstream,  /* (o): Output bitstream         */
  void          *work        /* (i/o): Pointer to work space  */
) {
  VQE_State *enc_st=(VQE_State *)work;
  Word16  i;
  Word16  sAcc;
  Word16  norm;
  INDEX   index;                 /* Gain and VQ indices             */
  Word16  sGain;                 /* Normalizing RMS, Q(sExpGain)    */
  Word16  sExpGain;              /* Q of sGain                      */
  Word16  sSpectrum[L_FRAME_NB]; /* MDCT coefficients, Q(sExpSpect) */
  Word16  sExpSpect;             /* Q of sSpectrum[]                */
  Word16  sNormSpec[N_FR_FREQ];  /* Normalized coefficients, Q12    */

  /* MDCT */
  mdct(enc_st->sIn, (Word16*)sBufin, sSpectrum, &sExpSpect);

  /* Frequency weighting */
  norm = Exp16Array(18, &sSpectrum[10]);
  IF (norm == 0)
  {
    FOR ( i=39; i>=28; i-- )
    {
      sSpectrum[i] = shr (sSpectrum[i], 1);
      move16();
    }
    FOR ( i=27; i>=22; i-- )
    {
      sSpectrum[i] = mult_r (sSpectrum[i], 21845);
      move16();
    }
    FOR ( i=21; i>=16; i-- )
    {
      sSpectrum[i] = mult_r (sSpectrum[i], 27307);
      move16();
    }
    FOR ( i=9; i>=4; i-- )
    {
      sSpectrum[i] = shr (sSpectrum[i], 1);
      move16();
    }
    sExpSpect = sub (sExpSpect, 1);
  }
  ELSE
  {
    FOR ( i=27; i>=22; i-- )
    {
      sAcc = round (L_shl (L_mult (sSpectrum[i], 21845), 1));
      sSpectrum[i] = sAcc;  move16();
      move16();
    }
    FOR ( i=21; i>=16; i-- )
    {
      sAcc = round (L_shl (L_mult (sSpectrum[i], 27307), 1));
      sSpectrum[i] = sAcc;  move16();
    }
    FOR ( i=15; i>=10; i-- )
    {
      sSpectrum[i] = shl (sSpectrum[i], 1);
      move16();
    }
  }

  sSpectrum[9] = mult_r( sSpectrum[9], 32488 ); /* *= sin(11*PI/24) */
  sSpectrum[8] = mult_r( sSpectrum[8], 30274 ); /* *= sin( 9*PI/24) */
  sSpectrum[7] = mult_r( sSpectrum[7], 25997 ); /* *= sin( 7*PI/24) */
  sSpectrum[6] = mult_r( sSpectrum[6], 19948 ); /* *= sin( 5*PI/24) */
  sSpectrum[5] = mult_r( sSpectrum[5], 12540 ); /* *= sin( 3*PI/24) */
  sSpectrum[4] = mult_r( sSpectrum[4],  4277 ); /* *= sin(   PI/24) */
/*  sSpectrum[3] = 0; */
/*  sSpectrum[2] = 0; */
/*  sSpectrum[1] = 0; */
/*  sSpectrum[0] = 0; */
  move16(); move16(); move16(); move16(); move16(); move16();

  /* Normalize MDCT coefficients with RMS */
  norm_spectrum(
      &sSpectrum[4],     /* (i) Q(sExpSpect) */
      sExpSpect,         /* (i) */
      sNormSpec,         /* (o) Q12 */
      &sGain, &sExpGain  /* (o) Q(sExpGain) */
  );

  /* Quantize normalized MDCT coefficients */
  VQencode_spectrum(
      sNormSpec,         /* (i) Q12 */
      index.wvq,         /* (o) */
      sGain, sExpGain,   /* (i) Q(sExpGain) */
      &index.pow         /* (o) */
  );

  /* MUX of indices */
  mux_bitstream(&index, bitstream);

  /* Save current input signal */
  mov16( L_FRAME_NB, (Word16 *)sBufin, enc_st->sIn );

  return ENCODER_OK;
}
