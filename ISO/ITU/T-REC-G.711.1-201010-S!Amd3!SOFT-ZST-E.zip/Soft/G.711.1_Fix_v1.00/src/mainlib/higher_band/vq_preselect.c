/* 
   ITU-T G.711-WB Optimization/Characterization Candidate   ANSI-C Source Code
   Copyright (c) 2007-2008
   NTT, France Telecom, VoiceAge Corp., ETRI, Huawei

   Version: 1.00
   Revision Date: Feb. 14, 2008
*/

#include "g711wbe_common.h"
#include "highband.h"

#define BLOCKSIZE  (CB_SIZE/N_CAN)    /* = 4 */

/*----------------------------------------------------------------
  Function:
    Pre-selection of Interleave CSVQ
  Return value:
    None
  ----------------------------------------------------------------*/
void vq_preselect(
  Word16  sTargetv[],        /* (i): Target subvector, Q12                */
  const Word16 (*psCodebook)[VECLEN], /* (i): Codebook table, Q12         */
  const Word32 *plCodebook_pow,       /* (i): Codebook table, Q22         */
  Word32  lCanMeas[N_CAN],   /* (o): Candidate measuremant parameter, Q22 */
  Word16  sCanSign[N_CAN],   /* (o): Candidate sign, Q14                  */
  Word16  sCanIndx[N_CAN]    /* (o): Candidate indices                    */
)
{
  int     i_cb, i_can, ismp, t_ind;
  Word16  cbTop;
  Word16  sSc;
  Word32  lMeasMax;
  Word32  lSc;
  Word32  lTmp;
  Word32  lMeas;

  sSc   = 0;  move16();
  t_ind = 0;  move16();
  cbTop = 0;  move16();

  FOR (i_can = 0; i_can < N_CAN; i_can++)
  {
    lMeasMax = MIN_32; move32();

    FOR (i_cb = 0; i_cb < BLOCKSIZE; i_cb++)
    {
      /* Sc = sum (targetv[] * codebook[]) */
      lSc = 0; move32();
      FOR (ismp = 0; ismp < VECLEN; ismp++)
      {
        lSc = L_mac0( lSc, sTargetv[ismp], psCodebook[i_cb][ismp] );
        /* Q24 = Q12 * Q12 */
      }

      /* meas = 4.0 * abs(Sc) - cc; */
      lTmp  = L_abs( lSc );
      lMeas = L_sub( lTmp, plCodebook_pow[i_cb] ); /* Q22=Q24*4.0-Q22 */

      IF ( L_sub( lMeas, lMeasMax ) > 0 )
      {
        lMeasMax = lMeas;    move32();
        t_ind = i_cb;        move16();
        sSc = extract_h( lSc );
      }
    }

    sCanSign[i_can] = 16384; move16(); /* Q14: 1 */

    if( s_and(sSc, 0x8000) != 0 ) /* sSc < 0 */
    {
      sCanSign[i_can] = -16384; move16(); /* Q14: -1 */
    }

    sCanIndx[i_can] = add( (Word16)t_ind, cbTop ); move16();

    lCanMeas[i_can] = lMeasMax; move32(); /* Q22 */

    cbTop = add( cbTop, BLOCKSIZE );
    psCodebook += BLOCKSIZE;
    plCodebook_pow += BLOCKSIZE;
  }
}
