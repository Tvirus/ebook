TEST_DIR=src/test_codec
TEST_VEC=test_vector
OUT_DIR=out
DIFF=cmp
TRUNCATE=./tools/truncate_g711ev
EID=./tools/eid-xor
FILTER=./tools/filter

if [ $1 = 'test' ]; then
PROC=1
COMP=1
fi
if [ $1 = 'proc' ]; then
PROC=1
COMP=0
fi
if [ $1 = 'comp' ]; then
PROC=0
COMP=1
fi


if [ $PROC = '1' ]; then

if [ ! -d $OUT_DIR ]; then
mkdir $OUT_DIR
fi

#
# Wideband Input (default)
#
$TEST_DIR/encoder A $TEST_VEC/Signal.inp tmp.bit

$TRUNCATE -fl 5 -mode 1 tmp.bit $OUT_DIR/Signal_R1_A.bit
$TRUNCATE -fl 5 -mode 2 tmp.bit $OUT_DIR/Signal_R2a_A.bit
$TRUNCATE -fl 5 -mode 3 tmp.bit $OUT_DIR/Signal_R2b_A.bit
$TRUNCATE -fl 5 -mode 4 tmp.bit $OUT_DIR/Signal_R3_A.bit

$EID -fer $OUT_DIR/Signal_R1_A.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R1_FER3_A.bit
$EID -fer $OUT_DIR/Signal_R2a_A.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R2a_FER3_A.bit
$EID -fer $OUT_DIR/Signal_R2b_A.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R2b_FER3_A.bit
$EID -fer $OUT_DIR/Signal_R3_A.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R3_FER3_A.bit

$TEST_DIR/decoder A -mode 1 $OUT_DIR/Signal_R1_A.bit  $OUT_DIR/Signal_R1_A.out
$TEST_DIR/decoder A -mode 2 $OUT_DIR/Signal_R2a_A.bit $OUT_DIR/Signal_R2a_A.out
$TEST_DIR/decoder A -mode 3 $OUT_DIR/Signal_R2b_A.bit $OUT_DIR/Signal_R2b_A.out
$TEST_DIR/decoder A -mode 4 $OUT_DIR/Signal_R3_A.bit  $OUT_DIR/Signal_R3_A.out

$TEST_DIR/decoder A -mode 1 $OUT_DIR/Signal_R1_FER3_A.bit  $OUT_DIR/Signal_R1_FER3_A.out
$TEST_DIR/decoder A -mode 2 $OUT_DIR/Signal_R2a_FER3_A.bit $OUT_DIR/Signal_R2a_FER3_A.out
$TEST_DIR/decoder A -mode 3 $OUT_DIR/Signal_R2b_FER3_A.bit $OUT_DIR/Signal_R2b_FER3_A.out
$TEST_DIR/decoder A -mode 4 $OUT_DIR/Signal_R3_FER3_A.bit  $OUT_DIR/Signal_R3_FER3_A.out

$TEST_DIR/decoder -r1pf A -mode 1 $OUT_DIR/Signal_R1_A.bit $OUT_DIR/Signal_R1_POST_A.out
$TEST_DIR/decoder -r1pf A -mode 1 $OUT_DIR/Signal_R1_FER3_A.bit $OUT_DIR/Signal_R1_POST_FER3_A.out

$TEST_DIR/encoder u $TEST_VEC/Signal.inp tmp.bit

$TRUNCATE -fl 5 -mode 1 tmp.bit $OUT_DIR/Signal_R1_u.bit
$TRUNCATE -fl 5 -mode 2 tmp.bit $OUT_DIR/Signal_R2a_u.bit
$TRUNCATE -fl 5 -mode 3 tmp.bit $OUT_DIR/Signal_R2b_u.bit
$TRUNCATE -fl 5 -mode 4 tmp.bit $OUT_DIR/Signal_R3_u.bit

$EID -fer $OUT_DIR/Signal_R1_u.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R1_FER3_u.bit
$EID -fer $OUT_DIR/Signal_R2a_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R2a_FER3_u.bit
$EID -fer $OUT_DIR/Signal_R2b_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R2b_FER3_u.bit
$EID -fer $OUT_DIR/Signal_R3_u.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_R3_FER3_u.bit

$TEST_DIR/decoder u -mode 1 $OUT_DIR/Signal_R1_u.bit  $OUT_DIR/Signal_R1_u.out
$TEST_DIR/decoder u -mode 2 $OUT_DIR/Signal_R2a_u.bit $OUT_DIR/Signal_R2a_u.out
$TEST_DIR/decoder u -mode 3 $OUT_DIR/Signal_R2b_u.bit $OUT_DIR/Signal_R2b_u.out
$TEST_DIR/decoder u -mode 4 $OUT_DIR/Signal_R3_u.bit  $OUT_DIR/Signal_R3_u.out

$TEST_DIR/decoder u -mode 1 $OUT_DIR/Signal_R1_FER3_u.bit  $OUT_DIR/Signal_R1_FER3_u.out
$TEST_DIR/decoder u -mode 2 $OUT_DIR/Signal_R2a_FER3_u.bit $OUT_DIR/Signal_R2a_FER3_u.out
$TEST_DIR/decoder u -mode 3 $OUT_DIR/Signal_R2b_FER3_u.bit $OUT_DIR/Signal_R2b_FER3_u.out
$TEST_DIR/decoder u -mode 4 $OUT_DIR/Signal_R3_FER3_u.bit  $OUT_DIR/Signal_R3_FER3_u.out

$TEST_DIR/decoder -r1pf u -mode 1 $OUT_DIR/Signal_R1_u.bit $OUT_DIR/Signal_R1_POST_u.out
$TEST_DIR/decoder -r1pf u -mode 1 $OUT_DIR/Signal_R1_FER3_u.bit $OUT_DIR/Signal_R1_POST_FER3_u.out

#
# Narrowband Input (option)
#
$FILTER -q FLAT1 $TEST_VEC/Signal.inp tmp.flt 80
$FILTER -q -down HQ2 tmp.flt tmp.8k 80

$TEST_DIR/encoder -nb A tmp.8k tmp.bit

$TRUNCATE -fl 5 -mode 1 tmp.bit $OUT_DIR/Signal_NB_R1_A.bit
$TRUNCATE -fl 5 -mode 2 tmp.bit $OUT_DIR/Signal_NB_R2a_A.bit
$TRUNCATE -fl 5 -mode 3 tmp.bit $OUT_DIR/Signal_NB_R2b_A.bit
$TRUNCATE -fl 5 -mode 4 tmp.bit $OUT_DIR/Signal_NB_R3_A.bit

$EID -fer $OUT_DIR/Signal_NB_R1_A.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R1_FER3_A.bit
$EID -fer $OUT_DIR/Signal_NB_R2a_A.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R2a_FER3_A.bit
$EID -fer $OUT_DIR/Signal_NB_R2b_A.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R2b_FER3_A.bit
$EID -fer $OUT_DIR/Signal_NB_R3_A.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R3_FER3_A.bit

$TEST_DIR/decoder A -mode 1 $OUT_DIR/Signal_NB_R1_A.bit  $OUT_DIR/Signal_NB_R1_A.out
$TEST_DIR/decoder A -mode 2 $OUT_DIR/Signal_NB_R2a_A.bit $OUT_DIR/Signal_NB_R2a_A.out
$TEST_DIR/decoder A -mode 3 $OUT_DIR/Signal_NB_R2b_A.bit $OUT_DIR/Signal_NB_R2b_A.out
$TEST_DIR/decoder A -mode 4 $OUT_DIR/Signal_NB_R3_A.bit  $OUT_DIR/Signal_NB_R3_A.out

$TEST_DIR/decoder A -mode 1 $OUT_DIR/Signal_NB_R1_FER3_A.bit  $OUT_DIR/Signal_NB_R1_FER3_A.out
$TEST_DIR/decoder A -mode 2 $OUT_DIR/Signal_NB_R2a_FER3_A.bit $OUT_DIR/Signal_NB_R2a_FER3_A.out
$TEST_DIR/decoder A -mode 3 $OUT_DIR/Signal_NB_R2b_FER3_A.bit $OUT_DIR/Signal_NB_R2b_FER3_A.out
$TEST_DIR/decoder A -mode 4 $OUT_DIR/Signal_NB_R3_FER3_A.bit  $OUT_DIR/Signal_NB_R3_FER3_A.out

$TEST_DIR/decoder -r1pf A -mode 1 $OUT_DIR/Signal_NB_R1_A.bit $OUT_DIR/Signal_NB_R1_POST_A.out
$TEST_DIR/decoder -r1pf A -mode 1 $OUT_DIR/Signal_NB_R1_FER3_A.bit $OUT_DIR/Signal_NB_R1_POST_FER3_A.out

$TEST_DIR/encoder -nb u tmp.8k tmp.bit

$TRUNCATE -fl 5 -mode 1 tmp.bit $OUT_DIR/Signal_NB_R1_u.bit
$TRUNCATE -fl 5 -mode 2 tmp.bit $OUT_DIR/Signal_NB_R2a_u.bit
$TRUNCATE -fl 5 -mode 3 tmp.bit $OUT_DIR/Signal_NB_R2b_u.bit
$TRUNCATE -fl 5 -mode 4 tmp.bit $OUT_DIR/Signal_NB_R3_u.bit

$EID -fer $OUT_DIR/Signal_NB_R1_u.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R1_FER3_u.bit
$EID -fer $OUT_DIR/Signal_NB_R2a_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R2a_FER3_u.bit
$EID -fer $OUT_DIR/Signal_NB_R2b_u.bit $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R2b_FER3_u.bit
$EID -fer $OUT_DIR/Signal_NB_R3_u.bit  $TEST_VEC/FER_pattern.g192 $OUT_DIR/Signal_NB_R3_FER3_u.bit

$TEST_DIR/decoder u -mode 1 $OUT_DIR/Signal_NB_R1_u.bit  $OUT_DIR/Signal_NB_R1_u.out
$TEST_DIR/decoder u -mode 2 $OUT_DIR/Signal_NB_R2a_u.bit $OUT_DIR/Signal_NB_R2a_u.out
$TEST_DIR/decoder u -mode 3 $OUT_DIR/Signal_NB_R2b_u.bit $OUT_DIR/Signal_NB_R2b_u.out
$TEST_DIR/decoder u -mode 4 $OUT_DIR/Signal_NB_R3_u.bit  $OUT_DIR/Signal_NB_R3_u.out

$TEST_DIR/decoder u -mode 1 $OUT_DIR/Signal_NB_R1_FER3_u.bit  $OUT_DIR/Signal_NB_R1_FER3_u.out
$TEST_DIR/decoder u -mode 2 $OUT_DIR/Signal_NB_R2a_FER3_u.bit $OUT_DIR/Signal_NB_R2a_FER3_u.out
$TEST_DIR/decoder u -mode 3 $OUT_DIR/Signal_NB_R2b_FER3_u.bit $OUT_DIR/Signal_NB_R2b_FER3_u.out
$TEST_DIR/decoder u -mode 4 $OUT_DIR/Signal_NB_R3_FER3_u.bit  $OUT_DIR/Signal_NB_R3_FER3_u.out

$TEST_DIR/decoder -r1pf u -mode 1 $OUT_DIR/Signal_NB_R1_u.bit $OUT_DIR/Signal_NB_R1_POST_u.out
$TEST_DIR/decoder -r1pf u -mode 1 $OUT_DIR/Signal_NB_R1_FER3_u.bit $OUT_DIR/Signal_NB_R1_POST_FER3_u.out

/bin/rm -f tmp.bit tmp.flt tmp.8k

fi

if [ $COMP = '1' ]; then

#
# Wideband Input (default)
#
$DIFF $TEST_VEC/Signal_R1_A.bit  $OUT_DIR/Signal_R1_A.bit
$DIFF $TEST_VEC/Signal_R2a_A.bit $OUT_DIR/Signal_R2a_A.bit
$DIFF $TEST_VEC/Signal_R2b_A.bit $OUT_DIR/Signal_R2b_A.bit
$DIFF $TEST_VEC/Signal_R3_A.bit  $OUT_DIR/Signal_R3_A.bit
$DIFF $TEST_VEC/Signal_R1_FER3_A.bit  $OUT_DIR/Signal_R1_FER3_A.bit
$DIFF $TEST_VEC/Signal_R2a_FER3_A.bit $OUT_DIR/Signal_R2a_FER3_A.bit
$DIFF $TEST_VEC/Signal_R2b_FER3_A.bit $OUT_DIR/Signal_R2b_FER3_A.bit
$DIFF $TEST_VEC/Signal_R3_FER3_A.bit  $OUT_DIR/Signal_R3_FER3_A.bit
	
$DIFF $TEST_VEC/Signal_R1_A.out  $OUT_DIR/Signal_R1_A.out
$DIFF $TEST_VEC/Signal_R2a_A.out $OUT_DIR/Signal_R2a_A.out
$DIFF $TEST_VEC/Signal_R2b_A.out $OUT_DIR/Signal_R2b_A.out
$DIFF $TEST_VEC/Signal_R3_A.out  $OUT_DIR/Signal_R3_A.out
$DIFF $TEST_VEC/Signal_R1_FER3_A.out  $OUT_DIR/Signal_R1_FER3_A.out
$DIFF $TEST_VEC/Signal_R2a_FER3_A.out $OUT_DIR/Signal_R2a_FER3_A.out
$DIFF $TEST_VEC/Signal_R2b_FER3_A.out $OUT_DIR/Signal_R2b_FER3_A.out
$DIFF $TEST_VEC/Signal_R3_FER3_A.out  $OUT_DIR/Signal_R3_FER3_A.out

$DIFF $TEST_VEC/Signal_R1_POST_A.out  $OUT_DIR/Signal_R1_POST_A.out
$DIFF $TEST_VEC/Signal_R1_POST_FER3_A.out  $OUT_DIR/Signal_R1_POST_FER3_A.out

$DIFF $TEST_VEC/Signal_R1_u.bit  $OUT_DIR/Signal_R1_u.bit
$DIFF $TEST_VEC/Signal_R2a_u.bit $OUT_DIR/Signal_R2a_u.bit
$DIFF $TEST_VEC/Signal_R2b_u.bit $OUT_DIR/Signal_R2b_u.bit
$DIFF $TEST_VEC/Signal_R3_u.bit  $OUT_DIR/Signal_R3_u.bit
$DIFF $TEST_VEC/Signal_R1_FER3_u.bit  $OUT_DIR/Signal_R1_FER3_u.bit
$DIFF $TEST_VEC/Signal_R2a_FER3_u.bit $OUT_DIR/Signal_R2a_FER3_u.bit
$DIFF $TEST_VEC/Signal_R2b_FER3_u.bit $OUT_DIR/Signal_R2b_FER3_u.bit
$DIFF $TEST_VEC/Signal_R3_FER3_u.bit  $OUT_DIR/Signal_R3_FER3_u.bit
	
$DIFF $TEST_VEC/Signal_R1_u.out  $OUT_DIR/Signal_R1_u.out
$DIFF $TEST_VEC/Signal_R2a_u.out $OUT_DIR/Signal_R2a_u.out
$DIFF $TEST_VEC/Signal_R2b_u.out $OUT_DIR/Signal_R2b_u.out
$DIFF $TEST_VEC/Signal_R3_u.out  $OUT_DIR/Signal_R3_u.out
$DIFF $TEST_VEC/Signal_R1_FER3_u.out  $OUT_DIR/Signal_R1_FER3_u.out
$DIFF $TEST_VEC/Signal_R2a_FER3_u.out $OUT_DIR/Signal_R2a_FER3_u.out
$DIFF $TEST_VEC/Signal_R2b_FER3_u.out $OUT_DIR/Signal_R2b_FER3_u.out
$DIFF $TEST_VEC/Signal_R3_FER3_u.out  $OUT_DIR/Signal_R3_FER3_u.out

$DIFF $TEST_VEC/Signal_R1_POST_u.out  $OUT_DIR/Signal_R1_POST_u.out
$DIFF $TEST_VEC/Signal_R1_POST_FER3_u.out  $OUT_DIR/Signal_R1_POST_FER3_u.out

#
# Narrowband Input (option)
#
$DIFF $TEST_VEC/Signal_NB_R1_A.bit  $OUT_DIR/Signal_NB_R1_A.bit
$DIFF $TEST_VEC/Signal_NB_R2a_A.bit $OUT_DIR/Signal_NB_R2a_A.bit
$DIFF $TEST_VEC/Signal_NB_R2b_A.bit $OUT_DIR/Signal_NB_R2b_A.bit
$DIFF $TEST_VEC/Signal_NB_R3_A.bit  $OUT_DIR/Signal_NB_R3_A.bit
$DIFF $TEST_VEC/Signal_NB_R1_FER3_A.bit  $OUT_DIR/Signal_NB_R1_FER3_A.bit
$DIFF $TEST_VEC/Signal_NB_R2a_FER3_A.bit $OUT_DIR/Signal_NB_R2a_FER3_A.bit
$DIFF $TEST_VEC/Signal_NB_R2b_FER3_A.bit $OUT_DIR/Signal_NB_R2b_FER3_A.bit
$DIFF $TEST_VEC/Signal_NB_R3_FER3_A.bit  $OUT_DIR/Signal_NB_R3_FER3_A.bit

$DIFF $TEST_VEC/Signal_NB_R1_A.out  $OUT_DIR/Signal_NB_R1_A.out
$DIFF $TEST_VEC/Signal_NB_R2a_A.out $OUT_DIR/Signal_NB_R2a_A.out
$DIFF $TEST_VEC/Signal_NB_R2b_A.out $OUT_DIR/Signal_NB_R2b_A.out
$DIFF $TEST_VEC/Signal_NB_R3_A.out  $OUT_DIR/Signal_NB_R3_A.out
$DIFF $TEST_VEC/Signal_NB_R1_FER3_A.out  $OUT_DIR/Signal_NB_R1_FER3_A.out
$DIFF $TEST_VEC/Signal_NB_R2a_FER3_A.out $OUT_DIR/Signal_NB_R2a_FER3_A.out
$DIFF $TEST_VEC/Signal_NB_R2b_FER3_A.out $OUT_DIR/Signal_NB_R2b_FER3_A.out
$DIFF $TEST_VEC/Signal_NB_R3_FER3_A.out  $OUT_DIR/Signal_NB_R3_FER3_A.out

$DIFF $TEST_VEC/Signal_NB_R1_POST_A.out  $OUT_DIR/Signal_NB_R1_POST_A.out
$DIFF $TEST_VEC/Signal_NB_R1_POST_FER3_A.out  $OUT_DIR/Signal_NB_R1_POST_FER3_A.out

$DIFF $TEST_VEC/Signal_NB_R1_u.bit  $OUT_DIR/Signal_NB_R1_u.bit
$DIFF $TEST_VEC/Signal_NB_R2a_u.bit $OUT_DIR/Signal_NB_R2a_u.bit
$DIFF $TEST_VEC/Signal_NB_R2b_u.bit $OUT_DIR/Signal_NB_R2b_u.bit
$DIFF $TEST_VEC/Signal_NB_R3_u.bit  $OUT_DIR/Signal_NB_R3_u.bit
$DIFF $TEST_VEC/Signal_NB_R1_FER3_u.bit  $OUT_DIR/Signal_NB_R1_FER3_u.bit
$DIFF $TEST_VEC/Signal_NB_R2a_FER3_u.bit $OUT_DIR/Signal_NB_R2a_FER3_u.bit
$DIFF $TEST_VEC/Signal_NB_R2b_FER3_u.bit $OUT_DIR/Signal_NB_R2b_FER3_u.bit
$DIFF $TEST_VEC/Signal_NB_R3_FER3_u.bit  $OUT_DIR/Signal_NB_R3_FER3_u.bit

$DIFF $TEST_VEC/Signal_NB_R1_u.out  $OUT_DIR/Signal_NB_R1_u.out
$DIFF $TEST_VEC/Signal_NB_R2a_u.out $OUT_DIR/Signal_NB_R2a_u.out
$DIFF $TEST_VEC/Signal_NB_R2b_u.out $OUT_DIR/Signal_NB_R2b_u.out
$DIFF $TEST_VEC/Signal_NB_R3_u.out  $OUT_DIR/Signal_NB_R3_u.out
$DIFF $TEST_VEC/Signal_NB_R1_FER3_u.out  $OUT_DIR/Signal_NB_R1_FER3_u.out
$DIFF $TEST_VEC/Signal_NB_R2a_FER3_u.out $OUT_DIR/Signal_NB_R2a_FER3_u.out
$DIFF $TEST_VEC/Signal_NB_R2b_FER3_u.out $OUT_DIR/Signal_NB_R2b_FER3_u.out
$DIFF $TEST_VEC/Signal_NB_R3_FER3_u.out  $OUT_DIR/Signal_NB_R3_FER3_u.out

$DIFF $TEST_VEC/Signal_NB_R1_POST_u.out  $OUT_DIR/Signal_NB_R1_POST_u.out
$DIFF $TEST_VEC/Signal_NB_R1_POST_FER3_u.out  $OUT_DIR/Signal_NB_R1_POST_FER3_u.out
fi
